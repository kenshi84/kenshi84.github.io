#pragma once
#include <vector>
#include <fstream>
#include <KLIB/OGL.h>
#include <KLIB/Polyline.h>
#include <KLIB/RBF.h>

struct CutParam {
    enum Mode {
        FREEFORM,       // user's sketch
        SLICEX,         // slice perpendicular to x axis
        SLICEY,         // slice perpendicular to y axis
        SLICEZ,         // slice perpendicular to x axis
        WEDGE,          // wedge around y axis
    } mode_;
    // freeform cut ============
    std::vector<KLIB::Vector2d> freeform_stroke2d_;
    std::vector<KLIB::Vector3d> freeform_stroke3d_;
    KLIB::ThinPlate2d           freeform_rbf2d_;
    // slice cut (x or y) ============
    double slice_top_;         // slice_bottom < slice_top
    double slice_bottom_;
    // wedge cut ============
    double wedge_begin_;        // -PI < wedge_begin < wedge_end < PI
    double wedge_end_;
    static const int NUM_WEDGE_VERTICES__;
    
    CutParam();
    // following functions assume that the current GL view is set to freeform_view
    void processStroke();
    double getCutValue(const KLIB::Vector3d& pos) const;
    KLIB::Vector2d project  (const KLIB::Vector3d& point3d) const;   // mapping from 3D point into 2D point on cutting surface
    KLIB::Vector3d unproject(const KLIB::Vector2d& point2d) const;   // mapping from 2D point on cutting surface into 3D point
    void save(std::ofstream& ofs) const;
    void load(std::ifstream& ifs);
};
