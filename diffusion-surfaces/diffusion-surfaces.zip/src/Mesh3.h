#pragma once
#include <KLIB/Vector.h>
#include <OpenMesh/Core/Mesh/Traits.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>

// Mesh3: remaining surface mesh after cutting Mesh0
struct Mesh3Traits : public OpenMesh::DefaultTraits {
    typedef KLIB::Vector3d Point;
    typedef KLIB::Vector3d Normal;
    VertexTraits {
    public:
        KLIB::Vector3d color_;
        KLIB::Vector3d back_color_;
        // for computing silhouettes
        double normal_eye_product_;
        VertexT() : normal_eye_product_(0) {}
    };
    EdgeTraits {
    public:
        // for computing silhouettes
        KLIB::Vector3d silhouettePos_;
        bool isSilhouetteCrossed_;
        EdgeT() : isSilhouetteCrossed_(false) {}
    };
    FaceTraits {
        bool isHidden() const { return false; }
    };
};
//typedef OpenMesh::TriMesh_ArrayKernelT<Mesh3Traits> Mesh3;
struct Mesh3 : public OpenMesh::TriMesh_ArrayKernelT<Mesh3Traits> {};
