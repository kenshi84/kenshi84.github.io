#pragma once
#include "TetMesh0.h"
#include "TetMesh1.h"

template <class TDiffuseAlgorithm>
struct VolumeObjectT;

struct CutParam;

struct DiffusePoisson {
    typedef VolumeObjectT<DiffusePoisson> VolumeObject;
    
    struct ObjectData {
        TetMesh0 tetMesh0_;             // intermediate tet-mesh (before vertex duplication)
        TetMesh1 tetMesh1_;             // tet-mesh (after vertex duplication) for Poisson solve
        void gl_init() {}
        void gl_deinit() {}
        void preprocess(VolumeObject& volObj);
    private:
        void preprocess_step1_buildTetMesh(VolumeObject& volObj);
        void preprocess_step2_solvePoisson(VolumeObject& volObj);
    };
    
    void gl_init() {}
    void gl_deinit() {}
    void cut_step2_mesh2(VolumeObject& volObj, CutParam& param);
};
