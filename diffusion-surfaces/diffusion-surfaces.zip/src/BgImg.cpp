#include "stdafx.h"
#include <stb_image.h>
#include <vector>
#include "BgImg.h"
#include "Core.h"
using namespace std;
using namespace KLIB;

namespace {
OGL& ogl = Core::getInstance().ogl_;
}

void BgImg::gl_init() {
    tex_.init();
}
void BgImg::gl_deinit() {
    tex_.deinit();
}
void BgImg::load(const string& fname) {
    int numChannel = 0;
    unsigned char *data = stbi_load(fname.c_str(), &width_, &height_, &numChannel, 0);
    if (data == 0) {
        cout << "Couldn't load image file: " << fname << endl;
        return;
    }
    cout << "Loaded image " << fname << ": width=" << width_ << ", height=" << height_ << ", numChannel=" << numChannel << endl;
    data_.clear();
    data_.resize(4 * width_ * height_, 255);
    for (int iy = 0; iy < height_; ++iy) for (int ix = 0; ix < width_; ++ix)    // flip vertically
    {
        for (int c = 0; c < (numChannel == 1 ? 3 : numChannel); ++c)
            data_[4 * (ix + width_ * (height_ - 1 - iy)) + c] = data[numChannel * (ix + width_ * iy) + (numChannel == 1 ? 0 : c)];
    }
    stbi_image_free(data);
    
    ogl.makeOpenGLCurrent();
    tex_.allocate(GL_RGBA, width_, height_, GL_RGBA, GL_UNSIGNED_BYTE, &data_[0]);
    
    double wh = 0.5 * (width_ + height_);
    double w = width_  / wh;
    double h = height_ / wh;
    cornerBL_.set(-w, -h);
    cornerBR_.set( w, -h);
    cornerTL_.set(-w,  h);
    cornerTR_.set( w,  h);
}
