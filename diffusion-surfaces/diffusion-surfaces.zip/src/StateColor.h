#pragma once
#include "state.h"
#include <GL/glew.h>
#include <KLIB/Vector.h>
#include <KLIB/GLUtil.h>

class StateColor : public State {
    StateColor(void) {}
    ~StateColor(void) {}
public:
    static StateColor* getInstance() {
        static StateColor p;
        return &p;
    }
    std::string message();
    void initialize();
    void finalize() {}
    bool isReady() { return true; }
    State* next();
    
    void draw();
    void OnLButtonDown(UINT nFlags, CPoint& point);
    void OnLButtonUp  (UINT nFlags, CPoint& point);
    void OnRButtonDown(UINT nFlags, CPoint& point);
    void OnRButtonUp  (UINT nFlags, CPoint& point);
    void OnMouseMove  (UINT nFlags, CPoint& point);
    void OnDropFiles(const std::string& fname, const std::string& ext);
    void OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags);
    
    enum Mode {
        MODE_PAINT,
        MODE_ERASE,
        MODE_PICKUP,
    } mode_;
    
    int currentObjectID_;
    KLIB::Vector3d currentColor_;
    KLIB::Vector2d cursorPosition_;
    
    bool isUpdated_;
    
    KLIB::TextureBuffer4uc img_;
};
