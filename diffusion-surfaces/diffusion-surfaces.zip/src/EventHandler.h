#pragma once

class EventHandler {
public:
    EventHandler(void)
        : isLButtonDown_(false)
        , isRButtonDown_(false)
        , isMButtonDown_(false)
    {}
    void OnLButtonDown(UINT nFlags, CPoint point);
    void OnLButtonUp  (UINT nFlags, CPoint point);
    void OnRButtonDown(UINT nFlags, CPoint point);
    void OnRButtonUp  (UINT nFlags, CPoint point);
    void OnMButtonDown(UINT nFlags, CPoint point);
    void OnMButtonUp  (UINT nFlags, CPoint point);
    void OnMouseMove  (UINT nFlags, CPoint point);
    void OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags);
    void OnDropFiles  (HDROP hDropInfo);
    void OnLButtonDblClk(UINT nFlags, CPoint point);
    bool isLButtonDown_;
    bool isRButtonDown_;
    bool isMButtonDown_;
    // default behaviors -----------------------------------------------------
    void default_OnRButtonDown_2D(UINT nFlags, CPoint point);
    void default_OnRButtonDown_3D(UINT nFlags, CPoint point);
    void default_OnRButtonUp  (UINT nFlags, CPoint point);
    void default_OnMButtonDown(UINT nFlags, CPoint point);
    void default_OnMButtonUp  (UINT nFlags, CPoint point);
    void default_OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags);
    void default_OnMouseMove  (UINT nFlags, CPoint point);
};
