#include "stdafx.h"
#include "DiffusionSurfaces.h"

#include "DiffusionSurfacesDoc.h"
#include "DiffusionSurfacesView.h"

#include "Core.h"
namespace {
Core& core = Core::getInstance();
}

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDiffusionSurfacesView

IMPLEMENT_DYNCREATE(CDiffusionSurfacesView, CView)

BEGIN_MESSAGE_MAP(CDiffusionSurfacesView, CView)
    ON_WM_CREATE()
    ON_WM_DESTROY()
    ON_WM_ERASEBKGND()
    ON_WM_SIZE()
    ON_WM_LBUTTONDOWN()
    ON_WM_LBUTTONUP()
    ON_WM_RBUTTONDOWN()
    ON_WM_RBUTTONUP()
    ON_WM_MBUTTONDOWN()
    ON_WM_MBUTTONUP()
    ON_WM_MOUSEMOVE()
    ON_WM_MOUSEWHEEL()
    ON_WM_KEYDOWN()
    ON_WM_DROPFILES()
    ON_WM_LBUTTONDBLCLK()
END_MESSAGE_MAP()

CDiffusionSurfacesView::CDiffusionSurfacesView() {
    Core::getInstance().view_ = this;

}

CDiffusionSurfacesView::~CDiffusionSurfacesView()
{
}

BOOL CDiffusionSurfacesView::PreCreateWindow(CREATESTRUCT& cs)
{
    cs.dwExStyle |= WS_EX_ACCEPTFILES;

	return CView::PreCreateWindow(cs);
}

void CDiffusionSurfacesView::OnDraw(CDC* pDC)
{
	CDiffusionSurfacesDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

    core.ogl_.OnDraw_Begin();
    core.drawer_.draw();
    core.ogl_.OnDraw_End();
    core.drawer_.postDraw(pDC);
}


#ifdef _DEBUG
void CDiffusionSurfacesView::AssertValid() const
{
	CView::AssertValid();
}

void CDiffusionSurfacesView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CDiffusionSurfacesDoc* CDiffusionSurfacesView::GetDocument() const
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDiffusionSurfacesDoc)));
	return (CDiffusionSurfacesDoc*)m_pDocument;
}
#endif //_DEBUG


int CDiffusionSurfacesView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
    if (CView::OnCreate(lpCreateStruct) == -1)
        return -1;

    core.ogl_.OnCreate(this);
    core.gl_init();
    core.drawer_.init();

    return 0;
}

void CDiffusionSurfacesView::OnDestroy()
{
    CView::OnDestroy();

    core.gl_deinit();
    core.ogl_.OnDestroy();
}

BOOL CDiffusionSurfacesView::OnEraseBkgnd(CDC* pDC)
{
    return TRUE;//CView::OnEraseBkgnd(pDC);
}

void CDiffusionSurfacesView::OnSize(UINT nType, int cx, int cy)
{
    CView::OnSize(nType, cx, cy);

    core.ogl_.OnSize(cx, cy);
    core.volObj_.silRenderer_.gl_resize(cx, cy);
    core.salad_ .silRenderer_.gl_resize(cx, cy);
}

void CDiffusionSurfacesView::OnLButtonDown(UINT nFlags, CPoint point)
{
    core.eventHandler_.OnLButtonDown(nFlags, point);

    CView::OnLButtonDown(nFlags, point);
}

void CDiffusionSurfacesView::OnLButtonUp(UINT nFlags, CPoint point)
{
    core.eventHandler_.OnLButtonUp(nFlags, point);

    CView::OnLButtonUp(nFlags, point);
}

void CDiffusionSurfacesView::OnRButtonDown(UINT nFlags, CPoint point)
{
    core.eventHandler_.OnRButtonDown(nFlags, point);

    CView::OnRButtonDown(nFlags, point);
}

void CDiffusionSurfacesView::OnRButtonUp(UINT nFlags, CPoint point)
{
    core.eventHandler_.OnRButtonUp(nFlags, point);

    CView::OnRButtonUp(nFlags, point);
}

void CDiffusionSurfacesView::OnMButtonDown(UINT nFlags, CPoint point)
{
    core.eventHandler_.OnMButtonDown(nFlags, point);

    CView::OnMButtonDown(nFlags, point);
}

void CDiffusionSurfacesView::OnMButtonUp(UINT nFlags, CPoint point)
{
    core.eventHandler_.OnMButtonUp(nFlags, point);

    CView::OnMButtonUp(nFlags, point);
}

void CDiffusionSurfacesView::OnMouseMove(UINT nFlags, CPoint point)
{
    core.eventHandler_.OnMouseMove(nFlags, point);

    CView::OnMouseMove(nFlags, point);
}

BOOL CDiffusionSurfacesView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
    return CView::OnMouseWheel(nFlags, zDelta, pt);
}

void CDiffusionSurfacesView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
    core.eventHandler_.OnKeyDown(nChar, nRepCnt, nFlags);

    CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CDiffusionSurfacesView::OnDropFiles(HDROP hDropInfo)
{
    core.eventHandler_.OnDropFiles(hDropInfo);

    CView::OnDropFiles(hDropInfo);
}

void CDiffusionSurfacesView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
    core.eventHandler_.OnLButtonDblClk(nFlags, point);

    CView::OnLButtonDblClk(nFlags, point);
}
