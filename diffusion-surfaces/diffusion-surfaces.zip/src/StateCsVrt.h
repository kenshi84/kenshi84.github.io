#pragma once
#include "state.h"
#include <KLIB/Polyline.h>
#include <KLIB/CurveDeformation2D.h>
#include <vector>

class StateCsVrt : public State {
    StateCsVrt(void)
        : mode_(MODE_DRAW)
        , draggedCorner_(0)
        , currentSweepObjID_(-1)
    {}
    ~StateCsVrt(void) {}
public:
    static StateCsVrt* getInstance() {
        static StateCsVrt p;
        return &p;
    }
    std::string message();
    void initialize();
    State* next();
    bool isReady();
    
    void draw();
    void OnLButtonDown(UINT nFlags, CPoint& point);
    void OnLButtonUp  (UINT nFlags, CPoint& point);
    void OnRButtonDown(UINT nFlags, CPoint& point);
    void OnRButtonUp  (UINT nFlags, CPoint& point);
    void OnMouseMove  (UINT nFlags, CPoint& point);
    void OnDropFiles(const std::string& fname, const std::string& ext);
    void OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags);
    
    
    KLIB::Vector2d* draggedCorner_;
    KLIB::Vector2d dragPrev_;
    enum Mode {
        MODE_DRAW,
        MODE_DEFORM,
        MODE_SMOOTH,
        MODE_BGIMG,
        MODE_DRAW_GRAIN,
    } mode_;
    enum BgImgMode {
        BGIMGMODE_CORNER,
        BGIMGMODE_TRANSLATE,
        BGIMGMODE_ROTATE,
    } bgImgMode_;
    KLIB::Polyline2d tempStroke_;
    
    // rigid deformation with peeling interface
    KLIB::CurveDeformation2D rigid_;
    KLIB::Polyline2d*        rigid_target_;
    KLIB::Vector2d           rigid_dragstart_;
    int                      rigid_dragid_;
    int                      rigid_peelsize_;

    // drawing grains
    int currentSweepObjID_;

    void snapStrokeEndpoints();
};
