#include "stdafx.h"
#include "Core.h"
#include "Modeler.h"
#include "my_atan2.h"
#include <iterator>
using namespace std;
using namespace KLIB;

double Modeler::THRESHOLD_UI_DISTANCE   = 0.05;
double Modeler::THRESHOLD_UI_RIGID_PEEL = 0.05;
double Modeler::STROKE_SEGMENT_LENGTH   = 0.05;

namespace {
OGL& ogl = Core::getInstance().ogl_;
}

void Modeler::gl_init() {
    bgImgVrt_.gl_init();
    bgImgHrz_.gl_init();
}
void Modeler::gl_deinit() {
    bgImgVrt_.gl_deinit();
    bgImgHrz_.gl_deinit();
}
void Modeler::convert_strokeHrz_exemplar_xy_rt() {
    size_t numFold = foldAngles_exemplar_.size();
    if (type_ == TYPE_CYLIND) {
        assert(numFold == 0);
        for (size_t objID = 0; objID < sweepObjects_.size(); ++objID) {
            SweepObject& sweepObj = sweepObjects_[objID];
            assert(sweepObj.strokeHrz_exemplar_xy_.size() == 1);
            sweepObj.strokeHrz_exemplar_.resize(1);
            sweepObj.strokeHrz_exemplar_[0] = sweepObj.strokeHrz_exemplar_xy_[0];
            for (size_t i = 0; i < sweepObj.strokeHrz_exemplar_xy_[0].size(); ++i) {
                Vector2d& xy = sweepObj.strokeHrz_exemplar_xy_[0][i];
                sweepObj.strokeHrz_exemplar_[0][i].set(xy.length(), my_atan2(xy[1], xy[0]));
            }
        }
    } else {    // (type_ == TYPE_NFOLD)
        for (size_t objID = 0; objID < sweepObjects_.size(); ++objID) {
            SweepObject& sweepObj = sweepObjects_[objID];
            if (sweepObj.type_ == SweepObject::TYPE_NFOLD1) {
                assert(sweepObj.strokeHrz_exemplar_xy_.size() == 1);
                sweepObj.strokeHrz_exemplar_.resize(numFold);
        
                size_t numVtx = sweepObj.strokeHrz_exemplar_xy_[0].size();
                // convert to (unnormalized) polar coordinates
                Polyline2d sample_rt = sweepObj.strokeHrz_exemplar_xy_[0];
                for (size_t i = 0; i < numVtx; ++i) {
                    Vector2d& xy = sweepObj.strokeHrz_exemplar_xy_[0][i];
                    sample_rt[i].set(xy.length(), my_atan2(xy[1], xy[0]));
                }
                // divide the closed stroke into numFold open strokes (normalized polar coordinates)
                vector<vector<Vector2d> > sample_rt_divided(numFold);
                size_t index_begin;
                for (size_t i = 0; i < numVtx; ++i) {
                    Vector2d& rt0 = sample_rt[i];
                    Vector2d& rt1 = sample_rt[(i + 1) % numVtx];
                    double radius0 = rt0[0];
                    double radius1 = rt1[0];
                    double theta0  = rt0[1];
                    double theta1  = rt1[1];
                    if (theta1 + M_PI < theta0) {
                        double w0 = theta1;
                        double w1 = 2 * M_PI - theta0;
                        assert(w0 != 0 && w1 != 0); // assume for now
                        double radius = (w0 * radius0 + w1 * radius1) / (w0 + w1);
                        sample_rt_divided[0].push_back(Vector2d(radius, 0));
                        index_begin = (i + 1) % numVtx;
                        break;
                    }
                }
                double angle_begin = 0;
                double angle_end   = foldAngles_exemplar_[0];
                size_t foldId = 0;
                for (size_t index0 = index_begin; ;) {
                    size_t index1 = (index0 + 1) % numVtx;
                    double radius0 = sample_rt[index0][0];
                    double radius1 = sample_rt[index1][0];
                    double theta0  = sample_rt[index0][1];
                    double theta1  = sample_rt[index1][1];
                    if (index1 == index_begin)
                        theta1 += 2 * M_PI;
                    if (angle_end < theta1) {
                        assert(theta0 < angle_end);
                        double w0 = theta1 - angle_end;
                        double w1 = angle_end - theta0;
                        double radius = (w0 * radius0 + w1 * radius1) / (w0 + w1);
                        sample_rt_divided[foldId].push_back(Vector2d(radius, 1));
                        ++foldId;
                        if (foldId == numFold)
                            break;
                        sample_rt_divided[foldId].push_back(Vector2d(radius, 0));
                        angle_begin = angle_end;
                        angle_end = angle_begin + foldAngles_exemplar_[foldId];
                    } else {
                        assert(theta0 != angle_end);
                        sample_rt_divided[foldId].push_back(Vector2d(radius0, (theta0 - angle_begin) / (angle_end - angle_begin)));
                    }
                    index0 = (index0 + 1) % numVtx;
                    assert(index0 != index_begin);
                }
                // resample, store
                size_t numVtx2 = 0;
                for (size_t i = 0; i < numFold; ++i)
                    if (numVtx2 < sample_rt_divided[i].size())
                        numVtx2 = sample_rt_divided[i].size();
                for (size_t i = 0; i < numFold; ++i) {
                    vector<Vector2d> points_xy;
                    for (size_t j = 0; j < sample_rt_divided[i].size(); ++j) {
                        Vector2d& rt = sample_rt_divided[i][j];
                        double theta = rt[1] * 2 * M_PI / numFold;
                        Vector2d xy(rt[0] * cos(theta), rt[0] * sin(theta));
                        points_xy.push_back(xy);
                    }
                    Polyline2d stroke_xy(points_xy, false);
                    stroke_xy.resample(numVtx2);
                    sweepObj.strokeHrz_exemplar_[i].resize(numVtx2);
                    for (size_t j = 0; j < numVtx2; ++j) {
                        Vector2d& xy = stroke_xy[j];
                        double radius = xy.length();
                        double theta  = my_atan2(xy[1], xy[0]);
                        theta /= (2 * M_PI / numFold);
                        sweepObj.strokeHrz_exemplar_[i][j].set(radius, theta);
                    }
                }
            } else {    // (sweepObj.type_ == SweepObject::TYPE_NFOLD1)
                assert(sweepObj.strokeHrz_exemplar_xy_.size() == numFold);
                sweepObj.strokeHrz_exemplar_.resize(numFold);
        
                size_t numVtx = 0;
                // resampling
                for (size_t i = 0; i < numFold; ++i)
                    if (numVtx < sweepObj.strokeHrz_exemplar_xy_[i].size())
                        numVtx = sweepObj.strokeHrz_exemplar_xy_[i].size();
                for (size_t i = 0; i < numFold; ++i)
                    sweepObj.strokeHrz_exemplar_xy_[i].resample(numVtx);
                // normalization
                vector<Polyline2d> xy_samples_normalized = sweepObj.strokeHrz_exemplar_xy_;
                for (size_t i = 0; i < numFold; ++i) {
                    Vector2d& xy0 = sweepObj.strokeHrz_exemplar_xy_[i][0];
                    double theta0 = my_atan2(xy0[1], xy0[0]);
                    double angle_begin = 0;
                    double angle_end;
                    for (size_t j = 0; j < numFold; ++j) {
                        angle_end = angle_begin + foldAngles_exemplar_[j];
                        if (angle_begin <= theta0 && theta0 < angle_end)
                            break;
                        angle_begin += foldAngles_exemplar_[j];
                    }
                    for (size_t j = 0; j < sweepObj.strokeHrz_exemplar_xy_[i].size(); ++j) {
                        Vector2d& xy = sweepObj.strokeHrz_exemplar_xy_[i][j];
                        Vector2d rt(xy.length(), my_atan2(xy[1], xy[0]));
                        double& theta = rt[1];
                        assert(angle_begin <= theta && theta < angle_end);
                        // normalization
                        theta -= angle_begin;
                        theta *= (2 * M_PI / numFold) / (angle_end - angle_begin);
                        xy_samples_normalized[i][j].set(rt[0] * cos(theta), rt[0] * sin(theta));
                    }
                }
                // make correspondence among normalized vertices
                for (size_t i = 1; i < numFold; ++i) {
                    int    minOffset = -1;
                    double minError  = DBL_MAX;
                    for (size_t offset = 0; offset < numVtx; ++offset) {
                        double distTotal = 0;
                        for (size_t j = 0; j < numVtx; ++j) {
                            Vector2d& p0 = xy_samples_normalized[0][j];
                            int index = (offset + j) % numVtx;
                            Vector2d& p1 = xy_samples_normalized[i][index];
                            distTotal += (p1 - p0).length();
                        }
                        if (distTotal < minError) {
                            minOffset = offset;
                            minError  = distTotal;
                        }
                    }
                    Polyline2d sampleOld = xy_samples_normalized[i];
                    int index = minOffset;
                    for (size_t j = 0; j < numVtx; ++j) {
                        xy_samples_normalized[i][j] = sampleOld[index];
                        index = (index + 1) % numVtx;
                    }
                }
                // convert to polar coordinates
                for (size_t i = 0; i < numFold; ++i) {
                    vector<Vector2d> points_rt(numVtx);
                    for (size_t j = 0; j < numVtx; ++j) {
                        Vector2d& xy = xy_samples_normalized[i][j];
                        Vector2d& rt = points_rt[j];
                        rt.set(xy.length(), my_atan2(xy[1], xy[0]) / (2 * M_PI / numFold));
                    }
                    sweepObj.strokeHrz_exemplar_[i] = Polyline2d(points_rt, true);
                }
            }
        }
    }
}
void Modeler::analyze_cylind() {
    for (size_t i = 0; i < sweepObjects_.size(); ++i)
        sweepObjects_[i].analyze_strokeHrz_cylind();
}
void Modeler::analyze_nfold() {
    int P = 0;  // dimension size
    for (size_t i = 0; i < sweepObjects_.size(); ++i)
        P += sweepObjects_[i].strokeHrz_exemplar_[0].size();

    P *= 2;
    size_t numFold = foldAngles_exemplar_.size();
    vector<VectorVLd> samples(numFold);
    for (size_t i = 0; i < numFold; ++i) {
        VectorVLd sample(P);
        size_t p = 0;
        for (size_t j = 0; j < sweepObjects_.size(); ++j) {
            Polyline2d& stroke = sweepObjects_[j].strokeHrz_exemplar_[i];
            for (size_t k = 0; k < stroke.size(); ++k) {
                sample[p++] = stroke[k].x_;
                sample[p++] = stroke[k].y_;
            }
        }
        assert(p == P);
        samples[i] = sample;
    }
    pcaMorphFold_.analyze(samples);
}
template <>
void Modeler::synthesize_cylind(VolumeObject& volObj) {
    volObj.srfMeshes_.clear();
    for (size_t i = 0; i < sweepObjects_.size(); ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        sweepObj.synthesize_strokeHrz_cylind();
        Mesh4 mesh4 = sweepObj.genMesh4_cylind(sweepObj.strokeHrz_synthesis_[0]);
        mesh4.copyCutValue(sweepObj.mesh4_ref_);
        Mesh0 mesh0 = mesh4.convert();
        mesh0.copyAttributes(sweepObj.mesh0_ref_);
        volObj.srfMeshes_.push_back(mesh0);
        if (sweepObj.hasGrain_) {
            sweepObj.distributeGrains(mesh0);
            copy(sweepObj.distributedGrains_.begin(), sweepObj.distributedGrains_.end(), back_inserter(volObj.srfMeshes_));
        }
    }
}
template <>
void Modeler::synthesize_nfold(VolumeObject& volObj, int numFold) {
    volObj.srfMeshes_.clear();
    synthesize_nfold_sub_foldAngles(numFold);
    synthesize_nfold_sub_strokeHrz_nfold(numFold);
    for (size_t objID = 0; objID < sweepObjects_.size(); ++objID) {
        SweepObject& sweepObj = sweepObjects_[objID];
        if (sweepObj.type_ == SweepObject::TYPE_NFOLD1) {
            vector<Mesh0> mesh0s(numFold);
            double angle_begin = 0;
            for (int foldID = 0; foldID < numFold; ++foldID) {
                double angle_end = angle_begin + foldAngles_synthesis_[foldID];
                Mesh4 mesh4 = sweepObj.genMesh4_nfold1(sweepObj.strokeHrz_synthesis_[foldID], angle_begin, angle_end);
                mesh4.copyCutValue(sweepObj.mesh4_ref_);
                mesh0s[foldID] = mesh4.convert();
                mesh0s[foldID].copyAttributes(sweepObj.mesh0_ref_);
                angle_begin = angle_end;
            }
            Mesh0 mesh0 = sweepObj.merge_nfold1(mesh0s);
            volObj.srfMeshes_.push_back(mesh0);
            if (sweepObj.hasGrain_) {
                sweepObj.distributeGrains(mesh0);
                copy(sweepObj.distributedGrains_.begin(), sweepObj.distributedGrains_.end(), back_inserter(volObj.srfMeshes_));
            }
        } else { // (sweepObj.type == SweepObject::TYPE_NFOLD2)
            double angle_begin = 0;
            for (int foldID = 0; foldID < numFold; ++foldID) {
                double angle_end = angle_begin + foldAngles_synthesis_[foldID];
                Mesh4 mesh4 = sweepObj.genMesh4_nfold2(sweepObj.strokeHrz_synthesis_[foldID], angle_begin, angle_end);
                mesh4.copyCutValue(sweepObj.mesh4_ref_);
                Mesh0 mesh0 = mesh4.convert();
                mesh0.copyAttributes(sweepObj.mesh0_ref_);
                volObj.srfMeshes_.push_back(mesh0);
                if (sweepObj.hasGrain_) {
                    sweepObj.distributeGrains(mesh0);
                    copy(sweepObj.distributedGrains_.begin(), sweepObj.distributedGrains_.end(), back_inserter(volObj.srfMeshes_));
                }
                angle_begin = angle_end;
            }
        }
    }
}
void Modeler::synthesize_nfold_sub_foldAngles(int numFold) {
    foldAngles_synthesis_.resize(numFold);
    double angleTotal = 0;
    size_t numFold_exemplar = foldAngles_exemplar_.size();
    for (int i = 0; i < numFold; ++i) {
        int random_index = rand() % numFold_exemplar;
        foldAngles_synthesis_[i] = foldAngles_exemplar_[random_index];  // for now, simple random selection
        angleTotal += foldAngles_synthesis_[i];
    }
    for (int i = 0; i < numFold; ++i)
        foldAngles_synthesis_[i] *= 2 * M_PI / angleTotal;
}
void Modeler::synthesize_nfold_sub_strokeHrz_nfold(int numFold) {
    for (size_t objID = 0; objID < sweepObjects_.size(); ++objID)
        sweepObjects_[objID].strokeHrz_synthesis_.resize(numFold);
    
    for (int foldID = 0; foldID < numFold; ++foldID) {
        VectorVLd sample = pcaMorphFold_.synthesize(0.2, 0.8);
        size_t p = 0;
        for (size_t objID = 0; objID < sweepObjects_.size(); ++objID) {
            SweepObject& sweepObj = sweepObjects_[objID];
            Polyline2d& stroke     = sweepObj.strokeHrz_synthesis_[foldID];
            Polyline2d& stroke_ref = sweepObjects_[objID ].strokeHrz_exemplar_[0];
            stroke.setLoop(stroke_ref.isLoop());
            stroke.resize (stroke_ref.size());
            memcpy(&stroke[0], &sample[p], sizeof(Vector2d) * stroke.size());
            p += 2 * stroke.size();
        }
        assert(p == sample.size());
    }
    
    // linearly blend across fold boundaries to ensure continuity
    for (size_t objID = 0; objID < sweepObjects_.size(); ++objID) {
        SweepObject& sweepObj = sweepObjects_[objID];
        if (sweepObj.type_ == SweepObject::TYPE_NFOLD2)
            continue;
        size_t sz_strokeHrz = sweepObj.strokeHrz_exemplar_[0].size();
        vector<Polyline2d> strokeHrz_synthesis_old = sweepObj.strokeHrz_synthesis_;
        for (size_t i = 0; i < numFold; ++i) {
            size_t i_next = (i == numFold - 1) ? 0       : (i + 1);
            size_t i_prev = (i == 0)     ? (numFold - 1) : (i - 1);
            Polyline2d& strokeHrz      = sweepObj.strokeHrz_synthesis_[i];
            Polyline2d& strokeHrz_old  = strokeHrz_synthesis_old[i];
            Polyline2d& strokeHrz_next = strokeHrz_synthesis_old[i_next];
            Polyline2d& strokeHrz_prev = strokeHrz_synthesis_old[i_prev];
            for (size_t j = 0; j < sz_strokeHrz; ++j) {
                double r0 = strokeHrz_old[j].x_;        // radius
                double t0 = strokeHrz_old[j].y_;        // theta (normalized to [0,1])
                double r1 = 0;
                double weight = 0;
                double margin = 0.25;
                if (t0 < margin) {
                    r1 = strokeHrz_prev[sz_strokeHrz - 1 - j].x_;
                    weight = 0.5 * (margin - t0) / margin;
                } else if (1 - margin < t0) {
                    r1 = strokeHrz_next[sz_strokeHrz - 1 - j].x_;
                    weight = 0.5 * (t0 - 1 + margin) / margin;
                }
                strokeHrz[j].x_ = (1 - weight) * r0 + weight * r1;
            }
        }
    }
}
// save/load functions
void Modeler::save_CsVrt     (ofstream& ofs) {
    size_t size_sweepObjects = sweepObjects_.size();
    ofs.write((char*)&size_sweepObjects, sizeof(size_t));
    
    // SweepObject::{strokeVert_, hasGrain_}
    for (size_t i = 0; i < size_sweepObjects; ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        Polyline2d& strokeVrt = sweepObj.strokeVrt_;
        size_t size_strokeVrt = strokeVrt.size();
        ofs.write((char*)&size_strokeVrt, sizeof(size_t));
        for (size_t j = 0; j < size_strokeVrt; ++j)
            ofs.write((char*)&strokeVrt[j], sizeof(Vector2d));
        bool isLoop = strokeVrt.isLoop();
        ofs.write((char*)&isLoop, sizeof(bool));
        ofs.write((char*)&sweepObj.type_, sizeof(SweepObject::Type));
        // GrainObject::{strokeVrtLeft_, strokeVrtRight_}
        GrainObject& grainObj = sweepObj.grainObject_;
        Polyline2d& strokeVrtLeft  = grainObj.strokeVrtLeft_;
        Polyline2d& strokeVrtRight = grainObj.strokeVrtRight_;
        size_t size_strokeVrtLeft  = strokeVrtLeft .size();
        size_t size_strokeVrtRight = strokeVrtRight.size();
        ofs.write((char*)&size_strokeVrtLeft,  sizeof(size_t));
        ofs.write((char*)&size_strokeVrtRight, sizeof(size_t));
        for (size_t j = 0; j < size_strokeVrtLeft ; ++j) ofs.write((char*)&strokeVrtLeft [j], sizeof(Vector2d));
        for (size_t j = 0; j < size_strokeVrtRight; ++j) ofs.write((char*)&strokeVrtRight[j], sizeof(Vector2d));
    }
    
    // bgImgVrt_
    ofs.write((char*)&bgImgVrt_.width_, sizeof(int));
    ofs.write((char*)&bgImgVrt_.height_, sizeof(int));
    if (!bgImgVrt_.data_.empty())
        ofs.write((char*)&bgImgVrt_.data_[0], 4 * bgImgVrt_.width_ * bgImgVrt_.height_);
    ofs.write((char*)&bgImgVrt_.cornerBL_, sizeof(Vector2d));
    ofs.write((char*)&bgImgVrt_.cornerBR_, sizeof(Vector2d));
    ofs.write((char*)&bgImgVrt_.cornerTL_, sizeof(Vector2d));
    ofs.write((char*)&bgImgVrt_.cornerTR_, sizeof(Vector2d));
}
bool Modeler::load_CsVrt     (ifstream& ifs) {
    size_t size_sweepObjects;
    ifs.read((char*)&size_sweepObjects, sizeof(size_t));
    sweepObjects_.resize(size_sweepObjects);
    
    // SweepObject::{strokeVert_, hasGrain_}
    for (size_t i = 0; i < size_sweepObjects; ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        size_t size_strokeVrt;
        ifs.read((char*)&size_strokeVrt, sizeof(size_t));
        sweepObj.strokeVrt_.resize(size_strokeVrt);
        for (size_t j = 0; j < size_strokeVrt; ++j)
            ifs.read((char*)&sweepObj.strokeVrt_[j], sizeof(Vector2d));
        bool isLoop;
        ifs.read((char*)&isLoop, sizeof(bool));
        sweepObj.strokeVrt_.setLoop(isLoop);
        ifs.read((char*)&sweepObj.type_, sizeof(SweepObject::Type));
        if ( isLoop && sweepObj.type_ == SweepObject::TYPE_CYLIND ||
            !isLoop && sweepObj.type_ == SweepObject::TYPE_NFOLD2)
            return false;
        // GrainObject::{strokeVrtLeft_, strokeVrtRight_}
        GrainObject& grainObj = sweepObj.grainObject_;
        size_t size_strokeVrtLeft;
        size_t size_strokeVrtRight;
        ifs.read((char*)&size_strokeVrtLeft,  sizeof(size_t));
        ifs.read((char*)&size_strokeVrtRight, sizeof(size_t));
        Polyline2d& strokeVrtLeft  = grainObj.strokeVrtLeft_;
        Polyline2d& strokeVrtRight = grainObj.strokeVrtRight_;
        strokeVrtLeft .resize(size_strokeVrtLeft );
        strokeVrtRight.resize(size_strokeVrtRight);
        for (size_t j = 0; j < size_strokeVrtLeft ; ++j) ifs.read((char*)&strokeVrtLeft [j], sizeof(Vector2d));
        for (size_t j = 0; j < size_strokeVrtRight; ++j) ifs.read((char*)&strokeVrtRight[j], sizeof(Vector2d));
    }
    
    // bgImgVrt_
    ifs.read((char*)&bgImgVrt_.width_, sizeof(int));
    ifs.read((char*)&bgImgVrt_.height_, sizeof(int));
    bgImgVrt_.data_.resize(4 * bgImgVrt_.width_ * bgImgVrt_.height_);
    if (!bgImgVrt_.data_.empty())
        ifs.read((char*)&bgImgVrt_.data_[0], 4 * bgImgVrt_.width_ * bgImgVrt_.height_);
    ogl.makeOpenGLCurrent();
    bgImgVrt_.tex_.allocate(GL_RGBA, bgImgVrt_.width_, bgImgVrt_.height_, GL_RGBA, GL_UNSIGNED_BYTE, &bgImgVrt_.data_[0]);
    ifs.read((char*)&bgImgVrt_.cornerBL_, sizeof(Vector2d));
    ifs.read((char*)&bgImgVrt_.cornerBR_, sizeof(Vector2d));
    ifs.read((char*)&bgImgVrt_.cornerTL_, sizeof(Vector2d));
    ifs.read((char*)&bgImgVrt_.cornerTR_, sizeof(Vector2d));
    ogl.RedrawWindow();

    return true;
}
void Modeler::save_CsHrz     (ofstream& ofs) {
    size_t size_sweepObjects = sweepObjects_.size();
    ofs.write((char*)&size_sweepObjects, sizeof(size_t));
    
    // foldAngles_exemplar_
    size_t numFold = foldAngles_exemplar_.size();
    ofs.write((char*)&numFold, sizeof(size_t));
    if (numFold != 0)
        ofs.write((char*)&foldAngles_exemplar_[0], numFold * sizeof(double));
    
    // SweepObject::strokeHrz_exemplar_xy_
    for (size_t i = 0; i < size_sweepObjects; ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        size_t size_strokes = sweepObj.strokeHrz_exemplar_xy_.size();
        ofs.write((char*)&size_strokes, sizeof(size_t));
        for (size_t j = 0; j < size_strokes; ++j) {
            Polyline2d& stroke = sweepObj.strokeHrz_exemplar_xy_[j];
            size_t size_stroke = stroke.size();
            ofs.write((char*)&size_stroke, sizeof(size_t));
            for (size_t k = 0; k < size_stroke; ++k)
                ofs.write((char*)&stroke[k], sizeof(Vector2d));
        }
        ofs.write((char*)&sweepObj.hasGrain_, sizeof(bool));
        if (sweepObj.hasGrain_) {
            Polyline2d& stroke = sweepObj.grainObject_.strokeHrz_;
            size_t size_stroke = stroke.size();
            ofs.write((char*)&size_stroke, sizeof(size_t));
            for (size_t k = 0; k < size_stroke; ++k)
                ofs.write((char*)&stroke[k], sizeof(Vector2d));
        }
    }
    
    //  bgImgHrz_
    ofs.write((char*)&bgImgHrz_.width_, sizeof(int));
    ofs.write((char*)&bgImgHrz_.height_, sizeof(int));
    if (!bgImgHrz_.data_.empty())
        ofs.write((char*)&bgImgHrz_.data_[0], 4 * bgImgHrz_.width_ * bgImgHrz_.height_);
    ofs.write((char*)&bgImgHrz_.cornerBL_, sizeof(Vector2d));
    ofs.write((char*)&bgImgHrz_.cornerBR_, sizeof(Vector2d));
    ofs.write((char*)&bgImgHrz_.cornerTL_, sizeof(Vector2d));
    ofs.write((char*)&bgImgHrz_.cornerTR_, sizeof(Vector2d));
}
bool Modeler::load_CsHrz     (ifstream& ifs) {
    size_t size_sweepObjects;
    ifs.read((char*)&size_sweepObjects, sizeof(size_t));
    if (size_sweepObjects != sweepObjects_.size())
        return false;
    
    // foldAngles_exemplar_
    size_t numFold;
    ifs.read((char*)&numFold, sizeof(size_t));
    if (numFold == 0 && type_ == TYPE_NFOLD)
        return false;
    foldAngles_exemplar_.resize(numFold);
    if (numFold != 0)
        ifs.read((char*)&foldAngles_exemplar_[0], numFold * sizeof(double));
    
    // SweepObject::strokeHrz_exemplar_xy_
    for (size_t i = 0; i < size_sweepObjects; ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        size_t size_strokes;
        ifs.read((char*)&size_strokes, sizeof(size_t));
        sweepObj.strokeHrz_exemplar_xy_.resize(size_strokes);
        for (size_t j = 0; j < size_strokes; ++j) {
            Polyline2d& stroke = sweepObj.strokeHrz_exemplar_xy_[j];
            size_t size_stroke;
            ifs.read((char*)&size_stroke, sizeof(size_t));
            stroke.resize(size_stroke);
            for (size_t k = 0; k < size_stroke; ++k)
                ifs.read((char*)&stroke[k], sizeof(Vector2d));
            stroke.setLoop(true);
        }
        bool hasGrain;
        ifs.read((char*)&hasGrain, sizeof(bool));
        if (hasGrain != sweepObj.hasGrain_)
            return false;
        if (sweepObj.hasGrain_) {
            Polyline2d& stroke = sweepObj.grainObject_.strokeHrz_;
            size_t size_stroke;
            ifs.read((char*)&size_stroke, sizeof(size_t));
            stroke.resize(size_stroke);
            for (size_t k = 0; k < size_stroke; ++k)
                ifs.read((char*)&stroke[k], sizeof(Vector2d));
            stroke.setLoop(true);
        }
    }
    //  bgImgHrz_
    ifs.read((char*)&bgImgHrz_.width_, sizeof(int));
    ifs.read((char*)&bgImgHrz_.height_, sizeof(int));
    bgImgHrz_.data_.resize(4 * bgImgHrz_.width_ * bgImgHrz_.height_);
    if (!bgImgHrz_.data_.empty())
        ifs.read((char*)&bgImgHrz_.data_[0], 4 * bgImgHrz_.width_ * bgImgHrz_.height_);
    ogl.makeOpenGLCurrent();
    bgImgHrz_.tex_.allocate(GL_RGBA, bgImgHrz_.width_, bgImgHrz_.height_, GL_RGBA, GL_UNSIGNED_BYTE, &bgImgHrz_.data_[0]);
    ifs.read((char*)&bgImgHrz_.cornerBL_, sizeof(Vector2d));
    ifs.read((char*)&bgImgHrz_.cornerBR_, sizeof(Vector2d));
    ifs.read((char*)&bgImgHrz_.cornerTL_, sizeof(Vector2d));
    ifs.read((char*)&bgImgHrz_.cornerTR_, sizeof(Vector2d));
    return true;
}
void Modeler::save_DeleteFace(ofstream& ofs) {
    size_t size_sweepObjects = sweepObjects_.size();
    ofs.write((char*)&size_sweepObjects, sizeof(size_t));
    
    // Mesh4::VertexT::cutValue
    for (size_t i = 0; i < size_sweepObjects; ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        {
            Mesh4& mesh4 = sweepObj.mesh4_ref_;
            unsigned int n_vertices = mesh4.n_vertices();
            ofs.write((char*)&n_vertices, sizeof(unsigned int));
            for (Mesh4::VIter v = mesh4.vertices_begin(); v != mesh4.vertices_end(); ++v)
                ofs.write((char*)&mesh4.data(v).cutValue_, sizeof(double));
        }
        ofs.write((char*)&sweepObj.hasGrain_, sizeof(bool));
        if (sweepObj.hasGrain_) {
            Mesh4& mesh4 = sweepObj.grainObject_.mesh4_ref_;
            unsigned int n_vertices = mesh4.n_vertices();
            ofs.write((char*)&n_vertices, sizeof(unsigned int));
            for (Mesh4::VIter v = mesh4.vertices_begin(); v != mesh4.vertices_end(); ++v)
                ofs.write((char*)&mesh4.data(v).cutValue_, sizeof(double));
        }
    }
}
bool Modeler::load_DeleteFace(ifstream& ifs) {
    size_t size_sweepObjects;
    ifs.read((char*)&size_sweepObjects, sizeof(size_t));
    if (size_sweepObjects != sweepObjects_.size())
        return false;
    
    // Mesh4::VertexT::cutValue
    for (size_t i = 0; i < size_sweepObjects; ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        {
            Mesh4& mesh4 = sweepObj.mesh4_ref_;
            unsigned int n_vertices;
            ifs.read((char*)&n_vertices, sizeof(unsigned int));
            if (n_vertices != mesh4.n_vertices())
                return false;
            for (Mesh4::VIter v = mesh4.vertices_begin(); v != mesh4.vertices_end(); ++v)
                ifs.read((char*)&mesh4.data(v).cutValue_, sizeof(double));
            sweepObj.mesh0_ref_ = mesh4.convert();
        }
        bool hasGrain;
        ifs.read((char*)&hasGrain, sizeof(bool));
        if (hasGrain != sweepObj.hasGrain_)
            return false;
        if (sweepObj.hasGrain_) {
            Mesh4& mesh4 = sweepObj.grainObject_.mesh4_ref_;
            unsigned int n_vertices;
            ifs.read((char*)&n_vertices, sizeof(unsigned int));
            if (n_vertices != mesh4.n_vertices())
                return false;
            for (Mesh4::VIter v = mesh4.vertices_begin(); v != mesh4.vertices_end(); ++v)
                ifs.read((char*)&mesh4.data(v).cutValue_, sizeof(double));
            sweepObj.grainObject_.mesh0_ref_ = mesh4.convert();
        }
    }
    return true;
}
void Modeler::save_Grain     (ofstream& ofs) {
    size_t size_sweepObjects = sweepObjects_.size();
    ofs.write((char*)&size_sweepObjects, sizeof(size_t));
    
    for (size_t i = 0; i < size_sweepObjects; ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        // SweepObject::hasGrain
        ofs.write((char*)&sweepObj.hasGrain_, sizeof(bool));
        if (!sweepObj.hasGrain_)
            continue;
        GrainObject& grainObj = sweepObj.grainObject_;
        // GrainObject::poissonRadius
        ofs.write((char*)&grainObj.poissonRadius_, sizeof(double));
        // GrainObject::Face::flagGrain
        int n_faces = sweepObj.mesh0_ref_.n_faces();
        ofs.write((char*)&n_faces, sizeof(int));
        for (Mesh0::FIter f = sweepObj.mesh0_ref_.faces_begin(); f != sweepObj.mesh0_ref_.faces_end(); ++f)
            ofs.write((char*)&sweepObj.mesh0_ref_.data(f).flagGrain_, sizeof(bool));
        // GrainObject::Vertex::point
        int n_vertices = grainObj.mesh0_ref_.n_vertices();
        ofs.write((char*)&n_vertices, sizeof(int));
        for (Mesh0::VIter v = grainObj.mesh0_ref_.vertices_begin(); v != grainObj.mesh0_ref_.vertices_end(); ++v)
            ofs.write((char*)&grainObj.mesh0_ref_.point(v), sizeof(Vector3d));
    }
}
bool Modeler::load_Grain     (ifstream& ifs) {
    size_t size_sweepObjects;
    ifs.read((char*)&size_sweepObjects, sizeof(size_t));
    if (size_sweepObjects != sweepObjects_.size())
        return false;
    
    for (size_t i = 0; i < size_sweepObjects; ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        // SweepObject::hasGrain
        bool hasGrain;
        ifs.read((char*)&hasGrain, sizeof(bool));
        if (hasGrain != sweepObj.hasGrain_)
            return false;
        if (!sweepObj.hasGrain_)
            continue;
        
        GrainObject& grainObj = sweepObj.grainObject_;
        // GrainObject::poissonRadius
        ifs.read((char*)&grainObj.poissonRadius_, sizeof(double));
        // GrainObject::Face::flagGrain
        int n_faces;
        ifs.read((char*)&n_faces, sizeof(int));
        if (n_faces != sweepObj.mesh0_ref_.n_faces())
            return false;
        for (Mesh0::FIter f = sweepObj.mesh0_ref_.faces_begin(); f != sweepObj.mesh0_ref_.faces_end(); ++f)
            ifs.read((char*)&sweepObj.mesh0_ref_.data(f).flagGrain_, sizeof(bool));
        // GrainObject::Vertex::point
        int n_vertices;
        ifs.read((char*)&n_vertices, sizeof(int));
        if (n_vertices != grainObj.mesh0_ref_.n_vertices())
            return false;
        for (Mesh0::VIter v = grainObj.mesh0_ref_.vertices_begin(); v != grainObj.mesh0_ref_.vertices_end(); ++v)
            ifs.read((char*)&grainObj.mesh0_ref_.point(v), sizeof(Vector3d));
    }
    return true;
}
void Modeler::save_Color     (ofstream& ofs) {
    size_t size_sweepObjects = sweepObjects_.size();
    ofs.write((char*)&size_sweepObjects, sizeof(size_t));

    struct Local {
        static void save_mesh0(Mesh0& mesh0, ofstream& ofs) {
            // Mesh0::{isTwoSided_, isHole_}
            ofs.write((char*)&mesh0.isTwoSided_, sizeof(bool));
            ofs.write((char*)&mesh0.isHole_,     sizeof(bool));
            // Mesh0::Vertex::{color, back_color_}
            unsigned int n_vertices = mesh0.n_vertices();
            ofs.write((char*)&n_vertices, sizeof(unsigned int));
            for (Mesh0::VIter v_it = mesh0.vertices_begin(); v_it != mesh0.vertices_end(); ++v_it) {
                Mesh0::VertexData& vdata = mesh0.data(v_it);
                ofs.write((char*)&vdata.color_     , sizeof(Vector3d));
                ofs.write((char*)&vdata.back_color_, sizeof(Vector3d));
                ofs.write((char*)&vdata.isConstrained_     , sizeof(bool));
                ofs.write((char*)&vdata.back_isConstrained_, sizeof(bool));
            }
        }
    };
    
    for (size_t i = 0; i < size_sweepObjects; ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        Local::save_mesh0(sweepObj.mesh0_ref_, ofs);
        ofs.write((char*)&sweepObj.hasGrain_, sizeof(bool));
        if (sweepObj.hasGrain_)
            Local::save_mesh0(sweepObj.grainObject_.mesh0_ref_, ofs);
    }
}
bool Modeler::load_Color     (ifstream& ifs) {
    size_t size_sweepObjects;
    ifs.read((char*)&size_sweepObjects, sizeof(size_t));
    if (size_sweepObjects != sweepObjects_.size())
        return false;

    struct Local {
        static bool load_mesh0(Mesh0& mesh0, ifstream& ifs) {
            // Mesh0::{isTwoSided_, isHole_}
            ifs.read((char*)&mesh0.isTwoSided_, sizeof(bool));
            ifs.read((char*)&mesh0.isHole_,     sizeof(bool));
            // Mesh0::Vertex::{color, back_color_}
            unsigned int n_vertices;
            ifs.read((char*)&n_vertices, sizeof(unsigned int));
            if (n_vertices != mesh0.n_vertices())
                return false;
            for (Mesh0::VIter v_it = mesh0.vertices_begin(); v_it != mesh0.vertices_end(); ++v_it) {
                Mesh0::VertexData& vdata = mesh0.data(v_it);
                ifs.read((char*)&vdata.color_,      sizeof(Vector3d));
                ifs.read((char*)&vdata.back_color_, sizeof(Vector3d));
                ifs.read((char*)&vdata.isConstrained_     , sizeof(bool));
                ifs.read((char*)&vdata.back_isConstrained_, sizeof(bool));
            }
            return true;
        }
    };
    
    for (size_t i = 0; i < size_sweepObjects; ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        if (!Local::load_mesh0(sweepObj.mesh0_ref_, ifs))
            return false;
        bool hasGrain;
        ifs.read((char*)&hasGrain, sizeof(bool));
        if (hasGrain != sweepObj.hasGrain_)
            return false;
        if (sweepObj.hasGrain_)
            if (!Local::load_mesh0(sweepObj.grainObject_.mesh0_ref_, ifs))
                return false;
    }
    return true;
}
void Modeler::save_Blur      (ofstream& ofs) {
    struct Local {
        static void save_mesh0(Mesh0& mesh0, ofstream& ofs) {
            ofs.write((char*)&mesh0.hasBlur_, sizeof(bool));
            if (!mesh0.hasBlur_)
                return;
            unsigned int n_vertices = mesh0.n_vertices();
            ofs.write((char*)&n_vertices, sizeof(unsigned int));
            for (Mesh0::VIter v = mesh0.vertices_begin(); v != mesh0.vertices_end(); ++v) {
                ofs.write((char*)&mesh0.data(v).blurValue_    , sizeof(double));
                ofs.write((char*)&mesh0.data(v).isConstrained_, sizeof(bool  ));
            }
        }
    };
    for (size_t i = 0; i < sweepObjects_.size(); ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        Local::save_mesh0(sweepObj.mesh0_ref_, ofs);
        ofs.write((char*)&sweepObj.hasGrain_, sizeof(bool));
        if (sweepObj.hasGrain_)
            Local::save_mesh0(sweepObj.grainObject_.mesh0_ref_, ofs);
    }
}
bool Modeler::load_Blur      (ifstream& ifs) {
    struct Local {
        static bool load_mesh0(Mesh0& mesh0, ifstream& ifs) {
            ifs.read((char*)&mesh0.hasBlur_, sizeof(bool));
            if (!mesh0.hasBlur_)
                return true;
            unsigned int n_vertices;
            ifs.read((char*)&n_vertices, sizeof(unsigned int));
            if (n_vertices != mesh0.n_vertices())
                return false;
            for (Mesh0::VIter v = mesh0.vertices_begin(); v != mesh0.vertices_end(); ++v) {
                ifs.read((char*)&mesh0.data(v).blurValue_    , sizeof(double));
                ifs.read((char*)&mesh0.data(v).isConstrained_, sizeof(bool  ));
            }
            return true;
        }
    };
    for (size_t i = 0; i < sweepObjects_.size(); ++i) {
        SweepObject& sweepObj = sweepObjects_[i];
        if (!Local::load_mesh0(sweepObj.mesh0_ref_, ifs))
            return false;
        bool hasGrain;
        ifs.read((char*)&hasGrain, sizeof(bool));
        if (hasGrain != sweepObj.hasGrain_)
            return false;
        if (sweepObj.hasGrain_)
            if (!Local::load_mesh0(sweepObj.grainObject_.mesh0_ref_, ifs))
                return false;
    }
    return true;
}

