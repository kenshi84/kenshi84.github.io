// DiffusionSurfaces Drawer class
#pragma once

#include <gl/gl.h>

#include <KLIB/GLSLUtil.h>
#include <KLIB/Vector.h>


class Drawer
{
public:
    Drawer(void);
    ~Drawer(void);
    
    void init();

    void draw();
	void postDraw(CDC* pDC);

    static void drawTexturedQuad(const KLIB::Vector2d& cornerBL, const KLIB::Vector2d& cornerBR, const KLIB::Vector2d& cornerTL, const KLIB::Vector2d& cornerTR);
    static void draw_axis();
    
    template <class TMesh>
    static void draw_mesh_face(TMesh& mesh) {
        glBegin(GL_TRIANGLES);
        for (TMesh::FIter f = mesh.faces_begin(); f != mesh.faces_end(); ++f)
            for (TMesh::FVIter v = mesh.fv_iter(f); v; ++v) {
                glNormal3d(mesh.normal(v));
                glVertex3d(mesh.point(v));
            }
        glEnd();
    }
    
    // draw colored mesh
    template <class TMesh>
    static void draw_mesh_colored(TMesh& mesh, double alpha = 1.0) {
        glBegin(GL_TRIANGLES);
        for (TMesh::FIter f = mesh.faces_begin(); f != mesh.faces_end(); ++f)
            for (TMesh::FVIter v = mesh.fv_iter(f); v; ++v) {
                KLIB::Vector3d& color  = mesh.data(v).color_;
                glColor4d(color.x_, color.y_, color.z_, alpha);
                glNormal3d(mesh.normal(v));
                glVertex3d(mesh.point(v));
            }
        glEnd();
    }
    // draw two-side-colored mesh
    template <class TMesh>
    static void draw_mesh_twosided(TMesh& mesh, double alpha = 1.0) {
        glBegin(GL_TRIANGLES);
        for (TMesh::FIter f = mesh.faces_begin(); f != mesh.faces_end(); ++f) {
            TMesh::HHandle h = mesh.halfedge_handle(f);
            for (int i = 0; i < 3; ++i) {            // front
                TMesh::VHandle v = mesh.to_vertex_handle(h);
                KLIB::Vector3d& color  = mesh.data(v).color_;
                glColor4d(color.x_, color.y_, color.z_, alpha);
                glNormal3d(mesh.normal(v));
                glVertex3d(mesh.point(v));
                h = mesh.next_halfedge_handle(h);
            }
            for (int i = 0; i < 3; ++i) {            // back
                TMesh::VHandle v = mesh.to_vertex_handle(h);
                KLIB::Vector3d& color = mesh.data(v).back_color_;
                glColor4d(color.x_, color.y_, color.z_, alpha);
                glNormal3d(-mesh.normal(v));
                glVertex3d(mesh.point(v));
                h = mesh.prev_halfedge_handle(h);
            }
        }
        glEnd();
    }
    
    template <class TMesh>
    static void draw_mesh_edge(TMesh& mesh) {
        glPushAttrib(GL_ENABLE_BIT);
        glDisable(GL_POLYGON_OFFSET_FILL);
        glBegin(GL_LINES);
        for (TMesh::EIter e = mesh.edges_begin(); e != mesh.edges_end(); ++e)
            for (int i = 0; i < 2; ++i)
                glVertex3d(mesh.point(mesh.to_vertex_handle(mesh.halfedge_handle(e, i))));
        glEnd();
        glPopAttrib();
    }
};
