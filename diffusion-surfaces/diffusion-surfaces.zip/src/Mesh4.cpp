#include "stdafx.h"
#include "Mesh4.h"
#include "Mesh0.h"
using namespace std;
using namespace KLIB;

const double Mesh4Traits::CUTVALUE_DEFAULT = 100;
Mesh0 Mesh4::convert() {
    Mesh0 mesh0;
    
    for (EIter e = edges_begin(); e != edges_end(); ++e) {
        double cutValue[2];
        for (int i = 0; i < 2; ++i) {
            VHandle v = from_vertex_handle(halfedge_handle(e, i));
            cutValue  [i] = data(v).cutValue_;
        }
        EdgeData& edata = data(e);
        edata.isCrossed_  = cutValue[0] * cutValue[1] < 0;
        edata.crossedPos_ = -cutValue[0] / (cutValue[1] - cutValue[0]);
    }
    
    //--------------+
    // add vertices |
    //--------------+
    
    vector<int> map_mesh4v_mesh0v(n_vertices(), -1);     // mapping from mesh4 vertex id to mesh0 vertex id
    for (int vid = 0; vid < n_vertices(); ++vid) {
        VHandle v = vertex_handle(vid);
        if (data(v).cutValue_ < 0)
            continue;            // i-th vertex is not included in mesh0
        Mesh0::VHandle mesh0_v = mesh0.add_vertex(point(v));
        mesh0.data(mesh0_v).nfold1_flagPole_ = data(v).nfold1_flagPole_;
        map_mesh4v_mesh0v[vid] = mesh0_v.idx();
    }
    for (int vid = 0; vid < n_vertices(); ++vid) {
        int mesh0_vid = map_mesh4v_mesh0v[vid];
        if (mesh0_vid  == -1)
            continue;
        VHandle v = vertex_handle(vid);
        Mesh0::VHandle mesh0_v = mesh0.vertex_handle(mesh0_vid);
        int mapped_vid = data(v).nfold1_mapped_vid_;
        if (mapped_vid == -1)
            continue;
        int mesh0_mapped_vid = map_mesh4v_mesh0v[mapped_vid];
        mesh0.data(mesh0_v).nfold1_mapped_vid_ = mesh0_mapped_vid;
    }
    
    vector<int> map_mesh4e_mesh0v(n_edges(), -1);        // mapping from mesh4 edge id to mesh0 vertex id
    for (int eid = 0; eid < n_edges(); ++eid) {
        EHandle e = edge_handle(eid);
        if (!data(e).isCrossed_)
            continue;            // i-th mesh0 edge is not included in mesh3
        Vector3d edge_point[2];
        for (int j = 0; j < 2; ++j)
            edge_point[j] = point(from_vertex_handle(halfedge_handle(e, j)));
        
        double crossedPos = data(e).crossedPos_;
        Mesh0::VHandle mesh0_v = mesh0.add_vertex((1 - crossedPos) * edge_point[0] + crossedPos * edge_point[1]);
        map_mesh4e_mesh0v[eid] = mesh0_v.idx();
    }
    for (int eid = 0; eid < n_edges(); ++eid) {
        int mesh0_vid = map_mesh4e_mesh0v[eid];
        if (mesh0_vid  == -1)
            continue;
        EHandle e = edge_handle(eid);
        Mesh0::VHandle mesh0_v = mesh0.vertex_handle(mesh0_vid);
        int mapped_eid = data(e).nfold1_mapped_eid_;
        if (mapped_eid == -1)
            continue;
        int mesh0_mapped_vid = map_mesh4e_mesh0v[mapped_eid];
        mesh0.data(mesh0_v).nfold1_mapped_vid_ = mesh0_mapped_vid;
    }
    
    //-----------+
    // add faces |
    //-----------+
    
    for (FIter f = faces_begin(); f != faces_end(); ++f) {
        vector<int> mesh0_vid;
        HHandle h = halfedge_handle(f);
        for (int i = 0; i < 3; ++i) {
            VHandle v = from_vertex_handle(h);
            EHandle e = edge_handle(h);
            if (0 < data(v).cutValue_)
                mesh0_vid.push_back(map_mesh4v_mesh0v[v.idx()]);
            if (data(e).isCrossed_)
                mesh0_vid.push_back(map_mesh4e_mesh0v[e.idx()]);
            h = next_halfedge_handle(h);
        }
        const Vector3d& n0 = normal(f);
        if (mesh0_vid.empty())
            continue;
        assert (mesh0_vid.size() == 3 || mesh0_vid.size() == 4);
        if (mesh0_vid.size() == 4) {
            mesh0_vid.push_back(mesh0_vid[0]);
            mesh0_vid.push_back(mesh0_vid[2]);
        }
        for (size_t i = 0; i < mesh0_vid.size(); i += 3) {
            vector<Mesh0::VHandle> face_vhandle(3);
            Vector3d mesh0_fpoint[3];
            for (int j = 0; j < 3; ++j) {
                face_vhandle[j] = mesh0.vertex_handle(mesh0_vid[i + j]);
                mesh0_fpoint[j] = mesh0.point(face_vhandle[j]);
            }
            Vector3d n2 = (mesh0_fpoint[1] - mesh0_fpoint[0]) % (mesh0_fpoint[2] - mesh0_fpoint[0]);
            if ((n0 | n2) < 0)
                swap(face_vhandle[0], face_vhandle[1]);
            mesh0.add_face(face_vhandle);
        }
    }
    
    mesh0.request_face_normals();
    mesh0.request_vertex_normals();
    mesh0.update_normals();
    mesh0.calcAuxiliaryInfo();
    return mesh0;
}
void Mesh4::copyCutValue(const Mesh4& src) {
    VIter v = vertices_begin();
    CVIter v_src = src.vertices_begin();
    for (; v != vertices_end(); ++v, ++v_src)
        data(v).cutValue_ = src.data(v_src).cutValue_;
}
void Mesh4::calcNfold1MappedEdge() {
    for (EIter e = edges_begin(); e != edges_end(); ++e)
        data(e).nfold1_mapped_eid_ = -1;
    for (EIter e = edges_begin(); e != edges_end(); ++e) {
        if (data(e).nfold1_mapped_eid_ != -1)
            continue;
        VHandle     v    [2];
        VertexData* vdata[2];
        for (int i = 0; i < 2; ++i) {
            v    [i] = to_vertex_handle(halfedge_handle(e, i));
            vdata[i] = &data(v[i]);
        }
        if (vdata[0]->nfold1_mapped_vid_ == -1) {
            swap(v    [0], v    [1]);
            swap(vdata[0], vdata[1]);
        }
        if (vdata[0]->nfold1_mapped_vid_ == -1 ||
            (vdata[1]->nfold1_mapped_vid_ == -1 && vdata[1]->nfold1_flagPole_ == 0))
            continue;
        VHandle mapped_v[2];
        for (int i = 0; i < 2; ++i) {
            mapped_v[i] = vdata[i]->nfold1_flagPole_
                ? v[i]
                : vertex_handle(vdata[i]->nfold1_mapped_vid_);
        }
        EHandle mapped_e;
        for (VOHIter h = voh_iter(mapped_v[0]); h; ++h) {
            if (to_vertex_handle(h) == mapped_v[1]) {
                mapped_e = edge_handle(h);
                break;
            }
        }
        if (mapped_e.is_valid()) {
            data(e       ).nfold1_mapped_eid_ = mapped_e.idx();
            data(mapped_e).nfold1_mapped_eid_ = e.handle().idx();
        }
    }
}
