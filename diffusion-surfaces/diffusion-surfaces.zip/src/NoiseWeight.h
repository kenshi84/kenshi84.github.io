#pragma once
#include <vector>
#include <KLIB/Vector.h>
#include <GL/glew.h>

struct NoiseWeight {
    int resolution_;
    std::vector<KLIB::Vector4uc> data_[2];
    GLuint texID_[2];
    NoiseWeight()
        : resolution_(0)
    {
        texID_[0] = texID_[1] = 0;
    }
    void gl_init();
    void gl_deinit();
    void clear();
    void resize(int resolution, const KLIB::Vector8uc& weight = KLIB::Vector8uc());
    bool load(const char* fname);
    void setDefault();
    void transferToGpu() const;
};
