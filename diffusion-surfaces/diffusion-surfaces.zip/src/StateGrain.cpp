#include "StdAfx.h"
#include "StateGrain.h"
#include "StateColor.h"
#include "Core.h"
#include <gl/glut.h>
#include <KLIB/RBF.h>

using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
Modeler& modeler = core.modeler_;
}

void StateGrain::initialize() {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    for (size_t i = 0; i < sz_sweepObjects; ++i) {
        if (!modeler.sweepObjects_[i].hasGrain_)
            continue;
        GrainObject& grainObj = modeler.sweepObjects_[i].grainObject_;
        grainObj.mesh0_ref_.calcAuxiliaryInfo();
        grainObj.poissonRadius_ = grainObj.mesh0_ref_.bbox_.diagonal() / 2;
        for (Mesh0::FIter f = grainObj.mesh0_ref_.faces_begin(); f != grainObj.mesh0_ref_.faces_end(); ++f)
            grainObj.mesh0_ref_.data(f).flagGrain_ = false;
    }
    for (currentObjectID_ = 0; !modeler.sweepObjects_[currentObjectID_].hasGrain_;)
        currentObjectID_ = (currentObjectID_ + 1) % sz_sweepObjects;
    
    refPointInit();
    refPointMesh0Update();
}
string StateGrain::message() {
    string msg;
    msg += "Step 4: Distribute grains\n";
    msg += "Mode: ";
    msg +=
        mode_ == MODE_TURNON  ? "Mark"   :
        mode_ == MODE_TURNOFF ? "Unmark" :
        mode_ == MODE_RADIUS  ? "Radius" :
        mode_ == MODE_OFFSET  ? "Offset" :
        mode_ == MODE_SCALE   ? "Scale"  : "Move reference";
    return msg;
}
State* StateGrain::next() {
    return StateColor::getInstance();
}

void StateGrain::draw() {
    SweepObject& sweepObj = modeler.sweepObjects_[currentObjectID_];
    GrainObject& grainObj = sweepObj.grainObject_;

    Mesh0& mesh0 = sweepObj.mesh0_ref_;

    glPushAttrib(GL_ENABLE_BIT | GL_LINE_BIT);
    
    // mesh face
    glEnable(GL_LIGHTING);
    glBegin(GL_TRIANGLES);
    for (Mesh0::FIter f_it = mesh0.faces_begin(); f_it != mesh0.faces_end(); ++f_it) {
        Mesh0::HHandle hhandle = mesh0.halfedge_handle(f_it);
        if ((mode_ == MODE_TURNON || mode_ == MODE_TURNOFF) && mesh0.data(f_it).flagGrain_)
            glColor3d(1, 0, 0);
        else
            glColor3d(1, 1, 1);
        for (int i = 0; i < 3; ++i) {            // front
            Mesh0::VHandle vhandle = mesh0.to_vertex_handle(hhandle);
            Vector3d  normal = mesh0.normal(vhandle);
            Vector3d& point = mesh0.point(vhandle);
            glNormal3dv(normal.ptr());
            glVertex3dv(point .ptr());
            hhandle = mesh0.next_halfedge_handle(hhandle);
        }
        for (int i = 0; i < 3; ++i) {            // back
            Mesh0::VHandle vhandle = mesh0.to_vertex_handle(hhandle);
            Vector3d  normal = -mesh0.normal(vhandle);
            Vector3d& point  = mesh0.point(vhandle);
            glNormal3dv(normal.ptr());
            glVertex3dv(point .ptr());
            hhandle = mesh0.prev_halfedge_handle(hhandle);
        }
    }
    glEnd();
    
    // mesh edge
    glDisable(GL_LIGHTING);
    glLineWidth(1);
    glColor3d(0, 0, 0);
    Drawer::draw_mesh_edge(mesh0);
    glEnable(GL_LIGHTING);
    
    if (mode_ == MODE_TURNON || mode_ == MODE_TURNOFF) {    // draw current distribution
        for (size_t i = 0; i < sweepObj.distributedGrains_.size(); ++i) {
            glEnable(GL_LIGHTING);
            glColor3d(1, 1, 1);
            Drawer::draw_mesh_face(sweepObj.distributedGrains_[i]);
            glDisable(GL_LIGHTING);
            glColor3d(0, 0, 0);
            Drawer::draw_mesh_edge(sweepObj.distributedGrains_[i]);
        }
    } else if (mode_ == MODE_RADIUS || mode_ == MODE_OFFSET || mode_ == MODE_SCALE || MODE_MOVEREF) {
        glEnable(GL_LIGHTING);
        glColor3d(0, 0, 1);
        glPushMatrix();
        glTranslated(refPoint_[0], refPoint_[1], refPoint_[2]);
        glutSolidSphere(0.01, 12, 12);
        if (mode_ == MODE_RADIUS) {
            glColor3d(0, 0, 1);
            glDisable(GL_LIGHTING);
            glutWireSphere(grainObj.poissonRadius_, 12, 12);
        }
        glPopMatrix();
        glEnable(GL_LIGHTING);
        glColor3d(1, 1, 1);
        Drawer::draw_mesh_face(refPoint_mesh0_);
        glDisable(GL_LIGHTING);
        glColor3d(0, 0, 0);
        Drawer::draw_mesh_edge(refPoint_mesh0_);
    }
    
    glLineWidth(5);
    if (!cutStroke2D_.empty()) {    // cutting stroke
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        glColor3d(1, 0, 0);
        glBegin(GL_LINE_STRIP);
        for (size_t i = 0; i < cutStroke3D_.size(); ++i) glVertex3dv(cutStroke3D_[i].ptr());
        glEnd();
        glEnable(GL_LIGHTING);
        glEnable(GL_DEPTH_TEST);
    }
    glPopAttrib();
}
void StateGrain::OnLButtonDown(UINT nFlags, CPoint& point) {
    point_old_ = point;
    if (mode_ == MODE_TURNON || mode_ == MODE_TURNOFF) {
        Vector2d point2d(point.x, point.y);
        Vector3d point3d = core.ogl_.unproject(point2d);
        cutStroke2D_.clear();
        cutStroke3D_.clear();
        cutStroke2D_.push_back(point2d);
        cutStroke3D_.push_back(point3d);
    }
}
void StateGrain::OnLButtonUp  (UINT nFlags, CPoint& point) {
    SweepObject& sweepObj = modeler.sweepObjects_[currentObjectID_];
    GrainObject& grainObj = sweepObj.grainObject_;
    
    if (mode_ == MODE_TURNON || mode_ == MODE_TURNOFF) {
        if (5 < cutStroke2D_.size()) {
            // resample stroke points evenly
            cutStroke2D_.resample(20);
            
            // construct 2D scalar field with RBF
            ThinPlate2d rbf;
            vector<Vector2d> rbfPoints;
            vector<double>   rbfValues;
            for (size_t i = 0; i < cutStroke2D_.size(); ++i) {
                Vector2d p = cutStroke2D_[i];
                Vector2d d;
                if (0 < i)
                    d += p - cutStroke2D_[i - 1];
                if (i < cutStroke2D_.size() - 1)
                    d += cutStroke2D_[i + 1] - p;
                d = rotate90(d);
                d.normalize();
                d *= (core.ogl_.getWidth() + core.ogl_.getHeight()) * 0.001;
                rbfPoints.push_back(p + d);     rbfValues.push_back( 1);
                rbfPoints.push_back(p - d);     rbfValues.push_back(-1);
            }
            rbf.setPoints(rbfPoints);
            rbf.setValues(rbfValues);
            
            Mesh0& mesh0 = sweepObj.mesh0_ref_;
            // evaluate RBF values on sweepObject.mesh0_ face's barycenter
            Vector3d eyeDir = core.ogl_.viewParam_.focusPoint_ - core.ogl_.viewParam_.eyePoint_;
            for (Mesh0::VIter v = mesh0.vertices_begin(); v != mesh0.vertices_end(); ++v) {
                Vector3d  normal = mesh0.normal(v);
                if (0 < (normal | eyeDir))
                    continue;
                Vector3d& point3d = mesh0.point(v);
                Vector2d& point2d = Vector2d(core.ogl_.project(point3d));
                double rbfValue = rbf.getValue(point2d);
                if (0 < rbfValue)
                    continue;
                for (Mesh0::VFIter f = mesh0.vf_iter(v); f; ++f)
                    mesh0.data(f).flagGrain_ = mode_ == MODE_TURNON;
            }
        }
        cutStroke2D_.clear();
        cutStroke3D_.clear();
        core.ogl_.RedrawWindow();
    }
}
void StateGrain::OnRButtonDown(UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonDown_3D(nFlags, point); }
void StateGrain::OnRButtonUp  (UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonUp(nFlags, point); }
void StateGrain::OnMouseMove  (UINT nFlags, CPoint& point) {
    SweepObject& sweepObj = modeler.sweepObjects_[currentObjectID_];
    GrainObject& grainObj = sweepObj.grainObject_;
    if (core.eventHandler_.isLButtonDown_) {
        if (mode_ == MODE_TURNON || mode_ == MODE_TURNOFF) {
            Vector2d point2d(point.x, point.y);
            Vector3d point3d = core.ogl_.unproject(point2d);
            cutStroke2D_.push_back(point2d);
            cutStroke3D_.push_back(point3d);
            core.ogl_.RedrawWindow();
        } else if  (mode_ == MODE_MOVEREF) {
            Vector3d start, ori;
            core.ogl_.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
            Mesh0& mesh0 = sweepObj.mesh0_ref_;
            double min_dist = DBL_MAX;
            Mesh0::FHandle min_fhandle;
            Vector3d min_point;
            Vector3d min_normal;
            for (Mesh0::FIter f_it = mesh0.faces_begin(); f_it != mesh0.faces_end(); ++f_it) {
                Mesh0::FVIter fv_it = mesh0.fv_iter(f_it);
                Vector3d point[3];
                for (int i = 0; i < 3; ++i, ++fv_it)
                    point  [i] = mesh0.point(fv_it);
                Vector2d baryCoordLine;
                Vector3d baryCoordFace;
                Util::calcIntersectionLineTriangle(start, start + ori,
                    point[0], point[1], point[2],
                    baryCoordLine, baryCoordFace);
                if (baryCoordFace[0] < 0 || baryCoordFace[1] < 0 || baryCoordFace[2] < 0)
                    continue;
                if (min_dist < baryCoordLine[1])
                    continue;
                min_dist = baryCoordLine[1];
                min_fhandle = f_it.handle();
                min_point = baryCoordFace[0] * point[0] + baryCoordFace[1] * point[1] + baryCoordFace[2] * point[2];
                min_normal = (point[1] - point[0]) % (point[2] - point[0]);
            }
            if (min_fhandle.idx() == -1)
                return;
            refPoint_ = min_point;
            refPoint_normal_ = min_normal;
            refPoint_normal_.normalize();
            refPointMesh0Update();
            core.ogl_.RedrawWindow();
        } else if (mode_ == MODE_RADIUS || mode_ == MODE_OFFSET || mode_ == MODE_SCALE) {
            double d = 0.5 * grainObj.mesh0_ref_.bbox_.diagonal() * (point.x - point_old_.x) / core.ogl_.getWidth();
            if (mode_ == MODE_RADIUS) {
                grainObj.poissonRadius_ += d;
                if (grainObj.poissonRadius_ < 0.0001)
                    grainObj.poissonRadius_ = 0.0001;
            } else if (mode_ == MODE_OFFSET || mode_ == MODE_SCALE) {
                Mesh0& mesh0 = grainObj.mesh0_ref_;
                for (Mesh0::VIter v_it = mesh0.vertices_begin(); v_it != mesh0.vertices_end(); ++v_it)
                    if (mode_ == MODE_OFFSET)
                        mesh0.point(v_it)[0] += d;
                    else if (mode_ == MODE_SCALE)
                        mesh0.point(v_it) *= (1 + d);
            }
            point_old_ = point;
            refPointMesh0Update();
            core.ogl_.RedrawWindow();
        }
    }
    core.eventHandler_.default_OnMouseMove(nFlags, point);
}
void StateGrain::OnDropFiles(const std::string& fname, const std::string& ext) {
    if (ext == "step4") {
        ifstream ifs;
        ifs.open(fname.c_str(), ios::binary);
        if (!ifs) {
            cout << "Couldn't open file: " << fname << endl;
            return;
        }
        if (!modeler.load_Grain(ifs)) {
            cout << "Error occurred in Modeler::load_Grain()" << endl;
            return;
        }
        core.ogl_.RedrawWindow();
    }
}
void StateGrain::OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags) {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    SweepObject& sweepObj = modeler.sweepObjects_[currentObjectID_];
    
    switch (nChar) {
    case ' ':
        while (true) {
            currentObjectID_ = (currentObjectID_ + 1) % sz_sweepObjects;
            if (modeler.sweepObjects_[currentObjectID_].hasGrain_)
                break;
        }
        refPointInit();
        refPointMesh0Update();
        core.ogl_.RedrawWindow();
        break;
    case 'Q':
    case 'W':
    case 'E':
    case 'R':
    case 'T':
    case 'Y':
        mode_ =
            nChar == 'Q' ? MODE_TURNON  :
            nChar == 'W' ? MODE_TURNOFF :
            nChar == 'E' ? MODE_RADIUS  :
            nChar == 'R' ? MODE_OFFSET  :
            nChar == 'T' ? MODE_SCALE   : MODE_MOVEREF;
        core.ogl_.RedrawWindow();
        break;
    case VK_RETURN: // re-distribute
        sweepObj.distributeGrains(sweepObj.mesh0_ref_);
        core.ogl_.RedrawWindow();
        break;
    case 'S':   // save
        {
            CFileDialog dlg(FALSE, "step4", "*.step4", OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Step4 files|*.step4||");
            if (dlg.DoModal() != IDOK) return;
            ofstream ofs;
            ofs.open(dlg.GetPathName(), ios::trunc | ios::binary);
            if (!ofs) {
                cout << "Couldn't open file: " << dlg.GetPathName() << endl;
                return;
            }
            modeler.save_Grain(ofs);
        }
        break;
    }
}

void StateGrain::refPointMesh0Update() {
    Vector3d axisY = Vector3d(0, 1, 0);
    Vector3d axis1 = axisY - (axisY | refPoint_normal_) * refPoint_normal_;
    axis1.normalize();
    Vector3d axis2 = refPoint_normal_ % axis1;
    Matrix3x3d M;
    M.setCols(refPoint_normal_, axis1, axis2);
    refPoint_mesh0_ = modeler.sweepObjects_[currentObjectID_].grainObject_.mesh0_ref_;
    for (Mesh0::VIter v_it = refPoint_mesh0_.vertices_begin(); v_it != refPoint_mesh0_.vertices_end(); ++v_it) {
        Vector3d& pos = refPoint_mesh0_.point(v_it);
        pos = M * pos;
        pos += refPoint_;
    }
    refPoint_mesh0_.update_normals();
}
void StateGrain::refPointInit() {
    SweepObject& sweepObj = modeler.sweepObjects_[currentObjectID_];
    Mesh0& mesh0 = sweepObj.mesh0_ref_;
    Mesh0::VHandle v = mesh0.vertex_handle(rand() % mesh0.n_vertices());
    refPoint_ = mesh0.point(v);
    refPoint_normal_ = mesh0.normal(v);
}
