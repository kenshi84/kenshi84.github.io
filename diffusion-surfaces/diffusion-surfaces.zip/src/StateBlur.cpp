#include "StdAfx.h"
#include "StateBlur.h"
#include "StateSynthHrz.h"
#include "Core.h"
#include <gl/glut.h>

using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
Modeler& modeler = core.modeler_;
const double PAINT_SPHERE_RADIUS = 0.025;
const double BLUR_VALUE_MIN = 0.001;
void draw_mesh0_transparent(Mesh0& mesh0, int side, bool flipNormal = false) {
    glBegin(GL_TRIANGLES);
    for (Mesh0::FIter f_it = mesh0.faces_begin(); f_it != mesh0.faces_end(); ++f_it) {
        Vector3d point [3];
        Vector3d normal[3];
        Vector3d offset[3];
        Vector3d color [3];
        Vector3d back_color[3];
        Mesh0::FVIter fv_it = mesh0.fv_iter(f_it);
        for (int i = 0; i < 3; ++i, ++fv_it) {
            Mesh0::VertexData& vdata = mesh0.data(fv_it);
            point     [i] = mesh0.point (fv_it);
            normal    [i] = flipNormal ? -mesh0.normal(fv_it) : mesh0.normal(fv_it);
            offset    [i] = mesh0.normal(fv_it) * vdata.blurValue_;
            color     [i] = vdata.color_;
            back_color[i] = vdata.back_color_;
        }
        double a = 0.5;
        if (side == 0) {
            glColor4d(0.8, 0.8, 0.8, a);
            glNormal3dv(normal[0].ptr());    glVertex3dv(point[0].ptr());
            glNormal3dv(normal[1].ptr());    glVertex3dv(point[1].ptr());
            glNormal3dv(normal[2].ptr());    glVertex3dv(point[2].ptr());
        } else if (side == 1) {
            // front
            glNormal3dv(normal[0].ptr());    glColor4d(color[0][0], color[0][1], color[0][2], a);    glVertex3dv((point[0] + offset[0]).ptr());
            glNormal3dv(normal[1].ptr());    glColor4d(color[1][0], color[1][1], color[1][2], a);    glVertex3dv((point[1] + offset[1]).ptr());
            glNormal3dv(normal[2].ptr());    glColor4d(color[2][0], color[2][1], color[2][2], a);    glVertex3dv((point[2] + offset[2]).ptr());
        } else if (side == 2) {
            // back
            glNormal3dv(normal[0].ptr());    glColor4d(back_color[0][0], back_color[0][1], back_color[0][2], a);    glVertex3dv((point[0] - offset[0]).ptr());
            glNormal3dv(normal[1].ptr());    glColor4d(back_color[1][0], back_color[1][1], back_color[1][2], a);    glVertex3dv((point[1] - offset[1]).ptr());
            glNormal3dv(normal[2].ptr());    glColor4d(back_color[2][0], back_color[2][1], back_color[2][2], a);    glVertex3dv((point[2] - offset[2]).ptr());
        }
    }
    glEnd();
}
}

void StateBlur::initialize() {
    struct Local {
        static void clearBlur(Mesh0& mesh0) {
            for (Mesh0::VIter v = mesh0.vertices_begin(); v != mesh0.vertices_end(); ++v)
                mesh0.data(v).isConstrained_ = false;
            mesh0.hasBlur_ = false;
        }
    };
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    for (size_t i = 0; i < sz_sweepObjects; ++i) {
        SweepObject& sweepObj = modeler.sweepObjects_[i];
        Local::clearBlur(sweepObj.mesh0_ref_);
        if (sweepObj.hasGrain_)
            Local::clearBlur(sweepObj.grainObject_.mesh0_ref_);
    }
    currentObjectID_ = 0;
    dragged_v_idx_ = -1;
    glLineWidth(1);
}
void StateBlur::finalize() {
    struct Local {
        static void verifyBlur(Mesh0& mesh0) {
            double blurValueMin = BLUR_VALUE_MIN * mesh0.bbox_.diagonal();
            if (!mesh0.hasBlur_)
                return;
            for (Mesh0::VIter v = mesh0.vertices_begin(); v != mesh0.vertices_end(); ++v) {
                double& blurValue = mesh0.data(v).blurValue_;
                blurValue = max<double>(blurValue, blurValueMin);
            }
        }
    };
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    for (size_t i = 0; i < sz_sweepObjects; ++i) {
        SweepObject& sweepObj = modeler.sweepObjects_[i];
        Local::verifyBlur(sweepObj.mesh0_ref_);
        if (sweepObj.hasGrain_)
            Local::verifyBlur(sweepObj.grainObject_.mesh0_ref_);
    }
}
State* StateBlur::next() {
    return StateSynthHrz::getInstance();
}
Mesh0& StateBlur::currentMesh0() const {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    return currentObjectID_ < sz_sweepObjects
        ? modeler.sweepObjects_[currentObjectID_].mesh0_ref_
        : modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].grainObject_.mesh0_ref_;
}

void StateBlur::draw() {
    Mesh0& mesh0 = currentMesh0();

    glEnable(GL_LIGHTING);
    if (!mesh0.hasBlur_) {
        Drawer::draw_mesh_twosided(mesh0);
        glColor3d(0, 0, 0);
        Drawer::draw_mesh_edge(mesh0);
        return;
    }
    for (Mesh0::VIter v_it = mesh0.vertices_begin(); v_it != mesh0.vertices_end(); ++v_it) {
        if (!mesh0.data(v_it).isConstrained_)
            continue;
        if (v_it.handle().idx() == dragged_v_idx_)
            glColor3d(1, 0, 0);
        else
            glColor3d(0, 1, 0);
        glPushMatrix();
        Vector3d& point = mesh0.point(v_it);
        glTranslated(point[0], point[1], point[2]);
        glutSolidSphere(PAINT_SPHERE_RADIUS, 12, 12);
        glPopMatrix();
    }
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glCullFace(GL_FRONT);
    draw_mesh0_transparent(mesh0, 2, true);
    draw_mesh0_transparent(mesh0, 0, true);
    draw_mesh0_transparent(mesh0, 1, true);
    glCullFace(GL_BACK);
    draw_mesh0_transparent(mesh0, 2, false);
    draw_mesh0_transparent(mesh0, 0, false);
    draw_mesh0_transparent(mesh0, 1, false);
    glDisable(GL_BLEND);
    glEnable(GL_LIGHTING);
}
void StateBlur::OnLButtonDown(UINT nFlags, CPoint& point) {
    int v_idx = findIntersection(point);
    if (v_idx == -1)
        return;
    Mesh0& mesh0 = currentMesh0();
    
    Mesh0::VHandle vhandle = mesh0.vertex_handle(v_idx);
    if (!mesh0.data(vhandle).isConstrained_)
        return;
    dragged_v_idx_ = v_idx;
    point_old_ = point;
    core.ogl_.RedrawWindow();
}
void StateBlur::OnLButtonUp  (UINT nFlags, CPoint& point) {
    dragged_v_idx_ = -1;
    core.ogl_.RedrawWindow();
}
void StateBlur::OnRButtonDown(UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonDown_3D(nFlags, point); }
void StateBlur::OnRButtonUp  (UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonUp(nFlags, point); }
void StateBlur::OnMouseMove  (UINT nFlags, CPoint& point) {
    if (dragged_v_idx_ != -1) {
        Mesh0& mesh0 = currentMesh0();
        {   // update current blurValue constraint
            double d = 0.1 * (point.x - point_old_.x) * mesh0.bbox_.diagonal() / core.ogl_.getWidth();
            Mesh0::VHandle vhandle = mesh0.vertex_handle(dragged_v_idx_);
            double& blurValue = mesh0.data(vhandle).blurValue_;
            blurValue += d;
            double blurValueMin = BLUR_VALUE_MIN * mesh0.bbox_.diagonal();
            if (blurValue < blurValueMin)
                blurValue = blurValueMin;
        }
        mesh0.updateBlur();
        point_old_ = point;
        core.ogl_.RedrawWindow();
    }
    core.eventHandler_.default_OnMouseMove(nFlags, point);
}
void StateBlur::OnDropFiles(const std::string& fname, const std::string& ext) {
    if (ext == "step6") {
        ifstream ifs;
        ifs.open(fname.c_str(), ios::binary);
        if (!ifs) {
            cout << "Couldn't open file: " << fname << endl;
            return;
        }
        if (!modeler.load_Blur(ifs)) {
            cout << "Error occurred in Modeler::load_Blur()" << endl;
            return;
        }
        return;
    }
}
void StateBlur::OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags) {
    size_t sz_sweepObjects = modeler.sweepObjects_.size();
    Mesh0& mesh0 = currentMesh0();
    
    switch (nChar) {
    case ' ':
        ++currentObjectID_;
        if (sz_sweepObjects <= currentObjectID_) {
            while (true) {
                if (currentObjectID_ == 2 * sz_sweepObjects) {
                    currentObjectID_ = 0;
                    break;
                }
                if (modeler.sweepObjects_[currentObjectID_ - sz_sweepObjects].hasGrain_)
                    break;
                ++currentObjectID_;
            }
        }
        core.ogl_.RedrawWindow();
        break;
    case 'S':   // save
        {
            CFileDialog dlg(FALSE, "step6", "*.step6", OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Step6 files|*.step6||");
            if (dlg.DoModal() != IDOK) return;
            ofstream ofs;
            ofs.open(dlg.GetPathName(), ios::trunc | ios::binary);
            if (!ofs) {
                cout << "Couldn't open file: " << dlg.GetPathName() << endl;
                return;
            }
            modeler.save_Blur(ofs);
        }
        break;
    }
}

void StateBlur::OnLButtonDblClk(UINT nFlags, CPoint point) {
    int v_idx = findIntersection(point);
    if (v_idx == -1)
        return;
    
    Mesh0& mesh0 = currentMesh0();
    
    {   // update constraint flag & value
        Mesh0::VertexData& vdata = mesh0.data(mesh0.vertex_handle(v_idx));
        bool& isConstrained = vdata.isConstrained_;
        isConstrained = !isConstrained;
        if (isConstrained)
            vdata.blurValue_ = 0.005 * mesh0.bbox_.diagonal();
    }
    mesh0.updateBlur();
}

int StateBlur::findIntersection(CPoint point) {
    Mesh0& mesh0 = currentMesh0();
    
    Vector3d start, ori;
    core.ogl_.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
    double dist_min = DBL_MAX;
    Mesh0::VHandle vhandle_target;
    for (Mesh0::FIter f_it = mesh0.faces_begin(); f_it != mesh0.faces_end(); ++f_it) {
        Vector3d       point  [3];
        Mesh0::VHandle vhandle[3];
        Mesh0::FVIter fv_it = mesh0.fv_iter(f_it);
        for (int i = 0; i < 3; ++i, ++fv_it) {
            point  [i] = mesh0.point(fv_it);
            vhandle[i] = fv_it.handle();
        }
        Vector2d baryCoordLine;
        Vector3d baryCoordFace;
        Util::calcIntersectionLineTriangle(start, start + ori,
            point[0], point[1], point[2],
            baryCoordLine, baryCoordFace);
        double bary_max = 0;
        int index = -1;
        for (int i = 0; i < 3; ++i) {
            if (baryCoordFace[i] < 0) {
                index = -1;
                break;
            }
            if (bary_max < baryCoordFace[i]) {
                bary_max = baryCoordFace[i];
                index = i;
            }
        }
        if (index == -1)
            continue;
        if (dist_min < baryCoordLine[1])
            continue;
        dist_min = baryCoordLine[1];
        vhandle_target = vhandle[index];
    }
    return vhandle_target.idx();
}
