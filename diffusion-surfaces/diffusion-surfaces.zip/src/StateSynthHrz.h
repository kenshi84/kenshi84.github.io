#pragma once
#include "state.h"
#include <vector>

class StateSynthHrz : public State {
    StateSynthHrz(void) {}
    ~StateSynthHrz(void) {}
public:
    static StateSynthHrz* getInstance() {
        static StateSynthHrz p;
        return &p;
    }
    std::string message() { return "Step 7: Synthesize random variations"; }
    void initialize();
    bool isReady() { return true; }
    State* next();
    void draw();
    
    void OnLButtonDown(UINT nFlags, CPoint& point);
    void OnLButtonUp  (UINT nFlags, CPoint& point);
    void OnRButtonDown(UINT nFlags, CPoint& point);
    void OnRButtonUp  (UINT nFlags, CPoint& point);
    void OnMouseMove  (UINT nFlags, CPoint& point);
    void OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags);
};
