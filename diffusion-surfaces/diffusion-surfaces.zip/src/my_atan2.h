#pragma once
#include <cmath>

namespace {
double my_atan2(double y, double x) {
    double theta = std::atan2(y, x);
    if (theta < 0)
        theta += 2 * M_PI;
    return theta;
}
}
