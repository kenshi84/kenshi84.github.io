#include "StdAfx.h"
#include "Core.h"
#include "Pmvc.h"
#include "DiffusePmvcT.h"
#include <iterator>
using namespace std;
using namespace KLIB;

namespace {
OGL& ogl = Core::getInstance().ogl_;
}

vector<Vector3d> Pmvc::getColor(const ObjectInfo& sceneInfo, const vector<Vector3d>& posList) const {
    size_t sampleTotal = posList.size();
    vector<Vector3d> colorList;
    colorList.reserve(sampleTotal);
    
    const int& N = resolution_;            // area required per sample (width x height): (6 * N) x N
    const int& M = maxTextureSize_;      // available GPU buffer(width x height): M x M
    const int capacity_w = M / (6 * N);
    const int capacity_h = M / N;
    const int capacity   = capacity_w * capacity_h;
    static const Vector3d viewDirection[6] = { Vector3d( 1,  0,  0), Vector3d( 0, -1,  0), Vector3d(-1,  0,  0), Vector3d( 0,  1,  0), Vector3d( 0,  0,  1), Vector3d( 0,  0, -1) };
    static const Vector3d upDirection  [6] = { Vector3d( 0,  0,  1), Vector3d( 0,  0,  1), Vector3d( 0,  0,  1), Vector3d( 0,  0,  1), Vector3d( 0,  1,  0), Vector3d( 0,  1,  0) };
    
    ogl.makeOpenGLCurrent();
    
    fbo_.bind();
    
    glPushAttrib(GL_VIEWPORT_BIT | GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_PROJECTION);    // store and set modelview/projection matrices
    glPushMatrix();
    glLoadIdentity();
    gluPerspective(90.0, 1.0, sceneInfo.zNear_, sceneInfo.zFar_);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glDisable(GL_LIGHTING);
    glDisable(GL_BLEND);
    glEnable(GL_DEPTH_TEST);
    glClearColor(1, 1, 1, 1);
    
    size_t sampleIndex_begin = 0;
    while (true) {
        size_t sampleIndex_end = sampleIndex_begin + capacity;
        if (sampleIndex_end > sampleTotal)
            sampleIndex_end = sampleTotal;
        cout << ".";
        
        // render
        glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
        int iw = 0, ih = 0;
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        for (size_t sampleIndex = sampleIndex_begin; sampleIndex < sampleIndex_end; ++sampleIndex) {
            int offset_h = N * ih;
            int offset_w = 6 * N * iw;
            const Vector3d& pos = posList[sampleIndex];
            for (int i = 0; i < 6; ++i) {
                glViewport(offset_w + i * N, offset_h, N, N);
                glLoadIdentity();
                Vector3d center = pos + viewDirection[i];
                gluLookAt(pos[0], pos[1], pos[2], center[0], center[1], center[2], upDirection[i][0], upDirection[i][1], upDirection[i][2]);
                sceneInfo.displayList_.callList();
            }
            ++iw;
            if (iw == capacity_w) {
                iw = 0;
                ++ih;
            }
        }
        
        vector<Vector3d> colorListTemp = integrate(sceneInfo, sampleIndex_end - sampleIndex_begin);
        copy(colorListTemp.begin(), colorListTemp.end(), back_inserter(colorList));
        
        // proceed to the next sweep
        sampleIndex_begin = sampleIndex_end;
        if (sampleIndex_begin == sampleTotal)
            break;
    }
    
    // GL finalization
    glMatrixMode(GL_PROJECTION);    // store and set modelview/projection matrices
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glPopAttrib();
    
    fbo_.unbind();
    
    return colorList;
}

vector<Vector3d> Pmvc::integrate(const ObjectInfo& sceneInfo, size_t sampleNum) const {
    vector<Vector3d> colorList(sampleNum);
    
    const int& N = resolution_;
    const int& M = maxTextureSize_;
    const int capacity_w = M / (6 * N);
    const int capacity_h = M / N;
    const int capacity   = capacity_w * capacity_h;
    int width  = capacity_w * 6 * N;
    int height = capacity_h * N;
    
    // init GL settings
    glPushAttrib(GL_VIEWPORT_BIT | GL_ENABLE_BIT);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0.0, width, 0.0, height);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glViewport(0, 0, width, height);
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_BLEND);
    
    GLenum attachmentpoints[] = { GL_COLOR_ATTACHMENT0_EXT, GL_COLOR_ATTACHMENT1_EXT };
    glDrawBuffer(attachmentpoints[1]);    // output: tex1
    
    //==== transform depths to weights, multiply weights with colors ====//
    shaderIntegralPrepare_.enable();
    shaderIntegralPrepare_.setUniform1f("u_zNear", sceneInfo.zNear_);
    shaderIntegralPrepare_.setUniform1f("u_zFar" , sceneInfo.zFar_ );
    shaderIntegralPrepare_.setUniform1i("u_N", N);
    glActiveTextureARB(GL_TEXTURE2); texAreaWeight_.bind();
    glActiveTextureARB(GL_TEXTURE1); texDepth_     .bind();
    glActiveTextureARB(GL_TEXTURE0); texColor_[0]  .bind();
    glBegin(GL_QUADS);    // render
    glTexCoord2f(0,     0     );    glVertex2f(0,     0     );
    glTexCoord2f(width, 0     );    glVertex2f(width, 0     );
    glTexCoord2f(width, height);    glVertex2f(width, height);
    glTexCoord2f(0,     height);    glVertex2f(0,     height);
    glEnd();
    // unbind textures
    glActiveTextureARB(GL_TEXTURE2); texAreaWeight_.unbind();
    glActiveTextureARB(GL_TEXTURE1); texDepth_     .unbind();
    glActiveTextureARB(GL_TEXTURE0); texColor_[0]  .unbind();
    shaderIntegralPrepare_.disable();
    
    //==== reduction ====//
    int numPasses = static_cast<int>(log(N + 0.) / log(2.0));
    int texRead  = 1;
    int texWrite = 0;
    shaderIntegralReduce_.enable();
    for (int i = 0; i < numPasses; i++) {
        texColor_[texRead].bind();
        glDrawBuffer(attachmentpoints[texWrite]);
        width  /= 2;
        height /= 2;
        glBegin(GL_QUADS);
        glTexCoord2f(0,     0     );    glVertex2f(0,     0     );
        glTexCoord2f(width, 0     );    glVertex2f(width, 0     );
        glTexCoord2f(width, height);    glVertex2f(width, height);
        glTexCoord2f(0,     height);    glVertex2f(0,     height);
        glEnd();
        swap(texRead, texWrite);
    }
    texColor_[0].unbind();
    shaderIntegralReduce_.disable();
    assert(width == 6 * capacity_w && height == capacity_h);
    
    //==== read back to CPU ====//
    vector<Vector4f> data(6 * capacity_w * capacity_h);
    glFinish();
    glReadBuffer(attachmentpoints[texRead]);
    glReadPixels(0, 0, 6 * capacity_w, capacity_h, GL_RGBA, GL_FLOAT, &data[0]);
    glFinish();
    for (size_t sampleIndex = 0; sampleIndex < sampleNum; ++sampleIndex) {
        Vector4f sum;
        for (int i = 0; i < 6; ++i)
            sum += data[6 * sampleIndex + i];
        colorList[sampleIndex].set(sum.x_, sum.y_, sum.z_);
        colorList[sampleIndex] /= sum.w_;
    }
    
    glMatrixMode(GL_PROJECTION);    // restore projection/modelview matrices
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glPopAttrib();
    
    return colorList;
}

void Pmvc::gl_init() {
    glGetIntegerv(GL_MAX_TEXTURE_SIZE, &maxTextureSize_);
    cout << "GL_MAX_TEXTURE_SIZE: " << maxTextureSize_ << endl;
    maxTextureSize_ /= 2;
    const int& N = resolution_;
    const int& M = maxTextureSize_;
    
    fbo_.init();
    fbo_.bind();
    
    texDepth_.init(GL_TEXTURE_RECTANGLE_ARB, GL_CLAMP, GL_NEAREST, GL_REPLACE);
    texDepth_.bind();
    texDepth_.allocate(GL_DEPTH_COMPONENT32, M, M, GL_DEPTH_COMPONENT);
    texDepth_.unbind();
    fbo_.attachTexture(GL_DEPTH_ATTACHMENT_EXT, texDepth_);
    for (int i = 0; i < 2; ++i) {
        texColor_[i].init(GL_TEXTURE_RECTANGLE_ARB, GL_CLAMP, GL_NEAREST, GL_REPLACE);
        texColor_[i].bind();
        texColor_[i].allocate(GL_FLOAT_RGBA32_NV, M, M, GL_RGBA);
        texColor_[i].unbind();
        fbo_.attachTexture(GL_COLOR_ATTACHMENT0_EXT + i, texColor_[i]);
    }
    GLUtil::checkFramebufferStatus("Pmvc::gl_init()");
    fbo_.unbind();
    
    {   // pixel weights based on their areas projected to a unit sphere
        std::vector<float> areaWeight(N * N, 0);
        int n = N / 2;
        float d = 1.0f / n;
        Vector3f dx(d, 0, 0);
        Vector3f dy(0, d, 0);
        for (int i = 0; i < n; ++i) for (int j = 0; j <= i; ++j) {
            Vector3f h0(- i      * d, - j      * d, 1);
            Vector3f h1(-(i + 1) * d, -(j + 1) * d, 1);
            Vector3f n0 = dx % h0;
            Vector3f n1 = dy % h0;
            Vector3f n2 = dx % h1;
            Vector3f n3 = dy % h1;
            n0.normalize();
            n1.normalize();
            n2.normalize();
            n3.normalize();
            float theta0 = acos( n0 | n1);
            float theta1 = acos(-n1 | n2);
            float theta2 = acos( n2 | n3);
            float theta3 = acos(-n3 | n0);
            float weight = theta0 + theta1 + theta2 + theta3 - 2 * M_PI;
            areaWeight[n + i     + N * (n + j    )] = weight;
            areaWeight[n - i - 1 + N * (n + j    )] = weight;
            areaWeight[n + i     + N * (n - j - 1)] = weight;
            areaWeight[n - i - 1 + N * (n - j - 1)] = weight;
            if (i == j) continue;
            areaWeight[n + j     + N * (n + i    )] = weight;
            areaWeight[n - j - 1 + N * (n + i    )] = weight;
            areaWeight[n + j     + N * (n - i - 1)] = weight;
            areaWeight[n - j - 1 + N * (n - i - 1)] = weight;
        }
        texAreaWeight_.init(GL_TEXTURE_RECTANGLE_ARB, GL_CLAMP, GL_NEAREST, GL_REPLACE);
        texAreaWeight_.bind();
        texAreaWeight_.allocate(GL_FLOAT_R32_NV, N, N, GL_LUMINANCE, GL_FLOAT, &areaWeight[0]);
        texAreaWeight_.unbind();
    }
    
    shaderIntegralPrepare_.init();
    shaderIntegralPrepare_.attach(ShaderObject("PmvcIntegralPrepare.frag", ShaderObject::FRAGMENT_SHADER));
    shaderIntegralPrepare_.link();
    shaderIntegralPrepare_.enable();
    shaderIntegralPrepare_.setUniform1i("u_texColor",      0);
    shaderIntegralPrepare_.setUniform1i("u_texDepth",      1);
    shaderIntegralPrepare_.setUniform1i("u_texAreaWeight", 2);
    shaderIntegralPrepare_.disable();
    
    shaderIntegralReduce_.init();
    shaderIntegralReduce_.attach(ShaderObject("PmvcIntegralReduce.frag", ShaderObject::FRAGMENT_SHADER));
    shaderIntegralReduce_.link();
}

void Pmvc::gl_deinit() {
    fbo_.deinit();
    texDepth_.deinit();
    texColor_[0].deinit();
    texColor_[1].deinit();
    texAreaWeight_.deinit();
    shaderIntegralPrepare_.deinit();
    shaderIntegralReduce_.deinit();
}

Pmvc::Pmvc(unsigned int resolution)
    : resolution_(resolution)
    , maxTextureSize_()
{}

void Pmvc::ObjectInfo::preprocess(VolumeObject& volObj) {
    // displayList_
    displayList_.newList(true);
    glBegin(GL_TRIANGLES);
    for (size_t i = 0; i < volObj.srfMeshes_.size(); ++i) {
        Mesh0& mesh0 = volObj.srfMeshes_[i].mesh0_;
        for (Mesh0::FIter f = mesh0.faces_begin(); f != mesh0.faces_end(); ++f) {
            // front
            Mesh0::HHandle h = mesh0.halfedge_handle(f);
            for (int j = 0; j < 3; ++j) {
                Mesh0::VHandle v = mesh0.to_vertex_handle(h);
                glColor3d (mesh0.data  (v).color_);
                glVertex3d(mesh0.point (v));
                h = mesh0.next_halfedge_handle(h);
            }
            // back
            for (int j = 0; j < 3; ++j) {
                Mesh0::VHandle v = mesh0.to_vertex_handle(h);
                glColor3d (mesh0.data (v).back_color_);
                glVertex3d(mesh0.point(v));
                h = mesh0.prev_halfedge_handle(h);
            }
        }
    }
    glEnd();
    displayList_.endList();
    // zNear_, zFar_
    zNear_ = DBL_MAX;
    for (size_t i = 0; i < volObj.srfMeshes_.size(); ++i) {
        Mesh0& mesh0 = volObj.srfMeshes_[i].mesh0_;
        for (Mesh0::EIter e = mesh0.edges_begin(); e != mesh0.edges_end(); ++e) {
            Vector3d point[2];
            for (int j = 0; j < 2; ++j)
                point[j] = mesh0.point(mesh0.to_vertex_handle(mesh0.halfedge_handle(e, j)));
            double len = (point[1] - point[0]).length();
            if (len < zNear_)
                zNear_ = len;
        }
    }
    zNear_ *= 0.01;
    zFar_= volObj.bbox_.diagonal();
}
