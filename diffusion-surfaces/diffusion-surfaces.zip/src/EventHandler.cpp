#include "StdAfx.h"
#include "EventHandler.h"
#include "DiffusionSurfaces.h"
#include "Core.h"
#include <KLIB/Util.h>
#include <iostream>
#include <algorithm>
using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
}

void EventHandler::OnLButtonDown(UINT nFlags, CPoint point) { isLButtonDown_ = true;  core.state_->OnLButtonDown(nFlags, point); }
void EventHandler::OnLButtonUp  (UINT nFlags, CPoint point) { isLButtonDown_ = false; core.state_->OnLButtonUp  (nFlags, point); }
void EventHandler::OnRButtonDown(UINT nFlags, CPoint point) { isRButtonDown_ = true;  core.state_->OnRButtonDown(nFlags, point); }
void EventHandler::OnRButtonUp  (UINT nFlags, CPoint point) { isRButtonDown_ = false; core.state_->OnRButtonUp  (nFlags, point); }
void EventHandler::OnMButtonDown(UINT nFlags, CPoint point) { isMButtonDown_ = true;  core.state_->OnMButtonDown(nFlags, point); }
void EventHandler::OnMButtonUp  (UINT nFlags, CPoint point) { isMButtonDown_ = false; core.state_->OnMButtonUp  (nFlags, point); }
void EventHandler::OnMouseMove(UINT nFlags, CPoint point) { core.state_->OnMouseMove(nFlags, point); }
void EventHandler::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) {
    core.state_->OnKeyDown(nChar, nRepCnt, nFlags);
    default_OnKeyDown(nChar, nRepCnt, nFlags);
}
void EventHandler::OnDropFiles  (HDROP hDropInfo) {
    char buf[256];
    if (DragQueryFile(hDropInfo, -1, buf, sizeof(buf)) != 1) return;
    DragQueryFile(hDropInfo, 0, buf, sizeof(buf));
    string fname(buf);
    size_t pos = fname.rfind(".");
    string ext = pos == -1 ? "" : fname.substr(pos + 1);
    transform(ext.begin(), ext.end(), ext.begin(), tolower);
    core.state_->OnDropFiles(fname, ext);
}
void EventHandler::OnLButtonDblClk(UINT nFlags, CPoint point) { core.state_->OnLButtonDblClk(nFlags, point); }

void EventHandler::default_OnRButtonDown_3D(UINT nFlags, CPoint point) {
    int width  = core.ogl_.getWidth ();
    int height = core.ogl_.getHeight();
    if (width * 0.9 < point.x) {
        core.ogl_.ButtonDownForZoom(point);
    } else if (nFlags & MK_CONTROL) {
        core.ogl_.ButtonDownForTranslate(point);
    } else {
        core.ogl_.ButtonDownForRotate(point);
    }
}
void EventHandler::default_OnRButtonDown_2D(UINT nFlags, CPoint point) {
    int width  = core.ogl_.getWidth ();
    int height = core.ogl_.getHeight();
    if (width * 0.9 < point.x) {
        core.ogl_.ButtonDownForZoom(point);
    } else {
        core.ogl_.ButtonDownForTranslate(point);
    }
}
void EventHandler::default_OnRButtonUp  (UINT nFlags, CPoint point) {
    core.ogl_.ButtonUp();
}
void EventHandler::default_OnMButtonDown(UINT nFlags, CPoint point) {
    core.ogl_.ButtonDownForTranslate(point);
}
void EventHandler::default_OnMButtonUp  (UINT nFlags, CPoint point) {
    core.ogl_.ButtonUp();
}
void EventHandler::default_OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) {
    switch (nChar) {
        case VK_TAB:
            if (core.state_->isReady())
                core.app_->OnStepNext();
            break;
    }
}
void EventHandler::default_OnMouseMove(UINT nFlags, CPoint point) {
    core.ogl_.MouseMove(point);
}

