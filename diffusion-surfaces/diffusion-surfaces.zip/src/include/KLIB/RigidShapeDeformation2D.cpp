#include "StdAfx.h"
#include "RigidShapeDeformation2D.h"

#include <cassert>
#include <algorithm>

using namespace std;

namespace KLIB {

void RigidShapeDeformation2D::init(
	const vector<Vector2d>& rest_vtx_position,
	const vector<int>& face_vtx_index)
{
	assert(face_vtx_index.size() % 3 == 0);
	num_vtx_ = rest_vtx_position.size();
	num_face_ = face_vtx_index.size() / 3;
	// store rest shape
	rest_vtx_position_ = rest_vtx_position;
	face_vtx_index_    = face_vtx_index;
	
    TRACE("setting up step1 matrix...");
    vector<CholmodMatrix::Triplet> triplets;
    triplets.reserve(30 * num_face_);
	for (size_t i = 0; i < num_face_; ++i) {
		int indices[3] = { face_vtx_index[3 * i], face_vtx_index[3 * i + 1], face_vtx_index[3 * i + 2] };
		for (int j0 = 0; j0 < 3; ++j0) {
			// 2 parameters w and h, such that
			// v2 = v0 + w * v01 + h * v01_rot90
			int j1 = (j0 + 1) % 3;
			int j2 = (j0 + 2) % 3;
			Vector2d v01 = rest_vtx_position[indices[j1]];
			Vector2d v02 = rest_vtx_position[indices[j2]];
			v01 -= rest_vtx_position[indices[j0]];
			v02 -= rest_vtx_position[indices[j0]];
			Vector2d v01_t = rotate90(v01);
			double lenSq = v01.lengthSquared();
			double w = v01  .dot_product(v02) / lenSq;
			double h = v01_t.dot_product(v02) / lenSq;
			// x-dir
            triplets.push_back(CholmodMatrix::Triplet(6 * i + 2 * j0    , 2 * indices[j0]    , 1 - w));
            triplets.push_back(CholmodMatrix::Triplet(6 * i + 2 * j0    , 2 * indices[j0] + 1, h    ));
            triplets.push_back(CholmodMatrix::Triplet(6 * i + 2 * j0    , 2 * indices[j1]    , w    ));
            triplets.push_back(CholmodMatrix::Triplet(6 * i + 2 * j0    , 2 * indices[j1] + 1, -h   ));
            triplets.push_back(CholmodMatrix::Triplet(6 * i + 2 * j0    , 2 * indices[j2]    , -1   ));
			// y-dir
            triplets.push_back(CholmodMatrix::Triplet(6 * i + 2 * j0 + 1, 2 * indices[j0]    , -h   ));
            triplets.push_back(CholmodMatrix::Triplet(6 * i + 2 * j0 + 1, 2 * indices[j0] + 1, 1 - w));
            triplets.push_back(CholmodMatrix::Triplet(6 * i + 2 * j0 + 1, 2 * indices[j1]    , h    ));
            triplets.push_back(CholmodMatrix::Triplet(6 * i + 2 * j0 + 1, 2 * indices[j1] + 1, w    ));
            triplets.push_back(CholmodMatrix::Triplet(6 * i + 2 * j0 + 1, 2 * indices[j2] + 1, -1   ));
		}
	}
    CholmodMatrix step1_A(6 * num_face_, 2 * num_vtx_, triplets);
    CholmodMatrix step1_At = step1_A.transpose();
    step1_AtA_ = step1_At * step1_A;
	TRACE("done!\n");
	// calc A_step2
	TRACE("setting up step2 matrix...");
    triplets.clear();
    triplets.reserve(6 * num_face_);
	for (int i = 0; i < num_face_; ++i) {
		int indices[3] = { face_vtx_index[3 * i], face_vtx_index[3 * i + 1], face_vtx_index[3 * i + 2] };
		for (int j0 = 0; j0 < 3; ++j0) {
			int j1 = (j0 + 1) % 3;
            triplets.push_back(CholmodMatrix::Triplet(3 * i + j0, indices[j0], -1));
            triplets.push_back(CholmodMatrix::Triplet(3 * i + j0, indices[j1],  1));
		}
	}
    CholmodMatrix step2_A(3 * num_face_, num_vtx_, triplets);
    step2_At_ = step2_A.transpose();
    step2_AtA_ = step2_At_ * step2_A;
	TRACE("done!\n");
}

void RigidShapeDeformation2D::compile(const vector<int>& is_vtx_constrained) {
	assert(is_vtx_constrained.size() == num_vtx_);
	is_vtx_constrained_ = is_vtx_constrained;
	
    vector<CholmodMatrix::Triplet> step1_triplets;
    vector<CholmodMatrix::Triplet> step2_triplets;

    num_const_ = 0;
	for (int i = 0; i < num_vtx_; ++i) {
		if (is_vtx_constrained[i] == 0) continue;
        step1_triplets.push_back(CholmodMatrix::Triplet(2 * num_const_,     2 * i,     1));
        step1_triplets.push_back(CholmodMatrix::Triplet(2 * num_const_ + 1, 2 * i + 1, 1));
        step2_triplets.push_back(CholmodMatrix::Triplet(    num_const_,         i,     1));
        ++num_const_;
	}
    CholmodMatrix step1_C(2 * num_const_, 2 * num_vtx_, step1_triplets);
    CholmodMatrix step2_C(    num_const_,     num_vtx_, step2_triplets);
    CholmodMatrix step1_Ct = step1_C.transpose();
    CholmodMatrix step2_Ct = step2_C.transpose();
    CholmodMatrix step1_M = step1_AtA_.horzcat(step1_Ct).vertcat(step1_C.horzcat(CholmodMatrix::zero(2 * num_const_, 2 * num_const_)));
    CholmodMatrix step2_M = step2_AtA_.horzcat(step2_Ct).vertcat(step2_C.horzcat(CholmodMatrix::zero(    num_const_,     num_const_)));
    
    step1_umfpack_.factorize(2 * (num_vtx_ + num_const_), step1_M.getAp(), step1_M.getAi(), step1_M.getAx());
    step2_umfpack_.factorize(     num_vtx_ + num_const_,  step2_M.getAp(), step2_M.getAi(), step2_M.getAx());
}

vector<Vector2d> RigidShapeDeformation2D::deform(const vector<Vector2d>& constrained_vtx_position) {
    // step 1: compute conformal(=angle preserving) deformation (allows uniform scaling)
    vector<double> step1_d;
    step1_d.reserve(2 * num_const_);
    for (size_t i = 0; i < num_vtx_; ++i) {
        if (is_vtx_constrained_[i] == 0) continue;
        const Vector2d& c = constrained_vtx_position[i];
        step1_d.push_back(c[0]);
        step1_d.push_back(c[1]);
    }
    assert(step1_d.size() == 2 * num_const_);
    vector<double> step1_rhs(2 * (num_vtx_ + num_const_), 0);
    memcpy(&step1_rhs[2 * num_vtx_], &step1_d[0], sizeof(double) * 2 * num_const_);
    vector<double> step1_v;
    step1_umfpack_.solve(step1_rhs, step1_v);
    vector<Vector2d> step1_result(num_vtx_);
    for (int i = 0; i < num_vtx_; ++i)
        step1_result[i] = Vector2d(&step1_v[2 * i]);
    
    // step 2: adjust scale using rotation from step 1
    vector<double> step2_bx(3 * num_face_), step2_by(3 * num_face_);
    for (size_t i = 0; i < num_face_; ++i) {
        int indices[3] = { face_vtx_index_[3 * i], face_vtx_index_[3 * i + 1], face_vtx_index_[3 * i + 2] };
        for (int j = 0; j < 3; ++j) {
            int ev0 = indices[j];
            int ev1 = indices[(j + 1) % 3];
            Vector2d rest_edge  = rest_vtx_position_[ev1] - rest_vtx_position_[ev0];
            Vector2d step1_edge = step1_result      [ev1] - step1_result      [ev0];
            step1_edge.normalize();
            step1_edge *= rest_edge.length();
            step2_bx[3 * i + j] = step1_edge[0];
            step2_by[3 * i + j] = step1_edge[1];
        }
    }
    VectorVLd step2_Atbx = step2_At_ * VectorVLd(step2_bx);
    VectorVLd step2_Atby = step2_At_ * VectorVLd(step2_by);
    vector<double> step2_dx;
    vector<double> step2_dy;
    step2_dx.reserve(num_const_);
    step2_dy.reserve(num_const_);
    for (size_t i = 0; i < num_vtx_; ++i) {
        if (is_vtx_constrained_[i] == 0) continue;
        const Vector2d& c = constrained_vtx_position[i];
        step2_dx.push_back(c[0]);
        step2_dy.push_back(c[1]);
    }
    assert(step2_dx.size() == num_const_ && step2_dy.size() == num_const_);
    vector<double> step2_rhsx(num_vtx_ + num_const_);
    vector<double> step2_rhsy(num_vtx_ + num_const_);
    memcpy(&step2_rhsx[0], &step2_Atbx[0], sizeof(double) * num_vtx_);
    memcpy(&step2_rhsy[0], &step2_Atby[0], sizeof(double) * num_vtx_);
    memcpy(&step2_rhsx[num_vtx_], &step2_dx[0], sizeof(double) * num_const_);
    memcpy(&step2_rhsy[num_vtx_], &step2_dy[0], sizeof(double) * num_const_);
    
    vector<double> step2_vx;
    vector<double> step2_vy;
    step2_umfpack_.solve(step2_rhsx, step2_vx);
    step2_umfpack_.solve(step2_rhsy, step2_vy);
    
    vector<Vector2d> step2_result(num_vtx_);
    for (size_t i = 0; i < num_vtx_; ++i)
        step2_result[i] = Vector2d(step2_vx[i], step2_vy[i]);
    
    return step2_result;
}

}
