#pragma once
#include "MatrixVL.h"
#include "LapackWrapper.h"
#include <vector>
#include <cassert>

namespace KLIB {

class PCA {
public:
    static void go(
        const std::vector<VectorVLd>& in_samples,
        VectorVLd& out_mean, std::vector<VectorVLd>& out_eigenvectors, std::vector<double>& out_eigenvalues)
    {
        const size_t N = in_samples.size();
        const size_t P = in_samples.front().size();
        out_mean.clear();
        out_mean.resize(P, 0.);
        for (size_t i = 0; i < N; ++i) {
            assert(in_samples[i].size() == P);
            out_mean += in_samples[i];
        }
        out_mean /= N;
        MatrixVLd covariance(P, P);
        for (size_t i = 0; i < P; ++i) {
            for (size_t j = i; j < P; ++j) {
                double sum = 0;
                for (size_t k = 0; k < N; ++k)
                    sum += (in_samples[k][i] - out_mean[i]) * (in_samples[k][j] - out_mean[j]);
                sum /= N - 1;
                covariance(i, j) = covariance(j, i) = sum;
            }
        }
        std::vector<VectorVLd> eigenvectors;
        std::vector<double>    eigenvalues_real;
        std::vector<double>    eigenvalues_img;
        LapackWrapper::eigen(covariance, eigenvectors, eigenvalues_real, eigenvalues_img);
        const double EPSILON = 1.0e-10;
        out_eigenvectors.clear();
        out_eigenvalues .clear();
        out_eigenvectors.reserve(eigenvectors.size());
        out_eigenvalues .reserve(eigenvectors.size());
        for (size_t i = 0; i < P; ++i) {
            assert(abs(eigenvalues_img[i]) < EPSILON);
            if (abs(eigenvalues_real[i]) < EPSILON)
                continue;
            out_eigenvectors.push_back(eigenvectors[i]);
            out_eigenvalues .push_back(eigenvalues_real[i]);
        }
    }
};
}   // namespace KLIB
