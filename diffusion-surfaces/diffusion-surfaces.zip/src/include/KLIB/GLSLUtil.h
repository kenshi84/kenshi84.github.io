#pragma once
#include <GL/glew.h>
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include "Matrix.h"
#include "Vector.h"
#include "GLUtil.h"

namespace KLIB {

class ShaderObject {
public:
    enum ShaderType {
        FRAGMENT_SHADER,
        VERTEX_SHADER
    };
private:
    GLhandleARB	handle_;
    std::string	filename_;
    std::string	id_;
    std::string	source_;
    ShaderType type_;
    ShaderObject(const ShaderObject& src);  // no copy constructor
    ShaderObject& operator=(const ShaderObject& src);  // no substitution operator
public:
    ShaderObject() : handle_(0) {}
    ShaderObject( const std::string& filename, ShaderType type) { loadFile(filename.c_str(), type); }
    ShaderObject( const char* filename, ShaderType type) { loadFile(filename, type); }
    ~ShaderObject() { if (handle_) glDeleteObjectARB( handle_ ); }
    void loadFile( const char* filename, ShaderType type) { loadFile(std::string(filename), type); }
    void loadFile( const std::string& filename, ShaderType type) {
        filename_ = id_ = filename;
	    // open source file
        std::ifstream f_in( filename_.c_str(), std::ios::binary );
	    if ( f_in.fail()) {
		    std::cerr << "ShaderObject::ShaderObject() - cannot open file: "
			     << filename << std::endl;
            return;
	    }
        std::ostringstream str_out;
	    str_out << f_in.rdbuf();
	    f_in.close();
        setSource(str_out.str(), type);
    }
    std::string id() const { return id_; }
    void setId(const std::string& id) { id_ = id;}
    void setSource( const char* source, ShaderType type) { setSource(std::string(source), type); }
    void setSource( const std::string& source, ShaderType type) {
	    source_ = source;
	    // create
        type_ = type;
        handle_ = glCreateShaderObjectARB( type_ == FRAGMENT_SHADER ? GL_FRAGMENT_SHADER_ARB : GL_VERTEX_SHADER_ARB);
        GLUtil::checkError("ShaderObject::loadSource() - cannot create");
	    // set shader source
        int len = static_cast<int>(source.length());
        const char *source_ptr = source.c_str();
	    glShaderSourceARB( handle_, 1, &source_ptr, &len );
        GLUtil::checkError("ShaderObject::loadSource() - cannot set shader source");
	    // compile
	    compile();
    }
    void compile() {
	    // compile
	    glCompileShaderARB( handle_ );
	    // check errors
	    GLint	result;
	    glGetObjectParameterivARB( handle_, GL_OBJECT_COMPILE_STATUS_ARB, &result );
	    if (!GLUtil::checkError("ShaderObject::compile() - compile errror. (" + filename_ + ")") || result == GL_FALSE ) {
		    int	length;
		    glGetObjectParameterivARB( handle_, GL_OBJECT_INFO_LOG_LENGTH_ARB, &length );
		    if ( length > 0 ) {
			    int	l;
			    GLcharARB *info_log = new GLcharARB[ length ];
			    glGetInfoLogARB( handle_, length, &l, info_log );
                std::cerr << "(id:" << id_ << ") " << info_log << std::endl;
			    delete [] info_log;
		    }
	    }
    }
    GLhandleARB handle() const { return handle_; }
};

class	ProgramObject {
private:
    GLhandleARB	handle_;
    ProgramObject(const ProgramObject& src );   // no copy constructor
    ProgramObject& operator=(const ProgramObject& src );   // no substituion operator
    std::string id_;
    std::map<std::string, GLint> attribLocation_;
public:
    ProgramObject() : handle_(0) {}
    void init() {
        deinit();
        handle_ = glCreateProgramObjectARB();
        GLUtil::checkError(id_ + "::init()");
    }
    void deinit() {
        if (handle_) {
            glDeleteObjectARB( handle_); 
            handle_ = 0;
        }
        GLUtil::checkError(id_ + "::deinit()");
    }
    
    GLhandleARB handle() const { return handle_; }
    void attach(const ShaderObject& s) {
	    glAttachObjectARB( handle_, s.handle());
        id_ = s.id();
        GLUtil::checkError(id_ + "::attach()");
    }
    std::string id() const { return id_; }
    void setId(const std::string& id) { id_ = id; }
    void link(void) const {
	    glLinkProgramARB( handle_ );
	    GLint result;
	    glGetObjectParameterivARB( handle_, GL_OBJECT_LINK_STATUS_ARB, &result );
	    if (!GLUtil::checkError(id_ + "::link()") || result == GL_FALSE ) {
		    int	length;
		    glGetObjectParameterivARB( handle_, GL_OBJECT_INFO_LOG_LENGTH_ARB, &length );
		    if ( length > 0 ) {
			    int	l;
			    GLcharARB *info_log = new GLcharARB[ length ];
			    glGetInfoLogARB( handle_, length, &l, info_log );
                std::cerr << "(id:" << id_ << ") " << info_log << std::endl;
			    delete [] info_log;
		    }
	    }
        GLUtil::checkError(id_ + "::link()");
    }
    void enable() const {
	    glUseProgramObjectARB( handle_ );
        GLUtil::checkError(id_ + "::enable()");
    }

    void disable() const { glUseProgramObjectARB( 0 ); }

    GLint getUniformLocation(const char *name ) const {
        GLint ul = glGetUniformLocationARB(handle_, name);
        if ( ul == -1 ) {
            std::cerr << "(id:" << id_ << ") no such uniform named " << name << std::endl;
        }
        return ul;
    }

    GLint getAttribLocation( const char *name ) const {
        GLint al = glGetAttribLocationARB( handle_, name );
        if ( al == -1 ) {
            std::cerr << "(id:" << id_ << ") no such attrib named " << name << std::endl;
        }
        return al;
    }

    void clearAttribLocation() { attribLocation_.clear(); }
    bool storeAttribLocation( const std::string& name) {
        if (attribLocation_.count(name) != 0)
            return false;
        GLint location = getAttribLocation(name.c_str());
        if (location == -1)
            return false;
        attribLocation_.insert(std::pair<std::string, GLint>(name, location));
        return true;
    }
    
    // uniform variable

    // int
    void setUniform1i( const char *name, GLint v0 )                               const { glUniform1iARB( getUniformLocation( name ), v0 ); }
    void setUniform2i( const char *name, GLint v0, GLint v1 )                     const { glUniform2iARB( getUniformLocation( name ), v0, v1 ); }
    void setUniform3i( const char *name, GLint v0, GLint v1, GLint v2 )           const { glUniform3iARB( getUniformLocation( name ), v0, v1, v2 ); }
    void setUniform4i( const char *name, GLint v0, GLint v1, GLint v2, GLint v3 ) const { glUniform4iARB( getUniformLocation( name ), v0, v1, v2, v3 ); }
    void setUniform1i( GLint location, GLint v0 )                               const { glUniform1iARB( location, v0 ); }
    void setUniform2i( GLint location, GLint v0, GLint v1 )                     const { glUniform2iARB( location, v0, v1 ); }
    void setUniform3i( GLint location, GLint v0, GLint v1, GLint v2 )           const { glUniform3iARB( location, v0, v1, v2 ); }
    void setUniform4i( GLint location, GLint v0, GLint v1, GLint v2, GLint v3 ) const { glUniform4iARB( location, v0, v1, v2, v3 ); }
    void setUniform1i( const std::string& name, GLint v0 )                               const { glUniform1iARB( getUniformLocation( name.c_str() ), v0 ); }
    void setUniform2i( const std::string& name, GLint v0, GLint v1 )                     const { glUniform2iARB( getUniformLocation( name.c_str() ), v0, v1 ); }
    void setUniform3i( const std::string& name, GLint v0, GLint v1, GLint v2 )           const { glUniform3iARB( getUniformLocation( name.c_str() ), v0, v1, v2 ); }
    void setUniform4i( const std::string& name, GLint v0, GLint v1, GLint v2, GLint v3 ) const { glUniform4iARB( getUniformLocation( name.c_str() ), v0, v1, v2, v3 ); }
    
    // Vector argument
    void setUniform2i( const char *name, const Vector2i& v ) const { setUniform2i(name, v[0], v[1]); }
    void setUniform3i( const char *name, const Vector3i& v ) const { setUniform3i(name, v[0], v[1], v[2]); }
    void setUniform4i( const char *name, const Vector4i& v ) const { setUniform4i(name, v[0], v[1], v[2], v[3]); }
    void setUniform2i( GLint location, const Vector2i& v ) const { setUniform2i(location, v[0], v[1]); }
    void setUniform3i( GLint location, const Vector3i& v ) const { setUniform3i(location, v[0], v[1], v[2]); }
    void setUniform4i( GLint location, const Vector4i& v ) const { setUniform4i(location, v[0], v[1], v[2], v[3]); }
    void setUniform2i( const std::string& name, const Vector2i& v ) const { setUniform2i(name, v[0], v[1]); }
    void setUniform3i( const std::string& name, const Vector3i& v ) const { setUniform3i(name, v[0], v[1], v[2]); }
    void setUniform4i( const std::string& name, const Vector4i& v ) const { setUniform4i(name, v[0], v[1], v[2], v[3]); }
    
    // int array
    void setUniform1iv( const char *name, GLuint count, const GLint *v ) const { glUniform1ivARB( getUniformLocation( name ), count, v ); }
    void setUniform2iv( const char *name, GLuint count, const GLint *v ) const { glUniform2ivARB( getUniformLocation( name ), count, v ); }
    void setUniform3iv( const char *name, GLuint count, const GLint *v ) const { glUniform3ivARB( getUniformLocation( name ), count, v ); }
    void setUniform4iv( const char *name, GLuint count, const GLint *v ) const { glUniform4ivARB( getUniformLocation( name ), count, v ); }
    void setUniform1iv( GLint location, GLuint count, const GLint *v ) const { glUniform1ivARB( location, count, v ); }
    void setUniform2iv( GLint location, GLuint count, const GLint *v ) const { glUniform2ivARB( location, count, v ); }
    void setUniform3iv( GLint location, GLuint count, const GLint *v ) const { glUniform3ivARB( location, count, v ); }
    void setUniform4iv( GLint location, GLuint count, const GLint *v ) const { glUniform4ivARB( location, count, v ); }
    void setUniform1iv( const std::string& name, GLuint count, const GLint *v ) const { glUniform1ivARB( getUniformLocation( name.c_str() ), count, v ); }
    void setUniform2iv( const std::string& name, GLuint count, const GLint *v ) const { glUniform2ivARB( getUniformLocation( name.c_str() ), count, v ); }
    void setUniform3iv( const std::string& name, GLuint count, const GLint *v ) const { glUniform3ivARB( getUniformLocation( name.c_str() ), count, v ); }
    void setUniform4iv( const std::string& name, GLuint count, const GLint *v ) const { glUniform4ivARB( getUniformLocation( name.c_str() ), count, v ); }

    // float
    void setUniform1f( const char *name, GLfloat v0 )                                     const { glUniform1fARB( getUniformLocation( name ), v0 ); }
    void setUniform2f( const char *name, GLfloat v0, GLfloat v1 )                         const { glUniform2fARB( getUniformLocation( name ), v0, v1 ); }
    void setUniform3f( const char *name, GLfloat v0, GLfloat v1, GLfloat v2 )             const { glUniform3fARB( getUniformLocation( name ), v0, v1, v2 ); }
    void setUniform4f( const char *name, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3 ) const { glUniform4fARB( getUniformLocation( name ), v0, v1, v2, v3 ); }
    void setUniform1f( GLint location, GLfloat v0 )                                     const { glUniform1fARB( location, v0 ); }
    void setUniform2f( GLint location, GLfloat v0, GLfloat v1 )                         const { glUniform2fARB( location, v0, v1 ); }
    void setUniform3f( GLint location, GLfloat v0, GLfloat v1, GLfloat v2 )             const { glUniform3fARB( location, v0, v1, v2 ); }
    void setUniform4f( GLint location, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3 ) const { glUniform4fARB( location, v0, v1, v2, v3 ); }
    void setUniform1f( const std::string& name, GLfloat v0 )                                     const { glUniform1fARB( getUniformLocation( name.c_str() ), v0 ); }
    void setUniform2f( const std::string& name, GLfloat v0, GLfloat v1 )                         const { glUniform2fARB( getUniformLocation( name.c_str() ), v0, v1 ); }
    void setUniform3f( const std::string& name, GLfloat v0, GLfloat v1, GLfloat v2 )             const { glUniform3fARB( getUniformLocation( name.c_str() ), v0, v1, v2 ); }
    void setUniform4f( const std::string& name, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3 ) const { glUniform4fARB( getUniformLocation( name.c_str() ), v0, v1, v2, v3 ); }
    // Vector argument
    void setUniform2f( const char *name, const Vector2f& v ) const { setUniform2f(name, v[0], v[1]); }
    void setUniform3f( const char *name, const Vector3f& v ) const { setUniform3f(name, v[0], v[1], v[2]); }
    void setUniform4f( const char *name, const Vector4f& v ) const { setUniform4f(name, v[0], v[1], v[2], v[3]); }
    void setUniform2f( GLint location, const Vector2f& v) const { setUniform2f(location, v[0], v[1]); }
    void setUniform3f( GLint location, const Vector3f& v) const { setUniform3f(location, v[0], v[1], v[2]); }
    void setUniform4f( GLint location, const Vector4f& v) const { setUniform4f(location, v[0], v[1], v[2], v[3]); }
    void setUniform2f( const std::string& name, const Vector2f& v ) const { setUniform2f(name, v[0], v[1]); }
    void setUniform3f( const std::string& name, const Vector3f& v ) const { setUniform3f(name, v[0], v[1], v[2]); }
    void setUniform4f( const std::string& name, const Vector4f& v ) const { setUniform4f(name, v[0], v[1], v[2], v[3]); }

    // float array
    void setUniform1fv( const char *name, GLuint count, const GLfloat *v ) const { glUniform1fvARB( getUniformLocation( name ), count, v ); }
    void setUniform2fv( const char *name, GLuint count, const GLfloat *v ) const { glUniform2fvARB( getUniformLocation( name ), count, v ); }
    void setUniform3fv( const char *name, GLuint count, const GLfloat *v ) const { glUniform3fvARB( getUniformLocation( name ), count, v ); }
    void setUniform4fv( const char *name, GLuint count, const GLfloat *v ) const { glUniform4fvARB( getUniformLocation( name ), count, v ); }
    void setUniform1fv( GLint location, GLuint count, const GLfloat *v ) const { glUniform1fvARB( location, count, v ); }
    void setUniform2fv( GLint location, GLuint count, const GLfloat *v ) const { glUniform2fvARB( location, count, v ); }
    void setUniform3fv( GLint location, GLuint count, const GLfloat *v ) const { glUniform3fvARB( location, count, v ); }
    void setUniform4fv( GLint location, GLuint count, const GLfloat *v ) const { glUniform4fvARB( location, count, v ); }
    void setUniform1fv( const std::string& name, GLuint count, const GLfloat *v ) const { glUniform1fvARB( getUniformLocation( name.c_str() ), count, v ); }
    void setUniform2fv( const std::string& name, GLuint count, const GLfloat *v ) const { glUniform2fvARB( getUniformLocation( name.c_str() ), count, v ); }
    void setUniform3fv( const std::string& name, GLuint count, const GLfloat *v ) const { glUniform3fvARB( getUniformLocation( name.c_str() ), count, v ); }
    void setUniform4fv( const std::string& name, GLuint count, const GLfloat *v ) const { glUniform4fvARB( getUniformLocation( name.c_str() ), count, v ); }

    // matrix
    void setUniformMatrix2fv( const char *name, GLuint count, GLboolean transpose, const GLfloat *v ) const { glUniformMatrix2fvARB( getUniformLocation( name ), count, transpose, v ); }
    void setUniformMatrix3fv( const char *name, GLuint count, GLboolean transpose, const GLfloat *v ) const { glUniformMatrix3fvARB( getUniformLocation( name ), count, transpose, v ); }
    void setUniformMatrix4fv( const char *name, GLuint count, GLboolean transpose, const GLfloat *v ) const { glUniformMatrix4fvARB( getUniformLocation( name ), count, transpose, v ); }
    void setUniformMatrix2fv( GLint location, GLuint count, GLboolean transpose, const GLfloat *v ) const { glUniformMatrix2fvARB( location, count, transpose, v ); }
    void setUniformMatrix3fv( GLint location, GLuint count, GLboolean transpose, const GLfloat *v ) const { glUniformMatrix3fvARB( location, count, transpose, v ); }
    void setUniformMatrix4fv( GLint location, GLuint count, GLboolean transpose, const GLfloat *v ) const { glUniformMatrix4fvARB( location, count, transpose, v ); }
    void setUniformMatrix2fv( const std::string& name, GLuint count, GLboolean transpose, const GLfloat *v ) const { glUniformMatrix2fvARB( getUniformLocation( name.c_str() ), count, transpose, v ); }
    void setUniformMatrix3fv( const std::string& name, GLuint count, GLboolean transpose, const GLfloat *v ) const { glUniformMatrix3fvARB( getUniformLocation( name.c_str() ), count, transpose, v ); }
    void setUniformMatrix4fv( const std::string& name, GLuint count, GLboolean transpose, const GLfloat *v ) const { glUniformMatrix4fvARB( getUniformLocation( name.c_str() ), count, transpose, v ); }
    void setUniformMatrix2f( const char *name, const Matrix2x2f& m) const { setUniformMatrix2fv( name, 1, GL_TRUE, m.ptr()); }
    void setUniformMatrix3f( const char *name, const Matrix3x3f& m) const { setUniformMatrix3fv( name, 1, GL_TRUE, m.ptr()); }
    void setUniformMatrix4f( const char *name, const Matrix4x4f& m) const { setUniformMatrix4fv( name, 1, GL_TRUE, m.ptr()); }
    void setUniformMatrix2f( GLint location, const Matrix2x2f& m) const { setUniformMatrix2fv( location, 1, GL_TRUE, m.ptr()); }
    void setUniformMatrix3f( GLint location, const Matrix3x3f& m) const { setUniformMatrix3fv( location, 1, GL_TRUE, m.ptr()); }
    void setUniformMatrix4f( GLint location, const Matrix4x4f& m) const { setUniformMatrix4fv( location, 1, GL_TRUE, m.ptr()); }
    void setUniformMatrix2f( const std::string& name, const Matrix2x2f& m) const { setUniformMatrix2fv( name, 1, GL_TRUE, m.ptr()); }
    void setUniformMatrix3f( const std::string& name, const Matrix3x3f& m) const { setUniformMatrix3fv( name, 1, GL_TRUE, m.ptr()); }
    void setUniformMatrix4f( const std::string& name, const Matrix4x4f& m) const { setUniformMatrix4fv( name, 1, GL_TRUE, m.ptr()); }
    
    // attribute variable

    // float
    void setAttrib1f( GLint location, GLfloat v0 )                                     const { glVertexAttrib1fARB( location, v0 ); }
    void setAttrib2f( GLint location, GLfloat v0, GLfloat v1 )                         const { glVertexAttrib2fARB( location, v0, v1 ); }
    void setAttrib3f( GLint location, GLfloat v0, GLfloat v1, GLfloat v2 )             const { glVertexAttrib3fARB( location, v0, v1, v2 ); }
    void setAttrib4f( GLint location, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3 ) const { glVertexAttrib4fARB( location, v0, v1, v2, v3 ); }
    void setAttrib1f( const std::string& name, GLfloat v0 ) const {
        std::map<std::string, GLint>::const_iterator it = attribLocation_.find(name);
        if (it == attribLocation_.end()) {
            std::cerr << "(id:" << id_ << ") attribute `" << name << "' is not stored in the name-location list." << std::endl;
            return;
        }
        glVertexAttrib1fARB( it->second, v0 );
    }
    void setAttrib2f( const std::string& name, GLfloat v0, GLfloat v1 ) const {
        std::map<std::string, GLint>::const_iterator it = attribLocation_.find(name);
        if (it == attribLocation_.end()) {
            std::cerr << "(id:" << id_ << ") attribute `" << name << "' is not stored in the name-location list." << std::endl;
            return;
        }
        glVertexAttrib2fARB( it->second, v0, v1 );
    }
    void setAttrib3f( const std::string& name, GLfloat v0, GLfloat v1, GLfloat v2 ) const {
        std::map<std::string, GLint>::const_iterator it = attribLocation_.find(name);
        if (it == attribLocation_.end()) {
            std::cerr << "(id:" << id_ << ") attribute `" << name << "' is not stored in the name-location list." << std::endl;
            return;
        }
        glVertexAttrib3fARB( it->second, v0, v1, v2 );
    }
    void setAttrib4f( const std::string& name, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3 ) const {
        std::map<std::string, GLint>::const_iterator it = attribLocation_.find(name);
        if (it == attribLocation_.end()) {
            std::cerr << "(id:" << id_ << ") attribute `" << name << "' is not stored in the name-location list." << std::endl;
            return;
        }
        glVertexAttrib4fARB( it->second, v0, v1, v2, v3 );
    }
    // Vector argument
    void setAttrib2f( GLint location, const Vector2f& v ) const { setAttrib2f( location, v[0], v[1] ); }
    void setAttrib3f( GLint location, const Vector3f& v ) const { setAttrib3f( location, v[0], v[1], v[2] ); }
    void setAttrib4f( GLint location, const Vector4f& v ) const { setAttrib4f( location, v[0], v[1], v[2], v[3] ); }

    // float array
    void setAttrib1fv( GLint location, const GLfloat *v ) const { glVertexAttrib1fvARB( location, v ); }
    void setAttrib2fv( GLint location, const GLfloat *v ) const { glVertexAttrib2fvARB( location, v ); }
    void setAttrib3fv( GLint location, const GLfloat *v ) const { glVertexAttrib3fvARB( location, v ); }
    void setAttrib4fv( GLint location, const GLfloat *v ) const { glVertexAttrib4fvARB( location, v ); }

    // double
    void setAttrib1d( GLint location, GLdouble v0 )                                        const { glVertexAttrib1dARB( location, v0 ); }
    void setAttrib2d( GLint location, GLdouble v0, GLdouble v1 )                           const { glVertexAttrib2dARB( location, v0, v1 ); }
    void setAttrib3d( GLint location, GLdouble v0, GLdouble v1, GLdouble v2 )              const { glVertexAttrib3dARB( location, v0, v1, v2 ); }
    void setAttrib4d( GLint location, GLdouble v0, GLdouble v1, GLdouble v2, GLdouble v3 ) const { glVertexAttrib4dARB( location, v0, v1, v2, v3 ); }
    // Vector argument
    void setAttrib2d( GLint location, const Vector2d& v ) const { setAttrib2d( location, v[0], v[1] ); }
    void setAttrib3d( GLint location, const Vector3d& v ) const { setAttrib3d( location, v[0], v[1], v[2] ); }
    void setAttrib4d( GLint location, const Vector4d& v ) const { setAttrib4d( location, v[0], v[1], v[2], v[3] ); }

    // double array
    void setAttrib1dv( GLint location, const GLdouble *v ) const { glVertexAttrib1dvARB( location, v ); }
    void setAttrib2dv( GLint location, const GLdouble *v ) const { glVertexAttrib2dvARB( location, v ); }
    void setAttrib3dv( GLint location, const GLdouble *v ) const { glVertexAttrib3dvARB( location, v ); }
    void setAttrib4dv( GLint location, const GLdouble *v ) const { glVertexAttrib4dvARB( location, v ); }
};

}   // namespace KLIB
