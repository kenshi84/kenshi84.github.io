#pragma once

#include "Umfpack.h"
#include "CholmodMatrix.h"
#include "Vector.h"
#include <vector>

namespace KLIB {

class RigidShapeDeformation2D {
public:
    RigidShapeDeformation2D(void) {}
    RigidShapeDeformation2D(
        const std::vector<KLIB::Vector2d>& rest_vtx_position,
        const std::vector<int>& vtx_indices)
    {
        init(rest_vtx_position, vtx_indices);
    }
    ~RigidShapeDeformation2D(void) {}

    // compute w and h, A_step1, rest_edges, A_step2
    void init(
        const std::vector<KLIB::Vector2d>& rest_vtx_position,
        const std::vector<int>& face_vtx_index);

    // add constraints on diagonals of AtA_step1 and AtA_step2
    void compile(const std::vector<int>& is_vtx_constrained);

    // calculate rigid deformation in 2 steps
    std::vector<KLIB::Vector2d> deform(const std::vector<KLIB::Vector2d>& constrained_vtx_position);

    //void set_constraint_weight(double w) { m_constraint_weight = w; }

private:
    // [init]
    size_t num_vtx_;
    size_t num_face_;
    size_t num_const_;
    std::vector<KLIB::Vector2d> rest_vtx_position_;				// [i] vertex position in the rest shape
    std::vector<int> face_vtx_index_;				// [i] face index data of the mesh
    CholmodMatrix step1_AtA_;    //m_At_step1, m_AtA_step1;			// [i] sparse matrix representing face similarity
    CholmodMatrix step2_At_, step2_AtA_;    //m_At_step2, m_AtA_step2;			// [i] sparse matrix of edge connectivity
    //double m_constraint_weight;								// weight for positional constraints

    // [compile]
    std::vector<int> is_vtx_constrained_;					// 0: unconstrained, 1: constrained
    Umfpack step1_umfpack_;
    Umfpack step2_umfpack_;
};

}
