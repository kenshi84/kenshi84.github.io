#include "stdafx.h"
#include "GLSLNoise.h"
#include <vector>

using namespace std;
using namespace KLIB;

ShaderObject GLSLNoise::fragShader__;
ShaderObject GLSLNoise::vertShader__;
GLuint GLSLNoise::permTextureID__;
GLuint GLSLNoise::gradTextureID__;

const int GLSLNoise::perm__[256] = { 151,160,137,91,90,15,
    131,13,201,95,96,53,194,233,7,225,140,36,103,30,69,142,8,99,37,240,21,10,23,
    190, 6,148,247,120,234,75,0,26,197,62,94,252,219,203,117,35,11,32,57,177,33,
    88,237,149,56,87,174,20,125,136,171,168, 68,175,74,165,71,134,139,48,27,166,
    77,146,158,231,83,111,229,122,60,211,133,230,220,105,92,41,55,46,245,40,244,
    102,143,54, 65,25,63,161, 1,216,80,73,209,76,132,187,208, 89,18,169,200,196,
    135,130,116,188,159,86,164,100,109,198,173,186, 3,64,52,217,226,250,124,123,
    5,202,38,147,118,126,255,82,85,212,207,206,59,227,47,16,58,17,182,189,28,42,
    223,183,170,213,119,248,152, 2,44,154,163, 70,221,153,101,155,167, 43,172,9,
    129,22,39,253, 19,98,108,110,79,113,224,232,178,185, 112,104,218,246,97,228,
    251,34,242,193,238,210,144,12,191,179,162,241, 81,51,145,235,249,14,239,107,
    49,192,214, 31,181,199,106,157,184, 84,204,176,115,121,50,45,127, 4,150,254,
    138,236,205,93,222,114,67,29,24,72,243,141,128,195,78,66,215,61,156,180
};
//    These are Ken Perlin's proposed gradients for 3D noise. I kept them for
//  better consistency with the reference implementation, but there is really
//  no need to pad this to 16 gradients for this particular implementation.
//  If only the "proper" first 12 gradients are used, they can be extracted
//  from the grad4[][] array: grad3[i][j] == grad4[i*2][j], 0<=i<=11, j=0,1,2
const int GLSLNoise::grad3__[16][3] = {
    {0,1,1},{0,1,-1},{0,-1,1},{0,-1,-1},
    {1,0,1},{1,0,-1},{-1,0,1},{-1,0,-1},
    {1,1,0},{1,-1,0},{-1,1,0},{-1,-1,0}, // 12 cube edges
    {1,0,-1},{-1,0,-1},{0,-1,1},{0,1,1}  // 4 more to make 16
};
//    These are my own proposed gradients for 4D noise. They are the coordinates
//  of the midpoints of each of the 32 edges of a tesseract, just like the 3D
//  noise gradients are the midpoints of the 12 edges of a cube.
const int GLSLNoise::grad4__[32][4] = {
    {0,1,1,1}, {0,1,1,-1}, {0,1,-1,1}, {0,1,-1,-1}, // 32 tesseract edges
    {0,-1,1,1}, {0,-1,1,-1}, {0,-1,-1,1}, {0,-1,-1,-1},
    {1,0,1,1}, {1,0,1,-1}, {1,0,-1,1}, {1,0,-1,-1},
    {-1,0,1,1}, {-1,0,1,-1}, {-1,0,-1,1}, {-1,0,-1,-1},
    {1,1,0,1}, {1,1,0,-1}, {1,-1,0,1}, {1,-1,0,-1},
    {-1,1,0,1}, {-1,1,0,-1}, {-1,-1,0,1}, {-1,-1,0,-1},
    {1,1,1,0}, {1,1,-1,0}, {1,-1,1,0}, {1,-1,-1,0},
    {-1,1,1,0}, {-1,1,-1,0}, {-1,-1,1,0}, {-1,-1,-1,0}
};
// /*
//  * 2D, 3D and 4D Perlin noise, classic and simplex, in a GLSL fragment shader.
//  *
//  * Classic noise is implemented by the functions:
//  * float noise(vec2 P)
//  * float noise(vec3 P)
//  * float noise(vec4 P)
//  *
//  * Simplex noise is implemented by the functions:
//  * float snoise(vec2 P)
//  * float snoise(vec3 P)
//  * float snoise(vec4 P)
//  *
//  * Author: Stefan Gustavson ITN-LiTH (stegu@itn.liu.se) 2004-12-05
//  * Simplex indexing functions by Bill Licea-Kane, ATI (bill@ati.com)
//  *
//  * You may use, modify and redistribute this code free of charge,
//  * provided that the author's names and this notice appear intact.
//  */
// 
// /*
//  * NOTE: there is a formal problem with the dependent texture lookups.
//  * A texture coordinate of exactly 1.0 will wrap to 0.0, so strictly speaking,
//  * an error occurs every 256 units of the texture domain, and the same gradient
//  * is used for two adjacent noise cells. One solution is to set the texture
//  * wrap mode to "CLAMP" and do the wrapping explicitly in GLSL with the "mod"
//  * operator. This could also give you noise with repetition intervals other
//  * than 256 without any extra cost.
//  * This error is not even noticeable to the eye even if you isolate the exact
//  * position in the domain where it occurs and know exactly what to look for.
//  * The noise pattern is still visually correct, so I left the bug in there.
//  * 
//  * The value of classic 4D noise goes above 1.0 and below -1.0 at some
//  * points. Not much and only very sparsely, but it happens. This is a
//  * bug from the original software implementation, so I left it untouched.
//  */
// 
// 
// /*
//  * "permTexture" is a 256x256 texture that is used for both the permutations
//  * and the 2D and 3D gradient lookup. For details, see the main C program.
//  * "gradTexture" is a 256x256 texture with 4D gradients, similar to
//  * "permTexture" but with the permutation index in the alpha component
//  * replaced by the w component of the 4D gradient.
//  * 2D classic noise uses only permTexture.
//  * 2D simplex noise uses only permTexture.
//  * 3D classic noise uses only permTexture.
//  * 3D simplex noise uses only permTexture.
//  * 4D classic noise uses permTexture and gradTexture.
//  * 4D simplex noise uses permTexture and gradTexture.
//  */
// uniform sampler2D permTexture;
// uniform sampler2D gradTexture;
// uniform float time; // Used for texture animation
// 
// /*
//  * Both 2D and 3D texture coordinates are defined, for testing purposes.
//  */
// varying vec2 v_texCoord2D;
// varying vec3 v_texCoord3D;
// varying vec4 v_color;
// 
// /*
//  * To create offsets of one texel and one half texel in the
//  * texture lookup, we need to know the texture image size.
//  */
// #define ONE 0.00390625
// #define ONEHALF 0.001953125
// // The numbers above are 1/256 and 0.5/256, change accordingly
// // if you change the code to use another texture size.
// 
// 
// /*
//  * The interpolation function. This could be a 1D texture lookup
//  * to get some more speed, but it's not the main part of the algorithm.
//  */
// float fade(float t) {
//   // return t*t*(3.0-2.0*t); // Old fade, yields discontinuous second derivative
//   return t*t*t*(t*(t*6.0-15.0)+10.0); // Improved fade, yields C2-continuous noise
// }
// 
// /*
//  * Efficient simplex indexing functions by Bill Licea-Kane, ATI. Thanks!
//  * (This was originally implemented as a texture lookup. Nice to avoid that.)
//  */
// void simplex( const in vec3 P, out vec3 offset1, out vec3 offset2 )
// {
//   vec3 offset0;
//  
//   vec2 isX = step( P.yz, P.xx );         // P.x >= P.y ? 1.0 : 0.0;  P.x >= P.z ? 1.0 : 0.0;
//   offset0.x  = dot( isX, vec2( 1.0 ) );  // Accumulate all P.x >= other channels in offset.x
//   offset0.yz = 1.0 - isX;                // Accumulate all P.x <  other channels in offset.yz
// 
//   float isY = step( P.z, P.y );          // P.y >= P.z ? 1.0 : 0.0;
//   offset0.y += isY;                      // Accumulate P.y >= P.z in offset.y
//   offset0.z += 1.0 - isY;                // Accumulate P.y <  P.z in offset.z
//  
//   // offset0 now contains the unique values 0,1,2 in each channel
//   // 2 for the channel greater than other channels
//   // 1 for the channel that is less than one but greater than another
//   // 0 for the channel less than other channels
//   // Equality ties are broken in favor of first x, then y
//   // (z always loses ties)
// 
//   offset2 = clamp(   offset0, 0.0, 1.0 );
//   // offset2 contains 1 in each channel that was 1 or 2
//   offset1 = clamp( --offset0, 0.0, 1.0 );
//   // offset1 contains 1 in the single channel that was 1
// }
// 
// void simplex( const in vec4 P, out vec4 offset1, out vec4 offset2, out vec4 offset3 )
// {
//   vec4 offset0;
//  
//   vec3 isX = step( P.yzw, P.xxx );        // See comments in 3D simplex function
//   offset0.x = dot( isX, vec3( 1.0 ) );
//   offset0.yzw = 1.0 - isX;
// 
//   vec2 isY = step( P.zw, P.yy );
//   offset0.y += dot( isY, vec2( 1.0 ) );
//   offset0.zw += 1.0 - isY;
//  
//   float isZ = step( P.w, P.z );
//   offset0.z += isZ;
//   offset0.w += 1.0 - isZ;
// 
//   // offset0 now contains the unique values 0,1,2,3 in each channel
// 
//   offset3 = clamp(   offset0, 0.0, 1.0 );
//   offset2 = clamp( --offset0, 0.0, 1.0 );
//   offset1 = clamp( --offset0, 0.0, 1.0 );
// }
// 
// 
// /*
//  * 2D classic Perlin noise. Fast, but less useful than 3D noise.
//  */
// float noise(vec2 P)
// {
//   vec2 Pi = ONE*floor(P)+ONEHALF; // Integer part, scaled and offset for texture lookup
//   vec2 Pf = fract(P);             // Fractional part for interpolation
// 
//   // Noise contribution from lower left corner
//   vec2 grad00 = texture2D(permTexture, Pi).rg * 4.0 - 1.0;
//   float n00 = dot(grad00, Pf);
// 
//   // Noise contribution from lower right corner
//   vec2 grad10 = texture2D(permTexture, Pi + vec2(ONE, 0.0)).rg * 4.0 - 1.0;
//   float n10 = dot(grad10, Pf - vec2(1.0, 0.0));
// 
//   // Noise contribution from upper left corner
//   vec2 grad01 = texture2D(permTexture, Pi + vec2(0.0, ONE)).rg * 4.0 - 1.0;
//   float n01 = dot(grad01, Pf - vec2(0.0, 1.0));
// 
//   // Noise contribution from upper right corner
//   vec2 grad11 = texture2D(permTexture, Pi + vec2(ONE, ONE)).rg * 4.0 - 1.0;
//   float n11 = dot(grad11, Pf - vec2(1.0, 1.0));
// 
//   // Blend contributions along x
//   vec2 n_x = mix(vec2(n00, n01), vec2(n10, n11), fade(Pf.x));
// 
//   // Blend contributions along y
//   float n_xy = mix(n_x.x, n_x.y, fade(Pf.y));
// 
//   // We're done, return the final noise value.
//   return n_xy;
// }
// 
// 
// /*
//  * 3D classic noise. Slower, but a lot more useful than 2D noise.
//  */
// float noise(vec3 P)
// {
//   vec3 Pi = ONE*floor(P)+ONEHALF; // Integer part, scaled so +1 moves one texel
//                                   // and offset 1/2 texel to sample texel centers
//   vec3 Pf = fract(P);     // Fractional part for interpolation
// 
//   // Noise contributions from (x=0, y=0), z=0 and z=1
//   float perm00 = texture2D(permTexture, Pi.xy).a ;
//   vec3  grad000 = texture2D(permTexture, vec2(perm00, Pi.z)).rgb * 4.0 - 1.0;
//   float n000 = dot(grad000, Pf);
//   vec3  grad001 = texture2D(permTexture, vec2(perm00, Pi.z + ONE)).rgb * 4.0 - 1.0;
//   float n001 = dot(grad001, Pf - vec3(0.0, 0.0, 1.0));
// 
//   // Noise contributions from (x=0, y=1), z=0 and z=1
//   float perm01 = texture2D(permTexture, Pi.xy + vec2(0.0, ONE)).a ;
//   vec3  grad010 = texture2D(permTexture, vec2(perm01, Pi.z)).rgb * 4.0 - 1.0;
//   float n010 = dot(grad010, Pf - vec3(0.0, 1.0, 0.0));
//   vec3  grad011 = texture2D(permTexture, vec2(perm01, Pi.z + ONE)).rgb * 4.0 - 1.0;
//   float n011 = dot(grad011, Pf - vec3(0.0, 1.0, 1.0));
// 
//   // Noise contributions from (x=1, y=0), z=0 and z=1
//   float perm10 = texture2D(permTexture, Pi.xy + vec2(ONE, 0.0)).a ;
//   vec3  grad100 = texture2D(permTexture, vec2(perm10, Pi.z)).rgb * 4.0 - 1.0;
//   float n100 = dot(grad100, Pf - vec3(1.0, 0.0, 0.0));
//   vec3  grad101 = texture2D(permTexture, vec2(perm10, Pi.z + ONE)).rgb * 4.0 - 1.0;
//   float n101 = dot(grad101, Pf - vec3(1.0, 0.0, 1.0));
// 
//   // Noise contributions from (x=1, y=1), z=0 and z=1
//   float perm11 = texture2D(permTexture, Pi.xy + vec2(ONE, ONE)).a ;
//   vec3  grad110 = texture2D(permTexture, vec2(perm11, Pi.z)).rgb * 4.0 - 1.0;
//   float n110 = dot(grad110, Pf - vec3(1.0, 1.0, 0.0));
//   vec3  grad111 = texture2D(permTexture, vec2(perm11, Pi.z + ONE)).rgb * 4.0 - 1.0;
//   float n111 = dot(grad111, Pf - vec3(1.0, 1.0, 1.0));
// 
//   // Blend contributions along x
//   vec4 n_x = mix(vec4(n000, n001, n010, n011),
//                  vec4(n100, n101, n110, n111), fade(Pf.x));
// 
//   // Blend contributions along y
//   vec2 n_xy = mix(n_x.xy, n_x.zw, fade(Pf.y));
// 
//   // Blend contributions along z
//   float n_xyz = mix(n_xy.x, n_xy.y, fade(Pf.z));
// 
//   // We're done, return the final noise value.
//   return n_xyz;
// }
// 
// 
// /*
//  * 4D classic noise. Slow, but very useful. 4D simplex noise is a lot faster.
//  *
//  * This function performs 8 texture lookups and 16 dependent texture lookups,
//  * 16 dot products, 4 mix operations and a lot of additions and multiplications.
//  * Needless to say, it's not super fast. But it's not dead slow either.
//  */
// float noise(vec4 P)
// {
//   vec4 Pi = ONE*floor(P)+ONEHALF; // Integer part, scaled so +1 moves one texel
//                                   // and offset 1/2 texel to sample texel centers
//   vec4 Pf = fract(P);      // Fractional part for interpolation
// 
//   // "n0000" is the noise contribution from (x=0, y=0, z=0, w=0), and so on
//   float perm00xy = texture2D(permTexture, Pi.xy).a ;
//   float perm00zw = texture2D(permTexture, Pi.zw).a ;
//   vec4 grad0000 = texture2D(gradTexture, vec2(perm00xy, perm00zw)).rgba * 4.0 -1.0;
//   float n0000 = dot(grad0000, Pf);
// 
//   float perm01zw = texture2D(permTexture, Pi.zw  + vec2(0.0, ONE)).a ;
//   vec4  grad0001 = texture2D(gradTexture, vec2(perm00xy, perm01zw)).rgba * 4.0 - 1.0;
//   float n0001 = dot(grad0001, Pf - vec4(0.0, 0.0, 0.0, 1.0));
// 
//   float perm10zw = texture2D(permTexture, Pi.zw  + vec2(ONE, 0.0)).a ;
//   vec4  grad0010 = texture2D(gradTexture, vec2(perm00xy, perm10zw)).rgba * 4.0 - 1.0;
//   float n0010 = dot(grad0010, Pf - vec4(0.0, 0.0, 1.0, 0.0));
// 
//   float perm11zw = texture2D(permTexture, Pi.zw  + vec2(ONE, ONE)).a ;
//   vec4  grad0011 = texture2D(gradTexture, vec2(perm00xy, perm11zw)).rgba * 4.0 - 1.0;
//   float n0011 = dot(grad0011, Pf - vec4(0.0, 0.0, 1.0, 1.0));
// 
//   float perm01xy = texture2D(permTexture, Pi.xy + vec2(0.0, ONE)).a ;
//   vec4  grad0100 = texture2D(gradTexture, vec2(perm01xy, perm00zw)).rgba * 4.0 - 1.0;
//   float n0100 = dot(grad0100, Pf - vec4(0.0, 1.0, 0.0, 0.0));
// 
//   vec4  grad0101 = texture2D(gradTexture, vec2(perm01xy, perm01zw)).rgba * 4.0 - 1.0;
//   float n0101 = dot(grad0101, Pf - vec4(0.0, 1.0, 0.0, 1.0));
// 
//   vec4  grad0110 = texture2D(gradTexture, vec2(perm01xy, perm10zw)).rgba * 4.0 - 1.0;
//   float n0110 = dot(grad0110, Pf - vec4(0.0, 1.0, 1.0, 0.0));
// 
//   vec4  grad0111 = texture2D(gradTexture, vec2(perm01xy, perm11zw)).rgba * 4.0 - 1.0;
//   float n0111 = dot(grad0111, Pf - vec4(0.0, 1.0, 1.0, 1.0));
// 
//   float perm10xy = texture2D(permTexture, Pi.xy + vec2(ONE, 0.0)).a ;
//   vec4  grad1000 = texture2D(gradTexture, vec2(perm10xy, perm00zw)).rgba * 4.0 - 1.0;
//   float n1000 = dot(grad1000, Pf - vec4(1.0, 0.0, 0.0, 0.0));
// 
//   vec4  grad1001 = texture2D(gradTexture, vec2(perm10xy, perm01zw)).rgba * 4.0 - 1.0;
//   float n1001 = dot(grad1001, Pf - vec4(1.0, 0.0, 0.0, 1.0));
// 
//   vec4  grad1010 = texture2D(gradTexture, vec2(perm10xy, perm10zw)).rgba * 4.0 - 1.0;
//   float n1010 = dot(grad1010, Pf - vec4(1.0, 0.0, 1.0, 0.0));
// 
//   vec4  grad1011 = texture2D(gradTexture, vec2(perm10xy, perm11zw)).rgba * 4.0 - 1.0;
//   float n1011 = dot(grad1011, Pf - vec4(1.0, 0.0, 1.0, 1.0));
// 
//   float perm11xy = texture2D(permTexture, Pi.xy + vec2(ONE, ONE)).a ;
//   vec4  grad1100 = texture2D(gradTexture, vec2(perm11xy, perm00zw)).rgba * 4.0 - 1.0;
//   float n1100 = dot(grad1100, Pf - vec4(1.0, 1.0, 0.0, 0.0));
// 
//   vec4  grad1101 = texture2D(gradTexture, vec2(perm11xy, perm01zw)).rgba * 4.0 - 1.0;
//   float n1101 = dot(grad1101, Pf - vec4(1.0, 1.0, 0.0, 1.0));
// 
//   vec4  grad1110 = texture2D(gradTexture, vec2(perm11xy, perm10zw)).rgba * 4.0 - 1.0;
//   float n1110 = dot(grad1110, Pf - vec4(1.0, 1.0, 1.0, 0.0));
// 
//   vec4  grad1111 = texture2D(gradTexture, vec2(perm11xy, perm11zw)).rgba * 4.0 - 1.0;
//   float n1111 = dot(grad1111, Pf - vec4(1.0, 1.0, 1.0, 1.0));
// 
//   // Blend contributions along x
//   float fadex = fade(Pf.x);
//   vec4 n_x0 = mix(vec4(n0000, n0001, n0010, n0011),
//                   vec4(n1000, n1001, n1010, n1011), fadex);
//   vec4 n_x1 = mix(vec4(n0100, n0101, n0110, n0111),
//                   vec4(n1100, n1101, n1110, n1111), fadex);
// 
//   // Blend contributions along y
//   vec4 n_xy = mix(n_x0, n_x1, fade(Pf.y));
// 
//   // Blend contributions along z
//   vec2 n_xyz = mix(n_xy.xy, n_xy.zw, fade(Pf.z));
// 
//   // Blend contributions along w
//   float n_xyzw = mix(n_xyz.x, n_xyz.y, fade(Pf.w));
// 
//   // We're done, return the final noise value.
//   return n_xyzw;
// }
// 
// 
// /*
//  * 2D simplex noise. Somewhat slower but much better looking than classic noise.
//  */
// float snoise(vec2 P) {
// 
// // Skew and unskew factors are a bit hairy for 2D, so define them as constants
// // This is (sqrt(3.0)-1.0)/2.0
// #define F2 0.366025403784
// // This is (3.0-sqrt(3.0))/6.0
// #define G2 0.211324865405
// 
//   // Skew the (x,y) space to determine which cell of 2 simplices we're in
//  	float s = (P.x + P.y) * F2;   // Hairy factor for 2D skewing
//   vec2 Pi = floor(P + s);
//   float t = (Pi.x + Pi.y) * G2; // Hairy factor for unskewing
//   vec2 P0 = Pi - t; // Unskew the cell origin back to (x,y) space
//   Pi = Pi * ONE + ONEHALF; // Integer part, scaled and offset for texture lookup
// 
//   vec2 Pf0 = P - P0;  // The x,y distances from the cell origin
// 
//   // For the 2D case, the simplex shape is an equilateral triangle.
//   // Find out whether we are above or below the x=y diagonal to
//   // determine which of the two triangles we're in.
//   vec2 o1;
//   if(Pf0.x > Pf0.y) o1 = vec2(1.0, 0.0);  // +x, +y traversal order
//   else o1 = vec2(0.0, 1.0);               // +y, +x traversal order
// 
//   // Noise contribution from simplex origin
//   vec2 grad0 = texture2D(permTexture, Pi).rg * 4.0 - 1.0;
//   float t0 = 0.5 - dot(Pf0, Pf0);
//   float n0;
//   if (t0 < 0.0) n0 = 0.0;
//   else {
//     t0 *= t0;
//     n0 = t0 * t0 * dot(grad0, Pf0);
//   }
// 
//   // Noise contribution from middle corner
//   vec2 Pf1 = Pf0 - o1 + G2;
//   vec2 grad1 = texture2D(permTexture, Pi + o1*ONE).rg * 4.0 - 1.0;
//   float t1 = 0.5 - dot(Pf1, Pf1);
//   float n1;
//   if (t1 < 0.0) n1 = 0.0;
//   else {
//     t1 *= t1;
//     n1 = t1 * t1 * dot(grad1, Pf1);
//   }
//   
//   // Noise contribution from last corner
//   vec2 Pf2 = Pf0 - vec2(1.0-2.0*G2);
//   vec2 grad2 = texture2D(permTexture, Pi + vec2(ONE, ONE)).rg * 4.0 - 1.0;
//   float t2 = 0.5 - dot(Pf2, Pf2);
//   float n2;
//   if(t2 < 0.0) n2 = 0.0;
//   else {
//     t2 *= t2;
//     n2 = t2 * t2 * dot(grad2, Pf2);
//   }
// 
//   // Sum up and scale the result to cover the range [-1,1]
//   return 70.0 * (n0 + n1 + n2);
// }
// 
// 
// /*
//  * 3D simplex noise. Comparable in speed to classic noise, better looking.
//  */
// float snoise(vec3 P) {
// 
// // The skewing and unskewing factors are much simpler for the 3D case
// #define F3 0.333333333333
// #define G3 0.166666666667
// 
//   // Skew the (x,y,z) space to determine which cell of 6 simplices we're in
//  	float s = (P.x + P.y + P.z) * F3; // Factor for 3D skewing
//   vec3 Pi = floor(P + s);
//   float t = (Pi.x + Pi.y + Pi.z) * G3;
//   vec3 P0 = Pi - t; // Unskew the cell origin back to (x,y,z) space
//   Pi = Pi * ONE + ONEHALF; // Integer part, scaled and offset for texture lookup
// 
//   vec3 Pf0 = P - P0;  // The x,y distances from the cell origin
// 
//   // For the 3D case, the simplex shape is a slightly irregular tetrahedron.
//   // To find out which of the six possible tetrahedra we're in, we need to
//   // determine the magnitude ordering of x, y and z components of Pf0.
//   vec3 o1;
//   vec3 o2;
//   simplex(Pf0, o1, o2);
// 
//   // Noise contribution from simplex origin
//   float perm0 = texture2D(permTexture, Pi.xy).a;
//   vec3  grad0 = texture2D(permTexture, vec2(perm0, Pi.z)).rgb * 4.0 - 1.0;
//   float t0 = 0.6 - dot(Pf0, Pf0);
//   float n0;
//   if (t0 < 0.0) n0 = 0.0;
//   else {
//     t0 *= t0;
//     n0 = t0 * t0 * dot(grad0, Pf0);
//   }
// 
//   // Noise contribution from second corner
//   vec3 Pf1 = Pf0 - o1 + G3;
//   float perm1 = texture2D(permTexture, Pi.xy + o1.xy*ONE).a;
//   vec3  grad1 = texture2D(permTexture, vec2(perm1, Pi.z + o1.z*ONE)).rgb * 4.0 - 1.0;
//   float t1 = 0.6 - dot(Pf1, Pf1);
//   float n1;
//   if (t1 < 0.0) n1 = 0.0;
//   else {
//     t1 *= t1;
//     n1 = t1 * t1 * dot(grad1, Pf1);
//   }
//   
//   // Noise contribution from third corner
//   vec3 Pf2 = Pf0 - o2 + 2.0 * G3;
//   float perm2 = texture2D(permTexture, Pi.xy + o2.xy*ONE).a;
//   vec3  grad2 = texture2D(permTexture, vec2(perm2, Pi.z + o2.z*ONE)).rgb * 4.0 - 1.0;
//   float t2 = 0.6 - dot(Pf2, Pf2);
//   float n2;
//   if (t2 < 0.0) n2 = 0.0;
//   else {
//     t2 *= t2;
//     n2 = t2 * t2 * dot(grad2, Pf2);
//   }
//   
//   // Noise contribution from last corner
//   vec3 Pf3 = Pf0 - vec3(1.0-3.0*G3);
//   float perm3 = texture2D(permTexture, Pi.xy + vec2(ONE, ONE)).a;
//   vec3  grad3 = texture2D(permTexture, vec2(perm3, Pi.z + ONE)).rgb * 4.0 - 1.0;
//   float t3 = 0.6 - dot(Pf3, Pf3);
//   float n3;
//   if(t3 < 0.0) n3 = 0.0;
//   else {
//     t3 *= t3;
//     n3 = t3 * t3 * dot(grad3, Pf3);
//   }
// 
//   // Sum up and scale the result to cover the range [-1,1]
//   return 32.0 * (n0 + n1 + n2 + n3);
// }
// 
// 
// /*
//  * 4D simplex noise. A lot faster than classic 4D noise, and better looking.
//  */
// 
// float snoise(vec4 P) {
// 
// // The skewing and unskewing factors are hairy again for the 4D case
// // This is (sqrt(5.0)-1.0)/4.0
// #define F4 0.309016994375
// // This is (5.0-sqrt(5.0))/20.0
// #define G4 0.138196601125
// 
//   // Skew the (x,y,z,w) space to determine which cell of 24 simplices we're in
//  	float s = (P.x + P.y + P.z + P.w) * F4; // Factor for 4D skewing
//   vec4 Pi = floor(P + s);
//   float t = (Pi.x + Pi.y + Pi.z + Pi.w) * G4;
//   vec4 P0 = Pi - t; // Unskew the cell origin back to (x,y,z,w) space
//   Pi = Pi * ONE + ONEHALF; // Integer part, scaled and offset for texture lookup
// 
//   vec4 Pf0 = P - P0;  // The x,y distances from the cell origin
// 
//   // For the 4D case, the simplex is a 4D shape I won't even try to describe.
//   // To find out which of the 24 possible simplices we're in, we need to
//   // determine the magnitude ordering of x, y, z and w components of Pf0.
//   vec4 o1;
//   vec4 o2;
//   vec4 o3;
//   simplex(Pf0, o1, o2, o3);  
// 
//   // Noise contribution from simplex origin
//   float perm0xy = texture2D(permTexture, Pi.xy).a;
//   float perm0zw = texture2D(permTexture, Pi.zw).a;
//   vec4  grad0 = texture2D(gradTexture, vec2(perm0xy, perm0zw)).rgba * 4.0 - 1.0;
//   float t0 = 0.6 - dot(Pf0, Pf0);
//   float n0;
//   if (t0 < 0.0) n0 = 0.0;
//   else {
//     t0 *= t0;
//     n0 = t0 * t0 * dot(grad0, Pf0);
//   }
// 
//   // Noise contribution from second corner
//   vec4 Pf1 = Pf0 - o1 + G4;
//   o1 = o1 * ONE;
//   float perm1xy = texture2D(permTexture, Pi.xy + o1.xy).a;
//   float perm1zw = texture2D(permTexture, Pi.zw + o1.zw).a;
//   vec4  grad1 = texture2D(gradTexture, vec2(perm1xy, perm1zw)).rgba * 4.0 - 1.0;
//   float t1 = 0.6 - dot(Pf1, Pf1);
//   float n1;
//   if (t1 < 0.0) n1 = 0.0;
//   else {
//     t1 *= t1;
//     n1 = t1 * t1 * dot(grad1, Pf1);
//   }
//   
//   // Noise contribution from third corner
//   vec4 Pf2 = Pf0 - o2 + 2.0 * G4;
//   o2 = o2 * ONE;
//   float perm2xy = texture2D(permTexture, Pi.xy + o2.xy).a;
//   float perm2zw = texture2D(permTexture, Pi.zw + o2.zw).a;
//   vec4  grad2 = texture2D(gradTexture, vec2(perm2xy, perm2zw)).rgba * 4.0 - 1.0;
//   float t2 = 0.6 - dot(Pf2, Pf2);
//   float n2;
//   if (t2 < 0.0) n2 = 0.0;
//   else {
//     t2 *= t2;
//     n2 = t2 * t2 * dot(grad2, Pf2);
//   }
//   
//   // Noise contribution from fourth corner
//   vec4 Pf3 = Pf0 - o3 + 3.0 * G4;
//   o3 = o3 * ONE;
//   float perm3xy = texture2D(permTexture, Pi.xy + o3.xy).a;
//   float perm3zw = texture2D(permTexture, Pi.zw + o3.zw).a;
//   vec4  grad3 = texture2D(gradTexture, vec2(perm3xy, perm3zw)).rgba * 4.0 - 1.0;
//   float t3 = 0.6 - dot(Pf3, Pf3);
//   float n3;
//   if (t3 < 0.0) n3 = 0.0;
//   else {
//     t3 *= t3;
//     n3 = t3 * t3 * dot(grad3, Pf3);
//   }
//   
//   // Noise contribution from last corner
//   vec4 Pf4 = Pf0 - vec4(1.0-4.0*G4);
//   float perm4xy = texture2D(permTexture, Pi.xy + vec2(ONE, ONE)).a;
//   float perm4zw = texture2D(permTexture, Pi.zw + vec2(ONE, ONE)).a;
//   vec4  grad4 = texture2D(gradTexture, vec2(perm4xy, perm4zw)).rgba * 4.0 - 1.0;
//   float t4 = 0.6 - dot(Pf4, Pf4);
//   float n4;
//   if(t4 < 0.0) n4 = 0.0;
//   else {
//     t4 *= t4;
//     n4 = t4 * t4 * dot(grad4, Pf4);
//   }
// 
//   // Sum up and scale the result to cover the range [-1,1]
//   return 27.0 * (n0 + n1 + n2 + n3 + n4);
// }
// 
// 
// void main( void )
// {
// 
//   /* These lines test, in order, 2D classic noise, 2D simplex noise,
//    * 3D classic noise, 3D simplex noise, 4D classic noise, and finally
//    * 4D simplex noise.
//    * Everything but the 4D simpex noise will make some uniform
//    * variables remain unused and be optimized away by the compiler,
//    * so OpenGL will fail to bind them. It's safe to ignore these
//    * warnings from the C program. The program is designed to work anyway.
//    */
//   //float n = noise(v_texCoord2D * 32.0 + 240.0);
//   //float n = snoise(v_texCoord2D * 16.0);
//   //float n = noise(vec3(4.0 * v_texCoord3D.xyz * (2.0 + sin(0.5 * time))));
//   float n = snoise(vec3(2.0 * v_texCoord3D.xyz * (2.0 + sin(0.5 * time))));
//   //float n = noise(vec4(8.0 * v_texCoord3D.xyz, 0.5 * time));
//   //float n = snoise(vec4(4.0 * v_texCoord3D.xyz, 0.5 * time));
// 
//   gl_FragColor = v_color * vec4(0.5 + 0.5 * vec3(n, n, n), 1.0);
// 
// }
const char* GLSLNoise::source__ = "\
uniform sampler2D permTexture;\n\
uniform sampler2D gradTexture;\n\
\n\
#define ONE 0.00390625\n\
#define ONEHALF 0.001953125\n\
\n\
float fade(float t) {\n\
  return t*t*t*(t*(t*6.0-15.0)+10.0); // Improved fade, yields C2-continuous noise\n\
}\n\
\n\
void simplex( const in vec3 P, out vec3 offset1, out vec3 offset2 )\n\
{\n\
  vec3 offset0;\n\
 \n\
  vec2 isX = step( P.yz, P.xx );         // P.x >= P.y ? 1.0 : 0.0;  P.x >= P.z ? 1.0 : 0.0;\n\
  offset0.x  = dot( isX, vec2( 1.0 ) );  // Accumulate all P.x >= other channels in offset.x\n\
  offset0.yz = 1.0 - isX;                // Accumulate all P.x <  other channels in offset.yz\n\
\n\
  float isY = step( P.z, P.y );          // P.y >= P.z ? 1.0 : 0.0;\n\
  offset0.y += isY;                      // Accumulate P.y >= P.z in offset.y\n\
  offset0.z += 1.0 - isY;                // Accumulate P.y <  P.z in offset.z\n\
 \n\
\n\
  offset2 = clamp(   offset0, 0.0, 1.0 );\n\
  offset1 = clamp( --offset0, 0.0, 1.0 );\n\
}\n\
\n\
void simplex( const in vec4 P, out vec4 offset1, out vec4 offset2, out vec4 offset3 )\n\
{\n\
  vec4 offset0;\n\
 \n\
  vec3 isX = step( P.yzw, P.xxx );        // See comments in 3D simplex function\n\
  offset0.x = dot( isX, vec3( 1.0 ) );\n\
  offset0.yzw = 1.0 - isX;\n\
\n\
  vec2 isY = step( P.zw, P.yy );\n\
  offset0.y += dot( isY, vec2( 1.0 ) );\n\
  offset0.zw += 1.0 - isY;\n\
 \n\
  float isZ = step( P.w, P.z );\n\
  offset0.z += isZ;\n\
  offset0.w += 1.0 - isZ;\n\
\n\
  offset3 = clamp(   offset0, 0.0, 1.0 );\n\
  offset2 = clamp( --offset0, 0.0, 1.0 );\n\
  offset1 = clamp( --offset0, 0.0, 1.0 );\n\
}\n\
\n\
float noise(vec2 P)\n\
{\n\
  vec2 Pi = ONE*floor(P)+ONEHALF; // Integer part, scaled and offset for texture lookup\n\
  vec2 Pf = fract(P);             // Fractional part for interpolation\n\
\n\
  vec2 grad00 = texture2D(permTexture, Pi).rg * 4.0 - 1.0;\n\
  float n00 = dot(grad00, Pf);\n\
\n\
  vec2 grad10 = texture2D(permTexture, Pi + vec2(ONE, 0.0)).rg * 4.0 - 1.0;\n\
  float n10 = dot(grad10, Pf - vec2(1.0, 0.0));\n\
\n\
  vec2 grad01 = texture2D(permTexture, Pi + vec2(0.0, ONE)).rg * 4.0 - 1.0;\n\
  float n01 = dot(grad01, Pf - vec2(0.0, 1.0));\n\
\n\
  vec2 grad11 = texture2D(permTexture, Pi + vec2(ONE, ONE)).rg * 4.0 - 1.0;\n\
  float n11 = dot(grad11, Pf - vec2(1.0, 1.0));\n\
\n\
  vec2 n_x = mix(vec2(n00, n01), vec2(n10, n11), fade(Pf.x));\n\
\n\
  float n_xy = mix(n_x.x, n_x.y, fade(Pf.y));\n\
\n\
  return n_xy;\n\
}\n\
\n\
\n\
float noise(vec3 P)\n\
{\n\
  vec3 Pi = ONE*floor(P)+ONEHALF; // Integer part, scaled so +1 moves one texel\n\
                                  // and offset 1/2 texel to sample texel centers\n\
  vec3 Pf = fract(P);     // Fractional part for interpolation\n\
\n\
  float perm00 = texture2D(permTexture, Pi.xy).a ;\n\
  vec3  grad000 = texture2D(permTexture, vec2(perm00, Pi.z)).rgb * 4.0 - 1.0;\n\
  float n000 = dot(grad000, Pf);\n\
  vec3  grad001 = texture2D(permTexture, vec2(perm00, Pi.z + ONE)).rgb * 4.0 - 1.0;\n\
  float n001 = dot(grad001, Pf - vec3(0.0, 0.0, 1.0));\n\
\n\
  float perm01 = texture2D(permTexture, Pi.xy + vec2(0.0, ONE)).a ;\n\
  vec3  grad010 = texture2D(permTexture, vec2(perm01, Pi.z)).rgb * 4.0 - 1.0;\n\
  float n010 = dot(grad010, Pf - vec3(0.0, 1.0, 0.0));\n\
  vec3  grad011 = texture2D(permTexture, vec2(perm01, Pi.z + ONE)).rgb * 4.0 - 1.0;\n\
  float n011 = dot(grad011, Pf - vec3(0.0, 1.0, 1.0));\n\
\n\
  float perm10 = texture2D(permTexture, Pi.xy + vec2(ONE, 0.0)).a ;\n\
  vec3  grad100 = texture2D(permTexture, vec2(perm10, Pi.z)).rgb * 4.0 - 1.0;\n\
  float n100 = dot(grad100, Pf - vec3(1.0, 0.0, 0.0));\n\
  vec3  grad101 = texture2D(permTexture, vec2(perm10, Pi.z + ONE)).rgb * 4.0 - 1.0;\n\
  float n101 = dot(grad101, Pf - vec3(1.0, 0.0, 1.0));\n\
\n\
  float perm11 = texture2D(permTexture, Pi.xy + vec2(ONE, ONE)).a ;\n\
  vec3  grad110 = texture2D(permTexture, vec2(perm11, Pi.z)).rgb * 4.0 - 1.0;\n\
  float n110 = dot(grad110, Pf - vec3(1.0, 1.0, 0.0));\n\
  vec3  grad111 = texture2D(permTexture, vec2(perm11, Pi.z + ONE)).rgb * 4.0 - 1.0;\n\
  float n111 = dot(grad111, Pf - vec3(1.0, 1.0, 1.0));\n\
\n\
  vec4 n_x = mix(vec4(n000, n001, n010, n011),\n\
                 vec4(n100, n101, n110, n111), fade(Pf.x));\n\
\n\
  vec2 n_xy = mix(n_x.xy, n_x.zw, fade(Pf.y));\n\
\n\
  float n_xyz = mix(n_xy.x, n_xy.y, fade(Pf.z));\n\
\n\
  return n_xyz;\n\
}\n\
\n\
float noise(vec4 P)\n\
{\n\
  vec4 Pi = ONE*floor(P)+ONEHALF; // Integer part, scaled so +1 moves one texel\n\
                                  // and offset 1/2 texel to sample texel centers\n\
  vec4 Pf = fract(P);      // Fractional part for interpolation\n\
\n\
  float perm00xy = texture2D(permTexture, Pi.xy).a ;\n\
  float perm00zw = texture2D(permTexture, Pi.zw).a ;\n\
  vec4 grad0000 = texture2D(gradTexture, vec2(perm00xy, perm00zw)).rgba * 4.0 -1.0;\n\
  float n0000 = dot(grad0000, Pf);\n\
\n\
  float perm01zw = texture2D(permTexture, Pi.zw  + vec2(0.0, ONE)).a ;\n\
  vec4  grad0001 = texture2D(gradTexture, vec2(perm00xy, perm01zw)).rgba * 4.0 - 1.0;\n\
  float n0001 = dot(grad0001, Pf - vec4(0.0, 0.0, 0.0, 1.0));\n\
\n\
  float perm10zw = texture2D(permTexture, Pi.zw  + vec2(ONE, 0.0)).a ;\n\
  vec4  grad0010 = texture2D(gradTexture, vec2(perm00xy, perm10zw)).rgba * 4.0 - 1.0;\n\
  float n0010 = dot(grad0010, Pf - vec4(0.0, 0.0, 1.0, 0.0));\n\
\n\
  float perm11zw = texture2D(permTexture, Pi.zw  + vec2(ONE, ONE)).a ;\n\
  vec4  grad0011 = texture2D(gradTexture, vec2(perm00xy, perm11zw)).rgba * 4.0 - 1.0;\n\
  float n0011 = dot(grad0011, Pf - vec4(0.0, 0.0, 1.0, 1.0));\n\
\n\
  float perm01xy = texture2D(permTexture, Pi.xy + vec2(0.0, ONE)).a ;\n\
  vec4  grad0100 = texture2D(gradTexture, vec2(perm01xy, perm00zw)).rgba * 4.0 - 1.0;\n\
  float n0100 = dot(grad0100, Pf - vec4(0.0, 1.0, 0.0, 0.0));\n\
\n\
  vec4  grad0101 = texture2D(gradTexture, vec2(perm01xy, perm01zw)).rgba * 4.0 - 1.0;\n\
  float n0101 = dot(grad0101, Pf - vec4(0.0, 1.0, 0.0, 1.0));\n\
\n\
  vec4  grad0110 = texture2D(gradTexture, vec2(perm01xy, perm10zw)).rgba * 4.0 - 1.0;\n\
  float n0110 = dot(grad0110, Pf - vec4(0.0, 1.0, 1.0, 0.0));\n\
\n\
  vec4  grad0111 = texture2D(gradTexture, vec2(perm01xy, perm11zw)).rgba * 4.0 - 1.0;\n\
  float n0111 = dot(grad0111, Pf - vec4(0.0, 1.0, 1.0, 1.0));\n\
\n\
  float perm10xy = texture2D(permTexture, Pi.xy + vec2(ONE, 0.0)).a ;\n\
  vec4  grad1000 = texture2D(gradTexture, vec2(perm10xy, perm00zw)).rgba * 4.0 - 1.0;\n\
  float n1000 = dot(grad1000, Pf - vec4(1.0, 0.0, 0.0, 0.0));\n\
\n\
  vec4  grad1001 = texture2D(gradTexture, vec2(perm10xy, perm01zw)).rgba * 4.0 - 1.0;\n\
  float n1001 = dot(grad1001, Pf - vec4(1.0, 0.0, 0.0, 1.0));\n\
\n\
  vec4  grad1010 = texture2D(gradTexture, vec2(perm10xy, perm10zw)).rgba * 4.0 - 1.0;\n\
  float n1010 = dot(grad1010, Pf - vec4(1.0, 0.0, 1.0, 0.0));\n\
\n\
  vec4  grad1011 = texture2D(gradTexture, vec2(perm10xy, perm11zw)).rgba * 4.0 - 1.0;\n\
  float n1011 = dot(grad1011, Pf - vec4(1.0, 0.0, 1.0, 1.0));\n\
\n\
  float perm11xy = texture2D(permTexture, Pi.xy + vec2(ONE, ONE)).a ;\n\
  vec4  grad1100 = texture2D(gradTexture, vec2(perm11xy, perm00zw)).rgba * 4.0 - 1.0;\n\
  float n1100 = dot(grad1100, Pf - vec4(1.0, 1.0, 0.0, 0.0));\n\
\n\
  vec4  grad1101 = texture2D(gradTexture, vec2(perm11xy, perm01zw)).rgba * 4.0 - 1.0;\n\
  float n1101 = dot(grad1101, Pf - vec4(1.0, 1.0, 0.0, 1.0));\n\
\n\
  vec4  grad1110 = texture2D(gradTexture, vec2(perm11xy, perm10zw)).rgba * 4.0 - 1.0;\n\
  float n1110 = dot(grad1110, Pf - vec4(1.0, 1.0, 1.0, 0.0));\n\
\n\
  vec4  grad1111 = texture2D(gradTexture, vec2(perm11xy, perm11zw)).rgba * 4.0 - 1.0;\n\
  float n1111 = dot(grad1111, Pf - vec4(1.0, 1.0, 1.0, 1.0));\n\
\n\
  float fadex = fade(Pf.x);\n\
  vec4 n_x0 = mix(vec4(n0000, n0001, n0010, n0011),\n\
                  vec4(n1000, n1001, n1010, n1011), fadex);\n\
  vec4 n_x1 = mix(vec4(n0100, n0101, n0110, n0111),\n\
                  vec4(n1100, n1101, n1110, n1111), fadex);\n\
\n\
  vec4 n_xy = mix(n_x0, n_x1, fade(Pf.y));\n\
\n\
  vec2 n_xyz = mix(n_xy.xy, n_xy.zw, fade(Pf.z));\n\
\n\
  float n_xyzw = mix(n_xyz.x, n_xyz.y, fade(Pf.w));\n\
\n\
  return n_xyzw;\n\
}\n\
\n\
\n\
float snoise(vec2 P) {\n\
\n\
#define F2 0.366025403784\n\
#define G2 0.211324865405\n\
\n\
 	float s = (P.x + P.y) * F2;   // Hairy factor for 2D skewing\n\
  vec2 Pi = floor(P + s);\n\
  float t = (Pi.x + Pi.y) * G2; // Hairy factor for unskewing\n\
  vec2 P0 = Pi - t; // Unskew the cell origin back to (x,y) space\n\
  Pi = Pi * ONE + ONEHALF; // Integer part, scaled and offset for texture lookup\n\
\n\
  vec2 Pf0 = P - P0;  // The x,y distances from the cell origin\n\
\n\
  vec2 o1;\n\
  if(Pf0.x > Pf0.y) o1 = vec2(1.0, 0.0);  // +x, +y traversal order\n\
  else o1 = vec2(0.0, 1.0);               // +y, +x traversal order\n\
\n\
  vec2 grad0 = texture2D(permTexture, Pi).rg * 4.0 - 1.0;\n\
  float t0 = 0.5 - dot(Pf0, Pf0);\n\
  float n0;\n\
  if (t0 < 0.0) n0 = 0.0;\n\
  else {\n\
    t0 *= t0;\n\
    n0 = t0 * t0 * dot(grad0, Pf0);\n\
  }\n\
\n\
  vec2 Pf1 = Pf0 - o1 + G2;\n\
  vec2 grad1 = texture2D(permTexture, Pi + o1*ONE).rg * 4.0 - 1.0;\n\
  float t1 = 0.5 - dot(Pf1, Pf1);\n\
  float n1;\n\
  if (t1 < 0.0) n1 = 0.0;\n\
  else {\n\
    t1 *= t1;\n\
    n1 = t1 * t1 * dot(grad1, Pf1);\n\
  }\n\
  \n\
  vec2 Pf2 = Pf0 - vec2(1.0-2.0*G2);\n\
  vec2 grad2 = texture2D(permTexture, Pi + vec2(ONE, ONE)).rg * 4.0 - 1.0;\n\
  float t2 = 0.5 - dot(Pf2, Pf2);\n\
  float n2;\n\
  if(t2 < 0.0) n2 = 0.0;\n\
  else {\n\
    t2 *= t2;\n\
    n2 = t2 * t2 * dot(grad2, Pf2);\n\
  }\n\
\n\
  return 70.0 * (n0 + n1 + n2);\n\
}\n\
\n\
float snoise(vec3 P) {\n\
#define F3 0.333333333333\n\
#define G3 0.166666666667\n\
\n\
 	float s = (P.x + P.y + P.z) * F3; // Factor for 3D skewing\n\
  vec3 Pi = floor(P + s);\n\
  float t = (Pi.x + Pi.y + Pi.z) * G3;\n\
  vec3 P0 = Pi - t; // Unskew the cell origin back to (x,y,z) space\n\
  Pi = Pi * ONE + ONEHALF; // Integer part, scaled and offset for texture lookup\n\
\n\
  vec3 Pf0 = P - P0;  // The x,y distances from the cell origin\n\
\n\
  vec3 o1;\n\
  vec3 o2;\n\
  simplex(Pf0, o1, o2);\n\
\n\
  float perm0 = texture2D(permTexture, Pi.xy).a;\n\
  vec3  grad0 = texture2D(permTexture, vec2(perm0, Pi.z)).rgb * 4.0 - 1.0;\n\
  float t0 = 0.6 - dot(Pf0, Pf0);\n\
  float n0;\n\
  if (t0 < 0.0) n0 = 0.0;\n\
  else {\n\
    t0 *= t0;\n\
    n0 = t0 * t0 * dot(grad0, Pf0);\n\
  }\n\
\n\
  vec3 Pf1 = Pf0 - o1 + G3;\n\
  float perm1 = texture2D(permTexture, Pi.xy + o1.xy*ONE).a;\n\
  vec3  grad1 = texture2D(permTexture, vec2(perm1, Pi.z + o1.z*ONE)).rgb * 4.0 - 1.0;\n\
  float t1 = 0.6 - dot(Pf1, Pf1);\n\
  float n1;\n\
  if (t1 < 0.0) n1 = 0.0;\n\
  else {\n\
    t1 *= t1;\n\
    n1 = t1 * t1 * dot(grad1, Pf1);\n\
  }\n\
  \n\
  vec3 Pf2 = Pf0 - o2 + 2.0 * G3;\n\
  float perm2 = texture2D(permTexture, Pi.xy + o2.xy*ONE).a;\n\
  vec3  grad2 = texture2D(permTexture, vec2(perm2, Pi.z + o2.z*ONE)).rgb * 4.0 - 1.0;\n\
  float t2 = 0.6 - dot(Pf2, Pf2);\n\
  float n2;\n\
  if (t2 < 0.0) n2 = 0.0;\n\
  else {\n\
    t2 *= t2;\n\
    n2 = t2 * t2 * dot(grad2, Pf2);\n\
  }\n\
  \n\
  vec3 Pf3 = Pf0 - vec3(1.0-3.0*G3);\n\
  float perm3 = texture2D(permTexture, Pi.xy + vec2(ONE, ONE)).a;\n\
  vec3  grad3 = texture2D(permTexture, vec2(perm3, Pi.z + ONE)).rgb * 4.0 - 1.0;\n\
  float t3 = 0.6 - dot(Pf3, Pf3);\n\
  float n3;\n\
  if(t3 < 0.0) n3 = 0.0;\n\
  else {\n\
    t3 *= t3;\n\
    n3 = t3 * t3 * dot(grad3, Pf3);\n\
  }\n\
\n\
  return 32.0 * (n0 + n1 + n2 + n3);\n\
}\n\
\n\
\n\
float snoise(vec4 P) {\n\
\n\
#define F4 0.309016994375\n\
#define G4 0.138196601125\n\
\n\
 	float s = (P.x + P.y + P.z + P.w) * F4; // Factor for 4D skewing\n\
  vec4 Pi = floor(P + s);\n\
  float t = (Pi.x + Pi.y + Pi.z + Pi.w) * G4;\n\
  vec4 P0 = Pi - t; // Unskew the cell origin back to (x,y,z,w) space\n\
  Pi = Pi * ONE + ONEHALF; // Integer part, scaled and offset for texture lookup\n\
\n\
  vec4 Pf0 = P - P0;  // The x,y distances from the cell origin\n\
\n\
  vec4 o1;\n\
  vec4 o2;\n\
  vec4 o3;\n\
  simplex(Pf0, o1, o2, o3);  \n\
\n\
  float perm0xy = texture2D(permTexture, Pi.xy).a;\n\
  float perm0zw = texture2D(permTexture, Pi.zw).a;\n\
  vec4  grad0 = texture2D(gradTexture, vec2(perm0xy, perm0zw)).rgba * 4.0 - 1.0;\n\
  float t0 = 0.6 - dot(Pf0, Pf0);\n\
  float n0;\n\
  if (t0 < 0.0) n0 = 0.0;\n\
  else {\n\
    t0 *= t0;\n\
    n0 = t0 * t0 * dot(grad0, Pf0);\n\
  }\n\
\n\
  vec4 Pf1 = Pf0 - o1 + G4;\n\
  o1 = o1 * ONE;\n\
  float perm1xy = texture2D(permTexture, Pi.xy + o1.xy).a;\n\
  float perm1zw = texture2D(permTexture, Pi.zw + o1.zw).a;\n\
  vec4  grad1 = texture2D(gradTexture, vec2(perm1xy, perm1zw)).rgba * 4.0 - 1.0;\n\
  float t1 = 0.6 - dot(Pf1, Pf1);\n\
  float n1;\n\
  if (t1 < 0.0) n1 = 0.0;\n\
  else {\n\
    t1 *= t1;\n\
    n1 = t1 * t1 * dot(grad1, Pf1);\n\
  }\n\
  \n\
  vec4 Pf2 = Pf0 - o2 + 2.0 * G4;\n\
  o2 = o2 * ONE;\n\
  float perm2xy = texture2D(permTexture, Pi.xy + o2.xy).a;\n\
  float perm2zw = texture2D(permTexture, Pi.zw + o2.zw).a;\n\
  vec4  grad2 = texture2D(gradTexture, vec2(perm2xy, perm2zw)).rgba * 4.0 - 1.0;\n\
  float t2 = 0.6 - dot(Pf2, Pf2);\n\
  float n2;\n\
  if (t2 < 0.0) n2 = 0.0;\n\
  else {\n\
    t2 *= t2;\n\
    n2 = t2 * t2 * dot(grad2, Pf2);\n\
  }\n\
  \n\
  vec4 Pf3 = Pf0 - o3 + 3.0 * G4;\n\
  o3 = o3 * ONE;\n\
  float perm3xy = texture2D(permTexture, Pi.xy + o3.xy).a;\n\
  float perm3zw = texture2D(permTexture, Pi.zw + o3.zw).a;\n\
  vec4  grad3 = texture2D(gradTexture, vec2(perm3xy, perm3zw)).rgba * 4.0 - 1.0;\n\
  float t3 = 0.6 - dot(Pf3, Pf3);\n\
  float n3;\n\
  if (t3 < 0.0) n3 = 0.0;\n\
  else {\n\
    t3 *= t3;\n\
    n3 = t3 * t3 * dot(grad3, Pf3);\n\
  }\n\
  \n\
  vec4 Pf4 = Pf0 - vec4(1.0-4.0*G4);\n\
  float perm4xy = texture2D(permTexture, Pi.xy + vec2(ONE, ONE)).a;\n\
  float perm4zw = texture2D(permTexture, Pi.zw + vec2(ONE, ONE)).a;\n\
  vec4  grad4 = texture2D(gradTexture, vec2(perm4xy, perm4zw)).rgba * 4.0 - 1.0;\n\
  float t4 = 0.6 - dot(Pf4, Pf4);\n\
  float n4;\n\
  if(t4 < 0.0) n4 = 0.0;\n\
  else {\n\
    t4 *= t4;\n\
    n4 = t4 * t4 * dot(grad4, Pf4);\n\
  }\n\
\n\
  return 27.0 * (n0 + n1 + n2 + n3 + n4);\n\
}\n\
";

void GLSLNoise::bindPermTexture(ProgramObject& prog, int textureUnit) {
    prog.setUniform1i("permTexture", textureUnit);
    glActiveTexture(GL_TEXTURE0 + textureUnit);
    glBindTexture(GL_TEXTURE_2D, permTextureID__);
    glEnable(GL_TEXTURE_2D);
    glActiveTexture(GL_TEXTURE0);
}
void GLSLNoise::bindGradTexture(ProgramObject& prog, int textureUnit) {
    prog.setUniform1i("gradTexture", textureUnit);
    glActiveTexture(GL_TEXTURE0 + textureUnit);
    glBindTexture(GL_TEXTURE_2D, gradTextureID__);
    glEnable(GL_TEXTURE_2D);
    glActiveTexture(GL_TEXTURE0);
}
void GLSLNoise::unbindTexture(int textureUnit) {
    glActiveTexture(GL_TEXTURE0 + textureUnit);
    glBindTexture(GL_TEXTURE_2D, 0);
    glDisable(GL_TEXTURE_2D);
    glActiveTexture(GL_TEXTURE0);
}

//   initPermTexture() - create and load a 2D texture for
// a combined index permutation and gradient lookup table.
// This texture is used for 2D and 3D noise, both classic and simplex.
void GLSLNoise::initPermTexture() {
    vector<char> pixels ( 256*256*4 );
    int i,j;
    for(i = 0; i<256; i++) {
        for(j = 0; j<256; j++) {
            int offset = (i*256+j)*4;
            char value = perm__[(j+perm__[i]) & 0xFF];
            pixels[offset] = grad3__[value & 0x0F][0] * 64 + 64;   // Gradient x
            pixels[offset+1] = grad3__[value & 0x0F][1] * 64 + 64; // Gradient y
            pixels[offset+2] = grad3__[value & 0x0F][2] * 64 + 64; // Gradient z
            pixels[offset+3] = value;                     // Permuted index
        }
    }

    glGenTextures(1, &permTextureID__);
    glBindTexture(GL_TEXTURE_2D, permTextureID__);
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, &pixels[0] );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
    glBindTexture(GL_TEXTURE_2D, 0);
}

//   initGradTexture() - create and load a 2D texture
// for a 4D gradient lookup table. This is used for 4D noise only.
void GLSLNoise::initGradTexture() {
    vector<char> pixels( 256*256*4 );
    int i,j;
    for(i = 0; i<256; i++) {
        for(j = 0; j<256; j++) {
            int offset = (i*256+j)*4;
            char value = perm__[(j+perm__[i]) & 0xFF];
            pixels[offset] = grad4__[value & 0x1F][0] * 64 + 64;   // Gradient x
            pixels[offset+1] = grad4__[value & 0x1F][1] * 64 + 64; // Gradient y
            pixels[offset+2] = grad4__[value & 0x1F][2] * 64 + 64; // Gradient z
            pixels[offset+3] = grad4__[value & 0x1F][3] * 64 + 64; // Gradient w
        }
    }

    glGenTextures(1, &gradTextureID__);
    glBindTexture(GL_TEXTURE_2D, gradTextureID__);
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, 256, 256, 0, GL_RGBA, GL_UNSIGNED_BYTE, &pixels[0] );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST );
    glTexParameteri( GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST );
    glBindTexture(GL_TEXTURE_2D, 0);
}
void GLSLNoise::finalize() {
    glDeleteTextures(1, &permTextureID__);
    glDeleteTextures(1, &gradTextureID__);
}

