#include "stdafx.h"
#include "CholmodMatrix.h"

namespace KLIB {

cholmod_common CholmodMatrix::common__;
CholmodMatrix operator*(double s, const CholmodMatrix& M) { return M * s; }

}
