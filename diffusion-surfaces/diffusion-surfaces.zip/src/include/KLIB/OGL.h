#pragma once

//#define USE_MULTISAMPLING

#ifdef USE_MULTISAMPLING
#include <GL/glew.h>
#include <GL/wglew.h>
#endif

#ifndef M_PI
#   define M_PI 3.1415926535897932384626433832795
#endif

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glaux.h>
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glaux.lib")

#include "Vector.h"
#include "Matrix.h"
#include "Util.h"
#include "GLUtil.h"

#include <iostream>
#include <vector>

namespace KLIB {

class OGL {
// member data
public:
    float clearColor_[4];
    // frustum parameter
    struct PersParam {
        PersParam() : fovy_(30), zNear_(0.01), zFar_(10000) {}
        double fovy_;
        double zNear_;
        double zFar_;
    } persParam_;
    // camera position parameter
    struct ViewParam {
        ViewParam() : eyePoint_(0, 0, 5), focusPoint_(0, 0, 0), upDirection_(0, 1, 0) {}
        Vector3d eyePoint_;
        Vector3d focusPoint_;
        Vector3d upDirection_;
    } viewParam_;

private:
    CWnd* wnd_;
    CDC* dc_;
    HGLRC hdc_;
    bool isDrawing_;
    bool isButtonDown_;
    CPoint prevpos_;
    enum {
        BUTTONDOWN_ROTATE,
        BUTTONDOWN_TRANSLATE,
        BUTTONDOWN_ZOOM
    } buttonDownMotionType_;

    bool isAutoRotate_;
// constructor & destructor
public:
    OGL() 
        : persParam_()
        , viewParam_()
        , wnd_(0)
        , dc_(0)
        , isDrawing_   (false)
        , isButtonDown_(false)
        , buttonDownMotionType_(BUTTONDOWN_ROTATE)
        , isAutoRotate_(false)
    {
        clearColor_[0] = clearColor_[1] = clearColor_[2] = clearColor_[3] = 1.0f;
    }
    ~OGL() {}
    
// member functions
public:
    bool OnCreate(CWnd* wnd) {
        wnd_ = wnd ;
        dc_ = new CClientDC(wnd);
        if (!dc_) return false;
        if (!setupPixelFormat()) return false;
        if ((hdc_ = wglCreateContext(dc_->GetSafeHdc())) == 0) return false;
        if (!wglMakeCurrent(dc_->GetSafeHdc(), hdc_)) return false;
        initOpenGL();
        return true;
    }
    void OnDraw_Begin() {
        isDrawing_ = true;
        makeOpenGLCurrent() ;
        glClearColor(clearColor_[0], clearColor_[1], clearColor_[2], clearColor_[3]);
        glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_ACCUM_BUFFER_BIT );
        glMatrixMode( GL_MODELVIEW ) ;
    }
    void OnDraw_End() {
        glFinish();
        SwapBuffers(dc_->GetSafeHdc());
        wglMakeCurrent(0, 0);
        isDrawing_ = false ;
    }
    void OnDestroy() {
        makeOpenGLCurrent() ;
        wglMakeCurrent(0, 0);
        wglDeleteContext(hdc_);
        if (dc_) delete dc_;
    }
    void OnSize(int cx, int cy) const {
        makeOpenGLCurrent() ;
        if (cx <= 0 || cy <= 0)	return;
        glViewport(0, 0, cx, cy);
        // select the viewing volume
        glMatrixMode( GL_PROJECTION );
        glLoadIdentity();
        gluPerspective(persParam_.fovy_, cx / static_cast<double>(cy), persParam_.zNear_, persParam_.zFar_);
        glMatrixMode( GL_MODELVIEW ) ;
        glLoadIdentity();
        updateView();
    }
    void ButtonDownForZoom(const CPoint& pos) {
        isButtonDown_ = true;
        prevpos_ = pos;
        wnd_->SetCapture();
        buttonDownMotionType_ = BUTTONDOWN_ZOOM;
    }
    void ButtonDownForRotate(const CPoint& pos) {
        isButtonDown_ = true;
        prevpos_ = pos;
        wnd_->SetCapture();
        buttonDownMotionType_ = BUTTONDOWN_ROTATE;
    }
    void ButtonDownForTranslate(const CPoint& pos) {
        isButtonDown_ = true;
        prevpos_ = pos;
        wnd_->SetCapture();
        buttonDownMotionType_ = BUTTONDOWN_TRANSLATE;
    }
    void MouseMove(const CPoint& pos) {
        makeOpenGLCurrent();
        if(isButtonDown_ && wnd_ == wnd_->GetCapture()){
            switch( buttonDownMotionType_ ){
            case BUTTONDOWN_ROTATE:
                {
                    double thetaX = 2 * M_PI * (pos.x - prevpos_.x) / getWidth ();
                    double thetaY = 2 * M_PI * (pos.y - prevpos_.y) / getHeight();

                    // Horizontal rotation
                    Matrix3x3d rotH = Util::rotationFromAxisAngle(viewParam_.upDirection_, -thetaX);
                    Vector3d eye = viewParam_.eyePoint_ - viewParam_.focusPoint_;
                    eye = rotH * eye;

                    // Vertical rotation
                    Vector3d leftDirection = cross_product(eye, viewParam_.upDirection_);
                    Matrix3x3d rotV = Util::rotationFromAxisAngle(leftDirection, thetaY);
                    eye = rotV * eye;
                    viewParam_.upDirection_ = rotV * viewParam_.upDirection_;

                    viewParam_.eyePoint_ = viewParam_.focusPoint_ + eye;
                }
                break;
            case BUTTONDOWN_TRANSLATE:
                {
                    Vector3d eye = viewParam_.eyePoint_ - viewParam_.focusPoint_;
                    Vector3d leftDirection = cross_product(eye, viewParam_.upDirection_);

                    double len = eye.length();
                    Vector3d transX(leftDirection);
                    Vector3d transY(viewParam_.upDirection_);
                    transX.normalize();
                    transY.normalize();
                    transX *= len * (pos.x - prevpos_.x) / getWidth ();
                    transY *= len * (pos.y - prevpos_.y) / getHeight();
                    
                    viewParam_.eyePoint_ += transX;
                    viewParam_.eyePoint_ += transY;
                    viewParam_.focusPoint_ += transX;
                    viewParam_.focusPoint_ += transY;
                }
                break;
            case BUTTONDOWN_ZOOM:
                {
                    Vector3d eyeDirection = viewParam_.focusPoint_ - viewParam_.eyePoint_;
                    eyeDirection *= (pos.y - prevpos_.y) / static_cast<double>(getHeight());

                    viewParam_.eyePoint_ += eyeDirection;
                }
                break;
            }
            prevpos_ = pos;
            updateView();
            RedrawWindow();
        }
    }
    void ButtonUp() {
        if(wnd_ == wnd_->GetCapture()){
            isButtonDown_ = false;
            ReleaseCapture();
        }
    }
    void updateView() const {
        makeOpenGLCurrent();
        glMatrixMode( GL_MODELVIEW );
        glLoadIdentity();
        gluLookAt(
            viewParam_.eyePoint_[0],
            viewParam_.eyePoint_[1],
            viewParam_.eyePoint_[2],
            viewParam_.focusPoint_[0],
            viewParam_.focusPoint_[1],
            viewParam_.focusPoint_[2],
            viewParam_.upDirection_[0],
            viewParam_.upDirection_[1],
            viewParam_.upDirection_[2]);
    }
    void setView(double eyeX, double eyeY, double eyeZ, double focusX, double focusY, double focusZ, double upX, double upY, double upZ) {
        viewParam_.eyePoint_   .set(eyeX  , eyeY  , eyeZ  );
        viewParam_.focusPoint_ .set(focusX, focusY, focusZ);
        viewParam_.upDirection_.set(upX   , upY   , upZ   );
        updateView();
    }
    void makeOpenGLCurrent() const { wglMakeCurrent( dc_->GetSafeHdc(), hdc_); }
    void startAutoRotate(double delta, size_t cnt = 0, double omega = 0) {
        if (isAutoRotate_)
            return;
        isAutoRotate_ = true;
        size_t i = 0;
        while (true) {
            Vector3d& eye   = viewParam_.eyePoint_;
            Vector3d& focus = viewParam_.focusPoint_;
            Vector3d& up    = viewParam_.upDirection_;

            double temp_delta = delta * cos(i * omega);
            Matrix3x3d rot = Util::rotationFromAxisAngle(up, temp_delta);
            Vector3d focus_eye = eye - focus;
            focus_eye = rot * focus_eye;
            eye = focus + focus_eye;
            updateView();
            RedrawWindow();
            Sleep(1);
            MSG msg;
            while(::PeekMessage( &msg, NULL, NULL, NULL, PM_NOREMOVE ))
                AfxGetThread()->PumpMessage();
            ++i;
            if (!isAutoRotate_ || i == cnt)
                break;
        }
        isAutoRotate_ = false;
    }
    bool isAutoRotate() const { return isAutoRotate_; }
    void stopAutoRotate() {
        isAutoRotate_ = false;
    }
    bool outputBitmap(const char* filename) const {
        RECT rect ;
        wnd_->GetClientRect( &rect ) ;
        int o = 4-((rect.right*3) % 4) ;
        o = (o==4?0:o) ;
        const int imgsize = (rect.right*3+o)*rect.bottom ;
        std::vector<char> imagebits(imgsize);
        makeOpenGLCurrent() ;
        glReadPixels( 0,0,rect.right,rect.bottom,GL_BGR_EXT
            ,GL_UNSIGNED_BYTE,&imagebits[0] ) ;
        BITMAPFILEHEADER bmfh ;		ZeroMemory( &bmfh,sizeof(BITMAPFILEHEADER) ) ;
        BITMAPINFOHEADER bmih ;			ZeroMemory( &bmih,sizeof(BITMAPINFOHEADER) ) ;
        bmfh.bfType = 0x4d42;  // 'BM'
        bmfh.bfSize = sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+imgsize ;
        bmfh.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) ;
        bmih.biSize = sizeof(BITMAPINFOHEADER);
        bmih.biWidth = rect.right ;
        bmih.biHeight = rect.bottom ;
        bmih.biPlanes = 1;
        bmih.biBitCount = 24 ;
        bmih.biCompression = BI_RGB ;
        bmih.biSizeImage = imgsize ;
        FILE* fp = fopen( filename,"wb" ) ;
        if( !fp
            || fwrite( &bmfh,sizeof( BITMAPFILEHEADER ),1,fp ) < 1
            || fwrite( &bmih,sizeof( BITMAPINFOHEADER ),1,fp ) < 1
            || fwrite( &imagebits[0],1,imgsize,fp ) < (unsigned)imgsize ) 
        {
            return false;
        } else {
            fclose(fp);
            return true;
        }
    }
    CDC* getDC() const { return dc_; }
    int getWidth () const { RECT rect; wnd_->GetClientRect(&rect); return rect.right  - rect.left; }
    int getHeight() const { RECT rect; wnd_->GetClientRect(&rect); return rect.bottom - rect.top;  }
    Vector3d project(const Vector3d& worldPos) const {
        makeOpenGLCurrent();
        int vp[4] ;
        double model[16], proj[16] ;
        glGetIntegerv(GL_VIEWPORT, vp) ;
        glGetDoublev(GL_MODELVIEW_MATRIX, model) ;
        glGetDoublev(GL_PROJECTION_MATRIX, proj) ;
        Vector3d screenPos;
        gluProject(worldPos[0], worldPos[1], worldPos[2], model, proj, vp, &screenPos[0], &screenPos[1], &screenPos[2]);
        screenPos[1] = vp[3] - 1 - screenPos[1];
        //wglMakeCurrent(NULL, NULL);   // unnecessary?
        return screenPos;
    }
    Vector3d unproject(const Vector2d& screenPos) const {
        int vp[4] ;
        double model[16], proj[16] ;
        makeOpenGLCurrent();
        glGetIntegerv(GL_VIEWPORT, vp) ;
        glGetDoublev(GL_MODELVIEW_MATRIX,  model) ;
        glGetDoublev(GL_PROJECTION_MATRIX, proj) ;
        Vector3d worldPos;
        gluUnProject( screenPos[0], vp[3] - 1 - screenPos[1], 1.0, model , proj, vp, &worldPos[0], &worldPos[1], &worldPos[2]);
        //wglMakeCurrent(NULL, NULL);   // unnecessary?
        return worldPos;
    }
    void getScreenCoordToGlobalLine(int cx, int cy, Vector3d& start, Vector3d& ori) const {
        makeOpenGLCurrent();
	    start = viewParam_.eyePoint_;
        ori = unproject(Vector2d(cx, cy));
        ori -= start;
        ori.normalize();
    }
    void RedrawWindow() const { if (wnd_) wnd_->RedrawWindow(); }
    void initOpenGL() {
        glClearColor(clearColor_[0], clearColor_[1], clearColor_[2], clearColor_[3]);
        glClearDepth( 1.0f );
        glEnable( GL_DEPTH_TEST );
        //glDepthFunc( GL_LEQUAL ) ;
        //glEnable( GL_BLEND );
        //glDisable( GL_BLEND );
        //glBlendFunc( GL_ONE_MINUS_SRC_ALPHA,GL_SRC_ALPHA );
        glBlendFunc( GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA );
        //glBlendFunc( GL_SRC_ALPHA,GL_DST_ALPHA );
        //glBlendFunc( GL_ONE_MINUS_DST_ALPHA,GL_DST_ALPHA );

        GLfloat lightpos[] = { 0, 0, 1, 0 };
        //GLfloat lightpos[] = { 1000,1000,-50000,1 };
        //Shading
        GLfloat spec[] = { 0, 0, 0, 1 };
        GLfloat diff[] = { 0.8f, 0.8f, 0.8f, 1 };
        GLfloat amb[]  = { 0.2f, 0.2f, 0.2f, 1 };
        //GLfloat spec[] = { 0,0,0.05f,1 } ;
        //GLfloat diff[] = { 0.8f,0.8f,0.8f,0.5f };
        //GLfloat amb[]  = { 0.3f,0.3f,0.3f,0.5f };

        GLfloat shininess = 0;	//1.5f ;

        glMaterialfv( GL_FRONT, GL_SPECULAR,  spec );
        glMaterialfv( GL_FRONT, GL_DIFFUSE,   diff );
        glMaterialfv( GL_FRONT, GL_AMBIENT,   amb );
        glMaterialfv( GL_FRONT, GL_SHININESS, &shininess );
        glLightfv(GL_LIGHT0, GL_POSITION, lightpos);

        GLfloat light_Ambient0[] = { 0, 0, 0, 1};
        GLfloat light_Diffuse0[] = { 0.8f, 0.8f, 0.8f, 1};
        GLfloat light_Specular0[]= { 1, 1, 1, 1};
        //GLfloat light_Ambient0[] = { 0.5f , 0.5f , 0.5f , 1};
        //GLfloat light_Diffuse0[] = { 0.8f, 0.8f, 0.8f, 0.8f};
        //GLfloat light_Specular0[]= { 0.1f , 0.1f , 0.1f , 1};
        glLightfv(GL_LIGHT0,GL_AMBIENT,light_Ambient0);
        glLightfv(GL_LIGHT0,GL_DIFFUSE,light_Diffuse0);
        glLightfv(GL_LIGHT0,GL_SPECULAR,light_Specular0);

        GLfloat light_Ambient1[] = { 0,0,0,1};
        GLfloat light_Diffuse1[] = { 0.5f , 0.5f , 0.5f , 1};
        GLfloat light_Specular1[]= { 0,0,0,1};
        glLightfv(GL_LIGHT1,GL_AMBIENT,light_Ambient1);
        glLightfv(GL_LIGHT1,GL_DIFFUSE,light_Diffuse1);
        glLightfv(GL_LIGHT1,GL_SPECULAR,light_Specular1);

        GLfloat light_Ambient2[] = { 0,0,0, 1};
        GLfloat light_Diffuse2[] = { 0.5f , 0.5f , 0.5f , 1};
        GLfloat light_Specular2[]= { 0,0,0,1};
        glLightfv(GL_LIGHT2,GL_AMBIENT,light_Ambient2);
        glLightfv(GL_LIGHT2,GL_DIFFUSE,light_Diffuse2);
        glLightfv(GL_LIGHT2,GL_SPECULAR,light_Specular2);

        glEnable( GL_LIGHT0 );
        glEnable( GL_LIGHT1 );
        //glEnable( GL_LIGHT2 );
        //glEnable( GL_LIGHTING ) ;
        //glEnable( GL_TEXTURE_2D );

        glEnable(GL_COLOR_MATERIAL);
        glColorMaterial(GL_FRONT, GL_DIFFUSE);

        //glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
        //glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
        //glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_DECAL);

        glShadeModel( GL_SMOOTH ) ;
        //glShadeModel( GL_FLAT ) ;
        glPixelStorei( GL_UNPACK_ALIGNMENT,4 ) ;

        glCullFace( GL_BACK ) ;
        glEnable( GL_CULL_FACE ) ;

        glPolygonMode( GL_FRONT,GL_FILL ) ;
        //glEnable( GL_NORMALIZE ) ;
    }
private:
    bool setupPixelFormat() {
#ifndef USE_MULTISAMPLING
        static PIXELFORMATDESCRIPTOR pfd = {
            sizeof(PIXELFORMATDESCRIPTOR),  // size of this pfd
            1,                              // version number
            PFD_DRAW_TO_WINDOW |            // support window
            PFD_SUPPORT_OPENGL |          // support OpenGL
            PFD_DOUBLEBUFFER,             // double buffered
            PFD_TYPE_RGBA,                  // RGBA type
            32,                             // 24-bit color depth
            0, 0, 0, 0, 0, 0,               // color bits ignored
            0,                              // no alpha buffer
            0,                              // shift bit ignored
            0,                              // no accumulation buffer
            0, 0, 0, 0,                     // accum bits ignored
            //        32,                             // 32-bit z-buffer
            16,	// NOTE: better performance with 16-bit z-buffer
            0,                              // no stencil buffer
            0,                              // no auxiliary buffer
            PFD_MAIN_PLANE,                 // main layer
            0,                              // reserved
            0, 0, 0                         // layer masks ignored
        };
        int pixelformat = ChoosePixelFormat(dc_->GetSafeHdc(), &pfd);
        if ( !pixelformat  )	return false;
        if ( !SetPixelFormat(dc_->GetSafeHdc(), pixelformat, &pfd) )
            return false;

#else   // USE_MULTISAMPLING code from http://www.codesampler.com/oglsrc/oglsrc_14.htm#ogl_multisample_transparency
        //
        // We need to create a dummy window to init GLEW...
        //
        HGLRC hRC = NULL;
        GLuint PixelFormat;

        PIXELFORMATDESCRIPTOR pfd;
        memset(&pfd, 0, sizeof(PIXELFORMATDESCRIPTOR));

        pfd.nSize      = sizeof(PIXELFORMATDESCRIPTOR);
        pfd.nVersion   = 1;
        pfd.dwFlags    = PFD_DRAW_TO_WINDOW |PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
        pfd.iPixelType = PFD_TYPE_RGBA;
        pfd.cColorBits = 16;
        pfd.cDepthBits = 16;

        PixelFormat = ChoosePixelFormat( dc_->GetSafeHdc(), &pfd );
        SetPixelFormat( dc_->GetSafeHdc(), PixelFormat, &pfd);
        hRC = wglCreateContext( dc_->GetSafeHdc());
        wglMakeCurrent( dc_->GetSafeHdc(), hRC );

        // Init GLEW and verify that we got the extensions we need...
        GLenum err = glewInit();

        if( err != GLEW_OK )
            return false;

        if( hRC != NULL )
        {
            wglMakeCurrent( NULL, NULL );
            wglDeleteContext( hRC );
            hRC = NULL;
        }

        //
        // GLEW is not setup. Use wglChoosePixelFormatARB to find a valid 
        // multisample configuration.
        //

        int pf_attr[] =
        {
            WGL_SUPPORT_OPENGL_ARB, GL_TRUE,    // Our context will be used with OpenGL
            WGL_RED_BITS_ARB, 8,                // At least 8 bits for RED channel
            WGL_GREEN_BITS_ARB, 8,              // At least 8 bits for GREEN channel
            WGL_BLUE_BITS_ARB, 8,               // At least 8 bits for BLUE channel
            WGL_ALPHA_BITS_ARB, 8,              // At least 8 bits for ALPHA channel
            WGL_DEPTH_BITS_ARB, 24,             // At least 16 bits for depth buffer
            WGL_DOUBLE_BUFFER_ARB, GL_TRUE,     // We don require double buffering
            WGL_SAMPLE_BUFFERS_ARB, GL_TRUE,    // Turn Multi-sampling on
            WGL_SAMPLES_ARB, 4,                 // Check For 4x Multi-sampling
            0                                   // Zero terminates the list
        };

        unsigned int count = 0;
        int nPixelFormat;
        wglChoosePixelFormatARB( dc_->GetSafeHdc(),(const int*)pf_attr, NULL, 1, &nPixelFormat, &count);

        if( count == 0 )
            return false;

        SetPixelFormat( dc_->GetSafeHdc(), nPixelFormat, NULL );
#endif  // USE_MULTISAMPLING
        return true;
    }

};


}   // namespace KLIB
