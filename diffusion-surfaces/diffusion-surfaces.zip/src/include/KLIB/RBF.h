#pragma once
#include "Vector.h"
#include "MatrixVL.h"
#include <vector>
#include <cmath>
#include "LapackWrapper.h"

namespace KLIB {

// example basis functions =========================
template <int N = 1>
class Basis1D {
public:
    typedef Vector<double, N> vector_type;
    static double phi(const vector_type& v0, const vector_type& v1) {
        double r = (v1 - v0).length();
        return r * r * r;
    }
};

template <int N = 2>
class Basis2D {
public:
    typedef Vector<double, N> vector_type;
    static double phi(const vector_type& v0, const vector_type& v1) {
        double r = (v1 - v0).lengthSquared();
        if (r == 0) return 0; else return r * log(sqrt(r));
    }
};

template <int N = 3>
class Basis3D {
public:
    typedef Vector<double, N> vector_type;
    static double phi(const vector_type& v0, const vector_type& v1) { return (v1 - v0).length(); }
};

// general declaration ============================
template <int N, class Basis, int DegPolynom>
class RBF {
public:
    typedef Vector<double, N> vector_type;
private:
    std::vector<vector_type> points_;
    VectorVL<double> coefficients_;
    MatrixVL<double> A_;
    bool isReady_;
public:
    RBF() : isReady_(false) {}
    RBF(const std::vector<vector_type>& points) : isReady_(false) { setPoints(points); }
    ~RBF() {}
    void setPoints(const std::vector<vector_type>& points);
    void setValues(const std::vector<double>& values);
    double getValue(const vector_type& point) const;
    bool isReady() { return isReady_; }
private:
    static double phi(const vector_type& v0, const vector_type& v1) { return Basis::phi(v0, v1); }
};

// implementation of RBF with 0-degree polynomial ===============================
template <int N, class Basis>
class RBF<N, Basis, 0> {
public:
    typedef Vector<double, N> vector_type;
private:
    std::vector<vector_type> points_;
    VectorVL<double> coefficients_;
    MatrixVL<double> A_;
    VectorVLl pivot_;
    bool isReady_;
public:
    RBF() : isReady_(false) {}
    RBF(const std::vector<vector_type>& points) { setPoints(points); }
    ~RBF() {}
    void setPoints(const std::vector<vector_type>& points) {
        points_ = points;
        int n = points_.size();
        int m = n + 1;
        A_.clear();
        A_.resize(m, m, 0);
        for (int i = 0; i < n; ++i) {
            for (int j = i + 1; j < n; ++j) A_(i, j) = A_(j, i) = phi(points_[i], points_[j]);
            A_(i, n) = A_(n, i) = 1;
        }
        long info = LapackWrapper::factorize(A_, pivot_);
        isReady_ = false;
    }
    void setValues(const std::vector<double>& values) {
        int n = points_.size();
        int m = n + 1;
        coefficients_.clear();
        coefficients_.resize(m, 0);
        for (size_t i = 0; i < n; ++i) coefficients_[i] = values[i];
        long info = LapackWrapper::solve(A_, pivot_, coefficients_);
        isReady_ = true;
    }
    double getValue(const vector_type& point) const {
        double result = 0;
        for (int i = 0; i < points_.size(); ++i) result += coefficients_[i] * phi(point, points_[i]);
        result += coefficients_[points_.size()];
        return result;
    }
    bool isReady() { return isReady_; }
private:
    static double phi(const vector_type& v0, const vector_type& v1) { return Basis::phi(v0, v1); }
};

// implementation of RBF with 1-degree polynomial ===============================
template <int N, class Basis>
class RBF<N, Basis, 1> {
public:
    typedef Vector<double, N> vector_type;
private:
    std::vector<vector_type> points_;
    VectorVL<double> coefficients_;
    MatrixVL<double> A_;
    VectorVLl pivot_;
    bool isReady_;
public:
    RBF() : isReady_(false) {}
    RBF(const std::vector<vector_type>& points) { setPoints(points); }
    ~RBF() {}
    void setPoints(const std::vector<vector_type>& points) {
        points_ = points;
        int n = points_.size();
        int m = n + N + 1;
        A_.clear();
        A_.resize(m, m, 0);
        for (int i = 0; i < n; ++i) {
            for (int j = i + 1; j < n; ++j) A_(i, j) = A_(j, i) = phi(points_[i], points_[j]);
            for (int k = 0; k < N; ++k) A_(i, n + k) = A_(n + k, i) = points_[i][k];
            A_(i, n + N) = A_(n + N, i) = 1;
        }
        long info = LapackWrapper::factorize(A_, pivot_);
        isReady_ = false;
    }
    void setValues(const std::vector<double>& values) {
        int n = points_.size();
        int m = n + N + 1;
        coefficients_.clear();
        coefficients_.resize(m, 0);
        for (int i = 0; i < n; ++i) coefficients_[i] = values[i];
        long info = LapackWrapper::solve(A_, pivot_, coefficients_);
        isReady_ = true;
    }
    double getValue(const vector_type& point) const {
        double result = 0;
        int n = points_.size();
        for (int i = 0; i < n; ++i) result += coefficients_[i] * phi(point, points_[i]);
        for (int k = 0; k < N; ++k) result += coefficients_[n + k] * point[k];
        result += coefficients_[n + N];
        return result;
    }
    bool isReady() const { return isReady_; }
private:
    static double phi(const vector_type& v0, const vector_type& v1) { return Basis::phi(v0, v1); }
};

// typedefs =====================================-
typedef RBF<1, Basis1D<1>, 0> ThinPlate1dConst;
typedef RBF<2, Basis2D<2>, 0> ThinPlate2dConst;
typedef RBF<3, Basis3D<3>, 0> ThinPlate3dConst;

typedef RBF<1, Basis1D<1>, 1> ThinPlate1d;
typedef RBF<2, Basis2D<2>, 1> ThinPlate2d;
typedef RBF<3, Basis3D<3>, 1> ThinPlate3d;

}   // namespace KLIB
