#pragma once
#include "GLSLUtil.h"

// /*
//  * 2D, 3D and 4D Perlin noise, classic and simplex, in a GLSL fragment shader.
//  *
//  * Classic noise is implemented by the functions:
//  * float noise(vec2 P)
//  * float noise(vec3 P)
//  * float noise(vec4 P)
//  *
//  * Simplex noise is implemented by the functions:
//  * float snoise(vec2 P)
//  * float snoise(vec3 P)
//  * float snoise(vec4 P)
//  *
//  * Author: Stefan Gustavson ITN-LiTH (stegu@itn.liu.se) 2004-12-05
//  * Simplex indexing functions by Bill Licea-Kane, ATI (bill@ati.com)
//  *
//  * You may use, modify and redistribute this code free of charge,
//  * provided that the author's names and this notice appear intact.
//  */
// 
// /*
//  * NOTE: there is a formal problem with the dependent texture lookups.
//  * A texture coordinate of exactly 1.0 will wrap to 0.0, so strictly speaking,
//  * an error occurs every 256 units of the texture domain, and the same gradient
//  * is used for two adjacent noise cells. One solution is to set the texture
//  * wrap mode to "CLAMP" and do the wrapping explicitly in GLSL with the "mod"
//  * operator. This could also give you noise with repetition intervals other
//  * than 256 without any extra cost.
//  * This error is not even noticeable to the eye even if you isolate the exact
//  * position in the domain where it occurs and know exactly what to look for.
//  * The noise pattern is still visually correct, so I left the bug in there.
//  * 
//  * The value of classic 4D noise goes above 1.0 and below -1.0 at some
//  * points. Not much and only very sparsely, but it happens. This is a
//  * bug from the original software implementation, so I left it untouched.
//  */
// 
// 
// /*
//  * "permTexture" is a 256x256 texture that is used for both the permutations
//  * and the 2D and 3D gradient lookup. For details, see the main C program.
//  * "gradTexture" is a 256x256 texture with 4D gradients, similar to
//  * "permTexture" but with the permutation index in the alpha component
//  * replaced by the w component of the 4D gradient.
//  * 2D classic noise uses only permTexture.
//  * 2D simplex noise uses only permTexture.
//  * 3D classic noise uses only permTexture.
//  * 3D simplex noise uses only permTexture.
//  * 4D classic noise uses permTexture and gradTexture.
//  * 4D simplex noise uses permTexture and gradTexture.
//  */
// uniform sampler2D permTexture;
// uniform sampler2D gradTexture;
// uniform float time; // Used for texture animation

namespace KLIB {

class GLSLNoise {
    GLSLNoise();
    ~GLSLNoise();
private:
    static ShaderObject fragShader__;   // shader objects
    static ShaderObject vertShader__;
    static GLuint permTextureID__;      // texture handles
    static GLuint gradTextureID__;
    // const data
    static const int perm__[256];
    static const int grad3__[16][3];
    static const int grad4__[32][4];
    static const char* source__;
public:     // public interfaces
    static void initialize() {
        fragShader__.setSource(source__, ShaderObject::FRAGMENT_SHADER);
        vertShader__.setSource(source__, ShaderObject::VERTEX_SHADER);
        initPermTexture();
        initGradTexture();
    }
    static void finalize();
    static const ShaderObject& fragShader() { return fragShader__; }
    static const ShaderObject& vertShader() { return vertShader__; }
    static void bindPermTexture(ProgramObject& prog, int textureUnit);
    static void bindGradTexture(ProgramObject& prog, int textureUnit);
    static void unbindTexture(int textureUnit);
private:    // internal functions
    static void initPermTexture();
    static void initGradTexture();
};

}
