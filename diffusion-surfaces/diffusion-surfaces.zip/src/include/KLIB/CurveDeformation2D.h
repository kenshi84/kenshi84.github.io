#pragma once

#include "RigidShapeDeformation2D.h"
#include "Polyline.h"

namespace KLIB {

class CurveDeformation2D {
public:
    CurveDeformation2D(void) {}
    CurveDeformation2D(const Polyline2d& curve_rest) { init(curve_rest); }
    ~CurveDeformation2D(void) {}

    // generate mesh, store rest shape and compute rigid matrix A
    void init(const Polyline2d& curve_rest) {
        curve_ = curve_rest;
        size_t num_vtx  = curve_rest.size();
        size_t num_face = num_vtx;
        if (!curve_rest.isLoop()) num_face -= 2;
        std::vector<int> face_vtx_index(3 * num_face);
        for (size_t i = 0; i < num_face; ++i) {
            face_vtx_index[3 * i    ] =  i;
            face_vtx_index[3 * i + 1] = (i + 1) % num_vtx;
            face_vtx_index[3 * i + 2] = (i + 2) % num_vtx;
        }
        const std::vector<Vector2d>& points = curve_rest.points();
        rigid_.init(points, face_vtx_index);
    }

    // add constraints to A and construct UMFPACK
    void compile(const std::vector<int>& is_vtx_constrained) { rigid_.compile(is_vtx_constrained); }

    Polyline2d deform(const std::vector<Vector2d>& constrained_vtx_position) {
        return Polyline2d(rigid_.deform(constrained_vtx_position), curve_.isLoop());
    }

private:
    Polyline2d curve_;
    RigidShapeDeformation2D rigid_;
};

}