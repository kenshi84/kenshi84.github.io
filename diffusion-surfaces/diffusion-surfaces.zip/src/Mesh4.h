#pragma once
#include <KLIB/Vector.h>
#include <OpenMesh/Core/Mesh/Traits.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>

// Mesh4: sweep surface mesh (intermediate data of mesh topology. later converted to Mesh0)
//-- sweep surface from strokeHrz and strokeVrt, with which the user can further delete parts of surfaces in StateDeleteFace --//
struct Mesh4Traits : public OpenMesh::DefaultTraits {
    typedef KLIB::Vector3d Point;
    typedef KLIB::Vector3d Normal;
    static const double CUTVALUE_DEFAULT;
    VertexTraits {
    public:
        double cutValue_;
        int nfold1_mapped_vid_;                // for the case of SweepObject::TYPE_NFOLD1
        int nfold1_flagPole_;              // 0: non-pole, 1: south pole, 2: north pole
        VertexT()
            : cutValue_(CUTVALUE_DEFAULT)
            , nfold1_mapped_vid_(-1)
            , nfold1_flagPole_(0)
        {}
    };
    EdgeTraits {
    public:
        bool isCrossed_;
        double crossedPos_;
        int nfold1_mapped_eid_;                // for the case of SweepObject::TYPE_NFOLD1
        EdgeT()
            : isCrossed_(false)
            , crossedPos_(0)
            , nfold1_mapped_eid_(-1)
        {}
    };
};
struct Mesh0;
struct Mesh4 : public OpenMesh::TriMesh_ArrayKernelT<Mesh4Traits> {
    size_t numSegHrz_;
    size_t numSegVrt_;
    bool isClosedBottom_;
    bool isClosedTop_;
    
    Mesh4()
        : numSegHrz_(0)
        , numSegVrt_(0)
        , isClosedBottom_(false)
        , isClosedTop_(false)
    {}
    Mesh0 convert();
    void copyCutValue(const Mesh4& src);      // assuming the same connectivity, copy cutValue
    void calcNfold1MappedEdge();
};
