#include "stdafx.h"
#include "SweepObject.h"
#include <KLIB/OpenMeshUtil.h>
#include "my_atan2.h"
using namespace std;
using namespace KLIB;

namespace {
Vector2d convert_rt_xy(const Vector2d& rt, double angle_begin, double angle_end) {
    double r = rt[0];
    double theta = rt[1] * (angle_end - angle_begin) + angle_begin;
    return Vector2d(r * cos(theta), r * sin(theta));
}
}

void SweepObject::analyze_strokeHrz_cylind() {
    assert(type_ == TYPE_CYLIND);
    size_t sz_strokeHrz = strokeHrz_exemplar_[0].size();
    vector<Vector2d> signal(sz_strokeHrz);
    //....convert to radius & angle difference
    for (size_t i = 0; i < sz_strokeHrz; ++i) {
        Vector2d& rt0 = strokeHrz_exemplar_[0][i];
        Vector2d& rt1 = i == sz_strokeHrz - 1 ? strokeHrz_exemplar_[0][0] : strokeHrz_exemplar_[0][i + 1];
        double r = rt0[0];
        double d = rt1[1] - rt0[1];
        if (d < -M_PI)
            d += 2 * M_PI;      // doesn't occur
        signal[i].set(r, d);
    }
    signalProcessor_.analyze(signal);
}
void SweepObject::synthesize_strokeHrz_cylind() {
    assert(type_ == TYPE_CYLIND);
    vector<Vector2d> signal = signalProcessor_.synthesize();
    strokeHrz_synthesis_.resize(1);
    size_t sz_strokeHrz = strokeHrz_exemplar_[0].size();
    strokeHrz_synthesis_[0].resize(sz_strokeHrz);
    //....convert to the origianl polar coordinate
    double acc_angle = 0;
    for (size_t i = 0; i < sz_strokeHrz; ++i) {
        Vector2d rt = signal[i];
        strokeHrz_synthesis_[0][i].set(rt.x_, acc_angle);
        acc_angle += rt.y_;
    }
    double angle_scale = 2 * M_PI / acc_angle;
    for (size_t i = 0; i < sz_strokeHrz; ++i)
        strokeHrz_synthesis_[0][i].y_ *= angle_scale;
}
Mesh4 SweepObject::genMesh4_cylind(const Polyline2d& strokeHrz) const {
    assert(type_ == SweepObject::TYPE_CYLIND);
    Mesh4 mesh4;
    size_t sz_strokeHrz = strokeHrz .size();
    size_t sz_strokeVrt = strokeVrt_.size();
    mesh4.numSegHrz_ = sz_strokeHrz;
    mesh4.numSegVrt_ = sz_strokeVrt - 1;
    mesh4.isClosedBottom_ = strokeVrt_.front().x_ == 0;
    mesh4.isClosedTop_    = strokeVrt_.back ().x_ == 0;
    size_t i_begin = mesh4.isClosedBottom_ ? 1 : 0;
    size_t i_end   = mesh4.isClosedTop_ ? (sz_strokeVrt - 2) : (sz_strokeVrt - 1);
    
    // add vertices & faces
    vector<Mesh4::VHandle> vhandles_ring1(sz_strokeHrz);
    vector<Mesh4::VHandle> vhandles_ring0;
    vector<Mesh4::VHandle> vhandles_ringBottom;
    vector<Mesh4::VHandle> vhandles_ringTop;
    vector<Mesh4::VHandle> face_vhandles(3);
    for (size_t i = i_begin; i <= i_end; ++i) {
        double r = strokeVrt_[i][0];
        double h = strokeVrt_[i][1];
        double s = r / strokeHrz[0].x_;
        for (size_t j = 0; j < sz_strokeHrz; ++j) {
            const Vector2d& rt = strokeHrz[j];
            Vector2d xy(rt[0] * sin(rt[1]), rt[0] * cos(rt[1]));
            xy *= s;
            Vector3d point3d(xy[0], h, xy[1]);
            vhandles_ring1[j] = mesh4.add_vertex(point3d);
        }
        if (i != i_begin) {
            // add faces
            for (size_t j = 0; j < sz_strokeHrz; ++j) {
                size_t j1 = (j == sz_strokeHrz - 1) ? 0 : (j + 1);
                face_vhandles[0] = vhandles_ring0[j];
                face_vhandles[1] = vhandles_ring0[j1];
                face_vhandles[2] = vhandles_ring1[j];
                mesh4.add_face(face_vhandles);
                face_vhandles[0] = vhandles_ring1[j];
                face_vhandles[1] = vhandles_ring0[j1];
                face_vhandles[2] = vhandles_ring1[j1];
                mesh4.add_face(face_vhandles);
            }
        }
        vhandles_ring0 = vhandles_ring1;
        if (i == i_begin)
            vhandles_ringBottom = vhandles_ring0;
        if (i == i_end)
            vhandles_ringTop    = vhandles_ring0;
    }
    if (mesh4.isClosedBottom_) {
        Mesh4::VHandle vhandleBottom = mesh4.add_vertex(Vector3d(0, strokeVrt_.front()[1], 0));
        for (size_t j = 0; j < sz_strokeHrz; ++j) {
            size_t j1 = (j == sz_strokeHrz - 1) ? 0 : (j + 1);
            face_vhandles[0] = vhandleBottom;
            face_vhandles[1] = vhandles_ringBottom[j1];
            face_vhandles[2] = vhandles_ringBottom[j];
            mesh4.add_face(face_vhandles);
        }
    }
    if (mesh4.isClosedTop_) {
        Mesh4::VHandle vhandleTop = mesh4.add_vertex(Vector3d(0, strokeVrt_.back ()[1], 0));
        for (size_t j = 0; j < sz_strokeHrz; ++j) {
            size_t j1 = (j == sz_strokeHrz - 1) ? 0 : (j + 1);
            face_vhandles[0] = vhandleTop;
            face_vhandles[1] = vhandles_ringTop[j];
            face_vhandles[2] = vhandles_ringTop[j1];
            mesh4.add_face(face_vhandles);
        }
    }
    mesh4.request_face_normals();
    mesh4.request_vertex_normals();
    mesh4.update_normals();
    return mesh4;
}
Mesh4 SweepObject::genMesh4_nfold1(const Polyline2d& strokeHrz, double angle_begin, double angle_end) const {
    assert(type_ == SweepObject::TYPE_NFOLD1);
    assert(!strokeHrz.isLoop());
    Mesh4 mesh4;
    size_t sz_strokeHrz = strokeHrz .size();
    size_t sz_strokeVrt = strokeVrt_.size();
    mesh4.numSegHrz_ = sz_strokeHrz - 1;
    mesh4.numSegVrt_ = sz_strokeVrt - 1;
    mesh4.isClosedBottom_ = strokeVrt_.front().x_ == 0;
    mesh4.isClosedTop_    = strokeVrt_.back ().x_ == 0;
    size_t i_begin = mesh4.isClosedBottom_ ? 1 : 0;
    size_t i_end   = mesh4.isClosedTop_ ? (sz_strokeVrt - 2) : (sz_strokeVrt - 1);
    
    // add vertices & faces
    vector<Mesh4::VHandle> vhandles_ring1(sz_strokeHrz);
    vector<Mesh4::VHandle> vhandles_ring0;
    vector<Mesh4::VHandle> vhandles_ringBottom;
    vector<Mesh4::VHandle> vhandles_ringTop;
    vector<Mesh4::VHandle> face_vhandles(3);
    for (size_t i = i_begin; i <= i_end; ++i) {
        double r = strokeVrt_[i][0];
        double h = strokeVrt_[i][1];
        double s = r / strokeHrz[sz_strokeHrz / 2].x_;
        for (size_t j = 0; j < sz_strokeHrz; ++j) {
            Vector2d rt = strokeHrz[j];
            rt[1] = (angle_end - angle_begin) * rt[1] + angle_begin;
            Vector2d xy(rt[0] * sin(rt[1]), rt[0] * cos(rt[1]));
            xy *= s;
            Vector3d point3d(xy[0], h, xy[1]);
            vhandles_ring1[j] = mesh4.add_vertex(point3d);
        }
        Mesh4::VHandle vhandle_map[2] = { vhandles_ring1.front(), vhandles_ring1.back() };
        for (int j = 0; j < 2; ++j)
            mesh4.data(vhandle_map[j]).nfold1_mapped_vid_ = vhandle_map[1 - j].idx();
        
        if (i != i_begin) {
            // add faces
            for (size_t j = 0; j < sz_strokeHrz - 1; ++j) {
                face_vhandles[0] = vhandles_ring0[j];
                face_vhandles[1] = vhandles_ring0[j + 1];
                face_vhandles[2] = vhandles_ring1[j];
                mesh4.add_face(face_vhandles);
                face_vhandles[0] = vhandles_ring1[j];
                face_vhandles[1] = vhandles_ring0[j + 1];
                face_vhandles[2] = vhandles_ring1[j + 1];
                mesh4.add_face(face_vhandles);
            }
        }
        vhandles_ring0 = vhandles_ring1;
        if (i == i_begin)
            vhandles_ringBottom = vhandles_ring0;
        if (i == i_end)
            vhandles_ringTop    = vhandles_ring0;
    }
    if (mesh4.isClosedBottom_) {
        Mesh4::VHandle vhandleBottom = mesh4.add_vertex(Vector3d(0, strokeVrt_.front()[1], 0));
        mesh4.data(vhandleBottom).nfold1_flagPole_ = 1;     // south pole
        for (size_t j = 0; j < sz_strokeHrz - 1; ++j) {
            face_vhandles[0] = vhandleBottom;
            face_vhandles[1] = vhandles_ringBottom[j + 1];
            face_vhandles[2] = vhandles_ringBottom[j];
            mesh4.add_face(face_vhandles);
        }
    }
    if (mesh4.isClosedTop_) {
        Mesh4::VHandle vhandleTop = mesh4.add_vertex(Vector3d(0, strokeVrt_.back ()[1], 0));
        mesh4.data(vhandleTop).nfold1_flagPole_ = 2;        // north pole
        for (size_t j = 0; j < sz_strokeHrz - 1; ++j) {
            face_vhandles[0] = vhandleTop;
            face_vhandles[1] = vhandles_ringTop[j];
            face_vhandles[2] = vhandles_ringTop[j + 1];
            mesh4.add_face(face_vhandles);
        }
    }
    mesh4.calcNfold1MappedEdge();
    mesh4.request_face_normals();
    mesh4.request_vertex_normals();
    mesh4.update_normals();
    return mesh4;
}
Mesh4 SweepObject::genMesh4_nfold2(const Polyline2d& strokeHrz, double angle_begin, double angle_end) const {
    assert(type_ == SweepObject::TYPE_NFOLD2);
    assert(strokeHrz.isLoop());
    Mesh4 mesh4;
    size_t sz_strokeHrz = strokeHrz .size();
    size_t sz_strokeVrt = strokeVrt_.size();
    mesh4.numSegHrz_ = sz_strokeHrz;
    mesh4.isClosedBottom_ = true;
    mesh4.isClosedTop_    = true;
    
    // split strokeVrt_ into strokeVrt_inner & strokeVrt_outer
    double yMax = -DBL_MAX;
    double yMin =  DBL_MAX;
    size_t index_yMax, index_yMin;
    for (size_t i = 0; i < sz_strokeVrt; ++i) {
        double y = strokeVrt_[i][1];
        if (yMax < y) {
            yMax = y;
            index_yMax = i;
        }
        if (y < yMin) {
            yMin = y;
            index_yMin = i;
        }
    }
    Polyline2d strokeVrt_inner;
    Polyline2d strokeVrt_outer;
    for (size_t i = index_yMin; ; i = (i == sz_strokeVrt - 1) ? 0 : (i + 1)) {
        strokeVrt_outer.push_back(strokeVrt_[i]);
        if (i == index_yMax)
            break;
    }
    for (size_t i = index_yMin; ; i = (i == 0) ? (sz_strokeVrt - 1) : (i - 1)) {
        strokeVrt_inner.push_back(strokeVrt_[i]);
        if (i == index_yMax)
            break;
    }
    if (strokeVrt_inner.size() < strokeVrt_outer.size())
        strokeVrt_inner.resample(strokeVrt_outer.size());
    if (strokeVrt_outer.size() < strokeVrt_inner.size())
        strokeVrt_outer.resample(strokeVrt_inner.size());
    
    mesh4.numSegVrt_ = strokeVrt_inner.size() - 1;
    
    //Vector2d h0_rt( DBL_MAX, 0);    // xy-coordinates corresponding to inner & outer vertical stroke
    //Vector2d h1_rt(-DBL_MAX, 0);    // choose the nearst & the farthest
    //for (size_t i = 0; i < sz_strokeHrz; ++i) {
    //    Vector2d& rt = strokeHrz[i];
    //    if (rt[0] < h0_rt[0])
    //        h0_rt = rt;
    //    if (h1_rt[0] < rt[0])
    //        h1_rt = rt;
    //}
    Vector2d h0_rt(-1, 0);    // xy-coordinates corresponding to inner & outer vertical stroke
    Vector2d h1_rt(-1, 0);    // intersection of fold midline with horizontal stroke
    int cnt_midpoint = 0;
    for (size_t i = 0; i < sz_strokeHrz; ++i) {
        const Vector2d& rt0 = strokeHrz[i];
        const Vector2d& rt1 = strokeHrz[(i + 1) % sz_strokeHrz];
        double w0 = rt0[1] - 0.5;
        double w1 = rt1[1] - 0.5;
        if (w0 * w1 < 0) {
            w0 = abs(w0);
            w1 = abs(w1);
            double radius = (w1 * rt0[0] + w0 * rt1[0]) / (w0 + w1);
            if (cnt_midpoint == 0) {
                h0_rt.set(radius, 0.5);
                ++cnt_midpoint;
            }else {
                assert(cnt_midpoint == 1);
                h1_rt.set(radius, 0.5);
                ++cnt_midpoint;
            }
        }
    }
    assert(cnt_midpoint == 2);
    if (h1_rt[0] < h0_rt[0])
        swap(h0_rt, h1_rt);
        
    // map points in strokeHrz to 3D space using strokeVrt_inner & strokeVty_outer
    Vector2d h0 = convert_rt_xy(h0_rt, angle_begin, angle_end);
    Vector2d h1 = convert_rt_xy(h1_rt, angle_begin, angle_end);
    Vector2d h01 = h1 - h0;
    double s = h01.length();
    double theta = -my_atan2(h01[1], h01[0]);
    Matrix2x2d M0(
        cos(theta), -sin(theta),
        sin(theta), cos(theta));
    M0 /= s;
    // construct mesh
    vector<Mesh4::VHandle> vhandles_ring1(sz_strokeHrz);
    vector<Mesh4::VHandle> vhandles_ring0;
    vector<Mesh4::VHandle> vhandles_ringBottom;
    vector<Mesh4::VHandle> vhandles_ringTop;
    vector<Mesh4::VHandle> face_vhandles(3);
    const size_t i_begin = 1;
    const size_t i_end   = strokeVrt_outer.size() - 2;
    double angle_mid = 0.5 * (angle_begin + angle_end);
    // add vertices & faces
    for (size_t i = i_begin; i <= i_end; ++i) {
        Vector2d& v0_2d = strokeVrt_inner[i];
        Vector2d& v1_2d = strokeVrt_outer[i];
        Vector3d v0(sin(angle_mid) * v0_2d[0], v0_2d[1], cos(angle_mid) * v0_2d[0]);
        Vector3d v1(sin(angle_mid) * v1_2d[0], v1_2d[1], cos(angle_mid) * v1_2d[0]);
        Vector3d v01 = v1 - v0;
        Vector3d v01_t = (v01 % Vector3d(0, -1, 0));
        v01_t.normalize();
        v01_t *= v01.length();
        for (size_t j = 0; j < sz_strokeHrz; ++j) {
            Vector2d h_rt = strokeHrz[j];
            Vector2d h = convert_rt_xy(h_rt, angle_begin, angle_end);
            Vector2d hh = M0 * (h - h0);
            Vector3d point3d = v0 + hh[0] * v01 + hh[1] * v01_t;
            vhandles_ring1[j] = mesh4.add_vertex(point3d);
        }
        if (i != i_begin) {
            // add faces
            for (size_t j = 0; j < sz_strokeHrz; ++j) {
                size_t j1 = (j == sz_strokeHrz - 1) ? 0 : (j + 1);
                face_vhandles[0] = vhandles_ring0[j];
                face_vhandles[1] = vhandles_ring0[j1];
                face_vhandles[2] = vhandles_ring1[j];
                mesh4.add_face(face_vhandles);
                face_vhandles[0] = vhandles_ring1[j];
                face_vhandles[1] = vhandles_ring0[j1];
                face_vhandles[2] = vhandles_ring1[j1];
                mesh4.add_face(face_vhandles);
            }
        }
        vhandles_ring0 = vhandles_ring1;
        if (i == i_begin)
            vhandles_ringBottom = vhandles_ring0;
        if (i == i_end)
            vhandles_ringTop    = vhandles_ring0;
    }
    {
        Vector2d& point2d = strokeVrt_outer.front();
        Vector3d  point3d(sin(angle_mid) * point2d[0], point2d[1], cos(angle_mid) * point2d[0]);
        Mesh4::VHandle vhandleBottom = mesh4.add_vertex(point3d);
        for (size_t j = 0; j < sz_strokeHrz; ++j) {
            size_t j1 = (j == sz_strokeHrz - 1) ? 0 : (j + 1);
            face_vhandles[0] = vhandleBottom;
            face_vhandles[1] = vhandles_ringBottom[j1];
            face_vhandles[2] = vhandles_ringBottom[j];
            mesh4.add_face(face_vhandles);
        }
    }
    {
        Vector2d& point2d = strokeVrt_outer.back();
        Vector3d  point3d(sin(angle_mid) * point2d[0], point2d[1], cos(angle_mid) * point2d[0]);
        Mesh4::VHandle vhandleTop = mesh4.add_vertex(point3d);
        for (size_t j = 0; j < sz_strokeHrz; ++j) {
            size_t j1 = (j == sz_strokeHrz - 1) ? 0 : (j + 1);
            face_vhandles[0] = vhandleTop;
            face_vhandles[1] = vhandles_ringTop[j];
            face_vhandles[2] = vhandles_ringTop[j1];
            mesh4.add_face(face_vhandles);
        }
    }
    
    mesh4.request_face_normals();
    mesh4.request_vertex_normals();
    mesh4.update_normals();
    return mesh4;
}
Mesh0 SweepObject::merge_nfold1(const vector<Mesh0>& mesh0s) const {
    assert(type_ == SweepObject::TYPE_NFOLD1);
    Mesh0 mesh0_result = mesh0_ref_;
    mesh0_result.clear();
    size_t numFold = mesh0s.size();
    int n_vertices = mesh0_ref_.n_vertices();
    
    // add vertices
    Mesh0::VHandle v_pole_ref[2];            // north & south poles are added later
    int fold_numVtx = 0;
    vector<int> vidMap_ref_result(n_vertices, -1);
    for (Mesh0::CVIter v = mesh0_ref_.vertices_begin(); v != mesh0_ref_.vertices_end(); ++v) {
        const Mesh0::VertexData& vdata = mesh0_ref_.data(v);
        if (vdata.nfold1_flagPole_ == 0) {
            if (vdata.nfold1_mapped_vid_ == -1 || v.handle().idx() < vdata.nfold1_mapped_vid_) {
                vidMap_ref_result[v.handle().idx()] = fold_numVtx;
                ++fold_numVtx;
            }
            continue;
        }
        v_pole_ref[vdata.nfold1_flagPole_ - 1] = v;
    }
    
    for (size_t foldID = 0; foldID < numFold; ++foldID) {
        const Mesh0& mesh0_fold = mesh0s[foldID];
        for (int vid = 0; vid < n_vertices; ++vid) {
            Mesh0::VHandle v = mesh0_fold.vertex_handle(vid);
            const Mesh0::VertexData& vdata = mesh0_fold.data(v);
            int mapped_vid = vdata.nfold1_mapped_vid_;
            if (vdata.nfold1_flagPole_ == 0 && (mapped_vid == -1 || vid < mapped_vid)) {
                Mesh0::VHandle w = mesh0_result.add_vertex(mesh0_fold.point(v));
                mesh0_result.data(w) = vdata;
            }
        }
    }
    
    Mesh0::VHandle v_pole_result[2];
    for (int i = 0; i < 2; ++i) {
        if (v_pole_ref[i].is_valid()) {
            v_pole_result[i] = mesh0_result.add_vertex(mesh0_ref_.point(v_pole_ref[i]));
            mesh0_result.data(v_pole_result[i]) = mesh0_ref_.data(v_pole_ref[i]);
        }
    }
    
    assert(mesh0_result.n_vertices() == numFold * fold_numVtx + (v_pole_ref[0].is_valid() ? 1 : 0) + (v_pole_ref[1].is_valid() ? 1 : 0));
    
    // add faces
    for (size_t foldID = 0; foldID < numFold; ++foldID) {
        for (Mesh0::CFIter f = mesh0_ref_.faces_begin(); f != mesh0_ref_.faces_end(); ++f) {
            vector<Mesh0::VHandle> face_vhandles(3);
            Mesh0::CFVIter v = mesh0_ref_.cfv_iter(f);
            for (int i = 0; i < 3; ++i, ++v) {
                int flagPole = mesh0_ref_.data(v).nfold1_flagPole_;
                if (flagPole == 0) {
                    int vid = v.handle().idx();
                    int result_vid = vidMap_ref_result[vid] + fold_numVtx * foldID;
                    int mapped_vid = mesh0_ref_.data(v).nfold1_mapped_vid_;
                    if (mapped_vid != -1 && mapped_vid < vid) {
                        if (foldID == numFold - 1)
                            result_vid = vidMap_ref_result[mapped_vid];
                        else
                            result_vid = vidMap_ref_result[mapped_vid] + fold_numVtx * (foldID + 1);
                    }
                    face_vhandles[i] = mesh0_result.vertex_handle(result_vid);
                } else {
                    face_vhandles[i] = v_pole_result[flagPole - 1];
                }
            }
            Mesh0::FHandle f_result = mesh0_result.add_face(face_vhandles);
            mesh0_result.data(f_result) = mesh0_ref_.data(f);
        }
    }
    
    mesh0_result.request_face_normals();
    mesh0_result.request_vertex_normals();
    mesh0_result.update_normals();
    return mesh0_result;
}

void SweepObject::distributeGrains(const Mesh0& mesh0) {
    distributedGrains_.clear();
    // poisson disk sampling over triangles
    double poissonRadius = grainObject_.poissonRadius_;
    Mesh0 mesh0_temp;
    mesh0_temp.request_vertex_normals();
    for (Mesh0::CVIter v = mesh0.vertices_begin(); v != mesh0.vertices_end(); ++v) {
        Mesh0::VHandle v_temp = mesh0_temp.add_vertex(mesh0.point(v));
        mesh0_temp.data(v_temp) = mesh0.data(v);
        mesh0_temp.set_normal(v_temp, mesh0.normal(v));
    }
    for (Mesh0::CFIter f = mesh0.faces_begin(); f != mesh0.faces_end(); ++f) {
        if (!mesh0.data(f).flagGrain_)
            continue;
        vector<Mesh0::VHandle> face_vhandles_temp(3);
        Mesh0::CFVIter v = mesh0.cfv_iter(f);
        for (int i = 0; i < 3; ++i, ++v)
            face_vhandles_temp[i] = mesh0_temp.vertex_handle(v.handle().idx());
        mesh0_temp.add_face(face_vhandles_temp);
    }
    vector<Mesh0::FHandle> out_fhandles;
    vector<Vector3d      > out_baryCoords;
    OpenMeshUtil<Mesh0>::calcDartThrowing(mesh0_temp, poissonRadius, out_fhandles, out_baryCoords);

    for (size_t i = 0; i < out_fhandles.size(); ++i) {
        Mesh0::FHandle f = out_fhandles[i];
        Vector3d& baryCoord = out_baryCoords[i];
        Vector3d point;
        Vector3d normal;
        Mesh0::FVIter v = mesh0_temp.fv_iter(f);
        for (int j = 0; j < 3; ++j, ++v) {
            point  += baryCoord[j] * mesh0_temp.point (v);
            normal += baryCoord[j] * mesh0_temp.normal(v);
        }
        //normal.z_ = point.z_ = 0;        // a hack for making kidney.xml
        normal.normalize();
        Vector3d axisY = Vector3d(0, 1, 0);
        Vector3d axis1 = axisY - (axisY | normal) * normal;
        axis1.normalize();
        Vector3d axis2 = normal % axis1;
        Matrix3x3d M;
        M.setCols(normal, axis1, axis2);
        Mesh0 mesh0_grain = grainObject_.mesh0_ref_;     // generate Mesh0 copy
        for (Mesh0::VIter v_it = mesh0_grain.vertices_begin(); v_it != mesh0_grain.vertices_end(); ++v_it) {
            Vector3d& pos = mesh0_grain.point(v_it);
            pos = M * pos;
            pos += point;
        }
        mesh0_grain.update_normals();
        distributedGrains_.push_back(mesh0_grain);
    }
}
void SweepObject::genGrainMesh4() {
    // for CsVrt |
    //-----------+
    // (1) find a point (and its normal) in strokeVrt_ closest to the grain starting point
    Polyline2d new_strokeVrtLeft  = grainObject_.strokeVrtLeft_;
    Polyline2d new_strokeVrtRight = grainObject_.strokeVrtRight_;
    
    Vector2d point_grain = 0.5 * (grainObject_.strokeVrtLeft_[0] + grainObject_.strokeVrtRight_[0]);
    
    double closest_dist = DBL_MAX;
    Vector2d closest_point;
    Vector2d closest_normal;
    for (size_t i = 0; i < strokeVrt_.size(); ++i) {
        Vector2d& point_sweep = strokeVrt_[i];
        double dist = (point_grain - point_sweep).length();
        if (closest_dist < dist)
            continue;
        closest_dist = dist;
        closest_point = point_sweep;
        Vector2d* point_prev = 0 < i                     ? &strokeVrt_[i - 1] : 0;
        Vector2d* point_next = i < strokeVrt_.size() - 1 ? &strokeVrt_[i + 1] : 0;
        Vector2d normal_prev = point_prev ? (point_sweep - *point_prev) : Vector2d(1);
        Vector2d normal_next = point_next ? (*point_next - point_sweep) : Vector2d(1);
        normal_prev = -rotate90(normal_prev);
        normal_next = -rotate90(normal_next);
        normal_prev.normalize();
        normal_next.normalize();
        closest_normal.set(0, 0);
        closest_normal += point_prev ? normal_prev : Vector2d();
        closest_normal += point_next ? normal_next : Vector2d();
        closest_normal.normalize();
    }
    Matrix2x2d rot22;
    rot22.setRows(closest_normal, rotate90(closest_normal));
    // (2) translate & rotate
    for (size_t k = 0; k < new_strokeVrtLeft.size(); ++k) {
        new_strokeVrtLeft [k] = rot22 * (grainObject_.strokeVrtLeft_ [k] - closest_point);
        new_strokeVrtRight[k] = rot22 * (grainObject_.strokeVrtRight_[k] - closest_point);
    }
    
    // for CsHrz |
    //-----------+
    //grainObject_.strokeHrz_ = tempStrokeHrz_[core.sweepObjects_.size() + grainObjectId].front();
    Polyline2d new_strokeHrz = grainObject_.strokeHrz_;
    {
        // (1) identify leftmost & rightmost points
        Vector2d pointLmost( DBL_MAX, 0);
        Vector2d pointRmost(-DBL_MAX, 0);
        for (size_t i = 0; i < grainObject_.strokeHrz_.size(); ++i) {
            Vector2d& point = grainObject_.strokeHrz_[i];
            if (point[0] < pointLmost[0])
                pointLmost = point;
            if (pointRmost[0] < point[0])
                pointRmost = point;
        }
        Vector2d d = pointRmost - pointLmost;
        double s = 1 / d.length();
        d *= s;
        Matrix2x2d rot22;
        rot22.setRows(d, rotate90(d));
        // (2) translate --> scale --> rotate
        for (size_t i = 0; i < new_strokeHrz.size(); ++i) {
            Vector2d& point = new_strokeHrz[i];
            point -= pointLmost;
            point *= s;
            point = rot22 * point;
        }
    }
    // 3D sweep surface generation |
    //-----------------------------+
    Mesh4& mesh4 = grainObject_.mesh4_ref_;
    mesh4.clear();
    mesh4.isClosedBottom_ = new_strokeVrtLeft.front() == new_strokeVrtRight.front();
    mesh4.isClosedTop_    = new_strokeVrtLeft.back () == new_strokeVrtRight.back ();
    const size_t i_begin = mesh4.isClosedBottom_ ? 1 : 0;
    const size_t i_end   = new_strokeVrtLeft.size() - 1 - (mesh4.isClosedTop_ ? 1 : 0);
    // add vertices & faces
    size_t numRingVtx = new_strokeHrz.size();
    vector<Mesh4::VHandle> vhandles_ring1(numRingVtx);
    vector<Mesh4::VHandle> vhandles_ring0;
    vector<Mesh4::VHandle> vhandles_ringBottom;
    vector<Mesh4::VHandle> vhandles_ringTop;
    vector<Mesh4::VHandle> face_vhandles(3);
    for (size_t i = i_begin; i <= i_end; ++i) {
        Vector2d& pointL = new_strokeVrtLeft [i];
        Vector2d& pointR = new_strokeVrtRight[i];
        Vector2d d = pointR - pointL;
        double ez = d.length();
        for (size_t j = 0; j < numRingVtx; ++j) {
            Vector2d& hrz_point2d = new_strokeHrz[j];
            Vector2d xy = pointL + d * hrz_point2d[0];
            Vector3d point3d(xy[0], xy[1], -ez * hrz_point2d[1]);
            vhandles_ring1[j] = mesh4.add_vertex(point3d);
        }
        if (i != i_begin) {
            // add faces
            for (size_t j = 0; j < numRingVtx; ++j) {
                size_t j1 = (j == numRingVtx - 1) ? 0 : (j + 1);
                face_vhandles[0] = vhandles_ring0[j];
                face_vhandles[1] = vhandles_ring0[j1];
                face_vhandles[2] = vhandles_ring1[j];
                mesh4.add_face(face_vhandles);
                face_vhandles[0] = vhandles_ring1[j];
                face_vhandles[1] = vhandles_ring0[j1];
                face_vhandles[2] = vhandles_ring1[j1];
                mesh4.add_face(face_vhandles);
            }
        }
        vhandles_ring0 = vhandles_ring1;
        if (i == i_begin)
            vhandles_ringBottom = vhandles_ring0;
        if (i == i_end)
            vhandles_ringTop    = vhandles_ring0;
    }
    if (mesh4.isClosedBottom_) {
        Mesh4::VHandle vhandleBottom = mesh4.add_vertex(Vector3d(new_strokeVrtLeft.front()[0], new_strokeVrtLeft.front()[1], 0));
        for (size_t j = 0; j < numRingVtx; ++j) {
            size_t j1 = (j == numRingVtx - 1) ? 0 : (j + 1);
            face_vhandles[0] = vhandleBottom;
            face_vhandles[1] = vhandles_ringBottom[j1];
            face_vhandles[2] = vhandles_ringBottom[j];
            mesh4.add_face(face_vhandles);
        }
    }
    if (mesh4.isClosedTop_) {
        Mesh4::VHandle vhandleTop = mesh4.add_vertex(Vector3d(new_strokeVrtLeft.back()[0], new_strokeVrtLeft.back()[1], 0));
        for (size_t j = 0; j < numRingVtx; ++j) {
            size_t j1 = (j == numRingVtx - 1) ? 0 : (j + 1);
            face_vhandles[0] = vhandleTop;
            face_vhandles[1] = vhandles_ringTop[j];
            face_vhandles[2] = vhandles_ringTop[j1];
            mesh4.add_face(face_vhandles);
        }
    }
    
    mesh4.request_vertex_normals();
    mesh4.request_face_normals();
    mesh4.update_normals();
}
