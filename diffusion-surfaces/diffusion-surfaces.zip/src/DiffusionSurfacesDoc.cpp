#include "stdafx.h"
#include "DiffusionSurfaces.h"

#include "DiffusionSurfacesDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CDiffusionSurfacesDoc

IMPLEMENT_DYNCREATE(CDiffusionSurfacesDoc, CDocument)

BEGIN_MESSAGE_MAP(CDiffusionSurfacesDoc, CDocument)
END_MESSAGE_MAP()


CDiffusionSurfacesDoc::CDiffusionSurfacesDoc()
{
}

CDiffusionSurfacesDoc::~CDiffusionSurfacesDoc()
{
}

BOOL CDiffusionSurfacesDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	return TRUE;
}




void CDiffusionSurfacesDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}
}


#ifdef _DEBUG
void CDiffusionSurfacesDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CDiffusionSurfacesDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

