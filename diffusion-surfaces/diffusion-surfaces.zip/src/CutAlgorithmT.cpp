#include "StdAfx.h"
#include "Core.h"
#include "CutAlgorithmT.h"
using namespace std;
using namespace KLIB;

namespace {
OGL& ogl = Core::getInstance().ogl_;
}

template <class TDiffuseAlgorithm>
void CutAlgorithmT<TDiffuseAlgorithm>::cut(VolumeObject& volObj) {
    if (param_.mode_ == CutParam::FREEFORM)
        param_.processStroke();
    
    cut_step1_cutValue(volObj);
    volObj.mesh2_.clear();
    diffuseAlgorithm_.cut_step2_mesh2(volObj, param_);
    volObj.mesh2_.request_face_normals();
    volObj.mesh2_.request_vertex_normals();
    volObj.mesh2_.update_normals();
    cut_step3_mesh3(volObj);
    
    volObj.cutDone_ = true;
    if (param_.mode_ == CutParam::WEDGE)     // compute NPR line on Mesh1 along y-axis
        calcWedgeLine(volObj);
}

template <class TDiffuseAlgorithm>
void CutAlgorithmT<TDiffuseAlgorithm>::cut_step1_cutValue(VolumeObject& volObj) {
    for (size_t i = 0; i < volObj.srfMeshes_.size(); ++i)
        cut_step1_cutValue_sub(volObj.srfMeshes_[i].mesh0_);
}
template <class TDiffuseAlgorithm>
void CutAlgorithmT<TDiffuseAlgorithm>::cut_step1_cutValue_sub(Mesh0& mesh0) {
    // add mesh1 boundary vertices where the RBF's zero isosurface crosses mesh0 edges
    for (Mesh0::VIter v_it = mesh0.vertices_begin(); v_it != mesh0.vertices_end(); ++v_it) {  // evaluate RBF values on mesh0 vertices
        Vector3d& pos = mesh0.point(v_it);
        mesh0.data(v_it).cutValue_ = param_.getCutValue(pos);
    }
    
    // check if the cutting stroke crosses edges
    for (Mesh0::EIter e_it = mesh0.edges_begin(); e_it != mesh0.edges_end(); ++e_it) {
        double   cutValue  [2];
        for (int i = 0; i < 2; ++i) {
            Mesh0::VHandle vhandle = mesh0.from_vertex_handle(mesh0.halfedge_handle(e_it, i));
            Mesh0::VertexData& vdata = mesh0.data(vhandle);
            cutValue  [i] = vdata.cutValue_;
        }
        Mesh0::EdgeData& mesh0_edata = mesh0.data(e_it);
        mesh0_edata.isCrossed_  = cutValue[0] * cutValue[1] < 0;
        mesh0_edata.crossedPos_ = -cutValue[0] / (cutValue[1] - cutValue[0]);
    }
}
template <class TDiffuseAlgorithm>
void CutAlgorithmT<TDiffuseAlgorithm>::cut_step3_mesh3   (VolumeObject& volObj) {
    volObj.silRenderer_.clear();
    for (vector<SrfMesh>::iterator it = volObj.srfMeshes_.begin(); it != volObj.srfMeshes_.end(); ++it)
        cut_step3_mesh3_sub(volObj, it->mesh0_, it->mesh3_);
}
template <class TDiffuseAlgorithm>
void CutAlgorithmT<TDiffuseAlgorithm>::cut_step3_mesh3_sub(VolumeObject& volObj, Mesh0& mesh0, Mesh3& mesh3) {
    mesh3.clear();
    
    vector<int> map_mesh0vid_mesh3vid(mesh0.n_vertices(), -1);     // mapping from mesh0 vertex id to mesh3 vertex id
    Mesh0::VIter v = mesh0.vertices_begin();
    for (int i = 0; v != mesh0.vertices_end(); ++v, ++i) {
        if (mesh0.data(v).cutValue_ < 0)
            continue;            // i-th mesh0 vertex is not included in mesh3
        Mesh3::VHandle mesh3_vhandle = mesh3.add_vertex(mesh0.point(v));
        mesh3.data(mesh3_vhandle).color_      = mesh0.data(v).color_;
        mesh3.data(mesh3_vhandle).back_color_ = mesh0.data(v).back_color_;
        map_mesh0vid_mesh3vid[i] = mesh3_vhandle.idx();
    }
    vector<int> map_mesh0eid_mesh3vid(mesh0.n_edges(), -1);        // mapping from mesh0 edge id to mesh3 vertex id
    Mesh0::EIter e = mesh0.edges_begin();
    for (int i = 0; e != mesh0.edges_end(); ++e, ++i) {
        if (!mesh0.data(e).isCrossed_)
            continue;            // i-th mesh0 edge is not included in mesh3
        Vector3d point     [2];
        Vector3d color     [2];
        Vector3d back_color[2];
        for (int j = 0; j < 2; ++j) {
            Mesh0::HHandle mesh0_hhandle = mesh0.halfedge_handle(e, j);
            Mesh0::VHandle mesh0_vhandle = mesh0.from_vertex_handle(mesh0_hhandle);
            point     [j] = mesh0.point(mesh0_vhandle);
            color     [j] = mesh0.data (mesh0_vhandle).color_;
            back_color[j] = mesh0.data (mesh0_vhandle).back_color_;
        }
        double crossedPos = mesh0.data(e).crossedPos_;
        Mesh3::VHandle mesh3_vhandle = mesh3.add_vertex((1 - crossedPos) * point[0] + crossedPos * point[1]);
        mesh3.data(mesh3_vhandle).color_      = (1 - crossedPos) * color     [0] + crossedPos * color     [1];
        mesh3.data(mesh3_vhandle).back_color_ = (1 - crossedPos) * back_color[0] + crossedPos * back_color[1];
        map_mesh0eid_mesh3vid[i] = mesh3_vhandle.idx();
    }
    for (Mesh0::FIter f = mesh0.faces_begin(); f != mesh0.faces_end(); ++f) {    // add afaces
        vector<int> mesh3_vid;
        Mesh0::HHandle hhandle = mesh0.halfedge_handle(f);
        for (int i = 0; i < 3; ++i) {
            Mesh0::VHandle vhandle = mesh0.from_vertex_handle(hhandle);
            Mesh0::EHandle ehandle = mesh0.edge_handle(hhandle);
            if (0 < mesh0.data(vhandle).cutValue_)
                mesh3_vid.push_back(map_mesh0vid_mesh3vid[vhandle.idx()]);
            if (mesh0.data(ehandle).isCrossed_)
                mesh3_vid.push_back(map_mesh0eid_mesh3vid[ehandle.idx()]);
            hhandle = mesh0.next_halfedge_handle(hhandle);
        }
        const Vector3d& n0 = mesh0.normal(f);
        if (mesh3_vid.empty())
            continue;
        assert (mesh3_vid.size() == 3 || mesh3_vid.size() == 4);
        if (mesh3_vid.size() == 4) {
            mesh3_vid.push_back(mesh3_vid[0]);
            mesh3_vid.push_back(mesh3_vid[2]);
        }
        for (size_t i = 0; i < mesh3_vid.size(); i += 3) {
            vector<Mesh3::VHandle> face_vhandle(3);
            Vector3d mesh3_fpoint[3];
            for (int j = 0; j < 3; ++j) {
                face_vhandle[j] = mesh3.vertex_handle(mesh3_vid[i + j]);
                mesh3_fpoint[j] = mesh3.point(face_vhandle[j]);
            }
            Vector3d n1 = (mesh3_fpoint[1] - mesh3_fpoint[0]) % (mesh3_fpoint[2] - mesh3_fpoint[0]);
            if ((n0 | n1) < 0)
                swap(face_vhandle[0], face_vhandle[1]);
            mesh3.add_face(face_vhandle);
        }
    }
    // use OpenMesh feature of normal calculation
    mesh3.request_face_normals();
    mesh3.request_vertex_normals();
    mesh3.update_normals();

    if (!mesh0.isOutermost_ && !mesh0.isHole_ && !mesh0.isTwoSided_)
        return;
    
    // collect cross-sectional segments
    list<pair<int, int> > cs_indices;
    for (Mesh0::FIter f = mesh0.faces_begin(); f != mesh0.faces_end(); ++f) {
        bool isFirst = true;
        pair<int, int> index_pair(-1, -1);
        for (Mesh0::FEIter fe_it = mesh0.fe_iter(f); fe_it; ++fe_it) {
            if (mesh0.data(fe_it).isCrossed_) {
                if (isFirst) {
                    isFirst = false;
                    index_pair.first  = map_mesh0eid_mesh3vid[fe_it.handle().idx()];
                } else {
                    assert(index_pair.second == -1);
                    index_pair.second = map_mesh0eid_mesh3vid[fe_it.handle().idx()];
                }
            }
        }
        if (index_pair.first != -1)
            cs_indices.push_back(index_pair);
    }
    int index_forward  = -1;
    int index_backward = -1;
    vector<Vector3d> points_forward;
    vector<Vector3d> points_backward;
    bool isLoop = false;
    while (true) {
        if (cs_indices.empty() || index_forward == -1 && index_backward == -1) {
            if (!points_forward.empty() || !points_backward.empty()) {
                Polyline3d cs_curve;
                for (vector<Vector3d>::reverse_iterator it = points_backward.rbegin(); it != points_backward.rend(); ++it)
                    cs_curve.push_back(*it);
                for (vector<Vector3d>::iterator         it = points_forward .begin (); it != points_forward .end (); ++it)
                    cs_curve.push_back(*it);
                cs_curve.setLoop(isLoop);
                volObj.silRenderer_.curves3d_fixed_.push_back(cs_curve);
            }
            if (cs_indices.empty())
                break;
            index_forward  = cs_indices.back().first;
            index_backward = cs_indices.back().second;
            cs_indices.pop_back();
            points_forward .clear();
            points_backward.clear();
            points_forward .push_back(mesh3.point(mesh3.vertex_handle(index_forward )));
            points_backward.push_back(mesh3.point(mesh3.vertex_handle(index_backward)));
            isLoop = false;
        }
        if (index_forward != -1) {
            bool isFound = false;
            for (list<pair<int, int> >::iterator it = cs_indices.begin(); it != cs_indices.end(); ++it) {
                if (it->first == index_forward || it->second == index_forward) {
                    index_forward = it->first == index_forward ? it->second : it->first;
                    cs_indices.erase(it);
                    if (index_forward == index_backward) {
                        isLoop = true;
                        index_forward = index_backward = -1;
                        break;
                    }
                    points_forward.push_back(mesh3.point(mesh3.vertex_handle(index_forward)));
                    isFound = true;
                    break;
                }
            }
            if (!isFound)
                index_forward = -1;
        }
        if (index_backward != -1) {
            bool isFound = false;
            for (list<pair<int, int> >::iterator it = cs_indices.begin(); it != cs_indices.end(); ++it) {
                if (it->first == index_backward || it->second == index_backward) {
                    index_backward = it->first == index_backward ? it->second : it->first;
                    cs_indices.erase(it);
                    if (index_forward == index_backward) {
                        isLoop = true;
                        index_forward = index_backward = -1;
                        break;
                    }
                    points_backward.push_back(mesh3.point(mesh3.vertex_handle(index_backward)));
                    isFound = true;
                    break;
                }
            }
            if (!isFound)
                index_backward = -1;
        }
    }
}

struct DiffusePoisson;
template <>
void CutAlgorithmT<DiffusePoisson>::calcWedgeLine(VolumeObject& volObj) {}

template <class TDiffuseAlgorithm>
void CutAlgorithmT<TDiffuseAlgorithm>::calcWedgeLine(VolumeObject& volObj) {
    Mesh1& mesh1 = volObj.cutData_.mesh1_;
    Mesh2& mesh2 = volObj.mesh2_;
    list<pair<int, int> > index_pairs;
    for (Mesh1::FIter f_it = mesh1.faces_begin(); f_it != mesh1.faces_end(); ++f_it) {
        int label = mesh2.data(mesh2.face_handle(mesh1.data(f_it).mesh2_fid_)).label_;
        if (label == -1)
            continue;
        if (!volObj.srfMeshes_[label].showFlag_.cs_)
            continue;
        bool isFirst = true;
        pair<int, int> index_pair(-1, -1);
        for (Mesh1::FEIter fe_it = mesh1.fe_iter(f_it); fe_it; ++fe_it) {
            Vector2d point2d[2];
            for (int i = 0; i < 2; ++i)
                point2d[i] = mesh1.data(mesh1.to_vertex_handle(mesh1.halfedge_handle(fe_it, i))).point2d_;
            if (point2d[0].x_ * point2d[1].x_ < 0) {
                if (isFirst) {
                    isFirst = false;
                    index_pair.first  = fe_it.handle().idx();
                } else {
                    assert(index_pair.second == -1);
                    index_pair.second = fe_it.handle().idx();
                }
            }
        }
        if (index_pair.first != -1)
            index_pairs.push_back(index_pair);
    }
    int index_forward  = -1;
    int index_backward = -1;
    vector<Vector3d> points_forward;
    vector<Vector3d> points_backward;
    bool isLoop = false;
    while (true) {
        if (index_pairs.empty() || index_forward == -1 && index_backward == -1) {
            if (!points_forward.empty() || !points_backward.empty()) {
                Polyline3d cs_curve;
                for (vector<Vector3d>::reverse_iterator it = points_backward.rbegin(); it != points_backward.rend(); ++it)
                    cs_curve.push_back(*it);
                for (vector<Vector3d>::iterator         it = points_forward .begin (); it != points_forward .end (); ++it)
                    cs_curve.push_back(*it);
                cs_curve.setLoop(isLoop);
                volObj.silRenderer_.curves3d_fixed_.push_back(cs_curve);
            }
            if (index_pairs.empty())
                break;
            index_forward  = index_pairs.back().first;
            index_backward = index_pairs.back().second;
            index_pairs.pop_back();
            points_forward .clear();
            points_backward.clear();
            points_forward .push_back(calcWedgeLine_sub(mesh1, index_forward ));
            points_backward.push_back(calcWedgeLine_sub(mesh1, index_backward));
            isLoop = false;
        }
        if (index_forward != -1) {
            bool isFound = false;
            for (list<pair<int, int> >::iterator it = index_pairs.begin(); it != index_pairs.end(); ++it) {
                if (it->first == index_forward || it->second == index_forward) {
                    index_forward = it->first == index_forward ? it->second : it->first;
                    index_pairs.erase(it);
                    if (index_forward == index_backward) {
                        isLoop = true;
                        index_forward = index_backward = -1;
                        break;
                    }
                    points_forward .push_back(calcWedgeLine_sub(mesh1, index_forward));
                    isFound = true;
                    break;
                }
            }
            if (!isFound)
                index_forward = -1;
        }
        if (index_backward != -1) {
            bool isFound = false;
            for (list<pair<int, int> >::iterator it = index_pairs.begin(); it != index_pairs.end(); ++it) {
                if (it->first == index_backward || it->second == index_backward) {
                    index_backward = it->first == index_backward ? it->second : it->first;
                    index_pairs.erase(it);
                    if (index_forward == index_backward) {
                        isLoop = true;
                        index_forward = index_backward = -1;
                        break;
                    }
                    points_backward.push_back(calcWedgeLine_sub(mesh1, index_backward));
                    isFound = true;
                    break;
                }
            }
            if (!isFound)
                index_backward = -1;
        }
    }
}

template <class TDiffuseAlgorithm>
Vector3d CutAlgorithmT<TDiffuseAlgorithm>::calcWedgeLine_sub(Mesh1& mesh1, int edge_id) {
    Mesh1::EHandle& ehandle = mesh1.edge_handle(edge_id);
    Vector3d point3d[2];
    Vector2d point2d[2];
    for (int i = 0; i < 2; ++i) {
        Mesh1::VHandle& vhandle = mesh1.to_vertex_handle(mesh1.halfedge_handle(ehandle, i)); 
        point3d[i] = mesh1.point(vhandle);
        point2d[i] = mesh1.data(vhandle).point2d_;
    }
    assert(point2d[1][0] != point2d[0][0]);
    double t = -point2d[1].x_ / (point2d[0].x_ - point2d[1].x_);    // t * point2d[0].x_ + (1 - t) * point2d[1].x_ = 0
    return t * point3d[0] + (1 - t) * point3d[1];
}

template struct CutAlgorithmT<DiffuseAlgorithm>;
