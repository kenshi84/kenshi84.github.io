#include "stdafx.h"
#include "Core.h"
#include "CutParam.h"
using namespace std;
using namespace KLIB;

namespace {
OGL& ogl = Core::getInstance().ogl_;
}
const int CutParam::NUM_WEDGE_VERTICES__ = 50;

void CutParam::processStroke() {
    size_t n_cutStroke = 50;
    // resample stroke points evenly
    Polyline2d polyline(freeform_stroke2d_, false);
    polyline.resample(n_cutStroke);
    freeform_stroke2d_ = polyline.points();
    freeform_stroke3d_.resize(n_cutStroke);
    for (size_t i = 0; i < n_cutStroke; ++i)
        freeform_stroke3d_[i] = ogl.unproject(freeform_stroke2d_[i]);
    double scale = 0.5 * (ogl.viewParam_.focusPoint_ - ogl.viewParam_.eyePoint_).length();
    for (size_t i = 0; i < n_cutStroke; ++i) {    // adjust 3D positions so that (eyePoint - cutStroke3D[i]).length() equals to scale
        Vector3d d = freeform_stroke3d_[i] - ogl.viewParam_.eyePoint_;
        d.normalize();
        d *= scale;
        freeform_stroke3d_[i] = ogl.viewParam_.eyePoint_ + d;
    }
    // construct 2D scalar field with RBF
    vector<Vector2d> rbfPoints;
    vector<double>   rbfValues;
    for (size_t i = 0; i < n_cutStroke; ++i) {
        Vector2d p = freeform_stroke2d_[i];
        Vector2d d;
        if (0 < i)               d += p - freeform_stroke2d_[i - 1];
        if (i < n_cutStroke - 1) d += freeform_stroke2d_[i + 1] - p;
        d = rotate90(d);
        d.normalize();
        d *= (ogl.getWidth() + ogl.getHeight()) * 0.001;
        rbfPoints.push_back(p + d);     rbfValues.push_back( 1);
        rbfPoints.push_back(p - d);     rbfValues.push_back(-1);
    }
    freeform_rbf2d_.setPoints(rbfPoints);
    freeform_rbf2d_.setValues(rbfValues);
}
double CutParam::getCutValue(const Vector3d& pos) const {
    double cutValue = 0;
    if (mode_ == FREEFORM) {                         // freeform cut
        Vector2d pos2d(ogl.project(pos));
        cutValue = freeform_rbf2d_.getValue(pos2d);
    } else if (mode_ == SLICEX || mode_ == SLICEY || mode_ == SLICEZ) {         // slice cut (x-axis)
        int coord     = mode_ == SLICEX ? 0 : mode_ == SLICEY ? 1 : 2;
        double top    = slice_top_;
        double bottom = slice_bottom_;
        cutValue = min(abs(pos[coord] - top), abs(pos[coord] - bottom));
        if (pos[coord] < bottom || top < pos[coord])
            cutValue *= -1;
    } else {                                                            // wedge cut
        Vector2d zx(pos[2], pos[0]);
        if (zx[0] == 0 && zx[1] == 0) {
            cutValue = -0.01;
        } else {
            double angle = atan2(zx[1], zx[0]);
            if (angle < 0) angle += 2 * M_PI;
            double angle_dist = DBL_MAX;
            for (int i = -1; i <= 1; ++i) {
                angle_dist = min(abs(wedge_begin_ + i * 2 * M_PI - angle), angle_dist);
                angle_dist = min(abs(wedge_end_   + i * 2 * M_PI - angle), angle_dist);
            }
            cutValue = wedge_begin_ < angle && angle < wedge_end_ ? angle_dist : -angle_dist;
        }
    }
    return cutValue;
}
Vector2d CutParam::project  (const Vector3d& point3d) const {
    if (mode_ == FREEFORM) {
        size_t n_cutStroke = freeform_stroke3d_.size();
        Vector2d result;
        double dist_min = DBL_MAX;
        for (size_t i = 0; i < n_cutStroke - 1; ++i) {
            const Vector3d& eye  = ogl.viewParam_.eyePoint_;
            const Vector3d& cut0 = freeform_stroke3d_[i];
            const Vector3d& cut1 = freeform_stroke3d_[i + 1];
            Vector3d v[3] = { eye, cut0, cut1 };
            Vector3d& baryCoordTriangle = Util::calcBarycentricCoord<double,3, 3>(v, point3d);
            if (0 < i               && baryCoordTriangle[2] < 0)
                continue;
            if (i < n_cutStroke - 2 && baryCoordTriangle[1] < 0)
                continue;
            Vector3d projected = baryCoordTriangle[0] * eye + baryCoordTriangle[1] * cut0 + baryCoordTriangle[2] * cut1;
            double dist = (point3d - projected).length();
            if (dist_min < dist)
                continue;
            result.set((i + baryCoordTriangle[2] / (1 - baryCoordTriangle[0])) / (n_cutStroke - 1.), baryCoordTriangle[0]);
            dist_min = dist;
        }
        return result;
    } else if (mode_ == SLICEX) {
        return Vector2d(point3d[2], point3d[1]);
    } else if (mode_ == SLICEY) {
        return Vector2d(point3d[0], point3d[2]);
    } else if (mode_ == SLICEZ) {
        return Vector2d(point3d[1], point3d[0]);
    } else {
        Vector2d zx(point3d[2], point3d[0]);
        double r = zx.length();
        if (r == 0)             // special case: point3d lies on y-axis
            return Vector2d(0, point3d[1]);
        double angle = atan2(zx[1], zx[0]);
        double diff_begin = DBL_MAX;
        double diff_end   = DBL_MAX;
        for (int i = -1; i <= 1; ++i) {
            diff_begin = min(abs(wedge_begin_ + i * 2 * M_PI - angle), diff_begin);
            diff_end   = min(abs(wedge_end_   + i * 2 * M_PI - angle), diff_end  );
        }
        Vector2d result(diff_begin < diff_end ? -r : r, point3d[1]);
        return result;
    }
}
Vector3d CutParam::unproject(const Vector2d& point2d) const {
    if (mode_ == FREEFORM) {
        size_t n_cutStroke = freeform_stroke3d_.size();
        double uScale = point2d[0] * (n_cutStroke - 1);
        int segmentID = static_cast<int>(uScale);
        if (segmentID       < 0)         segmentID = 0;
        if (n_cutStroke - 2 < segmentID) segmentID = n_cutStroke - 2;
        double t1 = uScale - segmentID;
        double t0 = 1 - t1;
        Vector3d baryCoordTriangle;
        baryCoordTriangle[0] = point2d[1];
        baryCoordTriangle[1] = t0 * (1 - baryCoordTriangle[0]);
        baryCoordTriangle[2] = t1 * (1 - baryCoordTriangle[0]);
        const Vector3d& eye  = ogl.viewParam_.eyePoint_;
        const Vector3d& cut0 = freeform_stroke3d_[segmentID];
        const Vector3d& cut1 = freeform_stroke3d_[segmentID + 1];
        Vector3d point3d =
            baryCoordTriangle[0] * eye +
            baryCoordTriangle[1] * cut0 + 
            baryCoordTriangle[2] * cut1;
        return point3d;
    } else if (mode_ == SLICEX) {
        return Vector3d(slice_top_, point2d[1], point2d[0]);
    } else if (mode_ == SLICEY) {
        return Vector3d(point2d[0], slice_top_, point2d[1]);
    } else if (mode_ == SLICEZ) {
        return Vector3d(point2d[1], point2d[0], slice_top_);
    } else {
        double r = abs(point2d[0]);
        double angle = point2d[0] < 0 ? wedge_begin_ : wedge_end_;
        Vector3d point3d(r * sin(angle), point2d[1], r * cos(angle));
        return point3d;
    }
}
void CutParam::save(ofstream& ofs) const {
    ofs.write((char*)&mode_, sizeof(Mode));
    size_t N = freeform_stroke2d_.size();
    ofs.write((char*)&N, sizeof(size_t));
    ofs.write((char*)&freeform_stroke2d_[0], N * sizeof(Vector2d));
    ofs.write((char*)&ogl.viewParam_, sizeof(OGL::ViewParam));
    ofs.write((char*)&slice_bottom_, sizeof(double));
    ofs.write((char*)&slice_top_   , sizeof(double));
    ofs.write((char*)&wedge_begin_ , sizeof(double));
    ofs.write((char*)&wedge_end_   , sizeof(double));
}
void CutParam::load(ifstream& ifs) {
    ifs.read((char*)&mode_, sizeof(Mode));
    size_t N = 0;
    ifs.read((char*)&N, sizeof(size_t));
    freeform_stroke2d_.resize(N);
    ifs.read((char*)&freeform_stroke2d_[0], N * sizeof(Vector2d));
    ifs.read((char*)&ogl.viewParam_, sizeof(OGL::ViewParam));
    ifs.read((char*)&slice_bottom_, sizeof(double));
    ifs.read((char*)&slice_top_   , sizeof(double));
    ifs.read((char*)&wedge_begin_ , sizeof(double));
    ifs.read((char*)&wedge_end_   , sizeof(double));
    ogl.makeOpenGLCurrent();
    ogl.updateView();
}
CutParam::CutParam()
    : mode_(FREEFORM)
    , slice_top_(0)
    , slice_bottom_(-10)
    , wedge_begin_(0.01)
    , wedge_end_(1.01)
{}
