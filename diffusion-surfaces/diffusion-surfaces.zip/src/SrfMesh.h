#pragma once
#include "Mesh0.h"
#include "Mesh3.h"

struct SrfMesh {
    Mesh0 mesh0_;
    Mesh3 mesh3_;
    struct ShowFlag {
        enum Srf {
            MESH0,
            MESH3,
            MESH0_OPPOSITE,
            MESH3_OPPOSITE,
            NONE,
        } srf_;
        bool cs_;
        ShowFlag()
            : srf_(NONE)
            , cs_(false)
        {}
    } showFlag_;
    SrfMesh() {}
    SrfMesh(const Mesh0& mesh0)
        : mesh0_(mesh0)
    {}
};
