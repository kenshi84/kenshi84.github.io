#pragma once

#ifndef __AFXWIN_H__
	#error "Include 'stdafx.h' before including this file."
#endif

#include "resource.h"       


// CDiffusionSurfacesApp:

class CDiffusionSurfacesApp : public CWinApp
{
public:
	CDiffusionSurfacesApp();


	virtual BOOL InitInstance();
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
public:
    afx_msg void OnStepNext();
public:
    afx_msg void OnUpdateStepNext(CCmdUI *pCmdUI);
public:
    afx_msg void OnStepHome();
public:
    afx_msg void OnUpdateStepHome(CCmdUI *pCmdUI);
public:
    afx_msg void OnModeModeling();
public:
    afx_msg void OnUpdateModeModeling(CCmdUI *pCmdUI);
public:
    afx_msg void OnModeBrowsing();
public:
    afx_msg void OnUpdateModeBrowsing(CCmdUI *pCmdUI);
public:
    afx_msg void OnToolbarStep();
public:
    afx_msg void OnUpdateToolbarStep(CCmdUI *pCmdUI);
public:
    afx_msg void OnModeSalad();
public:
    afx_msg void OnUpdateModeSalad(CCmdUI *pCmdUI);
};

extern CDiffusionSurfacesApp theApp;