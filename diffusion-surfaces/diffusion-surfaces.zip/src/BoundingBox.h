#pragma once
#include <KLIB/Vector.h>
struct BoundingBox {
    KLIB::Vector3d max_;
    KLIB::Vector3d min_;
    BoundingBox() { init(); }
    double diagonal() const { return (max_ - min_).length(); }
    KLIB::Vector3d center() const { return (max_ + min_) * 0.5; }
    void init() { max_.fill(-DBL_MAX); min_.fill(DBL_MAX); }
};
