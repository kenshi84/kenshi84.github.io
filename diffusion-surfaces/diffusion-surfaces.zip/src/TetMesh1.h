#pragma once
#include <KLIB/Matrix.h>
#include <vector>

// Simple tetrahedral mesh for solving a Poisson diffusion (see Appendix of Andrei Sharf's SIGGRAPH 2007 paper)
struct TetMesh1 {
    struct Tetra {
        int vertex_[4];
        KLIB::Matrix4x4d K_;
        Tetra() {
            vertex_  [0] = vertex_  [1] = vertex_  [2] = vertex_  [3] = -1;
        }
    };
    struct Vertex {
        KLIB::Vector3d pos_;
        bool isConstrained_;
        KLIB::Vector3d color_;
        double cutValue_;
        std::vector<int> neighbor_edges_;
        std::vector<int> neighbor_tetras_;
        double K_;
        Vertex() : isConstrained_(false), cutValue_(0), K_(0) {}
    };
    struct Edge {
        int vertex_[2];
        double K_;
        Edge() : K_(0) {
            vertex_[0] = vertex_[1] = -1;
        }
    };
    std::vector<Tetra > tetras_;
    std::vector<Vertex> vertices_;
    std::vector<Edge  > edges_;
    void clear() {
        vertices_.clear();
        tetras_  .clear();
        edges_   .clear();
    }
};
