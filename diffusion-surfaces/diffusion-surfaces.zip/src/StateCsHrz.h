#pragma once
#include "state.h"
#include <KLIB/Polyline.h>
#include <KLIB/CurveDeformation2D.h>
#include <vector>

class StateCsHrz : public State {
    StateCsHrz(void) {}
    ~StateCsHrz(void) {}
public:
    static StateCsHrz* getInstance() {
        static StateCsHrz p;
        return &p;
    }
    std::string message();
    void initialize();
    State* next();
    bool isReady();
    void draw();
    
    void OnLButtonDown(UINT nFlags, CPoint& point);
    void OnLButtonUp  (UINT nFlags, CPoint& point);
    void OnRButtonDown(UINT nFlags, CPoint& point);
    void OnRButtonUp  (UINT nFlags, CPoint& point);
    void OnMouseMove  (UINT nFlags, CPoint& point);
    void OnDropFiles(const std::string& fname, const std::string& ext);
    void OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags);
    
    
    KLIB::Vector2d* draggedCorner_;
    KLIB::Vector2d dragPrev_;
    enum Mode {
        MODE_BGIMG,
        MODE_FOLD_ANGLE,
        MODE_DRAW,
        MODE_DEFORM,
        MODE_SMOOTH,
    } mode_;
    enum BgImgMode {
        BGIMGMODE_CORNER,
        BGIMGMODE_TRANSLATE,
        BGIMGMODE_ROTATE,
    } bgImgMode_;
    
    std::vector<KLIB::Vector2d> tempPoints_;
    double* dragFoldAngle_[2];
    double  dragFoldAngle_begin_;
    double  dragFoldAngle_end_;
    
    int currentObjectID_;
    
    // rigid deformation with peeling interface
    KLIB::CurveDeformation2D rigid_;
    KLIB::Polyline2d*        rigid_target_;
    KLIB::Vector2d           rigid_dragstart_;
    int                      rigid_dragid_;
    int                      rigid_peelsize_;
};
