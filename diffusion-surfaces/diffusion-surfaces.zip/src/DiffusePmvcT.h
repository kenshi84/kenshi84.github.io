#pragma once
#include "Mesh0.h"
#include "Mesh1.h"

template <class TDiffuseAlgorithm>
struct VolumeObjectT;

struct CutParam;

template <class TPmvcAlgorithm>
struct DiffusePmvcT {
    typedef VolumeObjectT<DiffusePmvcT<TPmvcAlgorithm> > VolumeObject;
    
    struct ObjectData {
        Mesh1 mesh1_;                   // intermediate cross-section mesh
        typename TPmvcAlgorithm::ObjectInfo pmvcInfo_;
        void gl_init  () { pmvcInfo_.gl_init  (); }
        void gl_deinit() { pmvcInfo_.gl_deinit(); }
        void preprocess(VolumeObject& volObj) { pmvcInfo_.preprocess(volObj); }
    };
    TPmvcAlgorithm pmvc_;
    
    void gl_init() { pmvc_.gl_init(); }
    void gl_deinit() { pmvc_.gl_deinit(); }
    void cut_step2_mesh2(VolumeObject& volObj, CutParam& param);
private:
    struct SegmentInfo {
        int mesh0_id_;  // id of mesh0
        int mesh0_fid_; // id of mesh0 face
        SegmentInfo(int mesh0_id = -1, int mesh0_fid = -1)
            : mesh0_id_(mesh0_id)
            , mesh0_fid_(mesh0_fid)
        {}
    };
    struct TriangleInOut {
        // -- in --
        std::vector<SegmentInfo> segmentinfolist_;    // the same size as segmentlist
        std::vector<double> in_pointlist_;
        std::vector<int>    in_segmentlist_;
        std::vector<int>    in_segmentmarkerlist_;    // used by deleting Steiner points on boundary edges (may be unnecessary)
        size_t n_bvertices_;     // # of boundary vertices
        size_t n_bsegments_;     // # of boundary segments
        double in_area_;        // maximum area constraint
        // -- out --
        std::vector<double> out_pointlist_;
        std::vector<int>    out_pointmarkerlist_;
        std::vector<int>    out_trianglelist_;
        std::vector<int>    out_segmentlist_;
        std::vector<int>    out_segmentmarkerlist_;
        TriangleInOut()
            : n_bvertices_()
            , n_bsegments_()
            , in_area_()
        {}
    } triangle_inout_;
    
    void cut_step2a_mesh0intersect(VolumeObject& volObj, CutParam& param);
    void cut_step2b_mesh0segment  (VolumeObject& volObj, CutParam& param);
    void cut_step2c_calltriangle  (VolumeObject& volObj, CutParam& param);
    void cut_step2d_mesh1vertex   (VolumeObject& volObj, CutParam& param);
    void cut_step2e_mesh1edge     (VolumeObject& volObj, CutParam& param);
    void cut_step2f_mesh1_mesh2   (VolumeObject& volObj, CutParam& param);
    void cut_step2g_mesh2label    (VolumeObject& volObj, CutParam& param);
    void cut_step2h_mesh2color    (VolumeObject& volObj, CutParam& param);
    KLIB::Vector2d cut_step2_trimesh_project  (const KLIB::Vector3d& point3d, CutParam& param);   // mapping from 3D point into 2D point on cutting surface
    KLIB::Vector3d cut_step2_trimesh_unproject(const KLIB::Vector2d& point2d, CutParam& param);   // mapping from 2D point on cutting surface into 3D point
};
