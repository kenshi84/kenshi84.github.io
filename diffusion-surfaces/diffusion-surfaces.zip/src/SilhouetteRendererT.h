#pragma once
#include <vector>
#include <list>
#include <KLIB/Polyline.h>
#include <KLIB/GLUtil.h>

template <class TScene>
struct SilhouetteRendererT {
    void gl_init();
    void gl_deinit();
    void gl_resize(int width, int height);
    void gl_draw();
    void clear();
    
    void update(TScene& scene);
    
    void step1_renderID_pre();
    void step1_renderID_post();
    void step2_findVisible();
    void step3a_calcCurves2d();
    void step3b_pruneShortCurves();
    void step3c_smooth();
    void step3d_resample();
    void step3e_calcLappedCurves();
    void step4_calcStrips();
    
    template <class TMesh, class TTransform>
    void addSilhouette(TMesh& mesh, const TTransform& tfm);
    template <class TMesh>
    void addSilhouette(TMesh& mesh);
    
    template <class TMesh, class TTransform>
    void renderDepth(const TMesh& mesh, const TTransform& tfm) const;
    template <class TMesh>
    void renderDepth(const TMesh& mesh) const;

    std::vector<KLIB::Polyline3d> curves3d_fixed_;
    std::vector<KLIB::Polyline3d> curves3d_;
    std::vector<KLIB::Polyline2d> curves2d_;
    KLIB::FramebufferObject fbo_;
    KLIB::RenderbufferObject bufColor_;
    KLIB::RenderbufferObject bufDepth_;
    std::vector<unsigned char> bufColor_cpu_;
    KLIB::TextureObject texBrush_;
    std::vector<int> flagVisible_;
    std::vector<std::vector<KLIB::Vector2d> > strips_;
};
