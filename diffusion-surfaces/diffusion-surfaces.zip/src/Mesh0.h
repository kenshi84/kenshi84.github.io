#pragma once
#include <OpenMesh/Core/Mesh/Traits.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>
#include <KLIB/Vector.h>
#include <KLIB/CholmodMatrix.h>
#include "BoundingBox.h"

// Mesh0: input triangle surface mesh with each vertex assigned a (pair of) color
struct Mesh0Traits : public OpenMesh::DefaultTraits {
    typedef KLIB::Vector3d Point;
    typedef KLIB::Vector3d Normal;
    VertexTraits {
    public:
        bool isOpenEnd_;   // true if the vertex is at the open end of mesh (always false if mesh is closed)
        // members related to color editing
        KLIB::Vector3d color_;
        bool isConstrained_;
        KLIB::Vector3d back_color_;
        bool           back_isConstrained_;
        double blurValue_;
        // members used by cutting
        double cutValue_;
        double normal_eye_product_;         // for computing silhouettes
        int  nfold1_mapped_vid_;            // needed for SweepObject::merge_nfold1()
        int nfold1_flagPole_;              // 0: non-pole, 1: south pole, 2: north pole
        // ctor
        VertexT()
            : color_     (1, 1, 1)
            , back_color_(1, 1, 1)
            , isConstrained_     (false)
            , back_isConstrained_(false)
            , blurValue_(0)
            , cutValue_(0)
            , normal_eye_product_(0)
            , nfold1_mapped_vid_(-1)
            , nfold1_flagPole_(0)
        {}
    };
    EdgeTraits {
    public:
        bool isOpenEnd_;   // true if the vertex is at the open end of mesh (always false if mesh is closed)
        // members used by cutting
        bool isCrossed_;        // crossed by cutting stroke
        double crossedPos_;
        int mesh1_vid_;         // isCrossed ? mesh1_vid : -1
        // debug
        int              dbg_id_;
        std::vector<int> dbg_ev_;
        std::vector<int> dbg_ef_;
        // for computing silhouettes
        KLIB::Vector3d silhouettePos_;
        bool isSilhouetteCrossed_;
        int subdiv_vid_;    // used for subdivision
        EdgeT()
            : isSilhouetteCrossed_(false)
            , subdiv_vid_(-1)
        {}
    };
    FaceTraits {
    public:
        bool flagGrain_;
        FaceT()
            : flagGrain_(false)
        {}
        bool isHidden() const { return false; }     // needed for SilhouetteRendererT
    };
};
struct Mesh0 : public OpenMesh::TriMesh_ArrayKernelT<Mesh0Traits> {
    bool isTwoSided_;
    bool isHole_;
    bool isClosed_;         // if isClosed, the mesh is treated as a volume boundary (interface or hole)
    bool isOutermost_;
    bool hasBlur_;
    BoundingBox bbox_;
    KLIB::CholmodMatrix LtL_;       // Laplaican matrix
    
    Mesh0()
        : isTwoSided_ (false)
        , isHole_     (false)
        , isClosed_   (false)
        , isOutermost_(false)
        , hasBlur_    (false)
    {}
    
    void calcAuxiliaryInfo();   // calculates: bbox_, isClosed_, vdata.isOpenEnd_, edata.isOpenEnd_
    void copyAttributes(const Mesh0& src);      // assuming the same connectivity, copy color & blur attributes
    void calcLaplacianMatrix();
    void updateColor();
    void updateBlur();
};
