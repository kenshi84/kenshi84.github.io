#pragma once
#include <GL/glew.h>
#include <KLIB/Vector.h>
#include <KLIB/GLUtil.h>
#include <string>
#include <vector>

struct BgImg {  // background image
    KLIB::Vector2d cornerBL_;   // bottom left
    KLIB::Vector2d cornerBR_;   // bottom right
    KLIB::Vector2d cornerTL_;   // top left
    KLIB::Vector2d cornerTR_;   // top right
    KLIB::TextureObject tex_;
    void gl_init();
    void gl_deinit();
    void load(const std::string& fname);
    int width_;
    int height_;
    std::vector<unsigned char> data_;
    void init() {
        data_.clear();
        width_ = height_ = 0;
    }
    BgImg() : width_(0), height_(0) {}
};
