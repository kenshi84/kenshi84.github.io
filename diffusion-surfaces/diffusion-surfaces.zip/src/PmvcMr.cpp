#include "StdAfx.h"
#include "Core.h"
#include "PmvcMr.h"
#include "DiffusePmvcT.h"
#include <KLIB/Clock.h>
#include <stack>
#include <iterator>
using namespace std;
using namespace KLIB;

namespace {
OGL& ogl = Core::getInstance().ogl_;
}

PmvcMr::Node PmvcMr::Node::operator+(const PmvcMr::Node& rhs) const {
    Node result;
    double dist = (rhs.position_ - position_).length();
    result.radius_ = 0.5 * (radius_ + rhs.radius_ + dist);
    result.position_ = dist == 0 ? position_ : ((result.radius_ - radius_) * rhs.position_ + (result.radius_ - rhs.radius_) * position_) / dist;
    result.normal_ = normal_ + rhs.normal_;
    result.normal_.normalize_cond();
    bool isAligned = 0 < (normal_ | rhs.normal_);
    result.colorf_ = 0.5 * (colorf_ + (isAligned ? rhs.colorf_ : rhs.colorb_));
    result.colorb_ = 0.5 * (colorf_ + (isAligned ? rhs.colorb_ : rhs.colorf_));
    return result;
}

void PmvcMr::ObjectInfo::gl_init() {
    bufHierarchy_.texture_.init(GL_TEXTURE_RECTANGLE_ARB, GL_CLAMP_TO_EDGE, GL_NEAREST, GL_REPLACE);
}
void PmvcMr::ObjectInfo::gl_deinit() {
    bufHierarchy_.texture_.deinit();
}
namespace {
typedef unsigned int uint;
typedef unsigned char uchar;
uint calcMortonOrder(uchar x, uchar y, uchar z) {
    uint result = 0;
    for (uint i = 0; i < 8; ++i) {
        uint bit_x = (x & (1 << i)) >> i;
        uint bit_y = (y & (1 << i)) >> i;
        uint bit_z = (z & (1 << i)) >> i;
        result += (4 * bit_z + 2 * bit_y + bit_x) << (3 * i);
    }
    return result;
}
void sortMortonOrder(vector<Vector3f>& points, vector<int>& permutation) {
    Vector3f coord_max(-FLT_MAX), coord_min(FLT_MAX);
    size_t n = points.size();
    for (size_t i = 0; i < n; ++i) {
        coord_max = coord_max.pairwiseMax(points[i]);
        coord_min = coord_min.pairwiseMin(points[i]);
    }
    Vector3f coord_dim = coord_max - coord_min;
    struct SortElem {
        uint order_;
        int perm_;
        Vector3f point_;
        SortElem(uint order = 0, int perm = 0, const Vector3f& point = Vector3f())
            : order_(order)
            , perm_(perm)
            , point_(point)
        {}
        bool operator<(const SortElem& rhs) const { return order_ < rhs.order_; }
    };
    vector<SortElem> sorted_points;
    sorted_points.reserve(n);
    for (size_t i = 0; i < n; ++i) {
        Vector3f normalized_coord = (points[i] - coord_min) / coord_dim;
        Vector3uc uc_coord = (normalized_coord * 255.0).convert<uchar>();
        uint mortonOrder = calcMortonOrder(uc_coord.x_, uc_coord.y_, uc_coord.z_);
        sorted_points.push_back(SortElem(mortonOrder, i, points[i]));
    }
    sort(sorted_points.begin(), sorted_points.end());
    permutation.resize(n);
    for (size_t i = 0; i < n; ++i) {
        points     [i] = sorted_points[i].point_;
        permutation[i] = sorted_points[i].perm_;
    }
}
}

vector<Vector3d> PmvcMr::getColor(const ObjectInfo& objInfo, const vector<Vector3d>& posList) {
    //return getColor_glsl(objInfo, posList, 64);
    return getColor_cpu(objInfo, posList);
}

vector<Vector3d> PmvcMr::getColor_glsl(const ObjectInfo& objInfo, const vector<Vector3d>& posListLong, size_t unitSize) {
    size_t sz = posListLong.size();
    
    vector<Vector3d> resultLong;
    resultLong.reserve(sz);
    
    vector<Vector3d> posListShort;
    posListShort.reserve(unitSize);
    for (size_t i = 0; i < sz; ++i) {
        posListShort.push_back(posListLong[i]);
        if (i % unitSize == unitSize - 1 || i == sz - 1) {
            cout << "(" << ((i / unitSize) + 1) << "/" << ((sz / unitSize) + 1) << ") ";
            vector<Vector3d> resultShort = getColor_glsl(objInfo, posListShort);
            copy(resultShort.begin(), resultShort.end(), back_inserter(resultLong));
            posListShort.clear();
        }
    }
    return resultLong;
}

vector<Vector3d> PmvcMr::getColor_glsl(const ObjectInfo& objInfo, const vector<Vector3d>& posList) {
    ClkSimple clk("micro-rendering with GLSL...");
    
    int n = static_cast<int>(posList.size());
    
    ogl.makeOpenGLCurrent();
    
    // determine canvas size
    int width = 1;
    while (width * width < n)
        ++width;
    int height = n / width + 1;
    
    // copy/allocate input buffer
    bufInput_.cpuData_.resize(width * height);
    for (int i = 0; i < n; ++i)
        bufInput_.cpuData_[i] = posList[i].convert<float>();
    vector<int> permutation;
    sortMortonOrder(bufInput_.cpuData_, permutation);
    bufInput_.texture_.allocate(GL_RGB32F_ARB, width, height, GL_RGB, GL_FLOAT);
    bufInput_.copy_cpu2gpu();
    // allocate output buffer
    bufOutput_.texture_.allocate(GL_RGB32F_ARB, width, height, GL_RGB, GL_FLOAT);

    // set framebuffer and draw target
    fbo_.bind();

    // set viewport/camera
    glPushAttrib(GL_VIEWPORT_BIT);
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, width, 0, height);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    
    // set input texture
    glActiveTextureARB(GL_TEXTURE1);        objInfo.bufHierarchy_.texture_.bind();
    glActiveTextureARB(GL_TEXTURE0);        bufInput_.texture_.bind();
    
    // enable shader
    shader_.enable();
    shader_.setUniform1i("u_num_leaf_nodes", objInfo.leafNodes_.size());
    shader_.setUniform1i("u_hierarchy_texWidth", objInfo.bufHierarchy_.texture_.width() / 4);
    float dist_max = static_cast<float>(objInfo.bbox_.diagonal() * 2.0);
    shader_.setUniform1f("u_dist_max", dist_max);

    // render a quad
    glBegin(GL_QUADS);
    glVertex2f(0    , 0     );
    glVertex2f(width, 0     );
    glVertex2f(width, height);
    glVertex2f(0    , height);
    glEnd();

    // cleanup
    shader_.disable();
    glActiveTextureARB(GL_TEXTURE1);        objInfo.bufHierarchy_.texture_.unbind();
    glActiveTextureARB(GL_TEXTURE0);        bufInput_.texture_.unbind();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glPopAttrib();
    fbo_.unbind();
    
    glFlush();
    
    // copy output to CPU
    vector<Vector3d> result(width * height);
    bufOutput_.copy_gpu2cpu();
    for (int i = 0; i < width * height; ++i)
        result[permutation[i]] = bufOutput_.cpuData_[i].convert<double>();
    result.resize(n);
    
    return result;
}

vector<Vector3d> PmvcMr::getColor_cpu (const ObjectInfo& objInfo, const vector<Vector3d>& posList) {
    ClkSimple clk("micro-rendering with CPU...");
    
    vector<Vector3d> result;
    result.reserve(posList.size());
    for (size_t i = 0; i < posList.size(); ++i)
        result.push_back(getColor_cpu(objInfo, posList[i]));
    return result;
}

Vector3d PmvcMr::getColor_cpu (const ObjectInfo& objInfo, const Vector3d& pos) {
    struct BufferElem {
        KLIB::Vector3d color_;
        double dist_;
        BufferElem(const Vector3d& color = Vector3d(), double dist = DBL_MAX)
            : color_(color)
            , dist_ (dist)
        {}
    };
    vector<BufferElem> buffers[6];      // cube map buffer
    static const Vector3d viewDirection[6] = { Vector3d( 1,  0,  0), Vector3d( 0, -1,  0), Vector3d(-1,  0,  0), Vector3d( 0,  1,  0), Vector3d( 0,  0,  1), Vector3d( 0,  0, -1) };
    static const Vector3d upDirection  [6] = { Vector3d( 0,  0,  1), Vector3d( 0,  0,  1), Vector3d( 0,  0,  1), Vector3d( 0,  0,  1), Vector3d( 0,  1,  0), Vector3d( 0,  1,  0) };
    const int& N = resolution_;
    for (int i = 0; i < 6; ++i) {
        buffers[i].clear();
        buffers[i].resize(N * N);
    }
    // rendering by traversing hierarchy
    stack<int> index_stack;
    index_stack.push(0);
    int stack_len_max = 0;
    while (!index_stack.empty()) {
        stack_len_max = max<int>(stack_len_max, static_cast<int>(index_stack.size()));
        int index = index_stack.top();
        index_stack.pop();
        const Node& node = objInfo.hierarchy_[index];
        Vector3d v = node.position_ - pos;
        int buffer_id = -1;
        double dot_max = -DBL_MAX;
        for (int i = 0; i < 6; ++i) {
            double dot = viewDirection[i] | v;
            if (dot_max < dot) {
                dot_max = dot;
                buffer_id = i;
            }
        }
        vector<BufferElem>& buffer = buffers[buffer_id];
        Vector3d e0 = viewDirection[buffer_id];
        Vector3d e2 = upDirection[buffer_id];
        Vector3d e1 = e0 % e2;
        Vector3d d = v / (v | e0);
        double t1 = d | e1;
        double t2 = d | e2;     // -1 <= t1, t2 <= 1
        int ix = min<int>(static_cast<int>((t1 + 1) * N / 2), N - 1);
        int iy = min<int>(static_cast<int>((t2 + 1) * N / 2), N - 1);     // 0 <= ix, iy <= rez - 1
        double s1 = (ix - N * 0.5) / (N * 0.5);
        double s2 = (iy - N * 0.5) / (N * 0.5);               // -1 <= s1, s2 <= 1 - 2 / N
        Vector3d h[4];
        h[0] = e0 +  s1               * e1 +  s2               * e2;
        h[1] = e0 + (s1 + 2.0 / N) * e1 +  s2               * e2;
        h[2] = e0 + (s1 + 2.0 / N) * e1 + (s2 + 2.0 / N) * e2;
        h[3] = e0 +  s1               * e1 + (s2 + 2.0 / N) * e2;
        Vector4d pixelEdgeDist;
        double max_stickout = 0;
        for (int i = 0; i < 4; ++i) {
            Vector3d face[3] = { Vector3d(), h[i], h[(i + 1) % 4]};
            Vector3d projection = Util::calcProjection<double, 3, 3>(face, v);
            pixelEdgeDist[i] = (projection - v).length();
            max_stickout = max<double>(0, node.radius_ - pixelEdgeDist[i]);
        }
        if (0 < max_stickout && index < objInfo.leafNodes_.size() - 1) {       // if current node sticks out of this pixel and has children
            index_stack.push(2 * index + 2);
            index_stack.push(2 * index + 1);
        } else {
            double pixel_size = 0.5 * pixelEdgeDist.elemSum();
            int k = static_cast<int>(ceil(max_stickout / pixel_size));
            double   node_dist  = v.length();
            Vector3d node_color = (node.normal_ | v) < 0 ? node.colorf_ : node.colorb_;
            for (int dy = -k; dy <= k; ++dy) for (int dx = -k; dx <= k; ++dx) {
                int ix1 = ix + dx;
                int iy1 = iy + dy;
                if (ix1 < 0 || N <= ix1 || iy1 < 0 || N <= iy1)
                    continue;
                BufferElem& bufferElem = buffer[iy1 * N + ix1];
                if (node_dist < bufferElem.dist_) {
                    bufferElem.color_ = node_color;
                    bufferElem.dist_  = node_dist;
                }
            }
        }
    }
    // integration
    Vector3d result;
    double weight_sum = 0;
    for (int i = 0; i < 6; ++i) for (int j = 0; j < N * N; ++j) {
        BufferElem& bufferElem = buffers[i][j];
        double weight = areaWeight_[j] / bufferElem.dist_;
        result += weight * bufferElem.color_;
        weight_sum += weight;
    }
    result /= weight_sum;
    
    //{   // save micro-buffer image
    //    IplImage* img = cvCreateImage(cvSize(4 * N, 3 * N), IPL_DEPTH_8U, 3);
    //    for (int i = 0; i < 36 * N * N; ++i)
    //        img->imageData[i] = -128;
    //    for (int k = 0; k < 6; ++k) {
    //        for (int iy = 0; iy < N; ++iy) for (int ix = 0; ix < N; ++ix) {
    //            int i0 = iy * N + ix;
    //            Vector3d rgb = buffers[k][i0].color_;
    //            int i1 =
    //                k <  4 ? (2 * N - 1 - iy) * 4 * N +     ix + k * N :
    //                k == 4 ? (    N - 1 - iy) * 4 * N +     ix +     N :
    //                         (2 * N +     iy) * 4 * N - 1 - ix + 2 * N;
    //            for (int j = 0; j < 3; ++j)
    //                img->imageData[3 * i1 + j] = static_cast<unsigned char>(rgb[2 - j] * 0xFF);
    //        }
    //    }
    //    IplImage* img_resized = cvCreateImage(cvSize(img->width * 8, img->height * 8), IPL_DEPTH_8U, 3);
    //    cvResize(img, img_resized, CV_INTER_NN);
    //    cvSaveImage("micro-buffer.png", img_resized);
    //    cvReleaseImage(&img);
    //    cvReleaseImage(&img_resized);
    //}
    
    return result;
}

void PmvcMr::gl_init() {
    ShaderObject shader_areaWeight;
    {
        ostringstream oss;
        oss << "#version 130\n";
        int rez2 = resolution_ * resolution_;
        oss << "float areaWeight[" << rez2 << "] = float[" << rez2 << "](";
        for (int i = 0; i < rez2; ++i) {
            oss << areaWeight_[i];
            if (i < rez2 - 1)
                oss << ", ";
        }
        oss << ");\n";
        string source = oss.str();
        shader_areaWeight.setSource(source, ShaderObject::FRAGMENT_SHADER);
    }
    
    shader_.init();
    shader_.attach(shader_areaWeight);
    shader_.attach(ShaderObject("PmvcMr.frag", ShaderObject::FRAGMENT_SHADER));
    shader_.link();
    shader_.enable();
    shader_.setUniform1i("u_texture_position", 0);
    shader_.setUniform1i("u_texture_hierarchy", 1);
    shader_.disable();
    
    bufInput_ .texture_.init(GL_TEXTURE_RECTANGLE_ARB, GL_CLAMP_TO_EDGE, GL_NEAREST, GL_REPLACE);
    bufOutput_.texture_.init(GL_TEXTURE_RECTANGLE_ARB, GL_CLAMP_TO_EDGE, GL_NEAREST, GL_REPLACE);
    
    fbo_.init();
    fbo_.bind();
    fbo_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, bufOutput_.texture_);
    glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
    GLUtil::checkFramebufferStatus();
    fbo_.unbind();
}

void PmvcMr::gl_deinit() {
    bufInput_ .texture_.deinit();
    bufOutput_.texture_.deinit();
    fbo_.deinit();
}

PmvcMr::PmvcMr(int resolution)
    : resolution_(resolution)
{
    const int& N = resolution;
    const int& N2 = N * N;
    areaWeight_.resize(N2, 0);
    int n = N / 2;
    double d = 1. / n;
    Vector3d dx(d, 0, 0);
    Vector3d dy(0, d, 0);
    for (int i = 0; i < n; ++i) for (int j = 0; j <= i; ++j) {
        Vector3d h0(- i      * d, - j      * d, 1);
        Vector3d h1(-(i + 1) * d, -(j + 1) * d, 1);
        Vector3d n0 = dx % h0;
        Vector3d n1 = dy % h0;
        Vector3d n2 = dx % h1;
        Vector3d n3 = dy % h1;
        n0.normalize();
        n1.normalize();
        n2.normalize();
        n3.normalize();
        double theta0 = acos( n0 | n1);
        double theta1 = acos(-n1 | n2);
        double theta2 = acos( n2 | n3);
        double theta3 = acos(-n3 | n0);
        double weight = theta0 + theta1 + theta2 + theta3 - 2 * M_PI;
        areaWeight_[n + i     + N * (n + j    )] = weight;
        areaWeight_[n - i - 1 + N * (n + j    )] = weight;
        areaWeight_[n + i     + N * (n - j - 1)] = weight;
        areaWeight_[n - i - 1 + N * (n - j - 1)] = weight;
        if (i == j) continue;
        areaWeight_[n + j     + N * (n + i    )] = weight;
        areaWeight_[n - j - 1 + N * (n + i    )] = weight;
        areaWeight_[n + j     + N * (n - i - 1)] = weight;
        areaWeight_[n - j - 1 + N * (n - i - 1)] = weight;
    }
}

void PmvcMr::ObjectInfo::preprocess(VolumeObject& volObj) {
    bbox_ = volObj.bbox_;
    preprocess_step1_generatePoints(volObj);
    preprocess_step2_buildHierarchy(volObj);
}
void PmvcMr::ObjectInfo::preprocess_step1_generatePoints(VolumeObject& volObj) {
    // generate point sets (=leaf nodes) over surfaces
    leafNodes_.clear();
    double radius = volObj.bbox_.diagonal() * 0.01;
    int n = 0;
    for (vector<SrfMesh>::iterator it = volObj.srfMeshes_.begin(); it != volObj.srfMeshes_.end(); ++it) {
        Mesh0& mesh0 = it->mesh0_;
        for (Mesh0::FIter f = mesh0.faces_begin(); f != mesh0.faces_end(); ++f) {
            Vector3d f_points[3];
            Mesh0::FVIter v = mesh0.fv_iter(f);
            for (int i = 0; i < 3; ++i, ++v)
                f_points[i] = mesh0.point(v);
            double area = Util::calcArea(f_points[0], f_points[1], f_points[2]);
            int n1 = max<int>(static_cast<int>(area / (M_PI * radius * radius)), 1);
            vector<Vector3d> samples;
            samples.reserve(n1);
            for (int i = 0; i < n1; ++i, ++n) {
                Vector3d baryCoord;
                double dist_max = 0;
                for (int j = 0; j < 5; ++j) {       // best-candidate sampling?
                    Vector3d candidate;
                    candidate.set_random(0, 1);
                    candidate /= candidate.elemSum();
                    Vector3d position;
                    v = mesh0.fv_iter(f);
                    for (int k = 0; k < 3; ++k, ++v)
                        position += candidate[k] * mesh0.point(v);
                    double dist_min = DBL_MAX;
                    for (size_t k = 0; k < samples.size(); ++k)
                        dist_min = min<double>(dist_min, (samples[k] - position).lengthSquared());
                    if (dist_max < dist_min) {
                        dist_max = dist_min;
                        baryCoord = candidate;
                    }
                }
                Node node;
                node.radius_ = radius;
                v = mesh0.fv_iter(f);
                for (int j = 0; j < 3; ++j, ++v) {
                    node.position_ += baryCoord[j] * mesh0.point(v);
                    node.normal_   += baryCoord[j] * mesh0.normal(v);
                    node.colorf_   += baryCoord[j] * mesh0.data(v).color_;
                    node.colorb_   += baryCoord[j] * mesh0.data(v).back_color_;
                }
                node.normal_.normalize();
                leafNodes_.push_back(node);
                samples.push_back(node.position_);
            }
        }
    }
    int n2 = 1;
    while (n2 < n)
        n2 <<= 1;
    int m = n2 - n;
    for (int i = 0; i < m; ++i, ++n) {
        int srfmesh_id = rand() % volObj.srfMeshes_.size();
        Mesh0& mesh0 = volObj.srfMeshes_[srfmesh_id].mesh0_;
        int f_id = rand() % mesh0.n_faces();
        Mesh0::FHandle f = mesh0.face_handle(f_id);
        Vector3d baryCoord;
        baryCoord.set_random(0, 1);
        baryCoord /= baryCoord.elemSum();
        Node node;
        node.radius_ = radius;
        Mesh0::FVIter v = mesh0.fv_iter(f);
        for (int j = 0; j < 3; ++j, ++v) {
            node.position_ += baryCoord[j] * mesh0.point(v);
            node.normal_   += baryCoord[j] * mesh0.normal(v);
            node.colorf_   += baryCoord[j] * mesh0.data(v).color_;
            node.colorb_   += baryCoord[j] * mesh0.data(v).back_color_;
        }
        node.normal_.normalize();
        leafNodes_.push_back(node);
    }
    assert(leafNodes_.size() == n && n == n2);
}

void PmvcMr::ObjectInfo::preprocess_step2_buildHierarchy(VolumeObject& volObj) {
    const int n = static_cast<int>(leafNodes_.size());
    int n2 = n;
    int L = 0;
    for ( ; !(n2 & 1); ++L)
        n2 >>= 1;
    assert(n2 == 1);
    
    // perform sort in-place
    struct SortNode {
        enum SortKey { X, Y, Z };
        Node node_;
        SortNode(const Node& node = Node())
            : node_(node)
        {}
        static SortKey& sortKey() {
            static SortKey key = X;
            return key;
        }
        bool operator<(const SortNode& rhs) const {
            return
                sortKey() == X ? node_.position_.x_ < rhs.node_.position_.x_ :
                sortKey() == Y ? node_.position_.y_ < rhs.node_.position_.y_ : node_.position_.z_ < rhs.node_.position_.z_;
        }
    };
    vector<SortNode> sort_nodes;
    sort_nodes.reserve(n);
    for (int i = 0; i < n; ++i) {
        sort_nodes.push_back(SortNode());
        sort_nodes.back().node_ = leafNodes_[i];
    }
    
    n2 = n;
    for (int l = 0; l < L - 1; ++l) {
        vector<SortNode>::iterator sort_begin = sort_nodes.begin();
        vector<SortNode>::iterator sort_end   = sort_begin + 1;
        Vector3d bb_max(-DBL_MAX), bb_min(DBL_MAX);
        for (int i = 0; i < n; ++i) {
            bb_max = bb_max.pairwiseMax(sort_nodes[i].node_.position_);
            bb_min = bb_min.pairwiseMin(sort_nodes[i].node_.position_);
            if ((i + 1) % n2 == 0) {
                Vector3d diagonal = bb_max - bb_min;
                SortNode::sortKey() =
                    diagonal.y_ < diagonal.x_ && diagonal.z_ < diagonal.x_ ? SortNode::X :
                    diagonal.z_ < diagonal.y_ ? SortNode::Y : SortNode::Z;
                sort(sort_begin, sort_end);
                bb_max.fill(-DBL_MAX);
                bb_min.fill( DBL_MAX);
                sort_begin = sort_end;
            }
            if (i != n - 1)
                ++sort_end;
        }
        n2 >>= 1;
    }
    assert(n2 == 2);
    
    // construct binary tree
    hierarchy_.resize(2 * n - 1);
    for (int i = 0; i < n; ++i)
        hierarchy_[n - 1 + i] = sort_nodes[i].node_;
    n2 = n;
    for (int l = 0; l < L; ++l) {
        for (int i = n2 / 2 - 1; i < n2 - 1; ++i) {
            hierarchy_[i] = hierarchy_[2 * i + 1] + hierarchy_[2 * i + 2];
        }
        n2 >>= 1;
    }
        
    // determine texture size
    int width = 1;
    while (width * width < 2 * n - 1)
        ++width;
    int height = (2 * n - 1) / width + 1;

    // allocate & copy to GPU memory
    bufHierarchy_.cpuData_.resize(4 * width * height);
    for (int i = 0; i < 2 * n - 1; ++i) {
        Node& node = hierarchy_[i];
        bufHierarchy_.cpuData_[4 * i] = node.position_.convert<float>();
        Vector3f theta_phi_rad;
        {
            double rxy = Vector2d(node.normal_).length();
            double phi = atan2(node.normal_.z_, rxy);
            double theta = atan2(node.normal_.y_ / rxy, node.normal_.x_ / rxy);
            theta_phi_rad = Vector3d(theta, phi, node.radius_).convert<float>();
        }
        bufHierarchy_.cpuData_[4 * i + 1] = theta_phi_rad;
        bufHierarchy_.cpuData_[4 * i + 2] = node.colorf_.convert<float>();
        bufHierarchy_.cpuData_[4 * i + 3] = node.colorb_.convert<float>();
    }
    ogl.makeOpenGLCurrent();
    bufHierarchy_.texture_.allocate(GL_RGB16F_ARB, 4 * width, height, GL_RGB, GL_FLOAT);
    bufHierarchy_.copy_cpu2gpu();
}
