#pragma once
#include "Piece.h"
#include "SilhouetteRendererT.h"

struct Salad {
    std::vector<Piece> pieces_;
    
    void gl_init();
    void gl_deinit();
    bool load(const char* fname);
    bool save(const char* fname) const;
    
    // functions used in SilhouetteRenderer
    SilhouetteRendererT<Salad> silRenderer_;
    void updateSilhouette() { silRenderer_.update(*this); }
    void calcFixedCurves();
    void calcSilhouetteCurves();
    void renderSceneDepth() const;
};
