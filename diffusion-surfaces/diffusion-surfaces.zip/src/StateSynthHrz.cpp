#include "StdAfx.h"
#include "StateSynthHrz.h"
#include "StateBrowse.h"
#include "Core.h"
using namespace std;
using namespace KLIB;


namespace {
Core& core = Core::getInstance();
OGL& ogl = core.ogl_;
Modeler& modeler = core.modeler_;
}


void StateSynthHrz::initialize() {
    if (modeler.type_ == Modeler::TYPE_CYLIND) {
        modeler.analyze_cylind();
        modeler.synthesize_cylind(core.volObj_);
    } else {
        modeler.analyze_nfold();
        modeler.synthesize_nfold(core.volObj_, modeler.foldAngles_exemplar_.size());
    }
    glEnable(GL_LIGHTING);
    glLineWidth(1);
}

State* StateSynthHrz::next() {
    return StateBrowse::getInstance();
}
void StateSynthHrz::draw() {
    glPushAttrib(GL_ENABLE_BIT);
    glDisable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    for (size_t i = 0; i < core.volObj_.srfMeshes_.size(); ++i) {
        Mesh0& mesh = core.volObj_.srfMeshes_[i].mesh0_;
        Drawer::draw_mesh_colored(mesh, 0.75);
    }
    glPopAttrib();
}

void StateSynthHrz::OnLButtonDown(UINT nFlags, CPoint& point) {}
void StateSynthHrz::OnLButtonUp  (UINT nFlags, CPoint& point) {}
void StateSynthHrz::OnRButtonDown(UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonDown_3D(nFlags, point); }
void StateSynthHrz::OnRButtonUp  (UINT nFlags, CPoint& point) { core.eventHandler_.default_OnRButtonUp(nFlags, point); }
void StateSynthHrz::OnMouseMove  (UINT nFlags, CPoint& point) {
    if (core.eventHandler_.isRButtonDown_)
        core.eventHandler_.default_OnMouseMove(nFlags, point);
}
void StateSynthHrz::OnKeyDown    (UINT nChar, UINT nRepCnt, UINT nFlags) {
    switch (nChar) {
    case VK_UP:
    case VK_DOWN:
        if (modeler.type_ == Modeler::TYPE_CYLIND)
            return;
    case VK_RETURN:
        if (modeler.type_ == Modeler::TYPE_CYLIND) {
            modeler.synthesize_cylind(core.volObj_);
        } else {
            size_t numFold = modeler.foldAngles_synthesis_.size();
            numFold +=
                nChar == VK_UP   ?  1 :
                nChar == VK_DOWN ? -1 : 0;
            if (numFold == 1)
                numFold = 2;
            modeler.synthesize_nfold(core.volObj_, numFold);
        }
        core.ogl_.RedrawWindow();
        break;
    case 'S':   // save to XML
        {
            CFileDialog dlg(FALSE, "xml", "*.xml", OFN_NOCHANGEDIR | OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "XML files|*.xml|DSS files|*.dss||");
            if (dlg.DoModal() != IDOK) return;
            string fname(dlg.GetPathName());
            string ext(dlg.GetFileExt());
            if (ext == "xml")
                core.volObj_.saveXML(fname.c_str());
            else if (ext == "dss")
                core.volObj_.saveDSS(fname.c_str());
        }
        break;
    }
}
