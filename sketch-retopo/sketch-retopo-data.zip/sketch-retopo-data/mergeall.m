% merge_poly('armadillo_mauri',1e-2);
% merge_poly('bunny_alessia',1e-5);
% merge_poly('car_alessia',1e-3);
% merge_poly('hand_mauri',1e-3);
%merge_poly('horse_kenshi',1e-5);
%merge_poly('monkey_alessia',1e-3);
% merge_poly('spider_kenshi',1e-3);
merge_poly('zhead_mauri',1e-2);