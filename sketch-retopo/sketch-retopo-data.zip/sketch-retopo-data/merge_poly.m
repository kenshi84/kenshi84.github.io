function [] = merge_poly(filename,tol)

[PV,PF] = readOBJpoly_sketch([filename '.obj']);

% Mesh in (V,F)
[PV,SVI,SVJ] = remove_duplicate_vertices(PV,tol);

for i=1:length(PF)
  f = PF{i};
  f = SVJ(f);
  PF{i} = f;
end
 
fid = 1;

while (fid < length(PF))
  fid
  current = PF{fid};
  found = 0;
  
  for i=fid+1:length(PF)
    temp = PF{i};
    if all(sort(current) == sort(temp))
      found = 1;
    end
  end
  
  if (found)
    PF(fid) = [];
  else
    fid = fid + 1;
  end
 
end

writeOBJpoly(PV,PF,[filename '_merged.obj']);

end