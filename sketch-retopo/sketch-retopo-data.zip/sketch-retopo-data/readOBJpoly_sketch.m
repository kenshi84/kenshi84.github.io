function [ PV, PF ] = readOBJpoly_sketch( filename )

PV = {};
PF = {};

fid = fopen(filename,'r');

%% Skip the first two lines

while ~feof(fid)
  % Read a line
  string = textscan(fid,'%s',1,'delimiter','\n'); 
  if size(string{1},1) == 0
    break;
  end
  
  string = string{1}{1};
  % Split into pieces
  parts = strread(string,'%s','delimiter',' ');
  if ~isempty(parts)
    if strcmp('v', parts{1})
      % Vertex
      PV{end+1} = str2doubleq(parts(2:4))';
    elseif strcmp('f', parts{1})
      t = parts(2:end);
      for j=1:length(t)
        C = strread(char(t(j)),'%s','delimiter','//');
        t(j) = cellstr(C{1});
      end
      
      
      PF{end+1} = str2doubleq(t)';
    end
  end
  
end

fclose(fid);

PV = cell2mat(PV');
PF = PF';

