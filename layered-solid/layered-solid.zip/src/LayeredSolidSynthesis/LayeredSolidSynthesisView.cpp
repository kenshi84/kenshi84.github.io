// LayeredSolidSynthesisView.cpp : implementation of the CLayeredSolidSynthesisView class
//

#include "stdafx.h"
#include "LayeredSolidSynthesis.h"

#include "LayeredSolidSynthesisDoc.h"
#include "LayeredSolidSynthesisView.h"

#include "KCore.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CLayeredSolidSynthesisView

IMPLEMENT_DYNCREATE(CLayeredSolidSynthesisView, CView)

BEGIN_MESSAGE_MAP(CLayeredSolidSynthesisView, CView)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_DROPFILES()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDOWN()
END_MESSAGE_MAP()

// CLayeredSolidSynthesisView construction/destruction

CLayeredSolidSynthesisView::CLayeredSolidSynthesisView()
{
	// TODO: add construction code here

}

CLayeredSolidSynthesisView::~CLayeredSolidSynthesisView()
{
}

BOOL CLayeredSolidSynthesisView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.dwExStyle |= WS_EX_ACCEPTFILES;

	return CView::PreCreateWindow(cs);
}

// CLayeredSolidSynthesisView drawing

void CLayeredSolidSynthesisView::OnDraw(CDC* /*pDC*/)
{
	CLayeredSolidSynthesisDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	KCore& core = *KCore::getInstance();
	core.m_ogl.OnDraw_Begin();
	core.m_drawer.draw(this);
	core.m_ogl.OnDraw_End();
}


// CLayeredSolidSynthesisView diagnostics

#ifdef _DEBUG
void CLayeredSolidSynthesisView::AssertValid() const
{
	CView::AssertValid();
}

void CLayeredSolidSynthesisView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CLayeredSolidSynthesisDoc* CLayeredSolidSynthesisView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLayeredSolidSynthesisDoc)));
	return (CLayeredSolidSynthesisDoc*)m_pDocument;
}
#endif //_DEBUG


// CLayeredSolidSynthesisView message handlers

int CLayeredSolidSynthesisView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	KCore& core = *KCore::getInstance();
	core.m_ogl.OnCreate(this);
	core.m_drawer.init(this);

	return 0;
}

void CLayeredSolidSynthesisView::OnDestroy()
{
	CView::OnDestroy();

	KCore::getInstance()->m_ogl.OnDestroy();
}

BOOL CLayeredSolidSynthesisView::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;//CView::OnEraseBkgnd(pDC);
}

void CLayeredSolidSynthesisView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	KCore::getInstance()->m_ogl.OnSize(cx, cy);
}

void CLayeredSolidSynthesisView::OnRButtonDown(UINT nFlags, CPoint point)
{
	KCore::getInstance()->m_handler.OnRButtonDown(this, nFlags, point);

	CView::OnRButtonDown(nFlags, point);
}

void CLayeredSolidSynthesisView::OnRButtonUp(UINT nFlags, CPoint point)
{
	KCore::getInstance()->m_handler.OnRButtonUp(this, nFlags, point);

	CView::OnRButtonUp(nFlags, point);
}

void CLayeredSolidSynthesisView::OnMouseMove(UINT nFlags, CPoint point)
{
	KCore::getInstance()->m_handler.OnMouseMove(this, nFlags, point);

	CView::OnMouseMove(nFlags, point);
}

void CLayeredSolidSynthesisView::OnDropFiles(HDROP hDropInfo)
{
	KCore::getInstance()->m_handler.OnDropFiles(this, hDropInfo);

	CView::OnDropFiles(hDropInfo);
}

void CLayeredSolidSynthesisView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	KCore::getInstance()->m_handler.OnKeyDown(this, nChar, nRepCnt, nFlags);

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CLayeredSolidSynthesisView::OnLButtonDown(UINT nFlags, CPoint point)
{
	KCore::getInstance()->m_handler.OnLButtonDown(this, nFlags, point);

	CView::OnLButtonDown(nFlags, point);
}
