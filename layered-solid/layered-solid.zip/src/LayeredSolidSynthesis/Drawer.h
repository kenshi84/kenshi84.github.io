#pragma once

#define FTGL_LIBRARY_STATIC
#include <FTGL/ftgl.h>
#include <gl/glew.h>
#include <vector>

class Drawer
{
public:
	Drawer(void);
	~Drawer(void);
	
	GLuint m_texName_volume;
	
	FTFont *mp_font;
	
	void init(CView* view);
	void draw(CView* view);
	void postDraw(CView* view, CDC* pDC);
	void updateTexture_volume(int level);
};
