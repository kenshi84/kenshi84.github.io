#include "StdAfx.h"
#include "EventHandler.h"
#include "KCore.h"
#include <vector>
using namespace std;

EventHandler::EventHandler(void) {
}

EventHandler::~EventHandler(void) {
}

void EventHandler::OnLButtonDown(CView* view, UINT nFlags, CPoint point) {
	KCore& core = *KCore::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	int level = core.m_vis_currentLevel;
	double t = core.m_vis_slicePos / (double)KCore::TEXSIZE[level];
	// check intersections for all planes of xmin, xmax, ymin, ymax. zmin, zmax
	double plane_pos[3][2] = {{0, 1}, {0, 1}, {0, 1}};	// {pos_min, pos_max} for xyz directions
	double delta = 0.5 / KCore::TEXSIZE[level];
	plane_pos[core.m_vis_viewDir][1] = t;
	for (int dir = 0; dir < 3; ++dir) {	// for all xyz directions
		for (int minmax = 0; minmax < 2; ++minmax) {	// for 2 planes (min & max)
			// culling back face
			if (minmax == 0 && ori[dir] < 0) continue;
			if (minmax == 1 && ori[dir] > 0) continue;
			/*
			(start + k * ori).x = t
			k = (t - start.x) / ori.x
			*/
			double k = (plane_pos[dir][minmax] - start[dir]) / ori[dir];
			start.addWeighted(ori, k);
			if (start[0] < plane_pos[0][0] || start[1] < plane_pos[1][0] || start[2] < plane_pos[2][0] ) continue;
			if (start[0] > plane_pos[0][1] || start[1] > plane_pos[1][1] || start[2] > plane_pos[2][1] ) continue;
			start[dir] += (minmax == 0) ? delta : -delta;
			start.scale(KCore::TEXSIZE[level]);
			int ix = (int)start.x;
			int iy = (int)start.y;
			int iz = (int)start.z;
			int index = ix + KCore::TEXSIZE[level] * iy + KCore::TEXSIZE[level] * KCore::TEXSIZE[level] * iz;
			int nearest_x = core.m_volume_nearest_x_index[level][index];
			int nearest_y = core.m_volume_nearest_y_index[level][index];
			int N_SAMPLES_WIDTH = KCore::TEXSIZE[level] - 2 * KCore::N[level];
			int u_x = nearest_x % N_SAMPLES_WIDTH;
			int v_x = nearest_x / N_SAMPLES_WIDTH;
			int u_y = nearest_y % N_SAMPLES_WIDTH;
			int v_y = nearest_y / N_SAMPLES_WIDTH;
			printf("%c_%s: ", dir == 0 ? 'X' : dir == 1 ? 'Y' : 'Z', minmax == 0 ? "min" : "max");
			printf("(%d, %d, %d) - nearest_x = (%d, %d), nearest_y = (%d, %d)\n", ix, iy, iz, u_x, v_x, u_y, v_y);
			return;
		}
	}
}

void EventHandler::OnRButtonDown(CView* view, UINT nFlags, CPoint point) {
	if ((nFlags & MK_SHIFT) != 0) {
		KCore::getInstance()->m_ogl.ButtonDownForZoom(point);
	} else if ((nFlags & MK_CONTROL) != 0) {
		KCore::getInstance()->m_ogl.ButtonDownForTranslate(point);
	} else {
		KCore::getInstance()->m_ogl.ButtonDownForRotate(point);
	}
}
void EventHandler::OnRButtonUp(CView* view, UINT nFlags, CPoint point) {
	KCore::getInstance()->m_ogl.ButtonUp();
}
void EventHandler::OnMouseMove(CView* view, UINT nFlags, CPoint point) {
	KCore::getInstance()->m_ogl.MouseMove(point);
}
void EventHandler::OnKeyDown(CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {
	KCore& core = *KCore::getInstance();
	switch (nChar) {
		case VK_DOWN:
			if (1 < core.m_vis_slicePos) {
				--core.m_vis_slicePos;
				core.m_ogl.RedrawWindow();
			}
			break;
		case VK_UP:
			if (core.m_vis_slicePos < KCore::TEXSIZE[core.m_vis_currentLevel]) {
				++core.m_vis_slicePos;
				core.m_ogl.RedrawWindow();
			}
			break;
		case 'X':
			if (core.m_vis_viewDir == 0) break;
			core.m_vis_viewDir = 0;
			core.m_ogl.RedrawWindow();
			break;
		case 'Y':
			if (core.m_vis_viewDir == 1) break;
			core.m_vis_viewDir = 1;
			core.m_ogl.RedrawWindow();
			break;
		case 'Z':
			if (core.m_vis_viewDir == 2) break;
			core.m_vis_viewDir = 2;
			core.m_ogl.RedrawWindow();
			break;
		case 'P':
			//core.randomOrientation(core.m_vis_currentLevel);
			core.searchVolume(core.m_vis_currentLevel);
			core.optimizeVolume(core.m_vis_currentLevel);
			core.calcVolume_uchar(core.m_vis_currentLevel);
			core.m_drawer.updateTexture_volume(core.m_vis_currentLevel);
			core.m_ogl.RedrawWindow();
			break;
		case 'L':
			if (core.m_vis_currentLevel == KCore::MULTIRES - 1) {
				printf("cannot upsample any more!\n");
				break;
			}
			core.upsampleVolume(core.m_vis_currentLevel);
			++core.m_vis_currentLevel;
			core.calcHistogram_exemplar (core.m_vis_currentLevel);
			core.calcHistogram_synthesis(core.m_vis_currentLevel);
			core.m_vis_slicePos = KCore::TEXSIZE[core.m_vis_currentLevel];
			core.calcVolume_uchar(core.m_vis_currentLevel);
			core.m_drawer.updateTexture_volume(core.m_vis_currentLevel);
			core.m_ogl.RedrawWindow();
			break;
		case 'S':
			{
				CFileDialog dlg(FALSE, ".png", core.m_fname, OFN_OVERWRITEPROMPT, "VOL File (*.vol)|*.vol||", NULL);
				if (dlg.DoModal() == IDOK) {
					core.saveVolume_uchar(core.m_vis_currentLevel, dlg.GetFileName());
				}
				break;
			}
		case 'A':
			core.m_vis_showAxis = !core.m_vis_showAxis;
			core.m_ogl.RedrawWindow();
			break;
		case 'H':
			core.m_vis_showHelp = !core.m_vis_showHelp;
			core.m_ogl.RedrawWindow();
			break;
	}
}

void EventHandler::OnDropFiles(CView* view, HDROP hDropInfo) {
	KCore& core = *KCore::getInstance();
	if (DragQueryFile(hDropInfo, -1, NULL, 0) != 1) return;  // # of dropped files
	int len = DragQueryFile(hDropInfo, 0, NULL, 0);   // filename length of the first file
	vector<char> buf(len + 1, 0);
	DragQueryFile(hDropInfo, 0, &buf[0], len + 1);   // read the filename
	string fname(&buf[0]);
	string ext = fname.substr(fname.length() - 4, 4);   // check file type
	if (
		ext.compare(".jpg") &&
		ext.compare(".png") &&
		ext.compare(".bmp") 
	) {
		AfxMessageBox("Please drop *.{bmp|jpg|png} file!");
		return;
	}
	core.m_fname = fname.c_str();
	core.init();
	core.m_ogl.RedrawWindow();
}
