#include "StdAfx.h"
#include "KCore.h"

#include <OpenCV/cv.h>
#include <OpenCV/highgui.h>
#include <algorithm>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <KLIB/KUtil.h>
using namespace std;

const int KCore::N[MULTIRES] = {2, 3, 4};		// neighborhood size: (2 * N + 1)^2
int KCore::TEXSIZE   [MULTIRES];
int KCore::D_NEIGHBOR[MULTIRES];
int KCore::NEIGHBORSIZE[MULTIRES];

const int KCore::NUM_HISTOGRAM_BIN = 16;

const int KCore::NUM_CHANNEL = 4;
vector<double> KCore::CHANNEL_MAXVALUE;

const double KCore::WEIGHT_FEATURE = 1;
const double KCore::WEIGHT_HISTOGRAM = 10;

const double KCore::PCA_RATIO_VARIANCE = 0.99;

KCore::KCore(void) {
	srand((unsigned)time(NULL));
	// [begin] multi-res memory allocation-------------------------------------------
	m_exemplar_x               .resize(MULTIRES);
	m_exemplar_y               .resize(MULTIRES);
	m_neighbor_x               .resize(MULTIRES);
	m_neighbor_y               .resize(MULTIRES);
	mp_neighbor_pca_average_x  .resize(MULTIRES, NULL);
	mp_neighbor_pca_average_y  .resize(MULTIRES, NULL);
	mp_neighbor_pca_projected_x.resize(MULTIRES, NULL);
	mp_neighbor_pca_projected_y.resize(MULTIRES, NULL);
	mp_neighbor_pca_eigenvec_x .resize(MULTIRES, NULL);
	mp_neighbor_pca_eigenvec_y .resize(MULTIRES, NULL);
	m_neighbor_kdTree_ptr_x    .resize(MULTIRES);
	m_neighbor_kdTree_ptr_y    .resize(MULTIRES);
	mp_neighbor_kdTree_x       .resize(MULTIRES, NULL);
	mp_neighbor_kdTree_y       .resize(MULTIRES, NULL);
	m_histogram_exemplar       .resize(MULTIRES);
	m_histogram_synthesis      .resize(MULTIRES);
	m_volume                   .resize(MULTIRES);
	m_volume_uchar             .resize(MULTIRES);
	m_volume_nearest_x_index   .resize(MULTIRES);
	m_volume_nearest_y_index   .resize(MULTIRES);
	m_volume_nearest_x_dist    .resize(MULTIRES);
	m_volume_nearest_y_dist    .resize(MULTIRES);
	m_permutation_xyz          .resize(MULTIRES);
	// [end] multi-res memory allocation-------------------------------------------
	
	//m_fname = "texture_o_icon.jpg";
	m_vis_showAxis = true;
}

KCore::~KCore(void) {
	for (int level = 0; level < MULTIRES; ++level) {
		if (mp_neighbor_kdTree_x[level] != NULL) delete mp_neighbor_kdTree_x[level];
		if (mp_neighbor_kdTree_y[level] != NULL) delete mp_neighbor_kdTree_y[level];
		if (mp_neighbor_pca_average_x  [level] != NULL) cvReleaseMat(&mp_neighbor_pca_average_x [level]);
		if (mp_neighbor_pca_average_y  [level] != NULL) cvReleaseMat(&mp_neighbor_pca_average_y [level]);
		if (mp_neighbor_pca_projected_x[level] != NULL) cvReleaseMat(&mp_neighbor_pca_projected_x[level]);
		if (mp_neighbor_pca_projected_y[level] != NULL) cvReleaseMat(&mp_neighbor_pca_projected_y[level]);
		if (mp_neighbor_pca_eigenvec_x [level] != NULL) cvReleaseMat(&mp_neighbor_pca_eigenvec_x [level]);
		if (mp_neighbor_pca_eigenvec_y [level] != NULL) cvReleaseMat(&mp_neighbor_pca_eigenvec_y [level]);
	}
}

void KCore::init() {
	if (!loadExemplar(m_fname)) return;
	
	calcNeighbor();
	
	m_vis_currentLevel = 0;
	calcHistogram_exemplar(m_vis_currentLevel);
	calcHistogram_synthesis(m_vis_currentLevel);
	
	initVolume(m_vis_currentLevel);
	calcVolume_uchar(m_vis_currentLevel);
	m_drawer.updateTexture_volume(m_vis_currentLevel);
	
	m_vis_slicePos = TEXSIZE[m_vis_currentLevel];
}

bool KCore::loadExemplar(const CString& fname) {
	printf("Loading exemplar ...(fname: %s)...", (LPCSTR)fname);
	
	int dotPos = fname.Find('.');
	CString& ext = fname.Right(fname.GetLength() - dotPos);
	CString& fname2 = fname.Left(dotPos);
	
	IplImage *img_x;
	IplImage *img_y;
	IplImage *img_feature_x = NULL;
	IplImage *img_feature_y = NULL;
	
	// load for image in x-dir
	printf("loading %s as exemplar_x...\n", (LPCSTR)fname);
	img_x = cvLoadImage (fname, CV_LOAD_IMAGE_COLOR);
	if (img_x == NULL) {
		AfxMessageBox("Failed to load" + fname);
		return false;
	}
	if (img_x->width != img_x->height) {
		cvReleaseImage(&img_x);
		AfxMessageBox("The exemplar must be square");
		return false;
	}
	// Flip vertically
	cvFlip(img_x, NULL, 0);
	// Convert from BGR to RGB
	cvCvtColor(img_x, img_x, CV_BGR2RGB);
	int imgsize = img_x->width;
	m_is_given_exemplar_y = false;
	img_y = cvLoadImage (fname2 + "_y" + ext, CV_LOAD_IMAGE_COLOR);
	if (img_y != NULL) {
		printf("exemplar_y is found!\n");
		if (img_y->width != imgsize || img_y->height != imgsize) {
			cvReleaseImage(&img_y);
			printf("warning: exemplar_y is inconsistent in size. ");
			printf("assume exemplar_y is the same with exemplar_x.\n");
		} else {
			m_is_given_exemplar_y = true;
			// Flip vertically
			cvFlip(img_y, NULL, 0);
			// Convert from BGR to RGB
			cvCvtColor(img_y, img_y, CV_BGR2RGB);
		}
	}
	if (!m_is_given_exemplar_y) {
		// copy exemplar_x to exemplar_y (axis needs to be swapped)
		printf("exemplar_y is not found, so assume it as clone of exemplar_x.\n");
		img_y = cvCloneImage(img_x);
		for (int v = 0; v < imgsize; ++v) {
			for (int u = 0; u < imgsize; ++u) {
				int index  = 3 * (imgsize * v + u);
				int index2 = 3 * (imgsize * u + v);
				for (int ch = 0; ch < 3; ++ch) {
					img_y->imageData[index + ch] = img_x->imageData[index2 + ch];
				}
			}
		}
	}
	
	// build image pyramid
	int img_depth     = img_x->depth;
	int img_nChannels = img_x->nChannels;
	for (int level = MULTIRES - 1; level >= 0; --level) {
		// size registration
		TEXSIZE[level] = img_x->width;
		NEIGHBORSIZE[level] = (2 * N[level] + 1) * (2 * N[level] + 1);
		D_NEIGHBOR[level] = NUM_CHANNEL * NEIGHBORSIZE[level];
		
		// [begin] memory allocation -------------------------------------------
		m_exemplar_x            [level].resize(NUM_CHANNEL * TEXSIZE[level] * TEXSIZE[level]);
		m_exemplar_y            [level].resize(NUM_CHANNEL * TEXSIZE[level] * TEXSIZE[level]);
		m_neighbor_x            [level].resize(D_NEIGHBOR[level] * (TEXSIZE[level] - 2 * N[level]) * (TEXSIZE[level] - 2 * N[level]));
		m_neighbor_y            [level].resize(D_NEIGHBOR[level] * (TEXSIZE[level] - 2 * N[level]) * (TEXSIZE[level] - 2 * N[level]));
		m_volume                [level].resize(NUM_CHANNEL * TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_volume_uchar          [level].resize(3           * TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_volume_nearest_x_index[level].resize(2 * TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);		// the top 2 nearest is stored
		m_volume_nearest_y_index[level].resize(2 * TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_volume_nearest_x_dist [level].resize(2 * TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_volume_nearest_y_dist [level].resize(2 * TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_permutation_xyz       [level].resize(TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		// [end] memory allocation -------------------------------------------
		
		for (int v = 0; v < TEXSIZE[level]; ++v) {
			for (int u = 0; u < TEXSIZE[level]; ++u) {
				int index  = NUM_CHANNEL * (TEXSIZE[level] * v + u);
				int index2 = 3           * (TEXSIZE[level] * v + u);
				for (int ch = 0; ch < 3; ++ch) {
					m_exemplar_x[level][index + ch] = (unsigned char)img_x->imageData[index2 + ch];
					m_exemplar_y[level][index + ch] = (unsigned char)img_y->imageData[index2 + ch];
				}
				if (NUM_CHANNEL == 4) {
					// depth map channel
					double depth_x = 256. * v / TEXSIZE[level];
					double depth_y = 256. * u / TEXSIZE[level];
					m_exemplar_x[level][index + 3] = WEIGHT_FEATURE * depth_x;
					m_exemplar_y[level][index + 3] = WEIGHT_FEATURE * depth_y;
				}
			}
		}
		
		// go to the coarser level
		IplImage *img_next_x = cvCreateImage(cvSize(TEXSIZE[level] / 2, TEXSIZE[level] / 2), img_depth, img_nChannels);
		IplImage *img_next_y = cvCreateImage(cvSize(TEXSIZE[level] / 2, TEXSIZE[level] / 2), img_depth, img_nChannels);
		cvResize (img_x, img_next_x, CV_INTER_LINEAR);		// CV_INTER_CUBIC
		cvResize (img_y, img_next_y, CV_INTER_LINEAR);
		cvReleaseImage (&img_x);
		cvReleaseImage (&img_y);
		img_x = img_next_x;
		img_y = img_next_y;
	}
	cvReleaseImage (&img_x);
	cvReleaseImage (&img_y);
	CHANNEL_MAXVALUE.resize(NUM_CHANNEL);
	for (int ch = 0; ch < 3; ++ch) {
		CHANNEL_MAXVALUE[ch] = 256;
	}
	if (NUM_CHANNEL == 4) {
		CHANNEL_MAXVALUE[3] = 256 * WEIGHT_FEATURE;
	}
	printf("done!\n");
	return true;
}

void KCore::calcNeighbor() {
	printf("calcNeighbor...\n");
	for (int level = 0; level < MULTIRES; ++level) {
		printf("level:%d\n", level);
		int numData = (TEXSIZE[level] - 2 * N[level]) * (TEXSIZE[level] - 2 * N[level]);
		CvMat* p_source_x  = cvCreateMat(numData, D_NEIGHBOR[level], CV_64F);
		CvMat* p_source_y  = cvCreateMat(numData, D_NEIGHBOR[level], CV_64F);
		int row = 0;
		for (int v = N[level]; v < TEXSIZE[level] - N[level]; ++v) {
			for (int u = N[level]; u < TEXSIZE[level] - N[level]; ++u) {
				int col = 0;
				for (int dv = -N[level]; dv <= N[level]; ++dv) {
					for (int du = -N[level]; du <= N[level]; ++du) {
						int index = NUM_CHANNEL * (TEXSIZE[level] * (v + dv) + u + du);
						for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
							cvmSet(p_source_x, row, col, m_exemplar_x[level][index + ch]);
							cvmSet(p_source_y, row, col, m_exemplar_y[level][index + ch]);
							m_neighbor_x[level][D_NEIGHBOR[level] * row + col] = m_exemplar_x[level][index + ch];
							m_neighbor_y[level][D_NEIGHBOR[level] * row + col] = m_exemplar_y[level][index + ch];
							++col;
						}
					}
				}
				++row;
			}
		}
		// PCA calculation (obtain all eigenvectors of the input covariance matrix)
		if (mp_neighbor_pca_average_x[level] != NULL) cvReleaseMat(&mp_neighbor_pca_average_x[level]);
		if (mp_neighbor_pca_average_y[level] != NULL) cvReleaseMat(&mp_neighbor_pca_average_y[level]);
		mp_neighbor_pca_average_x[level] = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		mp_neighbor_pca_average_y[level] = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		CvMat* p_eigenValues_x = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		CvMat* p_eigenValues_y = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		CvMat* p_eigenVectors_all_x = cvCreateMat(D_NEIGHBOR[level], D_NEIGHBOR[level], CV_64F);
		CvMat* p_eigenVectors_all_y = cvCreateMat(D_NEIGHBOR[level], D_NEIGHBOR[level], CV_64F);
		cvCalcPCA(p_source_x, mp_neighbor_pca_average_x[level], p_eigenValues_x, p_eigenVectors_all_x, CV_PCA_DATA_AS_ROW);
		cvCalcPCA(p_source_y, mp_neighbor_pca_average_y[level], p_eigenValues_y, p_eigenVectors_all_y, CV_PCA_DATA_AS_ROW);
		// Decide amount of dimensionality reduction
		double contribution_total_x = 0;
		double contribution_total_y = 0;
		for (int i = 0; i < D_NEIGHBOR[level]; ++i) {
			contribution_total_x += cvmGet(p_eigenValues_x, 0, i);
			contribution_total_y += cvmGet(p_eigenValues_y, 0, i);
		}
		int dimPCA_x = 0;
		int dimPCA_y = 0;
		double contribution_acc_x = 0;
		double contribution_acc_y = 0;
		for (int i = 0; i < D_NEIGHBOR[level]; ++i) {
			double ratio_x = contribution_acc_x / contribution_total_x;
			double ratio_y = contribution_acc_y / contribution_total_y;
			if (ratio_x < PCA_RATIO_VARIANCE) {
				contribution_acc_x += cvmGet(p_eigenValues_x, 0, i);
				++dimPCA_x;
			}
			if (ratio_y < PCA_RATIO_VARIANCE) {
				contribution_acc_y += cvmGet(p_eigenValues_y, 0, i);
				++dimPCA_y;
			}
			if (PCA_RATIO_VARIANCE <= ratio_x && PCA_RATIO_VARIANCE <= ratio_y) break;
		}
		printf("PCA reduction (x): %d -> %d\n", D_NEIGHBOR[level], dimPCA_x);
		printf("PCA reduction (y): %d -> %d\n", D_NEIGHBOR[level], dimPCA_y);
		// Trim total eigenvectors into partial eigenvectors
		if (mp_neighbor_pca_eigenvec_x[level] != NULL) cvReleaseMat(&mp_neighbor_pca_eigenvec_x[level]);
		if (mp_neighbor_pca_eigenvec_y[level] != NULL) cvReleaseMat(&mp_neighbor_pca_eigenvec_y[level]);
		mp_neighbor_pca_eigenvec_x[level] = cvCreateMat(dimPCA_x, D_NEIGHBOR[level], CV_64F);
		mp_neighbor_pca_eigenvec_y[level] = cvCreateMat(dimPCA_y, D_NEIGHBOR[level], CV_64F);
		memcpy(mp_neighbor_pca_eigenvec_x[level]->data.db, p_eigenVectors_all_x->data.db, sizeof(double) * dimPCA_x * D_NEIGHBOR[level]);
		memcpy(mp_neighbor_pca_eigenvec_y[level]->data.db, p_eigenVectors_all_y->data.db, sizeof(double) * dimPCA_y * D_NEIGHBOR[level]);
		// PCA projection
		if (mp_neighbor_pca_projected_x[level] != NULL) cvReleaseMat(&mp_neighbor_pca_projected_x[level]);
		if (mp_neighbor_pca_projected_y[level] != NULL) cvReleaseMat(&mp_neighbor_pca_projected_y[level]);
		mp_neighbor_pca_projected_x[level] = cvCreateMat(numData, dimPCA_x, CV_64F);
		mp_neighbor_pca_projected_y[level] = cvCreateMat(numData, dimPCA_y, CV_64F);
		cvProjectPCA(p_source_x, mp_neighbor_pca_average_x[level], mp_neighbor_pca_eigenvec_x[level], mp_neighbor_pca_projected_x[level]);
		cvProjectPCA(p_source_y, mp_neighbor_pca_average_y[level], mp_neighbor_pca_eigenvec_y[level], mp_neighbor_pca_projected_y[level]);
		// kd-tree contruction
		m_neighbor_kdTree_ptr_x[level].resize(numData);
		m_neighbor_kdTree_ptr_y[level].resize(numData);
		for (int i = 0; i < numData; ++i) {
			m_neighbor_kdTree_ptr_x[level][i] = &mp_neighbor_pca_projected_x[level]->data.db[dimPCA_x * i];
			m_neighbor_kdTree_ptr_y[level][i] = &mp_neighbor_pca_projected_y[level]->data.db[dimPCA_y * i];
		}
		if (mp_neighbor_kdTree_x[level] != NULL) delete mp_neighbor_kdTree_x[level];
		if (mp_neighbor_kdTree_y[level] != NULL) delete mp_neighbor_kdTree_y[level];
		mp_neighbor_kdTree_x[level] = new ANNkd_tree(&m_neighbor_kdTree_ptr_x[level][0], numData, dimPCA_x);
		mp_neighbor_kdTree_y[level] = new ANNkd_tree(&m_neighbor_kdTree_ptr_y[level][0], numData, dimPCA_y);
		// release CV matrices
		cvReleaseMat(&p_source_x);
		cvReleaseMat(&p_source_y);
		cvReleaseMat(&p_eigenValues_x);
		cvReleaseMat(&p_eigenValues_y);
		cvReleaseMat(&p_eigenVectors_all_x);
		cvReleaseMat(&p_eigenVectors_all_y);
	}
}

void KCore::calcHistogram_synthesis(int level) {
	m_histogram_synthesis[level].clear();
	m_histogram_synthesis[level].resize(NUM_CHANNEL, vector<double>(NUM_HISTOGRAM_BIN, 0));
	double delta_histogram = 1. / (TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
	for (int i = 0; i < TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]; ++i) {
		for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
			double c = m_volume[level][NUM_CHANNEL * i + ch];
			int bin  = (int)(c * NUM_HISTOGRAM_BIN / CHANNEL_MAXVALUE[ch]);
			m_histogram_synthesis[level][ch][bin] += delta_histogram;
		}
	}
}
void KCore::updateHistogram_synthesis(int level, const std::vector<double>& color_old, const std::vector<double>& color_new) {
	double delta_histogram = 1. / (TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
	for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
		int bin_old = (int)(color_old[ch] * NUM_HISTOGRAM_BIN / CHANNEL_MAXVALUE[ch]);
		int bin_new = (int)(color_new[ch] * NUM_HISTOGRAM_BIN / CHANNEL_MAXVALUE[ch]);
		m_histogram_synthesis[level][ch][bin_old] -= delta_histogram;
		m_histogram_synthesis[level][ch][bin_new] += delta_histogram;
	}
}
void KCore::calcHistogram_exemplar (int level) {
	m_histogram_exemplar[level].clear();
	m_histogram_exemplar[level].resize(NUM_CHANNEL, vector<double>(NUM_HISTOGRAM_BIN, 0));
	double delta_histogram = 1. / (2 * TEXSIZE[level] * TEXSIZE[level]);
	vector<double>* p[2] = { &m_exemplar_x[level], &m_exemplar_y[level] };
	for (int ori = 0; ori < 2; ++ori) {
		for (int i = 0; i < TEXSIZE[level] * TEXSIZE[level]; ++i) {
			for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
				double c = (*p[ori])[NUM_CHANNEL * i + ch];
				int bin  = (int)(c * NUM_HISTOGRAM_BIN / CHANNEL_MAXVALUE[ch]);
				m_histogram_exemplar[level][ch][bin] += delta_histogram;
			}
		}
	}
}

void KCore::initVolume(int level) {
	vector<double>* p[2] = { &m_exemplar_x[level], &m_exemplar_y[level] };
	for (int z = 0; z < TEXSIZE[level]; ++z) {
		for (int xy = 0; xy < TEXSIZE[level] * TEXSIZE[level]; ++xy) {
			int index  = NUM_CHANNEL * (xy + TEXSIZE[level] * TEXSIZE[level] * z);
			int index2[2];
			index2[0] = NUM_CHANNEL * (TEXSIZE[level] * z + rand() % TEXSIZE[level]);
			index2[1] = NUM_CHANNEL * (TEXSIZE[level] * (rand() % TEXSIZE[level]) + z);
			int ori = rand() % 2;
			for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
				m_volume[level][index + ch] = (*p[ori])[index2[ori] + ch];
			}
		}
	}
}

void KCore::searchVolume(int level) {
	long time_start = clock();
	const double min_dist = 0.00000000001;
	printf("phase1:searching");
	vector<int> nearest_x_index_old = m_volume_nearest_x_index[level];
	vector<int> nearest_y_index_old = m_volume_nearest_y_index[level];
	double global_energy_new = 0;
	int cnt_nearest_index_new = 0;
	int cnt_collision_occurred = 0;
	int cnt_collision_total = 0;
	for (int i = 0; i < TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]; ++i) {
		if (i % (TEXSIZE[level] * TEXSIZE[level]) == 0) printf(".");
		int x =  i %  TEXSIZE[level];
		int y = (i /  TEXSIZE[level]) % TEXSIZE[level];
		int z =  i / (TEXSIZE[level]  * TEXSIZE[level]);
		if (z < N[level] || TEXSIZE[level] - N[level] <= z) {
			m_volume_nearest_x_index[level][i] = -1;
			m_volume_nearest_y_index[level][i] = -1;
			m_volume_nearest_x_dist [level][i] = DBL_MAX;
			m_volume_nearest_y_dist [level][i] = DBL_MAX;
			continue;
		}
		
		// obtain current neighborhood from volume
		CvMat* current_neighbor_x = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		CvMat* current_neighbor_y = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		int index = 0;
		for (int dv = -N[level]; dv <= N[level]; ++dv) {
			for (int du = -N[level]; du <= N[level]; ++du) {
				int index2_x = NUM_CHANNEL * (TEXSIZE[level] * TEXSIZE[level] * (z + dv) + TEXSIZE[level] * trimIndex(level, y + du) + x);
				int index2_y = NUM_CHANNEL * (TEXSIZE[level] * TEXSIZE[level] * (z + du) + TEXSIZE[level] * y + trimIndex(level, x + dv));
				for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
					cvmSet(current_neighbor_x, 0, index + ch, m_volume[level][index2_x + ch]);
					cvmSet(current_neighbor_y, 0, index + ch, m_volume[level][index2_y + ch]);
				}
				index += NUM_CHANNEL;
			}
		}
		// PCA projection
		int dimPCA_x = mp_neighbor_pca_eigenvec_x[level]->rows;
		int dimPCA_y = mp_neighbor_pca_eigenvec_y[level]->rows;
		CvMat* current_neighbor_x_projected = cvCreateMat(1, dimPCA_x, CV_64F);
		CvMat* current_neighbor_y_projected = cvCreateMat(1, dimPCA_y, CV_64F);
		cvProjectPCA(current_neighbor_x, mp_neighbor_pca_average_x[level], mp_neighbor_pca_eigenvec_x[level], current_neighbor_x_projected);
		cvProjectPCA(current_neighbor_y, mp_neighbor_pca_average_y[level], mp_neighbor_pca_eigenvec_y[level], current_neighbor_y_projected);
		// ANN search!
		int N_CANDIDATES = 2 * N[level];
		vector<int>    ann_index_x(N_CANDIDATES);
		vector<int>    ann_index_y(N_CANDIDATES);
		vector<double> ann_dist_x (N_CANDIDATES);
		vector<double> ann_dist_y (N_CANDIDATES);
		mp_neighbor_kdTree_x[level]->annkSearch(current_neighbor_x_projected->data.db, N_CANDIDATES, &ann_index_x[0], &ann_dist_x[0]);
		mp_neighbor_kdTree_y[level]->annkSearch(current_neighbor_y_projected->data.db, N_CANDIDATES, &ann_index_y[0], &ann_dist_y[0]);
		// CV release
		cvReleaseMat(&current_neighbor_x);
		cvReleaseMat(&current_neighbor_y);
		cvReleaseMat(&current_neighbor_x_projected);
		cvReleaseMat(&current_neighbor_y_projected);
		
		int    nearest_index_x;
		int    nearest_index_y;
		double nearest_dist_x;
		double nearest_dist_y;
		if (m_is_given_exemplar_y) {
		//if (true) {
			nearest_index_x = ann_index_x[0];
			nearest_index_y = ann_index_y[0];
			nearest_dist_x  = ann_dist_x [0];
			nearest_dist_y  = ann_dist_y [0];
		} else {
			int find_x = 0;
			int find_y = 0;
			while (find_x < N_CANDIDATES && find_y < N_CANDIDATES) {
				int N_SAMPLES_WIDTH = KCore::TEXSIZE[level] - 2 * KCore::N[level];
				int u_x = ann_index_x[find_x] % N_SAMPLES_WIDTH;
				int v_x = ann_index_x[find_x] / N_SAMPLES_WIDTH;
				int u_y = ann_index_y[find_y] % N_SAMPLES_WIDTH;
				int v_y = ann_index_y[find_y] / N_SAMPLES_WIDTH;
				if (abs(u_x - v_y) > N[level] || abs(v_x - u_y) > N[level]) break;
				// collision occerred!
				if (ann_dist_x[find_x] < ann_dist_y[find_y]) {
					++find_y;
				} else {
					++find_x;
				}
			}
			if (find_x > 0 || find_y > 0) ++cnt_collision_occurred;
			if (find_x == N_CANDIDATES) find_x = rand() % (N_CANDIDATES - 1) + 1;
			if (find_y == N_CANDIDATES) find_y = rand() % (N_CANDIDATES - 1) + 1;
			nearest_index_x = ann_index_x[find_x];
			nearest_index_y = ann_index_y[find_y];
			nearest_dist_x  = ann_dist_x [find_x];
			nearest_dist_y  = ann_dist_y [find_y];
		}
		//if (!m_is_given_exemplar_y && abs(u_x - v_y) <= N[level] && abs(v_x - u_y) <= N[level]) {	// collision occerred!
		//	if (ann_dist_x[0] < ann_dist_y[0]) {
		//		nearest_index_x = ann_index_x[0];
		//		nearest_index_y = ann_index_y[1];
		//		nearest_dist_x  = ann_dist_x [0];
		//		nearest_dist_y  = ann_dist_y [1];
		//	} else {
		//		nearest_index_x = ann_index_x[1];
		//		nearest_index_y = ann_index_y[0];
		//		nearest_dist_x  = ann_dist_x [1];
		//		nearest_dist_y  = ann_dist_y [0];
		//	}
		//	++cnt_collision_occurred;
		//} else {
		//	nearest_index_x = ann_index_x[0];
		//	nearest_index_y = ann_index_y[0];
		//	nearest_dist_x  = ann_dist_x [0];
		//	nearest_dist_y  = ann_dist_y [0];
		//}
		++cnt_collision_total;
		m_volume_nearest_x_index[level][i] = nearest_index_x;
		m_volume_nearest_y_index[level][i] = nearest_index_y;
		m_volume_nearest_x_dist [level][i] = nearest_dist_x + min_dist;
		m_volume_nearest_y_dist [level][i] = nearest_dist_y + min_dist;
		if (m_volume_nearest_x_index[level][i] != nearest_x_index_old[i]) ++cnt_nearest_index_new;
		if (m_volume_nearest_y_index[level][i] != nearest_y_index_old[i]) ++cnt_nearest_index_new;
		global_energy_new += m_volume_nearest_x_dist[level][i];
		global_energy_new += m_volume_nearest_y_dist[level][i];
	}
	printf("collsion : %d / %d\n", cnt_collision_occurred, cnt_collision_total);
	long time_end = clock();
	printf("done. clocks = %ld\n", (time_end - time_start));
	printf("updated NN:%d, global energy:%f\n", cnt_nearest_index_new, global_energy_new);
}

void KCore::initPermutation(int level) {
	for (int i = 0; i < TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]; ++i) {
		m_permutation_xyz[level][i] = i;
	}
	random_shuffle(m_permutation_xyz[level].begin(), m_permutation_xyz[level].end());
}

void KCore::optimizeVolume(int level) {
	long time_start = clock();
	initPermutation(level);
	printf("phase2:optimizing");
	for (int i2 = 0; i2 < TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]; ++i2) {
		int i = m_permutation_xyz[level][i2];
		int x = i % TEXSIZE[level];
		int y = (i / TEXSIZE[level]) % TEXSIZE[level];
		int z = i / (TEXSIZE[level] * TEXSIZE[level]);
		double weight_acc = 0;
		vector<double> color_acc(NUM_CHANNEL, 0);
		if (i2 % (TEXSIZE[level] * TEXSIZE[level]) == 0) printf(".");
		int m = 0;
		for (int dv = -N[level]; dv <= N[level]; ++dv) {
			for (int du = -N[level]; du <= N[level]; ++du) {
				int index2_x = TEXSIZE[level] * TEXSIZE[level] * (z + dv) + TEXSIZE[level] * trimIndex(level, y + du) + x;
				int index2_y = TEXSIZE[level] * TEXSIZE[level] * (z + du) + TEXSIZE[level] * y + trimIndex(level, x + dv);
				int index2[2] = { index2_x, index2_y };
				vector<int>   * volume_nearest_index[2] = { &m_volume_nearest_x_index[level], &m_volume_nearest_y_index[level] };
				vector<double>* volume_nearest_dist [2] = { &m_volume_nearest_x_dist [level], &m_volume_nearest_y_dist [level] };
				vector<double>* neighbor[2] = { &m_neighbor_x[level], &m_neighbor_y[level] };
				for (int ori = 0; ori < 2; ++ori) {
					if (ori == 0 && (z + dv < N[level] || TEXSIZE[level] - N[level] <= z + dv)) continue;
					if (ori == 1 && (z + du < N[level] || TEXSIZE[level] - N[level] <= z + du)) continue;
					int    nearest_index = (*volume_nearest_index[ori])[index2[ori]];
					double nearest_dist  = (*volume_nearest_dist [ori])[index2[ori]];
					assert(nearest_index != -1);
					double* p_neighbor = &(*neighbor[ori])[D_NEIGHBOR[level] * nearest_index];
					// color of overlapping neighborhood pixel
					vector<double> color(NUM_CHANNEL);
					for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
						color[ch] = p_neighbor[NUM_CHANNEL * (NEIGHBORSIZE[level] - 1 - m) + ch];
					}
					// blending weight of this color according to matching distance
					double weight = pow(nearest_dist, -0.6);
					// modify weight according to histogram matching
					double histogram_matching = 0;
					for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
						int bin = (int)(color[ch] * NUM_HISTOGRAM_BIN / CHANNEL_MAXVALUE[ch]);
						double histogram_exemplar  = m_histogram_exemplar [level][ch][bin];
						double histogram_synthesis = m_histogram_synthesis[level][ch][bin];
						histogram_matching += max(0, histogram_synthesis - histogram_exemplar);
					}
					weight *= 1 / (1 + WEIGHT_HISTOGRAM * histogram_matching);
					// accumulate color
					for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
						color_acc[ch] += weight * color[ch];
					}
					weight_acc += weight;
				}
				++m;
			}
		}
		// old & new colors for this voxel
		vector<double> color_old(NUM_CHANNEL);
		vector<double> color_new(NUM_CHANNEL);
		for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
			color_old[ch] = m_volume[level][NUM_CHANNEL * i + ch];
			color_new[ch] = color_acc[ch] / weight_acc;
		}
		// histogram update
		updateHistogram_synthesis(level, color_old, color_new);
		// voxel update
		for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
			m_volume[level][NUM_CHANNEL * i + ch] = color_new[ch];
		}
	}
	long time_end = clock();
	printf("done. clocks = %ld\n", (time_end - time_start));
}

void KCore::upsampleVolume(int level) {
	printf("upsample from level %d to level %d\n", level, level + 1);
	static const bool flag[8][8] = {
		{true , false, false, false, false, false, false, false},
		{true , true , false, false, false, false, false, false}, 
		{true , false, true , false, false, false, false, false},
		{true , true , true , true , false, false, false, false},
		{true , false, false, false, true , false, false, false},
		{true , true , false, false, true , true , false, false},
		{true , false, true , false, true , false, true , false},
		{true , true , true , true , true , true , true , true }};
	for (int z = 0; z < TEXSIZE[level]; ++z) {
		for (int y = 0; y < TEXSIZE[level]; ++y) {
			for (int x = 0; x < TEXSIZE[level]; ++x) {
				int index[8];
				for (int dz = 0; dz < 2; ++dz) {
					for (int dy = 0; dy < 2; ++dy) {
						for (int dx = 0; dx < 2; ++dx) {
							index[4 * dz + 2 * dy + dx] = NUM_CHANNEL * (
								TEXSIZE[level] * TEXSIZE[level] * min(z + dz, TEXSIZE[level] - 1) + 
								TEXSIZE[level] * trimIndex(level, y + dy) +
								trimIndex(level, x + dx));
						}
					}
				}
				for (int dz = 0; dz < 2; ++dz) {
					for (int dy = 0; dy < 2; ++dy) {
						for (int dx = 0; dx < 2; ++dx) {
							int index2 = NUM_CHANNEL * (TEXSIZE[level + 1] * TEXSIZE[level + 1] * (2 * z + dz) + TEXSIZE[level + 1] * (2 * y + dy) + 2 * x + dx);
							vector<double> color(NUM_CHANNEL, 0);
							int cnt = 0;
							for (int i = 0; i < 8; ++i) {
								if (flag[4 * dz + 2 * dy + dx][i]) {
									for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
										color[ch] += m_volume[level][index[i] + ch];
									}
									++cnt;
								}
							}
							for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
								color[ch] /= cnt;
								m_volume[level + 1][index2 + ch] = color[ch];
							}
						}
					}
				}
			}
		}
	}
}

void KCore::calcVolume_uchar(int level) {
	for (int i = 0; i < TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]; ++i) {
		m_volume_uchar[level][3 * i    ] = (GLubyte)max(min(255, m_volume[level][NUM_CHANNEL * i    ]), 0);
		m_volume_uchar[level][3 * i + 1] = (GLubyte)max(min(255, m_volume[level][NUM_CHANNEL * i + 1]), 0);
		m_volume_uchar[level][3 * i + 2] = (GLubyte)max(min(255, m_volume[level][NUM_CHANNEL * i + 2]), 0);
	}
}

void KCore::saveVolume_uchar(int level, const CString& fname) {
	struct VolumeHeader
	{
		char magic[4];
		int version;
		char texName[256];
		bool wrap;
		int volSize;
		int numChannels;
		int bytesPerChannel;
	};
	FILE * fout = fopen(fname, "wb");
	char buf[4096];
	VolumeHeader* header = (VolumeHeader *)buf;
	header->magic[0] = 'V';
	header->magic[1] = 'O';
	header->magic[2] = 'L';
	header->magic[3] = 'U';
	header->bytesPerChannel = 1;
	header->version = 4;
	header->volSize = TEXSIZE[level];
	header->numChannels = 3;
	sprintf(header->texName, "Created by LayeredSolidSynthesis");
	fwrite(buf, 1, 4096, fout);
	int volBytes = TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level] * 3;
	fwrite(&m_volume_uchar[level][0], 1, volBytes, fout);
	fclose(fout);
}

