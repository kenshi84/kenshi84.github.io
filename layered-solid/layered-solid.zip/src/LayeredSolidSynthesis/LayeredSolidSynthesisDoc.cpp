// LayeredSolidSynthesisDoc.cpp : implementation of the CLayeredSolidSynthesisDoc class
//

#include "stdafx.h"
#include "LayeredSolidSynthesis.h"

#include "LayeredSolidSynthesisDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CLayeredSolidSynthesisDoc

IMPLEMENT_DYNCREATE(CLayeredSolidSynthesisDoc, CDocument)

BEGIN_MESSAGE_MAP(CLayeredSolidSynthesisDoc, CDocument)
END_MESSAGE_MAP()


// CLayeredSolidSynthesisDoc construction/destruction

CLayeredSolidSynthesisDoc::CLayeredSolidSynthesisDoc()
{
	// TODO: add one-time construction code here

}

CLayeredSolidSynthesisDoc::~CLayeredSolidSynthesisDoc()
{
}

BOOL CLayeredSolidSynthesisDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CLayeredSolidSynthesisDoc serialization

void CLayeredSolidSynthesisDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CLayeredSolidSynthesisDoc diagnostics

#ifdef _DEBUG
void CLayeredSolidSynthesisDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CLayeredSolidSynthesisDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CLayeredSolidSynthesisDoc commands
