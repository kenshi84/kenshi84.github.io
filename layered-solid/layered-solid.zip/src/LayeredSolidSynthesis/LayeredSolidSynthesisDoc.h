// LayeredSolidSynthesisDoc.h : interface of the CLayeredSolidSynthesisDoc class
//


#pragma once


class CLayeredSolidSynthesisDoc : public CDocument
{
protected: // create from serialization only
	CLayeredSolidSynthesisDoc();
	DECLARE_DYNCREATE(CLayeredSolidSynthesisDoc)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CLayeredSolidSynthesisDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};


