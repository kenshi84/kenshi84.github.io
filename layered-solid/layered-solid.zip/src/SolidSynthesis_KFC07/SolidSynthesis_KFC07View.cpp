// SolidSynthesis_KFC07View.cpp : implementation of the CSolidSynthesis_KFC07View class
//

#include "stdafx.h"
#include "SolidSynthesis_KFC07.h"

#include "SolidSynthesis_KFC07Doc.h"
#include "SolidSynthesis_KFC07View.h"

#include "KCore.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CSolidSynthesis_KFC07View

IMPLEMENT_DYNCREATE(CSolidSynthesis_KFC07View, CView)

BEGIN_MESSAGE_MAP(CSolidSynthesis_KFC07View, CView)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_KEYDOWN()
	ON_WM_DROPFILES()
END_MESSAGE_MAP()

// CSolidSynthesis_KFC07View construction/destruction

CSolidSynthesis_KFC07View::CSolidSynthesis_KFC07View()
{
	// TODO: add construction code here

}

CSolidSynthesis_KFC07View::~CSolidSynthesis_KFC07View()
{
}

BOOL CSolidSynthesis_KFC07View::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.dwExStyle |= WS_EX_ACCEPTFILES;

	return CView::PreCreateWindow(cs);
}

// CSolidSynthesis_KFC07View drawing

void CSolidSynthesis_KFC07View::OnDraw(CDC* /*pDC*/)
{
	CSolidSynthesis_KFC07Doc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	KCore& core = *KCore::getInstance();
	core.m_ogl.OnDraw_Begin();
	core.m_drawer.draw(this);
	core.m_ogl.OnDraw_End();
}


// CSolidSynthesis_KFC07View diagnostics

#ifdef _DEBUG
void CSolidSynthesis_KFC07View::AssertValid() const
{
	CView::AssertValid();
}

void CSolidSynthesis_KFC07View::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CSolidSynthesis_KFC07Doc* CSolidSynthesis_KFC07View::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CSolidSynthesis_KFC07Doc)));
	return (CSolidSynthesis_KFC07Doc*)m_pDocument;
}
#endif //_DEBUG


// CSolidSynthesis_KFC07View message handlers

int CSolidSynthesis_KFC07View::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	KCore& core = *KCore::getInstance();
	core.m_ogl.OnCreate(this);
	core.m_drawer.init(this);
	//core.init();

	return 0;
}

void CSolidSynthesis_KFC07View::OnDestroy()
{
	CView::OnDestroy();

	KCore::getInstance()->m_ogl.OnDestroy();
}

BOOL CSolidSynthesis_KFC07View::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;//CView::OnEraseBkgnd(pDC);
}

void CSolidSynthesis_KFC07View::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	KCore::getInstance()->m_ogl.OnSize(cx, cy);
}

void CSolidSynthesis_KFC07View::OnRButtonDown(UINT nFlags, CPoint point)
{
	KCore::getInstance()->m_handler.OnRButtonDown(this, nFlags, point);

	CView::OnRButtonDown(nFlags, point);
}

void CSolidSynthesis_KFC07View::OnRButtonUp(UINT nFlags, CPoint point)
{
	KCore::getInstance()->m_handler.OnRButtonUp(this, nFlags, point);

	CView::OnRButtonUp(nFlags, point);
}

void CSolidSynthesis_KFC07View::OnMouseMove(UINT nFlags, CPoint point)
{
	KCore::getInstance()->m_handler.OnMouseMove(this, nFlags, point);

	CView::OnMouseMove(nFlags, point);
}

void CSolidSynthesis_KFC07View::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	KCore::getInstance()->m_handler.OnKeyDown(this, nChar, nRepCnt, nFlags);

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CSolidSynthesis_KFC07View::OnDropFiles(HDROP hDropInfo) {
	KCore::getInstance()->m_handler.OnDropFiles(this, hDropInfo);

	CView::OnDropFiles(hDropInfo);
}
