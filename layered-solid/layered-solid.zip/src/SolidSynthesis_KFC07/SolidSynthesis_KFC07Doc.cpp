// SolidSynthesis_KFC07Doc.cpp : implementation of the CSolidSynthesis_KFC07Doc class
//

#include "stdafx.h"
#include "SolidSynthesis_KFC07.h"

#include "SolidSynthesis_KFC07Doc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CSolidSynthesis_KFC07Doc

IMPLEMENT_DYNCREATE(CSolidSynthesis_KFC07Doc, CDocument)

BEGIN_MESSAGE_MAP(CSolidSynthesis_KFC07Doc, CDocument)
END_MESSAGE_MAP()


// CSolidSynthesis_KFC07Doc construction/destruction

CSolidSynthesis_KFC07Doc::CSolidSynthesis_KFC07Doc()
{
	// TODO: add one-time construction code here

}

CSolidSynthesis_KFC07Doc::~CSolidSynthesis_KFC07Doc()
{
}

BOOL CSolidSynthesis_KFC07Doc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}




// CSolidSynthesis_KFC07Doc serialization

void CSolidSynthesis_KFC07Doc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}


// CSolidSynthesis_KFC07Doc diagnostics

#ifdef _DEBUG
void CSolidSynthesis_KFC07Doc::AssertValid() const
{
	CDocument::AssertValid();
}

void CSolidSynthesis_KFC07Doc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CSolidSynthesis_KFC07Doc commands
