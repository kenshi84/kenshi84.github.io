// SolidSynthesis_KFC07.h : main header file for the SolidSynthesis_KFC07 application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CSolidSynthesis_KFC07App:
// See SolidSynthesis_KFC07.cpp for the implementation of this class
//

class CSolidSynthesis_KFC07App : public CWinApp
{
public:
	CSolidSynthesis_KFC07App();


// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CSolidSynthesis_KFC07App theApp;