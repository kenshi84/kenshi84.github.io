// SolidSynthesis_KFC07View.h : interface of the CSolidSynthesis_KFC07View class
//


#pragma once


class CSolidSynthesis_KFC07View : public CView
{
protected: // create from serialization only
	CSolidSynthesis_KFC07View();
	DECLARE_DYNCREATE(CSolidSynthesis_KFC07View)

// Attributes
public:
	CSolidSynthesis_KFC07Doc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// Implementation
public:
	virtual ~CSolidSynthesis_KFC07View();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
public:
	afx_msg void OnDestroy();
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
public:
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
public:
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
public:
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
public:
	afx_msg void OnDropFiles(HDROP hDropInfo);
};

#ifndef _DEBUG  // debug version in SolidSynthesis_KFC07View.cpp
inline CSolidSynthesis_KFC07Doc* CSolidSynthesis_KFC07View::GetDocument() const
   { return reinterpret_cast<CSolidSynthesis_KFC07Doc*>(m_pDocument); }
#endif

