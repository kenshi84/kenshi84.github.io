#include "StdAfx.h"
#include "EventHandler.h"
#include "KCore.h"
#include <vector>
using namespace std;

EventHandler::EventHandler(void) {
}

EventHandler::~EventHandler(void) {
}

void EventHandler::OnRButtonDown(CView* view, UINT nFlags, CPoint point) {
	if ((nFlags & MK_SHIFT) != 0) {
		KCore::getInstance()->m_ogl.ButtonDownForZoom(point);
	} else if ((nFlags & MK_CONTROL) != 0) {
		KCore::getInstance()->m_ogl.ButtonDownForTranslate(point);
	} else {
		KCore::getInstance()->m_ogl.ButtonDownForRotate(point);
	}
}
void EventHandler::OnRButtonUp(CView* view, UINT nFlags, CPoint point) {
	KCore::getInstance()->m_ogl.ButtonUp();
}
void EventHandler::OnMouseMove(CView* view, UINT nFlags, CPoint point) {
	KCore::getInstance()->m_ogl.MouseMove(point);
}
void EventHandler::OnKeyDown(CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {
	KCore& core = *KCore::getInstance();
	switch (nChar) {
		case VK_DOWN:
			if (1 < core.m_vis_slicePos) {
				--core.m_vis_slicePos;
				core.m_ogl.RedrawWindow();
			}
			break;
		case VK_UP:
			if (core.m_vis_slicePos < KCore::TEXSIZE[core.m_vis_currentLevel]) {
				++core.m_vis_slicePos;
				core.m_ogl.RedrawWindow();
			}
			break;
		case 'X':
			if (core.m_vis_viewDir == 0) break;
			core.m_vis_viewDir = 0;
			core.m_ogl.RedrawWindow();
			break;
		case 'Y':
			if (core.m_vis_viewDir == 1) break;
			core.m_vis_viewDir = 1;
			core.m_ogl.RedrawWindow();
			break;
		case 'Z':
			if (core.m_vis_viewDir == 2) break;
			core.m_vis_viewDir = 2;
			core.m_ogl.RedrawWindow();
			break;
		case 'P':
			//core.randomOrientation(core.m_vis_currentLevel);
			core.searchVolume(core.m_vis_currentLevel);
			core.optimizeVolume(core.m_vis_currentLevel);
			core.calcVolume_uchar(core.m_vis_currentLevel);
			core.m_drawer.updateTexture_volume(core.m_vis_currentLevel);
			core.m_ogl.RedrawWindow();
			break;
		case 'L':
			if (core.m_vis_currentLevel == KCore::MULTIRES - 1) {
				printf("cannot upsample any more!\n");
				break;
			}
			core.upsampleVolume(core.m_vis_currentLevel);
			++core.m_vis_currentLevel;
			core.calcHistogram_exemplar (core.m_vis_currentLevel);
			core.calcHistogram_synthesis(core.m_vis_currentLevel);
			core.m_vis_slicePos = KCore::TEXSIZE[core.m_vis_currentLevel];
			core.calcVolume_uchar(core.m_vis_currentLevel);
			core.m_drawer.updateTexture_volume(core.m_vis_currentLevel);
			core.m_ogl.RedrawWindow();
			break;
		case 'S':
			{
				CFileDialog dlg(FALSE, ".png", core.m_fname, OFN_OVERWRITEPROMPT, "VOL File (*.vol)|*.vol||", NULL);
				if (dlg.DoModal() == IDOK) {
					core.saveVolume_uchar(core.m_vis_currentLevel, dlg.GetFileName());
				}
				break;
			}
		case 'A':
			core.m_vis_showAxis = !core.m_vis_showAxis;
			core.m_ogl.RedrawWindow();
			break;
		case 'H':
			core.m_vis_showHelp = !core.m_vis_showHelp;
			core.m_ogl.RedrawWindow();
			break;
	}
}

void EventHandler::OnDropFiles(CView* view, HDROP hDropInfo) {
	KCore& core = *KCore::getInstance();
	if (DragQueryFile(hDropInfo, -1, NULL, 0) != 1) return;  // # of dropped files
	int len = DragQueryFile(hDropInfo, 0, NULL, 0);   // filename length of the first file
	vector<char> buf(len + 1, 0);
	DragQueryFile(hDropInfo, 0, &buf[0], len + 1);   // read the filename
	string fname(&buf[0]);
	string ext = fname.substr(fname.length() - 4, 4);   // check file type
	if (
		ext.compare(".jpg") &&
		ext.compare(".png") &&
		ext.compare(".bmp") 
	) {
		AfxMessageBox("Please drop *.{bmp|jpg|png} file!");
		return;
	}
	core.m_fname = fname.c_str();
	core.init();
	core.m_ogl.RedrawWindow();
}
