// SolidSynthesis_KFC07Doc.h : interface of the CSolidSynthesis_KFC07Doc class
//


#pragma once


class CSolidSynthesis_KFC07Doc : public CDocument
{
protected: // create from serialization only
	CSolidSynthesis_KFC07Doc();
	DECLARE_DYNCREATE(CSolidSynthesis_KFC07Doc)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CSolidSynthesis_KFC07Doc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
};


