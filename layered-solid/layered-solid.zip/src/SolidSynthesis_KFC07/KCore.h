#pragma once

#include "Drawer.h"
#include "EventHandler.h"
#include <KLIB/KOGL.h>
#include <vector>
#include <ANN/ANN.h>
#include <OpenCV/cv.h>

class KCore
{
	KCore(void);
	~KCore(void);
public:
	static const int MULTIRES = 3;		// # of multi-resolution (0 -> MULTIRES - 1 :: coarsest -> finest)
	
	static const int N   [MULTIRES];
	static int TEXSIZE   [MULTIRES];			// size of input exemplar
	static int D_NEIGHBOR[MULTIRES];		// dimension of neighborhood (:= 3 * (2 * N + 1)^2)
	static int NEIGHBORSIZE[MULTIRES];				// size: (2 * N + 1) * (2 * N + 1)
	
	static const int NUM_HISTOGRAM_BIN;			// # of histogram bins
	static int NUM_CHANNEL;				// # of channels (RGB, feature dist., RTF)
	static std::vector<double> CHANNEL_MAXVALUE;
	
	static const double WEIGHT_FEATURE;			// weight for feature distance
	static const double WEIGHT_HISTOGRAM;		// weight for RGB histogram
	
	static const double PCA_RATIO_VARIANCE;
	
	static KCore* getInstance() {
		static KCore p;
		return &p;
	}
	KOGL m_ogl;
	Drawer m_drawer;
	EventHandler m_handler;
	void init();
	
	int trimIndex(int level, int index, bool isToroidal = true) {
		if (isToroidal) {
			while (index < 0) index += TEXSIZE[level];
			return index % TEXSIZE[level];
		} else {
			while (true) {
				if (index < 0) index = -index;
				if (TEXSIZE[level] <= index) {
					index = 2 * (TEXSIZE[level] - 1) - index;
					continue;
				}
				break;
			}
			return index;
		}
	}
	
	CString m_fname;
	
	// multi-res variables are noted with [M]
	
	std::vector<std::vector<double> >  m_exemplar_x;		// [M] exemplar RGB image, size: NUM_CHANNEL * TEXSIZE^2
	std::vector<std::vector<double> >  m_exemplar_y;
	std::vector<std::vector<double> >  m_exemplar_z;
	bool loadExemplar(const CString& fname);
	
	// PCA-projected neighborhood vector
	std::vector<std::vector<double> > m_neighbor_x;				// [M] original neighborhood vector required for texture optimization
	std::vector<std::vector<double> > m_neighbor_y;
	std::vector<std::vector<double> > m_neighbor_z;
	std::vector<CvMat*> mp_neighbor_pca_average_x;						// [M] average of neighborhood vector
	std::vector<CvMat*> mp_neighbor_pca_average_y;
	std::vector<CvMat*> mp_neighbor_pca_average_z;
	std::vector<CvMat*> mp_neighbor_pca_projected_x;						// [M] PCA-projected neighborhood data
	std::vector<CvMat*> mp_neighbor_pca_projected_y;
	std::vector<CvMat*> mp_neighbor_pca_projected_z;
	std::vector<CvMat*> mp_neighbor_pca_eigenvec_x;						// [M] eigenvectors for covariant matrix
	std::vector<CvMat*> mp_neighbor_pca_eigenvec_y;
	std::vector<CvMat*> mp_neighbor_pca_eigenvec_z;
	std::vector<std::vector<double*> > m_neighbor_kdTree_ptr_x;			// [M] array of pointers to vectors required for ANNkd_tree
	std::vector<std::vector<double*> > m_neighbor_kdTree_ptr_y;
	std::vector<std::vector<double*> > m_neighbor_kdTree_ptr_z;
	std::vector<ANNkd_tree*          > mp_neighbor_kdTree_x;	// [M] ANN kdTree
	std::vector<ANNkd_tree*          > mp_neighbor_kdTree_y;
	std::vector<ANNkd_tree*          > mp_neighbor_kdTree_z;
	void calcNeighbor();
	
	// global histogram
	std::vector<std::vector<std::vector<double> > > m_histogram_exemplar;			// [M] size: NUM_CHANNEL x NUM_HISTOGRAM_BIN
	std::vector<std::vector<std::vector<double> > > m_histogram_synthesis;			// [M] size: NUM_CHANNEL x NUM_HISTOGRAM_BIN
	//std::vector<std::vector<double> > m_histogram_exemplar_r;			// [M] size: NUM_HISTOGRAM_BIN
	//std::vector<std::vector<double> > m_histogram_exemplar_g;			// [M] size: NUM_HISTOGRAM_BIN
	//std::vector<std::vector<double> > m_histogram_exemplar_b;			// [M] size: NUM_HISTOGRAM_BIN
	//std::vector<std::vector<double> > m_histogram_synthesis_r;			// [M] size: NUM_HISTOGRAM_BIN
	//std::vector<std::vector<double> > m_histogram_synthesis_g;			// [M] size: NUM_HISTOGRAM_BIN
	//std::vector<std::vector<double> > m_histogram_synthesis_b;			// [M] size: NUM_HISTOGRAM_BIN
	void calcHistogram_exemplar (int level);
	void calcHistogram_synthesis(int level);
	void updateHistogram_synthesis(int level, const std::vector<double>& color_old, const std::vector<double>& color_new);
	
	// synthesized volume
	std::vector<std::vector<double > > m_volume;			// [M] size: NUM_CHANNEL * TEXSIZE^3
	std::vector<std::vector<GLubyte> > m_volume_uchar;		// [M] size: 3 * TEXSIZE^3
	void calcVolume_uchar(int level);
	void saveVolume_uchar(int level, const CString& fname);
	
	// pseudocode-----------------------------------------------------------------
	// volume[0] := initVolume(0);                                        % initialization
	// for level = 0 to L                                                 % coarse-to-fine synthesis
	//   repeat                                                           % several iterations for a single level
	//     nearest_neighbor := searchVolume(level);                       % phase 1: search
	//     volume[level] := optimizeVolume(level, nearest_neighbor);      % phase 2: optimization
	//   until converged
	//   volume[level + 1] = upsampleVolume(level);                       % upsampling
	// end for
	//----------------------------------------------------------------------------
	// for more details, please refer to my master thesis which contains a brief review on the SIGGRAPH 2007 paper.
	
	// initialization
	void initVolume(int level);
	
	// phase 1: nearest neighbor search
	std::vector<std::vector<int   > > m_volume_nearest_x_index;		// [M] size: TEXSIZE^3
	std::vector<std::vector<int   > > m_volume_nearest_y_index;		// [M] size: TEXSIZE^3
	std::vector<std::vector<int   > > m_volume_nearest_z_index;		// [M] size: TEXSIZE^3
	std::vector<std::vector<double> > m_volume_nearest_x_dist;		// [M] size: TEXSIZE^3
	std::vector<std::vector<double> > m_volume_nearest_y_dist;		// [M] size: TEXSIZE^3
	std::vector<std::vector<double> > m_volume_nearest_z_dist;		// [M] size: TEXSIZE^3
	void searchVolume(int level);
	
	// phase 2: optimization
	void optimizeVolume(int level);
	// random permutation (precomputed)
	std::vector<std::vector<int> > m_permutation_xyz;				// [M] size: TEXSIZE^3
	void initPermutation(int level);
	
	// upsampling
	void upsampleVolume(int level);
	
	// variables related to visualization only
	int m_vis_slicePos;
	int m_vis_viewDir;		// 0->x,  1->y,  2->z
	int m_vis_currentLevel;
	bool m_vis_showHelp;
	bool m_vis_showAxis;
};
