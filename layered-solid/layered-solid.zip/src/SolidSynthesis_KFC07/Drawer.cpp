#include "StdAfx.h"
#include "Drawer.h"
#include "KCore.h"
#include "KLIB/KDrawer.h"
#include <vector>
#include <string>
using namespace std;

Drawer::Drawer(void) {
	mp_font = new FTGLPolygonFont("Xerox Sans Serif Narrow.ttf");
	mp_font->FaceSize(24);
}

Drawer::~Drawer(void) {
	delete mp_font;
}

void Drawer::init(CView* view) {
	KCore& core = *KCore::getInstance();
	core.m_ogl.makeOpenGLCurrent();
	glewInit();
	glDisable(GL_LIGHTING);
	glDisable(GL_CULL_FACE);
	core.m_ogl.m_eyePoint.set(3, 3, 3);
	core.m_ogl.m_focusPoint.set(0.5, 0.5, 0.5);
	core.m_ogl.m_upDirection.set(0, 0, 1);
	glLineWidth(5);
	glEnable(GL_TEXTURE_3D);
	glEnable(GL_TEXTURE_GEN_S);
	glEnable(GL_TEXTURE_GEN_T);
	glEnable(GL_TEXTURE_GEN_R);
}

void Drawer::updateTexture_volume(int level) {
	KCore& core = *KCore::getInstance();
	core.m_ogl.makeOpenGLCurrent();
	glDeleteTextures(1, &m_texName_volume);
	glGenTextures   (1, &m_texName_volume);
	glBindTexture(GL_TEXTURE_3D, m_texName_volume);
	glTexImage3D(GL_TEXTURE_3D, 0, GL_RGB,
		KCore::TEXSIZE[level], KCore::TEXSIZE[level], KCore::TEXSIZE[level],
		0, GL_RGB, GL_UNSIGNED_BYTE, &core.m_volume_uchar[level][0]);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP);
	double genfunc[][4] = {
		{1, 0, 0, 0},
		{0, 1, 0, 0},
		{0, 0, 1, 0}
	};
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGendv(GL_S, GL_OBJECT_PLANE, genfunc[0]);
	glTexGendv(GL_T, GL_OBJECT_PLANE, genfunc[1]);
	glTexGendv(GL_R, GL_OBJECT_PLANE, genfunc[2]);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
}

void Drawer::draw(CView* view) {
	KCore& core = *KCore::getInstance();
	CRect rect;
	view->GetWindowRect(&rect);
	int wndWidth  = rect.right  - rect.left;
	int wndHeight = rect.bottom - rect.top;
	
	if (m_texName_volume != 0) {
		glBindTexture(GL_TEXTURE_3D, m_texName_volume);
		glEnable(GL_TEXTURE_3D);
		double slice = core.m_vis_slicePos / (double)KCore::TEXSIZE[core.m_vis_currentLevel];
		double d = 0.000001;
		if (core.m_vis_viewDir == 0) {
			KDrawer::drawBox(0 + d, 0 + d, 0 + d, slice - d, 1 - d, 1 - d);
		} else if (core.m_vis_viewDir == 1) {
			KDrawer::drawBox(0 + d, 0 + d, 0 + d, 1 - d, slice - d, 1 - d);
		} else {
			KDrawer::drawBox(0 + d, 0 + d, 0 + d, 1 - d, 1 - d, slice - d);
		}
		glDisable(GL_TEXTURE_3D);
	}
	
	if (core.m_vis_showAxis) {
		KDrawer::drawAxis();
	}
	
	// print usage
	glColor3d(0.2, 0.2, 0.2);
	vector<string> messages;
	if (core.m_vis_showHelp) {
		messages.push_back("Drag & drop the exemplar image.");
		messages.push_back("Right mouse drag to rotate the texture.");
		messages.push_back("Right mouse drag + SHIFT to zoom in/out.");
		messages.push_back("Right mouse drag + CTRL  to pan.");
		messages.push_back("");
		messages.push_back("Press 'P' to perform one pass of 2-step sysnthesis.");
		messages.push_back("Press 'L' to proceed to the next finer level (max level is predefined as 3).");
		messages.push_back("Press 'S' to save the resulting texture at the finest level as "".vol"" file.");
		messages.push_back("Press 'Up'/'Down' to browse the volume by moving the cutting plane.");
		messages.push_back("Press 'X'/'Y'/'Z' to change the orientation of the cutting plane.");
		messages.push_back("Press 'A' to toggle xyz axes show/hide.");
		messages.push_back("Press 'H' to hide this help message.");
		messages.push_back("");
		messages.push_back("For more detailes, see readme.txt.");
	} else {
		messages.push_back("Press 'H' for usage");
	}
	float fontheigt = mp_font->Ascender() - mp_font->Descender();
	float off_x = 20;
	float off_y = 20;
	glMatrixMode(GL_PROJECTION);
	glPushMatrix();
	glLoadIdentity();
	gluOrtho2D(0, wndWidth, 0, wndHeight);
	glMatrixMode(GL_MODELVIEW);
	glPushMatrix();
	glLoadIdentity();
	glDisable(GL_DEPTH_TEST);
	glTranslatef(off_x, off_y, 0);
	for (int i = messages.size() - 1; i >= 0; --i) {
		mp_font->Render(messages[i].c_str());
		glTranslatef(0, fontheigt, 0);
	}
	glEnable(GL_DEPTH_TEST);
	glPopMatrix();
	glMatrixMode(GL_PROJECTION);
	glPopMatrix();
	glMatrixMode(GL_MODELVIEW);
}
void Drawer::postDraw(CView* view, CDC* pDC) {}

