#include "StdAfx.h"
#include "KCore.h"

#include <OpenCV/cv.h>
#include <OpenCV/highgui.h>
#include <algorithm>
#include <fstream>
#include <cstdlib>
#include <ctime>
#include <KLIB/KUtil.h>
using namespace std;

const int KCore::N[MULTIRES] = {2, 3, 4};		// neighborhood size: (2 * N + 1)^2
int KCore::TEXSIZE   [MULTIRES];
int KCore::D_NEIGHBOR[MULTIRES];
int KCore::NEIGHBORSIZE[MULTIRES];

const int KCore::NUM_HISTOGRAM_BIN = 16;

//const int KCore::NUM_CHANNEL = 3;
int KCore::NUM_CHANNEL;
vector<double> KCore::CHANNEL_MAXVALUE;

const double KCore::WEIGHT_FEATURE = 1;
const double KCore::WEIGHT_HISTOGRAM = 10;

const double KCore::PCA_RATIO_VARIANCE = 0.9;

KCore::KCore(void) {
	srand((unsigned)time(NULL));
	// [begin] multi-res memory allocation-------------------------------------------
	m_exemplar_x               .resize(MULTIRES);
	m_exemplar_y               .resize(MULTIRES);
	m_exemplar_z               .resize(MULTIRES);
	m_neighbor_x               .resize(MULTIRES);
	m_neighbor_y               .resize(MULTIRES);
	m_neighbor_z               .resize(MULTIRES);
	mp_neighbor_pca_average_x  .resize(MULTIRES, NULL);
	mp_neighbor_pca_average_y  .resize(MULTIRES, NULL);
	mp_neighbor_pca_average_z  .resize(MULTIRES, NULL);
	mp_neighbor_pca_projected_x.resize(MULTIRES, NULL);
	mp_neighbor_pca_projected_y.resize(MULTIRES, NULL);
	mp_neighbor_pca_projected_z.resize(MULTIRES, NULL);
	mp_neighbor_pca_eigenvec_x .resize(MULTIRES, NULL);
	mp_neighbor_pca_eigenvec_y .resize(MULTIRES, NULL);
	mp_neighbor_pca_eigenvec_z .resize(MULTIRES, NULL);
	m_neighbor_kdTree_ptr_x    .resize(MULTIRES);
	m_neighbor_kdTree_ptr_y    .resize(MULTIRES);
	m_neighbor_kdTree_ptr_z    .resize(MULTIRES);
	mp_neighbor_kdTree_x       .resize(MULTIRES, NULL);
	mp_neighbor_kdTree_y       .resize(MULTIRES, NULL);
	mp_neighbor_kdTree_z       .resize(MULTIRES, NULL);
	m_histogram_exemplar       .resize(MULTIRES);
	m_histogram_synthesis      .resize(MULTIRES);
	m_volume                   .resize(MULTIRES);
	m_volume_uchar             .resize(MULTIRES);
	m_volume_nearest_x_index   .resize(MULTIRES);
	m_volume_nearest_y_index   .resize(MULTIRES);
	m_volume_nearest_z_index   .resize(MULTIRES);
	m_volume_nearest_x_dist    .resize(MULTIRES);
	m_volume_nearest_y_dist    .resize(MULTIRES);
	m_volume_nearest_z_dist    .resize(MULTIRES);
	m_permutation_xyz          .resize(MULTIRES);
	// [end] multi-res memory allocation-------------------------------------------
	
	//m_fname = "texture_o_icon.jpg";
	m_vis_showAxis = true;
}

KCore::~KCore(void) {
	for (int level = 0; level < MULTIRES; ++level) {
		if (mp_neighbor_kdTree_x[level] != NULL) delete mp_neighbor_kdTree_x[level];
		if (mp_neighbor_kdTree_y[level] != NULL) delete mp_neighbor_kdTree_y[level];
		if (mp_neighbor_kdTree_z[level] != NULL) delete mp_neighbor_kdTree_z[level];
		if (mp_neighbor_pca_average_x  [level] != NULL) cvReleaseMat(&mp_neighbor_pca_average_x [level]);
		if (mp_neighbor_pca_average_y  [level] != NULL) cvReleaseMat(&mp_neighbor_pca_average_y [level]);
		if (mp_neighbor_pca_average_z  [level] != NULL) cvReleaseMat(&mp_neighbor_pca_average_z [level]);
		if (mp_neighbor_pca_projected_x[level] != NULL) cvReleaseMat(&mp_neighbor_pca_projected_x[level]);
		if (mp_neighbor_pca_projected_y[level] != NULL) cvReleaseMat(&mp_neighbor_pca_projected_y[level]);
		if (mp_neighbor_pca_projected_z[level] != NULL) cvReleaseMat(&mp_neighbor_pca_projected_z[level]);
		if (mp_neighbor_pca_eigenvec_x [level] != NULL) cvReleaseMat(&mp_neighbor_pca_eigenvec_x [level]);
		if (mp_neighbor_pca_eigenvec_y [level] != NULL) cvReleaseMat(&mp_neighbor_pca_eigenvec_y [level]);
		if (mp_neighbor_pca_eigenvec_z [level] != NULL) cvReleaseMat(&mp_neighbor_pca_eigenvec_z [level]);
	}
}

void KCore::init() {
	if (!loadExemplar(m_fname)) return;
	
	calcNeighbor();
	
	m_vis_currentLevel = 0;
	calcHistogram_exemplar(m_vis_currentLevel);
	calcHistogram_synthesis(m_vis_currentLevel);
	
	initVolume(m_vis_currentLevel);
	calcVolume_uchar(m_vis_currentLevel);
	m_drawer.updateTexture_volume(m_vis_currentLevel);
	
	m_vis_slicePos = TEXSIZE[m_vis_currentLevel];
}

bool KCore::loadExemplar(const CString& fname) {
	printf("Loading exemplar ...(fname: %s)...", (LPCSTR)fname);
	
	int dotPos = fname.Find('.');
	CString& ext = fname.Right(fname.GetLength() - dotPos);
	CString& fname2 = fname.Left(dotPos);
	
	IplImage *img_x;
	IplImage *img_y;
	IplImage *img_z;
	IplImage *img_feature_x = NULL;
	IplImage *img_feature_y = NULL;
	IplImage *img_feature_z = NULL;
	
	// load for image in x-dir
	printf("loading %s as exemplar_x...\n", (LPCSTR)fname);
	img_x = cvLoadImage (fname, CV_LOAD_IMAGE_COLOR);
	if (img_x == NULL) {
		AfxMessageBox("Failed to load" + fname);
		return false;
	} else if (img_x->width != img_x->height) {
		cvReleaseImage(&img_x);
		AfxMessageBox("The exemplar must be square");
		return false;
	}
	// Flip vertically
	cvFlip(img_x, NULL, 0);
	// Convert from BGR to RGB
	cvCvtColor(img_x, img_x, CV_BGR2RGB);
	int imgsize = img_x->width;
	bool is_given_y = false;
	bool is_given_z = false;
	img_y = cvLoadImage (fname2 + "_y" + ext, CV_LOAD_IMAGE_COLOR);
	img_z = cvLoadImage (fname2 + "_z" + ext, CV_LOAD_IMAGE_COLOR);
	if (img_y == NULL) {
		printf("assume exemplar_y is the same with exemplar_x.\n");
		img_y = cvCloneImage(img_x);
	} else if (img_y->width != imgsize || img_y->height != imgsize) {
		cvReleaseImage(&img_y);
		printf("warning: exemplar_y is inconsistent in size. ");
		printf("assume exemplar_y is the same with exemplar_x.\n");
		img_y = cvCloneImage(img_x);
	} else {
		printf("exemplar_y is found!\n");
		is_given_y = true;
		// Flip vertically
		cvFlip(img_y, NULL, 0);
		// Convert from BGR to RGB
		cvCvtColor(img_y, img_y, CV_BGR2RGB);
	}
	if (img_z == NULL) {
		printf("assume exemplar_z is the same with exemplar_x.\n");
		img_z = cvCloneImage(img_x);
	} else if (img_z->width != imgsize || img_z->height != imgsize) {
		cvReleaseImage(&img_z);
		printf("warning: exemplar_z is inconsistent in size.\n");
		printf("assume exemplar_z is the same with exemplar_x.\n");
		img_z = cvCloneImage(img_x);
	} else {
		printf("exemplar_y is found!\n");
		is_given_z = true;
		// Flip vertically
		cvFlip(img_z, NULL, 0);
		// Convert from BGR to RGB
		cvCvtColor(img_z, img_z, CV_BGR2RGB);
	}
	// load feature map if exists
	NUM_CHANNEL = 3;
	img_feature_x = cvLoadImage(fname2 + "_feature" + ext, CV_LOAD_IMAGE_COLOR);
	while (img_feature_x != NULL) {
		printf("feature map is found!\n");
		if (img_feature_x->width != imgsize || img_feature_x->height != imgsize) {
			printf("warning: feature map of exemplar_x is inconsistent in size.\n");
			break;
		}
		// Flip vertically
		cvFlip(img_feature_x, 0);
		if (is_given_y) {
			img_feature_y = cvLoadImage(fname2 + "_feature_y" + ext, CV_LOAD_IMAGE_COLOR);
			if (img_feature_y == NULL) {
				printf("warning: feature map of exemplar_y is not specified.\n");
				break;
			} else if (img_feature_y->width != imgsize || img_feature_y->height != imgsize) {
				printf("warning: feature map of exemplar_y is inconsistent in size.\n");
				break;
			}
			// Flip vertically
			cvFlip(img_feature_y, 0);
		} else {
			img_feature_y = cvCloneImage(img_feature_x);
		}
		if (is_given_z) {
			img_feature_z = cvLoadImage(fname2 + "_feature_z" + ext, CV_LOAD_IMAGE_COLOR);
			if (img_feature_z == NULL) {
				printf("warning: feature map of exemplar_z is not specified.\n");
				break;
			} else if (img_feature_z->width != imgsize || img_feature_z->height != imgsize) {
				printf("warning: feature map of exemplar_z is inconsistent in size.\n");
				break;
			}
			// Flip vertically
			cvFlip(img_feature_z, 0);
		} else {
			img_feature_z = cvCloneImage(img_feature_x);
		}
		NUM_CHANNEL = 4;
		break;
	}
	if (img_feature_x != NULL && NUM_CHANNEL == 3) {		// some errors occurred when loading feature maps
		cvReleaseImage(&img_feature_x);
		if (img_feature_y != NULL) cvReleaseImage(&img_feature_y);
		if (img_feature_z != NULL) cvReleaseImage(&img_feature_z);
		img_feature_x = img_feature_y = img_feature_z = NULL;
		printf("give up using feature maps.\n");
	}
	
	// build image pyramid
	int img_depth     = img_x->depth;
	int img_nChannels = img_x->nChannels;
	for (int level = MULTIRES - 1; level >= 0; --level) {
		// size registration
		TEXSIZE[level] = img_x->width;
		NEIGHBORSIZE[level] = (2 * N[level] + 1) * (2 * N[level] + 1);
		D_NEIGHBOR[level] = NUM_CHANNEL * NEIGHBORSIZE[level];
		
		// [begin] memory allocation -------------------------------------------
		m_exemplar_x            [level].resize(NUM_CHANNEL * TEXSIZE[level] * TEXSIZE[level]);
		m_exemplar_y            [level].resize(NUM_CHANNEL * TEXSIZE[level] * TEXSIZE[level]);
		m_exemplar_z            [level].resize(NUM_CHANNEL * TEXSIZE[level] * TEXSIZE[level]);
		m_neighbor_x            [level].resize(D_NEIGHBOR[level] * (TEXSIZE[level] - 2 * N[level]) * (TEXSIZE[level] - 2 * N[level]));
		m_neighbor_y            [level].resize(D_NEIGHBOR[level] * (TEXSIZE[level] - 2 * N[level]) * (TEXSIZE[level] - 2 * N[level]));
		m_neighbor_z            [level].resize(D_NEIGHBOR[level] * (TEXSIZE[level] - 2 * N[level]) * (TEXSIZE[level] - 2 * N[level]));
		m_volume                [level].resize(NUM_CHANNEL * TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_volume_uchar          [level].resize(3           * TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_volume_nearest_x_index[level].resize(TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_volume_nearest_y_index[level].resize(TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_volume_nearest_z_index[level].resize(TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_volume_nearest_x_dist [level].resize(TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_volume_nearest_y_dist [level].resize(TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_volume_nearest_z_dist [level].resize(TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		m_permutation_xyz       [level].resize(TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
		// [end] memory allocation -------------------------------------------
		
		for (int v = 0; v < TEXSIZE[level]; ++v) {
			for (int u = 0; u < TEXSIZE[level]; ++u) {
				int index  = NUM_CHANNEL * (TEXSIZE[level] * v + u);
				int index2 = 3           * (TEXSIZE[level] * v + u);
				for (int ch = 0; ch < 3; ++ch) {
					m_exemplar_x[level][index + ch] = (unsigned char)img_x->imageData[index2 + ch];
					m_exemplar_y[level][index + ch] = (unsigned char)img_y->imageData[index2 + ch];
					m_exemplar_z[level][index + ch] = (unsigned char)img_z->imageData[index2 + ch];
				}
				if (NUM_CHANNEL == 4) {		// additional feature map channel
					m_exemplar_x[level][index + 3] = WEIGHT_FEATURE * (unsigned char)img_feature_x->imageData[index2];
					m_exemplar_y[level][index + 3] = WEIGHT_FEATURE * (unsigned char)img_feature_y->imageData[index2];
					m_exemplar_z[level][index + 3] = WEIGHT_FEATURE * (unsigned char)img_feature_z->imageData[index2];
				}
			}
		}
		
		// go to the coarser level
		IplImage *img_next_x = cvCreateImage(cvSize(TEXSIZE[level] / 2, TEXSIZE[level] / 2), img_depth, img_nChannels);
		IplImage *img_next_y = cvCreateImage(cvSize(TEXSIZE[level] / 2, TEXSIZE[level] / 2), img_depth, img_nChannels);
		IplImage *img_next_z = cvCreateImage(cvSize(TEXSIZE[level] / 2, TEXSIZE[level] / 2), img_depth, img_nChannels);
		cvResize (img_x, img_next_x, CV_INTER_LINEAR);		// CV_INTER_CUBIC
		cvResize (img_y, img_next_y, CV_INTER_LINEAR);
		cvResize (img_z, img_next_z, CV_INTER_LINEAR);
		cvReleaseImage (&img_x);
		cvReleaseImage (&img_y);
		cvReleaseImage (&img_z);
		img_x = img_next_x;
		img_y = img_next_y;
		img_z = img_next_z;
		if (NUM_CHANNEL == 4) {
			IplImage *img_next_feature_x = cvCreateImage(cvSize(TEXSIZE[level] / 2, TEXSIZE[level] / 2), img_depth, img_nChannels);
			IplImage *img_next_feature_y = cvCreateImage(cvSize(TEXSIZE[level] / 2, TEXSIZE[level] / 2), img_depth, img_nChannels);
			IplImage *img_next_feature_z = cvCreateImage(cvSize(TEXSIZE[level] / 2, TEXSIZE[level] / 2), img_depth, img_nChannels);
			cvResize (img_feature_x, img_next_feature_x, CV_INTER_LINEAR);		// CV_INTER_CUBIC
			cvResize (img_feature_y, img_next_feature_y, CV_INTER_LINEAR);
			cvResize (img_feature_z, img_next_feature_z, CV_INTER_LINEAR);
			cvReleaseImage (&img_feature_x);
			cvReleaseImage (&img_feature_y);
			cvReleaseImage (&img_feature_z);
			img_feature_x = img_next_feature_x;
			img_feature_y = img_next_feature_y;
			img_feature_z = img_next_feature_z;
		}
	}
	cvReleaseImage (&img_x);
	cvReleaseImage (&img_y);
	cvReleaseImage (&img_z);
	if (NUM_CHANNEL == 4) {
		cvReleaseImage (&img_feature_x);
		cvReleaseImage (&img_feature_y);
		cvReleaseImage (&img_feature_z);
	}
	CHANNEL_MAXVALUE.resize(NUM_CHANNEL);
	for (int ch = 0; ch < 3; ++ch) {
		CHANNEL_MAXVALUE[ch] = 256;
	}
	if (NUM_CHANNEL == 4) CHANNEL_MAXVALUE[3] = WEIGHT_FEATURE * 256;
	printf("done!\n");
	return true;
}

void KCore::calcNeighbor() {
	printf("calcNeighbor...\n");
	for (int level = 0; level < MULTIRES; ++level) {
		printf("level:%d\n", level);
		int numData = (TEXSIZE[level] - 2 * N[level]) * (TEXSIZE[level] - 2 * N[level]);
		CvMat* p_source_x  = cvCreateMat(numData, D_NEIGHBOR[level], CV_64F);
		CvMat* p_source_y  = cvCreateMat(numData, D_NEIGHBOR[level], CV_64F);
		CvMat* p_source_z  = cvCreateMat(numData, D_NEIGHBOR[level], CV_64F);
		int row = 0;
		for (int v = N[level]; v < TEXSIZE[level] - N[level]; ++v) {
			for (int u = N[level]; u < TEXSIZE[level] - N[level]; ++u) {
				int col = 0;
				for (int dv = -N[level]; dv <= N[level]; ++dv) {
					for (int du = -N[level]; du <= N[level]; ++du) {
						int index = NUM_CHANNEL * (TEXSIZE[level] * (v + dv) + u + du);
						for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
							cvmSet(p_source_x, row, col, m_exemplar_x[level][index + ch]);
							cvmSet(p_source_y, row, col, m_exemplar_y[level][index + ch]);
							cvmSet(p_source_z, row, col, m_exemplar_z[level][index + ch]);
							m_neighbor_x[level][D_NEIGHBOR[level] * row + col] = m_exemplar_x[level][index + ch];
							m_neighbor_y[level][D_NEIGHBOR[level] * row + col] = m_exemplar_y[level][index + ch];
							m_neighbor_z[level][D_NEIGHBOR[level] * row + col] = m_exemplar_z[level][index + ch];
							++col;
						}
					}
				}
				++row;
			}
		}
		// PCA calculation (obtain all eigenvectors of the input covariance matrix)
		if (mp_neighbor_pca_average_x[level] != NULL) cvReleaseMat(&mp_neighbor_pca_average_x[level]);
		if (mp_neighbor_pca_average_y[level] != NULL) cvReleaseMat(&mp_neighbor_pca_average_y[level]);
		if (mp_neighbor_pca_average_z[level] != NULL) cvReleaseMat(&mp_neighbor_pca_average_z[level]);
		mp_neighbor_pca_average_x[level] = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		mp_neighbor_pca_average_y[level] = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		mp_neighbor_pca_average_z[level] = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		CvMat* p_eigenValues_x = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		CvMat* p_eigenValues_y = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		CvMat* p_eigenValues_z = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		CvMat* p_eigenVectors_all_x = cvCreateMat(D_NEIGHBOR[level], D_NEIGHBOR[level], CV_64F);
		CvMat* p_eigenVectors_all_y = cvCreateMat(D_NEIGHBOR[level], D_NEIGHBOR[level], CV_64F);
		CvMat* p_eigenVectors_all_z = cvCreateMat(D_NEIGHBOR[level], D_NEIGHBOR[level], CV_64F);
		cvCalcPCA(p_source_x, mp_neighbor_pca_average_x[level], p_eigenValues_x, p_eigenVectors_all_x, CV_PCA_DATA_AS_ROW);
		cvCalcPCA(p_source_y, mp_neighbor_pca_average_y[level], p_eigenValues_y, p_eigenVectors_all_y, CV_PCA_DATA_AS_ROW);
		cvCalcPCA(p_source_z, mp_neighbor_pca_average_z[level], p_eigenValues_z, p_eigenVectors_all_z, CV_PCA_DATA_AS_ROW);
		// Decide amount of dimensionality reduction
		double contribution_total_x = 0;
		double contribution_total_y = 0;
		double contribution_total_z = 0;
		for (int i = 0; i < D_NEIGHBOR[level]; ++i) {
			contribution_total_x += cvmGet(p_eigenValues_x, 0, i);
			contribution_total_y += cvmGet(p_eigenValues_y, 0, i);
			contribution_total_z += cvmGet(p_eigenValues_z, 0, i);
		}
		int dimPCA_x = 0;
		int dimPCA_y = 0;
		int dimPCA_z = 0;
		double contribution_acc_x = 0;
		double contribution_acc_y = 0;
		double contribution_acc_z = 0;
		for (int i = 0; i < D_NEIGHBOR[level]; ++i) {
			double ratio_x = contribution_acc_x / contribution_total_x;
			double ratio_y = contribution_acc_y / contribution_total_y;
			double ratio_z = contribution_acc_z / contribution_total_z;
			if (ratio_x < PCA_RATIO_VARIANCE) {
				contribution_acc_x += cvmGet(p_eigenValues_x, 0, i);
				++dimPCA_x;
			}
			if (ratio_y < PCA_RATIO_VARIANCE) {
				contribution_acc_y += cvmGet(p_eigenValues_y, 0, i);
				++dimPCA_y;
			}
			if (ratio_z < PCA_RATIO_VARIANCE) {
				contribution_acc_z += cvmGet(p_eigenValues_z, 0, i);
				++dimPCA_z;
			}
			if (PCA_RATIO_VARIANCE <= ratio_x && PCA_RATIO_VARIANCE <= ratio_y && PCA_RATIO_VARIANCE <= ratio_z) break;
		}
		printf("PCA reduction (x): %d -> %d\n", D_NEIGHBOR[level], dimPCA_x);
		printf("PCA reduction (y): %d -> %d\n", D_NEIGHBOR[level], dimPCA_y);
		printf("PCA reduction (z): %d -> %d\n", D_NEIGHBOR[level], dimPCA_z);
		// Trim total eigenvectors into partial eigenvectors
		if (mp_neighbor_pca_eigenvec_x[level] != NULL) cvReleaseMat(&mp_neighbor_pca_eigenvec_x[level]);
		if (mp_neighbor_pca_eigenvec_y[level] != NULL) cvReleaseMat(&mp_neighbor_pca_eigenvec_y[level]);
		if (mp_neighbor_pca_eigenvec_z[level] != NULL) cvReleaseMat(&mp_neighbor_pca_eigenvec_z[level]);
		mp_neighbor_pca_eigenvec_x[level] = cvCreateMat(dimPCA_x, D_NEIGHBOR[level], CV_64F);
		mp_neighbor_pca_eigenvec_y[level] = cvCreateMat(dimPCA_y, D_NEIGHBOR[level], CV_64F);
		mp_neighbor_pca_eigenvec_z[level] = cvCreateMat(dimPCA_z, D_NEIGHBOR[level], CV_64F);
		memcpy(mp_neighbor_pca_eigenvec_x[level]->data.db, p_eigenVectors_all_x->data.db, sizeof(double) * dimPCA_x * D_NEIGHBOR[level]);
		memcpy(mp_neighbor_pca_eigenvec_y[level]->data.db, p_eigenVectors_all_y->data.db, sizeof(double) * dimPCA_y * D_NEIGHBOR[level]);
		memcpy(mp_neighbor_pca_eigenvec_z[level]->data.db, p_eigenVectors_all_z->data.db, sizeof(double) * dimPCA_z * D_NEIGHBOR[level]);
		// PCA projection
		if (mp_neighbor_pca_projected_x[level] != NULL) cvReleaseMat(&mp_neighbor_pca_projected_x[level]);
		if (mp_neighbor_pca_projected_y[level] != NULL) cvReleaseMat(&mp_neighbor_pca_projected_y[level]);
		if (mp_neighbor_pca_projected_z[level] != NULL) cvReleaseMat(&mp_neighbor_pca_projected_z[level]);
		mp_neighbor_pca_projected_x[level] = cvCreateMat(numData, dimPCA_x, CV_64F);
		mp_neighbor_pca_projected_y[level] = cvCreateMat(numData, dimPCA_y, CV_64F);
		mp_neighbor_pca_projected_z[level] = cvCreateMat(numData, dimPCA_z, CV_64F);
		cvProjectPCA(p_source_x, mp_neighbor_pca_average_x[level], mp_neighbor_pca_eigenvec_x[level], mp_neighbor_pca_projected_x[level]);
		cvProjectPCA(p_source_y, mp_neighbor_pca_average_y[level], mp_neighbor_pca_eigenvec_y[level], mp_neighbor_pca_projected_y[level]);
		cvProjectPCA(p_source_z, mp_neighbor_pca_average_z[level], mp_neighbor_pca_eigenvec_z[level], mp_neighbor_pca_projected_z[level]);
		// kd-tree contruction
		m_neighbor_kdTree_ptr_x[level].resize(numData);
		m_neighbor_kdTree_ptr_y[level].resize(numData);
		m_neighbor_kdTree_ptr_z[level].resize(numData);
		for (int i = 0; i < numData; ++i) {
			m_neighbor_kdTree_ptr_x[level][i] = &mp_neighbor_pca_projected_x[level]->data.db[dimPCA_x * i];
			m_neighbor_kdTree_ptr_y[level][i] = &mp_neighbor_pca_projected_y[level]->data.db[dimPCA_y * i];
			m_neighbor_kdTree_ptr_z[level][i] = &mp_neighbor_pca_projected_z[level]->data.db[dimPCA_z * i];
		}
		if (mp_neighbor_kdTree_x[level] != NULL) delete mp_neighbor_kdTree_x[level];
		if (mp_neighbor_kdTree_y[level] != NULL) delete mp_neighbor_kdTree_y[level];
		if (mp_neighbor_kdTree_z[level] != NULL) delete mp_neighbor_kdTree_z[level];
		mp_neighbor_kdTree_x[level] = new ANNkd_tree(&m_neighbor_kdTree_ptr_x[level][0], numData, dimPCA_x);
		mp_neighbor_kdTree_y[level] = new ANNkd_tree(&m_neighbor_kdTree_ptr_y[level][0], numData, dimPCA_y);
		mp_neighbor_kdTree_z[level] = new ANNkd_tree(&m_neighbor_kdTree_ptr_z[level][0], numData, dimPCA_z);
		// release CV matrices
		cvReleaseMat(&p_source_x);
		cvReleaseMat(&p_source_y);
		cvReleaseMat(&p_source_z);
		cvReleaseMat(&p_eigenValues_x);
		cvReleaseMat(&p_eigenValues_y);
		cvReleaseMat(&p_eigenValues_z);
		cvReleaseMat(&p_eigenVectors_all_x);
		cvReleaseMat(&p_eigenVectors_all_y);
		cvReleaseMat(&p_eigenVectors_all_z);
	}
}

void KCore::calcHistogram_synthesis(int level) {
	m_histogram_synthesis[level].clear();
	m_histogram_synthesis[level].resize(NUM_CHANNEL, vector<double>(NUM_HISTOGRAM_BIN, 0));
	double delta_histogram = 1. / (TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
	for (int i = 0; i < TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]; ++i) {
		for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
			double c = m_volume[level][NUM_CHANNEL * i + ch];
			int bin  = (int)(c * NUM_HISTOGRAM_BIN / CHANNEL_MAXVALUE[ch]);
			m_histogram_synthesis[level][ch][bin] += delta_histogram;
		}
	}
}
void KCore::updateHistogram_synthesis(int level, const std::vector<double>& color_old, const std::vector<double>& color_new) {
	double delta_histogram = 1. / (TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]);
	for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
		int bin_old = (int)(color_old[ch] * NUM_HISTOGRAM_BIN / CHANNEL_MAXVALUE[ch]);
		int bin_new = (int)(color_new[ch] * NUM_HISTOGRAM_BIN / CHANNEL_MAXVALUE[ch]);
		m_histogram_synthesis[level][ch][bin_old] -= delta_histogram;
		m_histogram_synthesis[level][ch][bin_new] += delta_histogram;
	}
}
void KCore::calcHistogram_exemplar (int level) {
	m_histogram_exemplar[level].clear();
	m_histogram_exemplar[level].resize(NUM_CHANNEL, vector<double>(NUM_HISTOGRAM_BIN, 0));
	double delta_histogram = 1. / (3 * TEXSIZE[level] * TEXSIZE[level]);
	vector<double>* p[3] = { &m_exemplar_x[level], &m_exemplar_y[level], &m_exemplar_z[level] };
	for (int ori = 0; ori < 3; ++ori) {
		for (int i = 0; i < TEXSIZE[level] * TEXSIZE[level]; ++i) {
			for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
				double c = (*p[ori])[NUM_CHANNEL * i + ch];
				int bin  = (int)(c * NUM_HISTOGRAM_BIN / CHANNEL_MAXVALUE[ch]);
				m_histogram_exemplar[level][ch][bin] += delta_histogram;
			}
		}
	}
}

void KCore::initVolume(int level) {
	vector<double>* p[3] = { &m_exemplar_x[level], &m_exemplar_y[level], &m_exemplar_z[level] };
	for (int xyz = 0; xyz < TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]; ++xyz) {
		int index2 = NUM_CHANNEL * (rand() % (TEXSIZE[level] * TEXSIZE[level]));
		int ori = rand() % 3;
		for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
			m_volume[level][NUM_CHANNEL * xyz + ch] = p[ori]->operator[](index2 + ch);
		}
	}
}

void KCore::searchVolume(int level) {
	long time_start = clock();
	const double min_dist = 0.00000000001;
	printf("phase1:searching");
	vector<int> nearest_x_index_old = m_volume_nearest_x_index[level];
	vector<int> nearest_y_index_old = m_volume_nearest_y_index[level];
	vector<int> nearest_z_index_old = m_volume_nearest_z_index[level];
	double global_energy_new = 0;
	int cnt_nearest_index_new = 0;
	for (int i = 0; i < TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]; ++i) {
		if (i % (TEXSIZE[level] * TEXSIZE[level]) == 0) printf(".");
		int x =  i %  TEXSIZE[level];
		int y = (i /  TEXSIZE[level]) % TEXSIZE[level];
		int z =  i / (TEXSIZE[level]  * TEXSIZE[level]);
		// obtain current neighborhood_x from volume
		CvMat* current_neighbor_x = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		CvMat* current_neighbor_y = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		CvMat* current_neighbor_z = cvCreateMat(1, D_NEIGHBOR[level], CV_64F);
		int index = 0;
		for (int dv = -N[level]; dv <= N[level]; ++dv) {
			for (int du = -N[level]; du <= N[level]; ++du) {
				int index2_x = NUM_CHANNEL * (TEXSIZE[level] * TEXSIZE[level] * trimIndex(level, z + dv) + TEXSIZE[level] * trimIndex(level, y + du) + x);
				int index2_y = NUM_CHANNEL * (TEXSIZE[level] * TEXSIZE[level] * trimIndex(level, z + du) + TEXSIZE[level] * y + trimIndex(level, x + dv));
				int index2_z = NUM_CHANNEL * (TEXSIZE[level] * TEXSIZE[level] * z + TEXSIZE[level] * trimIndex(level, y + dv) + trimIndex(level, x + du));
				for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
					cvmSet(current_neighbor_x, 0, index + ch, m_volume[level][index2_x + ch]);
					cvmSet(current_neighbor_y, 0, index + ch, m_volume[level][index2_y + ch]);
					cvmSet(current_neighbor_z, 0, index + ch, m_volume[level][index2_z + ch]);
				}
				index += NUM_CHANNEL;
			}
		}
		// PCA projection
		int dimPCA_x = mp_neighbor_pca_eigenvec_x[level]->rows;
		int dimPCA_y = mp_neighbor_pca_eigenvec_y[level]->rows;
		int dimPCA_z = mp_neighbor_pca_eigenvec_z[level]->rows;
		CvMat* current_neighbor_x_projected = cvCreateMat(1, dimPCA_x, CV_64F);
		CvMat* current_neighbor_y_projected = cvCreateMat(1, dimPCA_y, CV_64F);
		CvMat* current_neighbor_z_projected = cvCreateMat(1, dimPCA_z, CV_64F);
		cvProjectPCA(current_neighbor_x, mp_neighbor_pca_average_x[level], mp_neighbor_pca_eigenvec_x[level], current_neighbor_x_projected);
		cvProjectPCA(current_neighbor_y, mp_neighbor_pca_average_y[level], mp_neighbor_pca_eigenvec_y[level], current_neighbor_y_projected);
		cvProjectPCA(current_neighbor_z, mp_neighbor_pca_average_z[level], mp_neighbor_pca_eigenvec_z[level], current_neighbor_z_projected);
		// ANN search!
		int ann_index_x;
		int ann_index_y;
		int ann_index_z;
		double ann_dist_x;
		double ann_dist_y;
		double ann_dist_z;
		mp_neighbor_kdTree_x[level]->annkSearch(current_neighbor_x_projected->data.db, 1, &ann_index_x, &ann_dist_x);
		mp_neighbor_kdTree_y[level]->annkSearch(current_neighbor_y_projected->data.db, 1, &ann_index_y, &ann_dist_y);
		mp_neighbor_kdTree_z[level]->annkSearch(current_neighbor_z_projected->data.db, 1, &ann_index_z, &ann_dist_z);
		// CV release
		cvReleaseMat(&current_neighbor_x);
		cvReleaseMat(&current_neighbor_y);
		cvReleaseMat(&current_neighbor_z);
		cvReleaseMat(&current_neighbor_x_projected);
		cvReleaseMat(&current_neighbor_y_projected);
		cvReleaseMat(&current_neighbor_z_projected);
		m_volume_nearest_x_index[level][i] = ann_index_x;
		m_volume_nearest_y_index[level][i] = ann_index_y;
		m_volume_nearest_z_index[level][i] = ann_index_z;
		m_volume_nearest_x_dist [level][i] = ann_dist_x + min_dist;
		m_volume_nearest_y_dist [level][i] = ann_dist_y + min_dist;
		m_volume_nearest_z_dist [level][i] = ann_dist_z + min_dist;
		if (m_volume_nearest_x_index[level][i] != nearest_x_index_old[i]) ++cnt_nearest_index_new;
		if (m_volume_nearest_y_index[level][i] != nearest_y_index_old[i]) ++cnt_nearest_index_new;
		if (m_volume_nearest_z_index[level][i] != nearest_z_index_old[i]) ++cnt_nearest_index_new;
		global_energy_new += m_volume_nearest_x_dist[level][i];
		global_energy_new += m_volume_nearest_y_dist[level][i];
		global_energy_new += m_volume_nearest_z_dist[level][i];
	}
	long time_end = clock();
	printf("done. clocks = %ld\n", (time_end - time_start));
	printf("updated NN:%d, global energy:%f\n", cnt_nearest_index_new, global_energy_new);
}

void KCore::initPermutation(int level) {
	for (int i = 0; i < TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]; ++i) {
		m_permutation_xyz[level][i] = i;
	}
	random_shuffle(m_permutation_xyz[level].begin(), m_permutation_xyz[level].end());
}

void KCore::optimizeVolume(int level) {
	long time_start = clock();
	initPermutation(level);
	printf("phase2:optimizing");
	for (int i2 = 0; i2 < TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]; ++i2) {
		int i = m_permutation_xyz[level][i2];
		int x = i % TEXSIZE[level];
		int y = (i / TEXSIZE[level]) % TEXSIZE[level];
		int z = i / (TEXSIZE[level] * TEXSIZE[level]);
		double weight_acc = 0;
		vector<double> color_acc(NUM_CHANNEL, 0);
		if (i2 % (TEXSIZE[level] * TEXSIZE[level]) == 0) printf(".");
		int m = 0;
		for (int dv = -N[level]; dv <= N[level]; ++dv) {
			for (int du = -N[level]; du <= N[level]; ++du) {
				int index2_x = TEXSIZE[level] * TEXSIZE[level] * trimIndex(level, z + dv) + TEXSIZE[level] * trimIndex(level, y + du) + x;
				int index2_y = TEXSIZE[level] * TEXSIZE[level] * trimIndex(level, z + du) + TEXSIZE[level] * y + trimIndex(level, x + dv);
				int index2_z = TEXSIZE[level] * TEXSIZE[level] * z + TEXSIZE[level] * trimIndex(level, y + dv) + trimIndex(level, x + du);
				int index2[3] = { index2_x, index2_y, index2_z };
				vector<int>   * volume_nearest_index[3] = { &m_volume_nearest_x_index[level], &m_volume_nearest_y_index[level], &m_volume_nearest_z_index[level] };
				vector<double>* volume_nearest_dist [3] = { &m_volume_nearest_x_dist [level], &m_volume_nearest_y_dist [level], &m_volume_nearest_z_dist [level] };
				vector<double>* neighbor[3] = { &m_neighbor_x[level], &m_neighbor_y[level], &m_neighbor_z[level] };
				for (int ori = 0; ori < 3; ++ori) {
					int    nearest_index = (*volume_nearest_index[ori])[index2[ori]];
					double nearest_dist  = (*volume_nearest_dist [ori])[index2[ori]];
					double* p_neighbor = &(*neighbor[ori])[D_NEIGHBOR[level] * nearest_index];
					// color of overlapping neighborhood pixel
					vector<double> color(NUM_CHANNEL);
					for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
						color[ch] = p_neighbor[NUM_CHANNEL * (NEIGHBORSIZE[level] - 1 - m) + ch];
					}
					// blending weight of this color according to matching distance
					double weight = pow(nearest_dist, -0.6);
					// modify weight according to histogram matching
					double histogram_matching = 0;
					for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
						int bin = (int)(color[ch] * NUM_HISTOGRAM_BIN / CHANNEL_MAXVALUE[ch]);
						double histogram_exemplar  = m_histogram_exemplar [level][ch][bin];		// [0, 1]
						double histogram_synthesis = m_histogram_synthesis[level][ch][bin];		// [0, 1]
						histogram_matching += max(0, histogram_synthesis - histogram_exemplar);		// [0, 1]
					}
					weight *= 1 / (1 + WEIGHT_HISTOGRAM * histogram_matching);
					// accumulate color
					for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
						color_acc[ch] += weight * color[ch];
					}
					weight_acc += weight;
				}
				++m;
			}
		}
		// old & new colors for this voxel
		vector<double> color_old(NUM_CHANNEL);
		vector<double> color_new(NUM_CHANNEL);
		for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
			color_old[ch] = m_volume[level][NUM_CHANNEL * i + ch];
			color_new[ch] = color_acc[ch] / weight_acc;
		}
		// histogram update
		updateHistogram_synthesis(level, color_old, color_new);
		// voxel update
		for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
			m_volume[level][NUM_CHANNEL * i + ch] = color_new[ch];
		}
	}
	long time_end = clock();
	printf("done. clocks = %ld\n", (time_end - time_start));
}

void KCore::upsampleVolume(int level) {
	printf("upsample from level %d to level %d\n", level, level + 1);
	static const bool flag[8][8] = {
		{true , false, false, false, false, false, false, false},
		{true , true , false, false, false, false, false, false}, 
		{true , false, true , false, false, false, false, false},
		{true , true , true , true , false, false, false, false},
		{true , false, false, false, true , false, false, false},
		{true , true , false, false, true , true , false, false},
		{true , false, true , false, true , false, true , false},
		{true , true , true , true , true , true , true , true }};
	for (int z = 0; z < TEXSIZE[level]; ++z) {
		for (int y = 0; y < TEXSIZE[level]; ++y) {
			for (int x = 0; x < TEXSIZE[level]; ++x) {
				int index[8];
				for (int dz = 0; dz < 2; ++dz) {
					for (int dy = 0; dy < 2; ++dy) {
						for (int dx = 0; dx < 2; ++dx) {
							index[4 * dz + 2 * dy + dx] = NUM_CHANNEL * (
								TEXSIZE[level] * TEXSIZE[level] * min(z + dz, TEXSIZE[level] - 1) + 
								TEXSIZE[level] * trimIndex(level, y + dy) +
								trimIndex(level, x + dx));
						}
					}
				}
				for (int dz = 0; dz < 2; ++dz) {
					for (int dy = 0; dy < 2; ++dy) {
						for (int dx = 0; dx < 2; ++dx) {
							int index2 = NUM_CHANNEL * (TEXSIZE[level + 1] * TEXSIZE[level + 1] * (2 * z + dz) + TEXSIZE[level + 1] * (2 * y + dy) + 2 * x + dx);
							vector<double> color(NUM_CHANNEL, 0);
							int cnt = 0;
							for (int i = 0; i < 8; ++i) {
								if (flag[4 * dz + 2 * dy + dx][i]) {
									for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
										color[ch] += m_volume[level][index[i] + ch];
									}
									++cnt;
								}
							}
							for (int ch = 0; ch < NUM_CHANNEL; ++ch) {
								color[ch] /= cnt;
								m_volume[level + 1][index2 + ch] = color[ch];
							}
						}
					}
				}
			}
		}
	}
}

void KCore::calcVolume_uchar(int level) {
	for (int i = 0; i < TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level]; ++i) {
		m_volume_uchar[level][3 * i    ] = (GLubyte)max(min(255, m_volume[level][NUM_CHANNEL * i    ]), 0);
		m_volume_uchar[level][3 * i + 1] = (GLubyte)max(min(255, m_volume[level][NUM_CHANNEL * i + 1]), 0);
		m_volume_uchar[level][3 * i + 2] = (GLubyte)max(min(255, m_volume[level][NUM_CHANNEL * i + 2]), 0);
	}
}

void KCore::saveVolume_uchar(int level, const CString& fname) {
	struct VolumeHeader
	{
		char magic[4];
		int version;
		char texName[256];
		bool wrap;
		int volSize;
		int numChannels;
		int bytesPerChannel;
	};
	FILE * fout = fopen(fname, "wb");
	char buf[4096];
	VolumeHeader* header = (VolumeHeader *)buf;
	header->magic[0] = 'V';
	header->magic[1] = 'O';
	header->magic[2] = 'L';
	header->magic[3] = 'U';
	header->bytesPerChannel = 1;
	header->version = 4;
	header->volSize = TEXSIZE[level];
	header->numChannels = 3;
	sprintf(header->texName, "Created by LayeredSolidSynthesis");
	fwrite(buf, 1, 4096, fout);
	int volBytes = TEXSIZE[level] * TEXSIZE[level] * TEXSIZE[level] * 3;
	fwrite(&m_volume_uchar[level][0], 1, volBytes, fout);
	fclose(fout);
}

