#include "StdAfx.h"
#include "Drawer.h"
#include "MainFrm.h"
#include <KLIB/KUtil.h>
#include <KLIB/KDrawer.h>
#include "StateDrawStroke.h"
#include "StateSetS1.h"

#include <gl/glext.h>

using namespace std;

State* StateDrawStroke::next() {
	return 0;//StateSetS1::getInstance();
}

void StateDrawStroke::init() {
	Core& core = *Core::getInstance();
	CMainFrame& f = *core.p_mainFrm;
	f.ShowControlBar(&f.m_wndToolBar_setdepth, false, true);
	f.ShowControlBar(&f.m_wndToolBar_drawstroke, true, true);
	core.m_strokes.clear();
}

void StateDrawStroke::draw() {
	Core& core = *Core::getInstance();
	if (core.m_showStreamLines) {
		glDisable(GL_LIGHTING);
		vector<vector<pair<KVector3d, double> > >& streamLines =
			core.m_viewMode == Core::VIEWMODE_CUT ? core.m_streamLinesPoly : core.m_streamLinesPolyLayers[core.m_currentLayer];
		glColor3dv(Drawer::COLOR_FACE);
		glEnable(GL_TEXTURE_1D);
		glBindTexture(GL_TEXTURE_1D, core.m_drawer.m_texNameDepth);
		glLineWidth(2);
		glEnable(GL_BLEND);
		for (int i = 0; i < (int)streamLines.size(); ++i) {
			vector<pair<KVector3d, double> >& streamLine = streamLines[i];
			glBegin(GL_LINE_STRIP);
			for (int j = 0; j < (int)streamLine.size(); ++j) {
				glTexCoord1d(-0.5 * streamLine[j].second);
				glVertex3dv(streamLine[j].first.getPtr());
			}
			glEnd();
		}
		glDisable(GL_BLEND);
		glDisable(GL_TEXTURE_1D);
		glEnable(GL_LIGHTING);
	} else {
		KPolygonModel& poly =
			core.m_viewMode == Core::VIEWMODE_CUT ? core.m_poly : core.m_polyLayers[core.m_currentLayer];
		glColor3dv(Drawer::COLOR_FACE);
		//if (m_useTexture) {
		//	glEnable(GL_TEXTURE_3D);
		//	glBindTexture(GL_TEXTURE_3D, core.m_drawer.m_texNameLIC);
		//}
		glBegin(GL_TRIANGLES);
		for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
			KPolygon& p = poly.m_polygons[i];
			for (int j = 0; j < 3; ++j) {
				KVector3d& n = p.m_normal[j];
				KVector3d& v = poly.m_vertices[p.m_vtx[j]].m_pos;
				glNormal3dv(n.getPtr());
				//if (m_useTexture) glTexCoord3dv(v.getPtr());
				glVertex3dv(v.getPtr());
			}
		}
		glEnd();
		glColor3dv(Drawer::COLOR_STROKE);
		for (int i = 0; i < (int)core.m_strokes.size(); ++i) {
			vector<KVector3d>& stroke = core.m_strokes[i];
			for (int j = 1; j < (int)stroke.size(); ++j) {
				KVector3d& start = stroke[j - 1];
				KVector3d  ori   = stroke[j];
				ori.sub(start);
				double radius = 0.01;
				KDrawer::drawCylinder(start, ori, radius);
				if (j == (int)stroke.size() - 1) KDrawer::drawCone(stroke.back(), ori, 2 * radius, 0.05);
			}
		}
	}
	//if (m_useTexture) glDisable(GL_TEXTURE_3D);
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDepthMask(GL_FALSE);
	glColor3dv(Drawer::COLOR_CUTSTROKE);
	glLineWidth(5);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < (int)core.m_cutStroke.size(); ++i)
		glVertex3dv(core.m_cutStroke[i].getPtr());
	glEnd();
	glDepthMask(GL_TRUE);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
}

void StateDrawStroke::postDraw(CWnd* hWnd, CDC* pDC) {
	Core& core = *Core::getInstance();
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	pDC->DrawText ( "Draw strokes!", -1, &rc, DT_LEFT | DT_TOP | DT_SINGLELINE);
	pDC->SelectObject ( pOldFont );
}

void StateDrawStroke::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KPolygonModel& poly = core.m_viewMode == Core::VIEWMODE_CUT ? core.m_poly : core.m_polyLayers[core.m_currentLayer];
	KVector3d pos;
	int polyID;
	m_pointOld = point;
	if (!core.m_showStreamLines && KUtil::getIntersection(pos, polyID, poly, start, ori)) {
		core.m_strokes.push_back(vector<KVector3d>());
		core.m_strokes.back().push_back(pos);
		m_isDrawing = true;
	} else if (core.m_viewMode == Core::VIEWMODE_CUT) {
		start.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(start);
		m_isCutting = true;
		core.initPoly();
		core.initStreamLinesPoly();
	}
	core.m_ogl.RedrawWindow();
}

void StateDrawStroke::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	m_isDrawing = false;
	if (!m_isCutting) return;
	m_isCutting = false;
	if (core.m_cutStroke.size() == 1) {
		core.m_cutStroke.clear();
		return;
	} else {
		core.calcPoly(core.m_cutStroke);
		core.calcStreamLinesPoly(core.m_cutStroke);
	}
	core.m_cutStroke.clear();
	core.m_ogl.RedrawWindow();
}

void StateDrawStroke::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isCutting || m_isDrawing) {
		double dx = point.x - m_pointOld.x;
		double dy = point.y - m_pointOld.y;
		double dist = sqrt(dx * dx + dy * dy);
		KVector3d start, ori;
		core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
		if (m_isCutting) {
			if (dist < 20) return;
			m_pointOld = point;
			KVector3d pos(start);
			pos.addWeighted(ori, 0.5);
			core.m_cutStroke.push_back(pos);
			core.m_ogl.RedrawWindow();
		} else {
			if (dist < 30) return;
			m_pointOld = point;
			KPolygonModel& poly = core.m_viewMode == Core::VIEWMODE_CUT ? core.m_poly : core.m_polyLayers[core.m_currentLayer];
			KVector3d pos;
			int polyID;
			if (KUtil::getIntersection(pos, polyID, poly, start, ori)) {
				core.m_strokes.back().push_back(pos);
			}
			core.m_ogl.RedrawWindow();
		}
	}
}

void StateDrawStroke::OnKeyDown(CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {
	Core& core = *Core::getInstance();
	switch (nChar) {
	case 'S':
		{
			FILE* fout = fopen(core.m_fname + ".stroke", "wb");
			int numStroke = (int)core.m_strokes.size();
			fwrite(&numStroke, sizeof(int), 1, fout);
			for (int i = 0; i < numStroke; ++i) {
				int numPoint = (int)core.m_strokes[i].size();
				fwrite(&numStroke, sizeof(int), 1, fout);
				fwrite(&core.m_strokes[i][0], sizeof(KVector3d), numPoint, fout);
			}
			fclose(fout);
		}
		break;
	}
}

bool StateDrawStroke::load(const string& fname) {
	Core& core = *Core::getInstance();
	string ext = fname.substr(fname.size() - 7, 7);
	if (ext.compare(".stroke")) {
		CString str;
		str.Format("Please drop *.stroke file");
		AfxMessageBox(str);
		return false;
	}
	FILE * fin = fopen(fname.c_str(), "rb");
	if (!fin) {
		CString str;
		str.Format("Failed to open file %s", fname.c_str());
		AfxMessageBox(str);
		return false;
	}
	
	int numStrokes;
	fread(&numStrokes, sizeof(int), 1, fin);
	vector<vector<KVector3d> > strokes;
	strokes.reserve(numStrokes);
	for (int i = 0; i < numStrokes; ++i) {
		int numPoints;
		fread(&numPoints, sizeof(int), 1, fin);
		vector<KVector3d> stroke(numPoints);
		fread(&stroke[0], sizeof(KVector3d), numPoints, fin);
		strokes.push_back(stroke);
	}
	
	fclose(fin);
	core.m_strokes = strokes;
	return true;
}

void StateDrawStroke::undo() {
	Core::getInstance()->m_strokes.pop_back();
}

bool StateDrawStroke::isUndoable() {
	return !Core::getInstance()->m_strokes.empty();
}

void StateDrawStroke::save() {
	Core& core = *Core::getInstance();
	CFileDialog dialog(FALSE, ".stroke", NULL, OFN_OVERWRITEPROMPT, "Stroke files(*.stroke)|*.stroke||");
	if (dialog.DoModal() != IDOK) return;
	string fname = dialog.GetPathName();
	FILE * fout = fopen(fname.c_str(), "wb");
	if (!fout) {
		CString str;
		str.Format("Failed to open file %s", fname.c_str());
		AfxMessageBox(str);
		return;
	}
	
	int numStrokes = (int)core.m_strokes.size();
	fwrite(&numStrokes, sizeof(int), 1, fout);
	for (int i = 0; i < numStrokes; ++i) {
		vector<KVector3d>& stroke = core.m_strokes[i];
		int numPoints = (int)stroke.size();
		fwrite(&numPoints, sizeof(int), 1, fout);
		fwrite(&stroke[0], sizeof(KVector3d), numPoints, fout);
	}
	
	fclose(fout);
}

bool StateDrawStroke::isSavable() {
	return !Core::getInstance()->m_strokes.empty();
}

void StateDrawStroke::update() {
	Core& core = *Core::getInstance();
	core.calcVtxFiber();
	core.calcVolFiber();
	core.calcStreamLines();
	core.initStreamLinesPoly();
	core.calcStreamLinesPolyLayers();
	//core.m_drawer.genTexLIC(Core::VOL_SIZE, core.m_volFiber, 5);
}
