#include "StdAfx.h"
#include "KMath.h"

