#pragma once

#include "Drawer.h"
#include "EventHandler.h"
#include "State.h"
#include <KLIB/KLaplacianSmoothing.h>

#include <KLIB/KOGL.h>
#include <KLIB/KGeometry.h>
#include <KLIB/KRBF.h>
#include <KLIB/KUmfpackSparseMatrix.h>

#include <vector>
#include <map>

class CMainFrame;

class Core
{
public:
	static const double GRADIENT_DELTA;
	static const double LAMBDA_EUCLID;
	static const double LAMBDA_DEPTH;
	static const int VOL_SIZE;
	static const int LAYER_MAX;

protected:
	Core(void);
	~Core(void) {}
public:
	static Core* getInstance() {
		static Core p;
		return &p;
	}
	
	KOGL m_ogl;
	Drawer m_drawer;
	EventHandler m_handler;
	State* m_state;
	
	CMainFrame* p_mainFrm;
	
	enum ViewMode {
		VIEWMODE_CUT,
		VIEWMODE_LAYER
	} m_viewMode;
	
	// tetra model of the heart
	KTetraModel m_tetra;
	CString m_fname;
	/////////////////////////////
	//                         //
	// set by [StateLoadTetra] //
	//                         //
	/////////////////////////////
	
	// polygon model for displaying
	KPolygonModel m_poly, m_polyContour;
	void initPoly();
	void initPolyContour();
	// cutting
	std::vector<KVector3d> m_cutStroke;
	void calcPoly(const std::vector<KVector3d>& cutStroke);
	
	// tetra ID to which each voxel belongs
	std::vector<int>       m_volTetID;
	void calcVolTetID();
	
	// boundary tetra vertices
	std::vector<bool> m_isTetVtxBoundary;
	std::vector<KVector3d> m_tetVtxBoundaryNormal;
	void calcTetVtxBoundary();
	
	// pairs of point and value for depth field
	std::vector<KVector3d> m_rbfPoints;
	std::vector<double>    m_rbfValues;
	////////////////////////////
	//                        //
	// set by [StateSetDepth] //
	//                        //
	////////////////////////////
	
	// depth field represented as 3D-RBF
	KThinPlate3D m_rbfDepth;
	void calcRbfDepth();
	
	// depth field over the tetra vtx
	std::vector<double> m_vtxDepth;
	void calcVtxDepth();
	
	// layers (iso-surface of the depth field)
	std::vector<KPolygonModel> m_polyLayers;
	int m_currentLayer;
	void calcPolyLayers();
	
	// depth value assigned to each polygon vertex (for 1-D texturing)
	std::vector<double> m_polyVtxDepth;
	std::vector<std::vector<double> > m_polyLayersVtxDepth;
	void calcPolyVtxDepth();
	void calcPolyLayersVtxDepth();
	
	// depth value assigned to each voxel
	std::vector<double>    m_volDepth;
	void calcVolDepth();
	
	// Laplacian smoothing object (considering depth)
	KLaplacianSmoothing m_laplacian;
	void calcLaplacian();
	
	// strokes to specify vector field
	std::vector<std::vector<KVector3d> > m_strokes;
	//////////////////////////////
	//                          //
	// set by [StateDrawStroke] //
	//                          //
	//////////////////////////////
	
	// fiber orientation (unnormalized) assigned to each vtx
	std::vector<KVector3d> m_vtxFiber;
	void calcVtxFiber();
	
	// fiber orientation (unnormalized) assigned to each voxel
	std::vector<KVector3d> m_volFiber;
	void calcVolFiber();
	
	// streamlines that represent fiber orientation
	bool m_showStreamLines;
	std::vector<std::vector<std::pair<KVector3d, double> > > m_streamLines;
	std::vector<std::vector<std::pair<KVector3d, double> > > m_streamLinesPoly;
	std::vector<std::vector<std::vector<std::pair<KVector3d, double> > > > m_streamLinesPolyLayers;
	void calcStreamLines();
	void initStreamLinesPoly();
	void calcStreamLinesPoly(const std::vector<KVector3d>& cutStroke);
	void calcStreamLinesPolyLayers();
	
	// s1 points for the heart
	std::vector<KVector3d> m_s1Points;
	//////////////////////////////
	//                          //
	// set by [StateSetS1] //
	//                          //
	//////////////////////////////
	
	// parameters for FFD
	KVector3d m_deformOrigin;
	double    m_deformRadius;
	KVector3d m_deformOffset;
	///////////////////////////////
	//                           //
	// set by [StateDeformTetra] //
	//                           //
	///////////////////////////////
	
	std::vector<int>       m_deformVtxList;
	std::vector<double>    m_deformVtxWeight;
	std::vector<KVector3d> m_deformVtxOffset;
	void calcDeformVtxList  (const KVector3d& origin, double radius);
	void calcDeformVtxOffset(const KVector3d& offset);
	
	// tetra deformation (and corresponding transformation of depth & stroke)
	void deformTetra(const std::vector<KVector3d>& vtxPosNew);
	KVector3d transform(
		const KTetraModel& tetraOld,
		const KTetraModel& tetraNew,
		const KVector3d& pos);
	
	// export volume fiber data
	void exportVolData();
	
	void initEyePosition();

	static double i2d(int i) {
		const int& N = VOL_SIZE;
		return i / (N - 1.);
	}
	static int d2i(double d) {
		const int& N = VOL_SIZE;
		int i = (int)(d * (N - 1));
		if (d * (N - 1) - i > 0.5) ++i;
		return i;
	}
	static int getIndex(int ix, int iy, int iz) {
		const int& N = VOL_SIZE;
		if (ix < 0 || ix >= N || iy < 0 || iy >= N || iz < 0 || iz >= N) return -1;
		return ix + N * iy + N * N * iz;
	}
};
