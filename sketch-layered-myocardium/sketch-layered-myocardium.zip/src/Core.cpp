#include "StdAfx.h"
#include "Core.h"

#include <KLIB/KMarchingTetra.h>
#include <KLIB/KUtil.h>
#include <KLIB/KUmfpack.h>
#include <KLIB/KUmfpackSparseMatrix.h>

#include "StateLoadTetra.h"

#include <gl/glext.h>
PFNGLTEXIMAGE3DPROC glTexImage3D;

#include <iostream>
#include <fstream>
#include <algorithm>
#include <set>

#include <ctime>
#include <cstdlib>

using namespace std;

const double Core::GRADIENT_DELTA = 0.005;
const int Core::LAYER_MAX = 9;
const int Core::VOL_SIZE = 64;
const double Core::LAMBDA_EUCLID = 1;
const double Core::LAMBDA_DEPTH  = 5;

Core::Core(void) {
	m_state = StateLoadTetra::getInstance();
	m_state->init();
	m_viewMode = VIEWMODE_CUT;
	m_currentLayer = 0;
	srand( static_cast<unsigned int>( time(NULL) ) );
}

void Core::initPoly() {
	m_poly = m_tetra.toPolygonModel();
	m_poly.calcSmoothNormals();
}

void Core::initPolyContour() {
	m_polyContour = m_tetra.toPolygonModel();
	m_polyContour.calcSmoothNormals();
}

void Core::calcPoly(const vector<KVector3d>& cutStroke) {
	KThinPlate2D rbfCut;
	{
		// construct 2D-RBF height field by projecting cutStroke onto the screen
		vector<KVector2d> cutStroke2D;
		for (int i = 0; i < (int)cutStroke.size(); ++i) {
			const KVector3d& pos = cutStroke[i];
			double winx, winy, winz;
			m_ogl.project(pos.x, pos.y, pos.z, winx, winy, winz);
			cutStroke2D.push_back(KVector2d(winx, winy));
		}
		vector<KVector2d> points;
		vector<double   > values;
		for (int i = 1; i < (int)cutStroke2D.size(); ++i) {
			KVector2d& p0 = cutStroke2D[i - 1];
			KVector2d& p1 = cutStroke2D[i];
			KVector2d d(p1);
			d.sub(p0);
			d.normalize();
			d.scale(10);
			KVector2d cp(p0), cm(p0);
			cp.add(-d.y, d.x);
			cm.add(d.y, -d.x);
			points.push_back(cp);
			points.push_back(cm);
			values.push_back( 1);
			values.push_back(-1);
		}
		rbfCut.setPoints(points);
		rbfCut.setValues(values);
	}
	vector<double> vtxValue(m_tetra.m_vertices.size());
	{
		// calc vtxValue of the height field by projecting each tetra vtx
		for (int i = 0; i < (int)m_tetra.m_vertices.size(); ++i) {
			KVector3d& pos = m_tetra.m_vertices[i].m_pos;
			double winx, winy, winz;
			m_ogl.project(pos.x, pos.y, pos.z, winx, winy, winz);
			double val = rbfCut.getValue(winx, winy);
			vtxValue[i] = val;
		}
	}
	m_poly = KMarchingTetra::calcMarchingTetra(m_tetra, vtxValue, 0);
	m_poly.calcSmoothNormals();
}

void Core::calcVolTetID() {
	const int& N = VOL_SIZE;
	m_volTetID.clear();
	m_volTetID.resize(N * N * N, -1);
	for (int i = 0; i < (int)m_tetra.m_tetras.size(); ++i) {
		KTetra& tet = m_tetra.m_tetras[i];
		double zmin =  DBL_MAX;
		double zmax = -DBL_MAX;
		for (int j = 0; j < 4; ++j) {
			KVector3d& pos = m_tetra.m_vertices[tet.m_vtx[j]].m_pos;
			zmin = min(pos.z, zmin);
			zmax = max(pos.z, zmax);
		}
		int izmin = (int)(zmin * (N - 1));
		int izmax = (int)(zmax * (N - 1));
		if (izmin < zmin * (N - 1)) ++izmin;
		for (int iz = izmin; iz <= izmax; ++iz) {
			if (iz < 0 || iz >= N) continue;
			double dz = iz / (N - 1.);
			vector<KVector3d> intersectZ;
			intersectZ.reserve(4);
			for (int j = 0; j < 4; ++j) {
				KVector3d& pos0 = m_tetra.m_vertices[tet.m_vtx[j]].m_pos;
				double uz0 = pos0.z - dz;
				for (int k = j + 1; k < 4; ++k) {
					KVector3d& pos1 = m_tetra.m_vertices[tet.m_vtx[k]].m_pos;
					double uz1 = pos1.z - dz;
					if (uz0 * uz1 <= 0) {
						KVector3d pos;
						pos.addWeighted(pos0, abs(uz1 / (uz1 - uz0)));
						pos.addWeighted(pos1, abs(uz0 / (uz1 - uz0)));
						intersectZ.push_back(pos);
					}
				}
			}
			double ymin =  DBL_MAX;
			double ymax = -DBL_MAX;
			for (int j = 0; j < (int)intersectZ.size(); ++j) {
				KVector3d& pos = intersectZ[j];
				ymin = min(pos.y, ymin);
				ymax = max(pos.y, ymax);
			}
			int iymin = (int)(ymin * (N - 1));
			int iymax = (int)(ymax * (N - 1));
			if (iymin < ymin * (N - 1)) ++iymin;
			for (int iy = iymin; iy <= iymax; ++iy) {
				if (iy < 0 || iy >= N) continue;
				double dy = iy / (N - 1.);
				vector<KVector3d> intersectY;
				intersectY.reserve(4);
				for (int j = 0; j < (int)intersectZ.size(); ++j) {
					KVector3d& pos0 = intersectZ[j];
					double uy0 = pos0.y - dy;
					for (int k = j + 1; k < (int)intersectZ.size(); ++k) {
						KVector3d& pos1 = intersectZ[k];
						double uy1 = pos1.y - dy;
						if (uy0 * uy1 <= 0) {
							KVector3d pos;
							pos.addWeighted(pos0, abs(uy1 / (uy1 - uy0)));
							pos.addWeighted(pos1, abs(uy0 / (uy1 - uy0)));
							intersectY.push_back(pos);
						}
					}
				}
				double xmin =  DBL_MAX;
				double xmax = -DBL_MAX;
				for (int j = 0; j < (int)intersectY.size(); ++j) {
					KVector3d& pos = intersectY[j];
					xmin = min(pos.x, xmin);
					xmax = max(pos.x, xmax);
				}
				int ixmin = (int)(xmin * (N - 1));
				int ixmax = (int)(xmax * (N - 1));
				if (ixmin < xmin * (N -1)) ++ixmin;
				for (int ix = ixmin; ix <= ixmax; ++ix) {
					if (ix < 0 || ix >= N) continue;
					m_volTetID[ix + N * iy + N * N * iz] = i;
				}
			}
		}
	}
}

void Core::calcTetVtxBoundary() {
	int numVtx = (int)m_tetra.m_vertices.size();
	m_isTetVtxBoundary    .clear();
	m_tetVtxBoundaryNormal.clear();
	m_isTetVtxBoundary    .resize(numVtx, false);
	m_tetVtxBoundaryNormal.resize(numVtx, KVector3d());
	for (int i = 0; i < (int)m_tetra.m_tetras.size(); ++i) {
		KTetra& tet = m_tetra.m_tetras[i];
		for (int j = 0; j < 4; ++j) {
			if (tet.m_neighbor[j] != -1) continue;
			KVector3d& n = KUtil::calcNormal(
				m_tetra.m_vertices[tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][0]]].m_pos,
				m_tetra.m_vertices[tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][1]]].m_pos,
				m_tetra.m_vertices[tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][2]]].m_pos);
			for (int k = 0; k < 3; ++k) {
				int vtxID = tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][k]];
				m_isTetVtxBoundary[vtxID] = true;
				m_tetVtxBoundaryNormal[vtxID].add(n);
			}
		}
	}
	for (int i = 0; i < numVtx; ++i) {
		if (!m_isTetVtxBoundary[i]) continue;
		m_tetVtxBoundaryNormal[i].normalize();
	}
}

void Core::calcRbfDepth() {
	m_rbfDepth.setPoints(m_rbfPoints);
	m_rbfDepth.setValues(m_rbfValues);
}

void Core::calcVtxDepth() {
	int vtxSize = (int)m_tetra.m_vertices.size();
	m_vtxDepth.resize(vtxSize);
	for (int i = 0; i < vtxSize; ++i) {
		KVector3d& pos = m_tetra.m_vertices[i].m_pos;
		m_vtxDepth[i] = m_rbfDepth.getValue(pos);
	}
}

void Core::calcPolyLayers() {
	int margin0 = 0;
	int margin1 = 1;
	m_polyLayers.clear();
	m_polyLayers.reserve(LAYER_MAX + 1);
	for (int i = 0; i <= LAYER_MAX; ++i) {
		double depth = -2 * (i + margin0) / (double)(LAYER_MAX + margin0 + margin1);
		KPolygonModel& poly = KMarchingTetra::calcMarchingTetra(m_tetra, m_vtxDepth, depth);
		poly.calcSmoothNormals();
		m_polyLayers.push_back(poly);
	}
}

void Core::calcPolyVtxDepth() {
	m_polyVtxDepth.resize(m_poly.m_vertices.size());
	for (int i = 0; i < (int)m_poly.m_vertices.size(); ++i) {
		m_polyVtxDepth[i] = m_rbfDepth.getValue(m_poly.m_vertices[i].m_pos);
	}
}

void Core::calcPolyLayersVtxDepth() {
	m_polyLayersVtxDepth.resize(LAYER_MAX + 1, vector<double>());
	for (int i = 0; i <= LAYER_MAX; ++i) {
		vector<double>& vtxDepth = m_polyLayersVtxDepth[i];
		KPolygonModel& poly = m_polyLayers[i];
		vtxDepth.resize(poly.m_vertices.size());
		for (int j = 0; j < (int)poly.m_vertices.size(); ++j)
			vtxDepth[j] = m_rbfDepth.getValue(poly.m_vertices[j].m_pos);
	}
}

void Core::calcVolDepth() {
	const int& N = VOL_SIZE;
	m_volDepth.clear();
	m_volDepth.resize(N * N * N, -DBL_MAX);
	for (int iz = 0; iz < N; ++iz) {
		double dz = iz / (N - 1.);
		for (int iy = 0; iy < N; ++iy) {
			double dy = iy / (N - 1.);
			for (int ix = 0; ix < N; ++ix) {
				double dx = ix / (N - 1.);
				int index = ix + N * iy + N * N * iz;
				int tetID = m_volTetID[index];
				if (tetID == -1) continue;
				KVector3d pos(dx, dy, dz);
				KTetra& tet = m_tetra.m_tetras[tetID];
				double w[4];
				KVector3d vtx[4];
				for (int i = 0; i < 4; ++i)
					vtx[i] = m_tetra.m_vertices[tet.m_vtx[i]].m_pos;
				KUtil::getBarycentricCoord(w[0], w[1], w[2], w[3], vtx[0], vtx[1], vtx[2], vtx[3], pos, 1);
				double depth = 0;
				for (int i = 0; i < 4; ++i)
					depth += w[i] * m_vtxDepth[tet.m_vtx[i]];
				//double depth = m_rbfDepth.getValue(dx, dy, dz);
				m_volDepth[index] = depth;
			}
		}
	}
}

void Core::calcLaplacian() {
	int N = (int)m_tetra.m_vertices.size();
	vector<set<int> > vtxNeighbor(N);
	vector<map<int, double> > vtxNeighborDistEuclid(N);
	vector<map<int, double> > vtxNeighborDistDepth (N);
	{
		// calculate neighbor around tetra vertex and its associated depth-based distance
		for (int i = 0; i < (int)m_tetra.m_tetras.size(); ++i) {
			KTetra& tet = m_tetra.m_tetras[i];
			for (int j = 0; j < 4; ++j) {
				int vID = tet.m_vtx[j];
				KVector3d& vPos = m_tetra.m_vertices[vID].m_pos;
				set<int>& vNeighbor = vtxNeighbor[vID];
				for (int k = 0; k < 3; ++k) {
					int wID = tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][k]];
					KVector3d& wPos = m_tetra.m_vertices[wID].m_pos;
					if (vNeighbor.find(wID) == vNeighbor.end()) {
						set<int>& wNeighbor = vtxNeighbor[wID];
						vNeighbor.insert(wID);
						wNeighbor.insert(vID);
						double distEuclid = KUtil::getDistance(vPos, wPos);
						double distDepth  = abs(m_vtxDepth[vID] - m_vtxDepth[wID]);
						vtxNeighborDistEuclid[vID].insert(pair<int, double>(wID, distEuclid));
						vtxNeighborDistEuclid[wID].insert(pair<int, double>(vID, distEuclid));
						vtxNeighborDistDepth [vID].insert(pair<int, double>(wID, distDepth ));
						vtxNeighborDistDepth [wID].insert(pair<int, double>(vID, distDepth ));
					}
				}
			}
		}
	}
	cout << "creating A (while considering depth) ...";
	cout << "(size : " << N << ") ...";
	KUmfpackSparseMatrix A(N, N, 30 * N);
	{
		// construct Laplacian matrix A
		double lambdaEuclid = 1;		// degree of attenuation for Euclid distance
		double lambdaDepth  = 5;		// degree of attenuation for depth distance
		for (int i = 0; i < N; ++i) {
			set<int>& neighbor = vtxNeighbor[i];
			int M = (int)neighbor.size();
			// each weight differs accorging to distance
			map<int, double>& distEuclidMap = vtxNeighborDistEuclid[i];
			map<int, double>& distDepthMap  = vtxNeighborDistDepth [i];
			vector<double> weights;
			weights.reserve(M);
			double total = 0;
			set<int>::iterator iter = neighbor.begin();
			for (int j = 0; j < M; ++j, ++iter) {
				double distEuclid = distEuclidMap.find(*iter)->second;
				double distDepth  = distDepthMap .find(*iter)->second;
				double w =
					exp(-LAMBDA_EUCLID * distEuclid * distEuclid) *
					exp(-LAMBDA_DEPTH  * distDepth  * distDepth);
				weights.push_back(w);
				total += w;
			}
			for (int j = 0; j < M; ++j) {
				weights[j] /= total;
			}
			iter = neighbor.begin();
			for (int j = 0; j < M; ++j, ++iter) {
				A.setValue(i, *iter, weights[j]);
			}
			A.setValue(i, i, -1);
		}
	}
	cout << "creating At and AtA ...";
	m_laplacian.setA(A);
	cout << "done." << endl;
}

void Core::calcVtxFiber() {
	const int& N = VOL_SIZE;
	int numVtx = (int)m_tetra.m_vertices.size();
	m_vtxFiber.clear();
	m_vtxFiber.reserve(numVtx);
	printf("constructing constraint matrix C...\n");
	vector<KVector3d> constraintPos;
	vector<double>    constraintX;
	vector<double>    constraintY;
	vector<double>    constraintZ;
	for (int i = 0; i < (int)m_strokes.size(); ++i) {
		vector<KVector3d>& stroke = m_strokes[i];
		for (int j = 1; j < (int)stroke.size(); ++j) {
			KVector3d& pos0 = stroke[j - 1];
			KVector3d& pos1 = stroke[j];
			constraintPos.push_back(pos0);
			constraintX.push_back(pos1.x - pos0.x);
			constraintY.push_back(pos1.y - pos0.y);
			constraintZ.push_back(pos1.z - pos0.z);
		}
	}
	vector<KSparseVector> C;
	vector<double>    constraintX_skip;
	vector<double>    constraintY_skip;
	vector<double>    constraintZ_skip;
	C.reserve(constraintPos.size());
	constraintX_skip.reserve(constraintPos.size());
	constraintY_skip.reserve(constraintPos.size());
	constraintZ_skip.reserve(constraintPos.size());
	for (int i = 0; i < (int)constraintPos.size(); ++i) {
		KVector3d& pos = constraintPos[i];
		int    vID[4];
		double weights[4];
		{
			int tetID;
			//KVector3d iPos(pos);
			//iPos.scale(N - 1);
			//int ix = (int)iPos.x;	if (iPos.x - ix > 0.5) ++ix;
			//int iy = (int)iPos.y;	if (iPos.y - iy > 0.5) ++iy;
			//int iz = (int)iPos.z;	if (iPos.z - iz > 0.5) ++iz;
			//if (ix < 0 || ix >= N || iy < 0 || iy >= N || iz < 0 || iz >= N) continue;
			//int index = ix + N * iy + N * N * iz;
			//tetID = m_volTetID[index];
			//if (tetID == -1) continue;
			double dist;
			KUtil::getNearestTetraID(tetID, dist, m_tetra, pos);
			KTetra& tet = m_tetra.m_tetras[tetID];
			double depth = m_rbfDepth.getValue(pos);
			double total = 0;
			for (int j = 0; j < 4; ++j) {
				vID[j] = tet.m_vtx[j];
				KVector3d& vPos = m_tetra.m_vertices[vID[j]].m_pos;
				double distEuclid = KUtil::getDistance(pos, vPos);
				double distDepth  = abs(m_vtxDepth[vID[j]] - depth);
				weights[j] =
					exp(-LAMBDA_EUCLID * distEuclid * distEuclid) *
					exp(-LAMBDA_DEPTH  * distDepth  * distDepth);
				total += weights[j];
			}
			for (int j = 0; j < 4; ++j)
				weights[j] /= total;
			//KUtil::getLinearCoefficient(w[0], w[1], w[2], w[3], v[0], v[1], v[2], v[3], pos);
		}
		KSparseVector c(numVtx, 4);
		for (int j = 0; j < 4; ++j) {
			c.setValue(vID[j], weights[j]);
		}
		C.push_back(c);
		constraintX_skip.push_back(constraintX[i]);
		constraintY_skip.push_back(constraintY[i]);
		constraintZ_skip.push_back(constraintZ[i]);
	}
	printf("setting C to the laplacian...\n");
	m_laplacian.setC(C);
	vector<double> vtxFiberX;
	vector<double> vtxFiberY;
	vector<double> vtxFiberZ;
	printf("solving component x...\n");
	m_laplacian.solve(vtxFiberX, constraintX_skip);
	printf("solving component y...\n");
	m_laplacian.solve(vtxFiberY, constraintY_skip);
	printf("solving component z...\n");
	m_laplacian.solve(vtxFiberZ, constraintZ_skip);
	for (int i = 0; i < numVtx; ++i) {
		KVector3d fiber(vtxFiberX[i], vtxFiberY[i], vtxFiberZ[i]);
		m_vtxFiber.push_back(fiber);
	}
}

void Core::calcVolFiber() {
	const int& N = VOL_SIZE;
	m_volFiber.clear();
	m_volFiber.reserve(N * N * N);
	for (int iz = 0; iz < N; ++iz) {
		double dz = iz / (N - 1.);
		for (int iy = 0; iy < N; ++iy) {
			double dy = iy / (N - 1.);
			for (int ix = 0; ix < N; ++ix) {
				double dx = ix / (N - 1.);
				int index = ix + N * iy + N * N * iz;
				int tetID = m_volTetID[index];
				if (tetID == -1) {
					m_volFiber.push_back(KVector3d());
					continue;
				}
				KVector3d pos(dx, dy, dz);
				KTetra& tet = m_tetra.m_tetras[tetID];
				double weights[4];
				//// simple linear interpolation
				//KVector3d vtx[4];
				//for (int i = 0; i < 4; ++i)
				//	vtx[i] = m_tetra.m_vertices[tet.m_vtx[i]].m_pos;
				//KUtil::getLinearCoefficient(weights[0], weights[1], weights[2], weights[3], vtx[0], vtx[1], vtx[2], vtx[3], pos);
				
				// depth-aware interpolation
				double total = 0;
				double depth = m_volDepth[index];
				for (int i = 0; i < 4; ++i) {
					double distEuclid = KUtil::getDistance(m_tetra.m_vertices[tet.m_vtx[i]].m_pos, pos);
					double distDepth  = abs(m_vtxDepth[tet.m_vtx[i]] - depth);
					weights[i] =
						exp(-LAMBDA_EUCLID * distEuclid * distEuclid) *
						exp(-LAMBDA_DEPTH  * distDepth  * distDepth);
					total += weights[i];
				}
				for (int i = 0; i < 4; ++i)
					weights[i] /= total;
				
				KVector3d fiber;
				for (int i = 0; i < 4; ++i) {
					fiber.addWeighted(m_vtxFiber[tet.m_vtx[i]], weights[i]);
				}
				fiber.normalize();
				m_volFiber.push_back(fiber);
			}
		}
	}
}

void Core::calcStreamLines() {
	const int& N = VOL_SIZE;
	vector<bool> volVisited(N * N * N, false);
	m_streamLines.clear();
	double delta = 0.05;
	//int numStreamLines = 50000;
	//int numStreamLines = 25000;
	int numStreamLines = 12500;
	int sizeMin = 3;
	for (int i = 0; i < numStreamLines; ++i) {
		KVector3d pos0(rand() / (double)RAND_MAX, rand() / (double)RAND_MAX, rand() / (double)RAND_MAX);
		int index0 = getIndex(d2i(pos0.x), d2i(pos0.y), d2i(pos0.z));
		if (index0 < 0) continue;
		if (m_volTetID[index0] == -1) continue;
		if (volVisited[index0]) continue;
		volVisited[index0] = true;
		double depth0 = m_volDepth[index0];
		KVector3d pos, vec;
		// go forward
		vector<pair<KVector3d, double> > forward;
		pos.set(pos0);
		vec.set(m_volFiber[index0]);
		while (true) {
			pos.addWeighted(vec, delta);
			int index = getIndex(d2i(pos.x), d2i(pos.y), d2i(pos.z));
			if (index < 0) break;
			if (m_volTetID[index] < 0) break;
			if (volVisited[index]) break;
			volVisited[index] = true;
			forward.push_back(pair<KVector3d, double>(pos, m_volDepth[index]));
			vec.set(m_volFiber[index]);
		}
		// go backward
		vector<pair<KVector3d, double> > backward;
		pos.set(pos0);
		vec.set(m_volFiber[index0]);
		while (true) {
			pos.addWeighted(vec, -delta);
			int index = getIndex(d2i(pos.x), d2i(pos.y), d2i(pos.z));
			if (index < 0) break;
			if (m_volTetID[index] < 0) break;
			if (volVisited[index]) break;
			volVisited[index] = true;
			backward.push_back(pair<KVector3d, double>(pos, m_volDepth[index]));
			vec.set(m_volFiber[index]);
		}
		int size = (int)(forward.size() + backward.size() + 1);
		//if (size < sizeMin) continue;
		vector<pair<KVector3d, double> > streamLine;
		streamLine.reserve(size);
		for (int i = (int)backward.size() - 1; i >= 0; --i)
			streamLine.push_back(backward[i]);
			//streamLine.push_back(pair<KVector3d, double>(backward[i], m_rbfDepth.getValue(backward[i])));
		//streamLine.push_back(pair<KVector3d, double>(pos0, m_rbfDepth.getValue(pos0)));
		streamLine.push_back(pair<KVector3d, double>(pos0, depth0));
		for (int i = 0; i < (int)forward.size(); ++i)
			streamLine.push_back(forward[i]);
		m_streamLines.push_back(streamLine);
	}
}

void Core::initStreamLinesPoly() {
	m_streamLinesPoly = m_streamLines;
}

void Core::calcStreamLinesPoly(const vector<KVector3d>& cutStroke) {
	KThinPlate2D rbfCut;
	{
		// construct 2D-RBF height field by projecting cutStroke onto the screen
		vector<KVector2d> cutStroke2D;
		for (int i = 0; i < (int)cutStroke.size(); ++i) {
			const KVector3d& pos = cutStroke[i];
			double winx, winy, winz;
			m_ogl.project(pos.x, pos.y, pos.z, winx, winy, winz);
			cutStroke2D.push_back(KVector2d(winx, winy));
		}
		vector<KVector2d> points;
		vector<double   > values;
		for (int i = 1; i < (int)cutStroke2D.size(); ++i) {
			KVector2d& p0 = cutStroke2D[i - 1];
			KVector2d& p1 = cutStroke2D[i];
			KVector2d d(p1);
			d.sub(p0);
			d.normalize();
			d.scale(10);
			KVector2d cp(p0), cm(p0);
			cp.add(-d.y, d.x);
			cm.add(d.y, -d.x);
			points.push_back(cp);
			points.push_back(cm);
			values.push_back( 1);
			values.push_back(-1);
		}
		rbfCut.setPoints(points);
		rbfCut.setValues(values);
	}
	m_streamLinesPoly.clear();
	for (int i = 0; i < (int)m_streamLines.size(); ++i) {
		m_streamLinesPoly.push_back(vector<pair<KVector3d, double> >());
		vector<pair<KVector3d, double> >& streamLine = m_streamLines[i];
		for (int j = 0; j < (int)streamLine.size(); ++j) {
			KVector3d& pos = streamLine[j].first;
			double winx, winy, winz;
			m_ogl.project(pos.x, pos.y, pos.z, winx, winy, winz);
			double val = rbfCut.getValue(winx, winy);
			if (val > 0) {
				if (!m_streamLinesPoly.back().empty()) m_streamLinesPoly.push_back(vector<pair<KVector3d, double> >());
				continue;
			}
			m_streamLinesPoly.back().push_back(streamLine[j]);
		}
	}
	if (m_streamLinesPoly.back().empty()) m_streamLinesPoly.pop_back();
}

void Core::calcStreamLinesPolyLayers() {
	int margin0 = 0;
	int margin1 = 1;
	m_streamLinesPolyLayers.clear();
	m_streamLinesPolyLayers.reserve(LAYER_MAX + 1);
	for (int i = 0; i <= LAYER_MAX; ++i) {
		double layerDepth = -2 * (i + margin0) / (double)(LAYER_MAX + margin0 + margin1);
		vector<vector<pair<KVector3d, double> > > streamLines;
		for (int j = 0; j < (int)m_streamLines.size(); ++j) {
			streamLines.push_back(vector<pair<KVector3d, double> >());
			vector<pair<KVector3d, double> >& streamLine = m_streamLines[j];
			for (int k = 0; k < (int)streamLine.size(); ++k) {
				double depth = streamLine[k].second;
				if (depth > layerDepth) {
					if (!streamLines.back().empty()) streamLines.push_back(vector<pair<KVector3d, double> >());
					continue;
				}
				streamLines.back().push_back(streamLine[k]);
			}
		}
		if (streamLines.back().empty()) streamLines.pop_back();
		m_streamLinesPolyLayers.push_back(streamLines);
	}
}
void Core::calcDeformVtxList(const KVector3d& origin, double radius) {
	m_deformVtxList.clear();
	m_deformVtxWeight.clear();
	KVector3d eye(m_ogl.m_focusPoint);
	eye.sub(m_ogl.m_eyePoint);
	eye.normalize();
	for (int i = 0; i < (int)m_tetra.m_vertices.size(); ++i) {
		if (!m_isTetVtxBoundary[i]) continue;
		KVector3d& pos = m_tetra.m_vertices[i].m_pos;
		double dist = KUtil::getDistance(origin, pos);
		if (dist > radius) continue;
		KVector3d& n = m_tetVtxBoundaryNormal[i];
		if (eye.dot(n) > 0) continue;
		m_deformVtxList.push_back(i);
		m_deformVtxWeight.push_back(0.5 + 0.5 * cos(M_PI * dist / radius));
	}
}

void Core::calcDeformVtxOffset(const KVector3d& offset) {
	m_deformVtxOffset.clear();
	for (int i = 0; i < (int)m_deformVtxList.size(); ++i) {
		double weight = m_deformVtxWeight[i];
		KVector3d v(offset);
		v.scale(weight);
		m_deformVtxOffset.push_back(v);
	}
}

void Core::deformTetra(const vector<KVector3d>& vtxPosNew) {
	KTetraModel tetraOld = m_tetra;
	//vector<KVector3d> vtxPosOld;
	//vtxPosOld.reserve(m_tetra.m_vertices.size());
	//for (int i = 0; i < (int)m_tetra.m_vertices.size(); ++i)
	//	vtxPosOld.push_back(m_tetra.m_vertices[i].m_pos);
	//vector<KVector3d> vtxPosNew(vtxPosOld);
	//for (int i = 0; i < (int)m_deformVtxList.size(); ++i)
	//	vtxPosNew[m_deformVtxList[i]].add(m_deformVtxOffset[i]);
	
	// transform tetra vertices
	for (int i = 0; i < (int)vtxPosNew.size(); ++i)
		m_tetra.m_vertices[i].m_pos.set(vtxPosNew[i]);
	// update geometry
	initPoly();
	
	//// transform depth-constraint points
	//vector<KVector3d> rbfPointsNew;
	//rbfPointsNew.reserve(m_rbfPoints.size());
	//for (int i = 0; i < (int)m_rbfPoints.size(); ++i)
	//	rbfPointsNew.push_back(transform(vtxPosOld, vtxPosNew, m_rbfPoints[i]));
	//
	//m_rbfPoints = rbfPointsNew;
	// update depth
	//calcRbfDepth();
	//calcVtxDepth();
	calcPolyLayers();
	
	// transform strokes
	vector<vector<KVector3d> > strokesNew;
	strokesNew.reserve(m_strokes.size());
	for (int i = 0; i < (int)m_strokes.size(); ++i) {
		vector<KVector3d> strokeNew;
		strokeNew.reserve(m_strokes[i].size());
		for (int j = 0; j < (int)m_strokes[i].size(); ++j) {
			strokeNew.push_back(transform(tetraOld, m_tetra, m_strokes[i][j]));
		}
		strokesNew.push_back(strokeNew);
	}
	m_strokes = strokesNew;
	vector<KVector3d> s1PointsNew;
	s1PointsNew.reserve(m_s1Points.size());
	for (int i = 0; i < (int)m_s1Points.size(); ++i)
		s1PointsNew.push_back(transform(tetraOld, m_tetra, m_s1Points[i]));
	m_s1Points = s1PointsNew;
}

KVector3d Core::transform(const KTetraModel& tetraOld, const KTetraModel& tetraNew, const KVector3d& pos) {
	//int ix = d2i(pos.x);
	//int iy = d2i(pos.y);
	//int iz = d2i(pos.z);
	//int tetID = m_volTetID[getIndex(ix, iy, iz)];
	//if (tetID < 0) return pos;
	int tetID;
	double dist;
	KUtil::getNearestTetraID(tetID, dist, tetraOld, pos);
	double w[4];
	KVector3d v[4];
	for (int i = 0; i < 4; ++i)
		//v[i] = vtxPosOld[m_tetra.m_tetras[tetID].m_vtx[i]];
		v[i] = tetraOld.m_vertices[tetraOld.m_tetras[tetID].m_vtx[i]].m_pos;
	KUtil::getBarycentricCoord(w[0], w[1], w[2], w[3], v[0], v[1], v[2], v[3], pos, 1);
	KVector3d posNew;
	for (int i = 0; i < 4; ++i)
		posNew.addWeighted(tetraNew.m_vertices[tetraNew.m_tetras[tetID].m_vtx[i]].m_pos, w[i]);
	return posNew;
}

void Core::exportVolData() {
	//CFileDialog dialog(FALSE, ".vfib", NULL, OFN_OVERWRITEPROMPT, "Volume Fiber files(*.vfib)|*.vfib||");
	CFileDialog dialog(FALSE, ".txt", NULL, OFN_OVERWRITEPROMPT, "Text files(*.txt)|*.txt||");
	if (dialog.DoModal() != IDOK) return;
	string fname = dialog.GetPathName();
	//FILE * fout = fopen(fname.c_str(), "wb");
	FILE * fout = fopen(fname.c_str(), "w");
	if (!fout) {
		CString str;
		str.Format("Failed to open file %s", fname.c_str());
		AfxMessageBox(str);
		return;
	}
	for (int i = 0; i < (int)m_tetra.m_vertices.size(); ++i) {
		KVector3d vx = m_vtxFiber[i];
		KVector3d& pos = m_tetra.m_vertices[i].m_pos;
		double f0 = m_rbfDepth.getValue(pos);
		double fx = m_rbfDepth.getValue(pos.x + Core::GRADIENT_DELTA, pos.y, pos.z);
		double fy = m_rbfDepth.getValue(pos.x, pos.y + Core::GRADIENT_DELTA, pos.z);
		double fz = m_rbfDepth.getValue(pos.x, pos.y, pos.z + Core::GRADIENT_DELTA);
		KVector3d vy(fx - f0, fy - f0, fz - f0);
		vy.scale(1 / Core::GRADIENT_DELTA);
		KVector3d vz;
		vz.cross(vx, vy);
		vx.normalize();
		vy.normalize();
		vz.normalize();
		fprintf(fout, "%4d %f %f %f %f %f %f %f %f %f\n", i, vx.x, vx.y, vx.z, vy.x, vy.y, vy.z, vz.x, vz.y, vz.z);
	}
	
	//// voxel size
	//const int& N = VOL_SIZE;
	//fwrite(&N, sizeof(int), 1, fout);
	//
	//// flag of existance
	//int N3 = N * N * N;
	//vector<unsigned char> volExist(N3);
	//for (int i = 0; i < N3; ++i)
	//	volExist[i] = m_volTetID[i] == -1 ? 0 : 1;
	//fwrite(&  volExist[0], sizeof(char)     , N3, fout);
	//
	//// fiber orientations
	//fwrite(&m_volFiber[0], sizeof(KVector3d), N3, fout);
	//
	//// s1 stimulus positions
	//int numS1Points = (int)m_s1Points.size();
	//fwrite(&numS1Points, sizeof(int), 1, fout);
	//vector<int> s1Points3i(m_s1Points.size() * 3);
	//for (int i = 0; i < (int)m_s1Points.size(); ++i) {
	//	KVector3d& pos = m_s1Points[i];
	//	int ix = d2i(pos.x);
	//	int iy = d2i(pos.y);
	//	int iz = d2i(pos.z);
	//	if (getIndex(ix, iy, iz) < 0) continue;
	//	s1Points3i[3 * i]     = ix;
	//	s1Points3i[3 * i + 1] = iy;
	//	s1Points3i[3 * i + 2] = iz;
	//}
	//fwrite(&s1Points3i[0], sizeof(int), s1Points3i.size(), fout);
	
	fclose(fout);
}


void Core::initEyePosition() {
	m_ogl.m_eyePoint.set(0.5, 0.5, -2);
	m_ogl.m_focusPoint.set(0.5, 0.5, 0.5);
	m_ogl.m_upDirection.set(0, 1, 0);
	m_ogl.updateEyePosition();
}

