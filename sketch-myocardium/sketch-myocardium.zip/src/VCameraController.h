#pragma once

class VCameraController
{
public:
	VCameraController(void);
	~VCameraController(void);
};
