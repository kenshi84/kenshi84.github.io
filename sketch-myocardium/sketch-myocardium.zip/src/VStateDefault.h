#pragma once
#include "vstate.h"

class VStateDefault :
	public VState
{
public:
	
	static inline VStateDefault* getInstance(){
		static VStateDefault p;
		return &p;
	}
	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
};
