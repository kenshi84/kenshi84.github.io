#pragma once
#include "vstate.h"

class VStateDrawCrossSectionStroke :
	public VState
{
public:
	static inline VStateDrawCrossSectionStroke* getInstance(){
		static VStateDrawCrossSectionStroke p;
		return &p;
	}
	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
};
