// MainFrm.h : interface of the CMainFrame class
//


#pragma once
class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnDrawEdges();
	afx_msg void OnDrawFaces();
	afx_msg void OnDrawStrokesonsurface();
	afx_msg void OnDrawStrokesonvolume();
	afx_msg void OnDrawFieldonsurface();
	afx_msg void OnDrawFieldonvolume();
	afx_msg void OnEditUndo();
	afx_msg void OnUpdateEditUndo(CCmdUI *pCmdUI);
	afx_msg void OnUpdateEditRedo(CCmdUI *pCmdUI);
	afx_msg void OnEditRedo();
	afx_msg void OnUpdateDrawEdges(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDrawFaces(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDrawFieldonsurface(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDrawFieldonvolume(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDrawStrokesonsurface(CCmdUI *pCmdUI);
	afx_msg void OnUpdateDrawStrokesonvolume(CCmdUI *pCmdUI);
	afx_msg void OnEditClearAll();
	afx_msg void OnDrawCsshape();
	afx_msg void OnUpdateDrawCsshape(CCmdUI *pCmdUI);
	afx_msg void OnDrawAxis();
	afx_msg void OnUpdateDrawAxis(CCmdUI *pCmdUI);
	afx_msg void OnUpdateEditClearAll(CCmdUI *pCmdUI);
};


