// SO_PolygonModel.cpp: SO_PolygonModel �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
/*#include <fstream>
#include <float.h>
#include <math.h>
#include <algorithm>
#include <map>
#include <deque>*/

#include "ILOGL.h"
//#include <magick++.h>
//using namespace Magick ;

/*
#if (_MSC_VER == 1200) && (WINVER < 0x0500)
extern "C" long _ftol( double ); //defined by VC6 C libs
extern "C" long _ftol2( double dblSource ) { return _ftol( dblSource );
}
#endif
*/

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

/*
bool ILOGLTexture::ReadFromFile(const char* filename,bool bFitScale){
	if( strlen(filename)==0 )
		return false ;
	FILE* fp = fopen(filename,"rb") ;
	if( !fp )	return false ;
	fclose(fp) ;
	try { 
		// Read a file into image object 
		Image img(filename);
	
		img.flip() ;
		if( bFitScale ){
			int obj_width = SmallestBeqPow2(img.columns()) , obj_height = SmallestBeqPow2(img.rows()) ;
			CString str ;
			str.Format( "%dx%d!",obj_width,obj_height ) ;
			img.scale( str.GetBuffer(256) ) ;
		}
		
		int _w = img.columns() , _h = img.rows() ;
		unsigned char* tmp = new unsigned char[_w*_h*4] ;
		unsigned char* origimage = (unsigned char*)img.getPixels(0,0,_w,_h) ;

		unsigned char *pt = tmp,*ps = origimage ;
		for( int i=0;i<_w*_h;i++,pt+=4,ps+=8 ){
			pt[0]=ps[5];
			pt[1]=ps[3];
			pt[2]=ps[1];
			pt[3]=255 ;
		}textureNameString = filename;
		
		Allocate(_w,_h,tmp) ;
		delete[] tmp ;
	} 
	catch( Exception &error_ ) 
    { 
      TRACE("Caught exception: %s\n",error_.what() ) ;
      return 1; 
    } 

	return true ;
}

void ILOGLTexture::HalfSize(){
	if( width<2 || height<2 )	return ;
	int neww = width/2 , newh = height/2 ;
	unsigned char* newImg = new unsigned char[neww*newh*4] ;
	for( int y=1;y<newh-1;y++ ) for( int x=1;x<neww-1;x++ ){
		int orgx = x*2 , orgy = y*2 ;
		unsigned char* pxls[1+4+4] = {
			GetPixelp(orgx,orgy),
				GetPixelp(orgx+1,orgy),GetPixelp(orgx,orgy+1),GetPixelp(orgx-1,orgy),GetPixelp(orgx,orgy-1),
				GetPixelp(orgx-1,orgy-1),GetPixelp(orgx-1,orgy+1),GetPixelp(orgx+1,orgy+1),GetPixelp(orgx+1,orgy-1),
		} ;
		unsigned char* tgt = &newImg[(y*neww+x)*4] ;
		for( int rgba=0;rgba<4;rgba++)
			tgt[rgba] +=
			ClipUchar(
			(
			pxls[0][rgba]
			+ 0.5 *(pxls[1][rgba]+pxls[2][rgba]+pxls[3][rgba]+pxls[4][rgba])
			+ 0.25*(pxls[5][rgba]+pxls[6][rgba]+pxls[7][rgba]+pxls[8][rgba])
			) / (1+0.5*4+0.25*4)) ;
	}
	for( int x=1;x<neww-1;x++ ){
		int orgx = x*2 ;
		unsigned char* pxls[2+4] = {
			GetPixelp(orgx,0),GetPixelp(orgx,1),
			GetPixelp(orgx-1,0),GetPixelp(orgx+1,0),GetPixelp(orgx-1,1),GetPixelp(orgx+1,1)
		} ;
		unsigned char* tgt = &newImg[x*4] ;
		for( int rgba=0;rgba<4;rgba++)
			tgt[rgba] +=
			ClipUchar(
			(
			+ 0.5 *(pxls[0][rgba]+pxls[1][rgba])
			+ 0.25*(pxls[2][rgba]+pxls[3][rgba]+pxls[4][rgba]+pxls[5][rgba])
			) / (0.5*2+0.25*4)) ;
		
		int orgy = newh-1 ;
		unsigned char* pxls2[2+4] = {
			GetPixelp(orgx,orgy),GetPixelp(orgx,orgy-1),
			GetPixelp(orgx-1,orgy),GetPixelp(orgx+1,orgy),GetPixelp(orgx-1,orgy-1),GetPixelp(orgx+1,orgy-1)
		} ;
		tgt = &newImg[((newh-1)*neww+x)*4] ;
		for( int rgba=0;rgba<4;rgba++)
			tgt[rgba] +=
			ClipUchar(
			(
			+ 0.5 *(pxls[0][rgba]+pxls[1][rgba])
			+ 0.25*(pxls[2][rgba]+pxls[3][rgba]+pxls[4][rgba]+pxls[5][rgba])
			) / (0.5*2+0.25*4)) ;
		
	}
	for( int y=1;y<newh-1;y++ ){
		int orgy = y*2 ;
		unsigned char* pxls[2+4] = {
			GetPixelp(0,orgy),GetPixelp(1,orgy),
			GetPixelp(0,orgy-1),GetPixelp(0,orgy+1),GetPixelp(1,orgy-1),GetPixelp(1,orgy+1)
		} ;
		unsigned char* tgt = &newImg[y*neww*4] ;
		for( int rgba=0;rgba<4;rgba++)
			tgt[rgba] +=
			ClipUchar(
			(
			+ 0.5 *(pxls[0][rgba]+pxls[1][rgba])
			+ 0.25*(pxls[2][rgba]+pxls[3][rgba]+pxls[4][rgba]+pxls[5][rgba])
			) / (0.5*2+0.25*4)) ;
		
		int orgx = neww-1 ;
		unsigned char* pxls2[2+4] = {
			GetPixelp(orgx,orgy),GetPixelp(orgx-1,orgy),
			GetPixelp(orgx-1,orgy),GetPixelp(orgx+1,orgy),GetPixelp(orgx-1,orgy-1),GetPixelp(orgx+1,orgy-1)
		} ;
		tgt = &newImg[(y*neww+neww-1)*4] ;
		for( int rgba=0;rgba<4;rgba++)
			tgt[rgba] +=
			ClipUchar(
			(
			+ 0.5 *(pxls[0][rgba]+pxls[1][rgba])
			+ 0.25*(pxls[2][rgba]+pxls[3][rgba]+pxls[4][rgba]+pxls[5][rgba])
			) / (0.5*2+0.25*4)) ;
		
	}
	{
		unsigned char* tgts[4] = {
			&newImg[0],&newImg[(neww-1)*4],&newImg[((newh-1)*neww+0)*4],&newImg[((newh-1)*neww+(neww-1))*4]
		} ;
		unsigned char* pxls[4][4] = {
			{GetPixelp(0,0),GetPixelp(0,1),GetPixelp(1,0),GetPixelp(1,1)},
			{GetPixelp(neww-1,0),GetPixelp(neww-1,1),GetPixelp(neww-2,0),GetPixelp(neww-2,1)},
			{GetPixelp(0,newh-1),GetPixelp(0,newh-2),GetPixelp(1,newh-1),GetPixelp(1,newh-2)},
			{GetPixelp(neww-1,newh-1),GetPixelp(neww-1,newh-2),GetPixelp(neww-2,newh-1),GetPixelp(neww-2,newh-2)},
		} ;
		for( int i=0;i<4;i++ ){
			for( int rgba=0;rgba<4;rgba++ )
				tgts[i][rgba] = ClipUchar(
					0.25*(pxls[i][0][rgba]+pxls[i][1][rgba]+pxls[i][2][rgba]+pxls[i][3][rgba])
				) ;
		}
	}

	int new_avail_width = avail_width/2 ;
	int new_avail_height = avail_height/2 ;
	Allocate(neww,newh,newImg) ;
	avail_width = new_avail_width ;
	avail_height = new_avail_height ;
	uvw_scale[0] = avail_width/(double)neww ; uvw_scale[1] = avail_height/(double)newh ;
	delete[] newImg ;
}*/
