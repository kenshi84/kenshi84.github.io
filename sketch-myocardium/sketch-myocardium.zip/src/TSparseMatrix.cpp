#include "StdAfx.h"
#include ".\tsparsematrix.h"
#include "ILMath.h"


#ifdef T_USE_UMFPACK
#include "SparseMatSolve/SparseMatSolve.h"
#include "SparseMatSolve/umfpack.h"
#endif
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

TSparseMatrix::TSparseMatrix():columnmax(0) {
	m_isLinearSolverFieldsReady = false;
	m_Ap_c = 0;
	m_Ai_c = 0;
	m_Ax_c = 0;
	m_b_c  = 0;
	m_x_c  = 0;

	m_Ap_size = 0;
	m_Ai_size = 0;
	m_Ax_size = 0;
}

TSparseMatrix::~TSparseMatrix(){
	if(m_isLinearSolverFieldsReady){
		if(m_Ap_c != 0) delete m_Ap_c;
		if(m_Ai_c != 0) delete m_Ai_c;
		if(m_Ax_c != 0) delete m_Ax_c;
		if(m_b_c != 0)  delete m_b_c;
		if(m_x_c != 0)  delete m_x_c;
	}
}


void TSparseMatrix::SetColumns()
{
	columns.clear();
	columns.resize( columnmax ) ;
	for( int i=0;i<(int)rows.size();i++ ){
		for( int j=0;j<(int)rows[i].indice.size();j++ ){
			columns[ rows[i].indice[j] ].indice.push_back( i ) ; //push_back for vector
			columns[ rows[i].indice[j] ].coefficients.push_back(rows[i].coefficients[j]);
		}
	}
	
	//for( int i=0;i<columnmax;i++ )           copy<int>( columns_l[i] , columns[i] ) ;
}



void TSparseMatrix::initializeLinearSolverFields()
{
	assert(!m_isLinearSolverFieldsReady);

	list<int> Ap,Ai ;
	list<double>Ax ;

	int i = 0 ;

	for( int row_i = 0; row_i < (int)rows.size(); ++row_i ){
		Ap.push_back(i) ;
		Row& row = rows[row_i] ;
		for( int idx=0;idx< (int)row.indice.size() ;++idx,++i ){
			Ai.push_back(row.indice[idx]) ;
			Ax.push_back(row.coefficients[idx]) ;
		}
	}
	Ap.push_back(i) ;

	m_Ap_c = new int[    Ap.size() ] ;
	m_Ai_c = new int[    Ai.size() ] ;
	m_Ax_c = new double[ Ax.size() ] ;
	m_b_c  = new double[ rowmax    ] ;
	m_x_c  = new double[ columnmax ] ;

	m_Ai_size = (int) Ai.size();
	m_Ap_size = (int) Ap.size();
	m_Ax_size = (int) Ax.size();


	i=0 ; for( list<int>::iterator    iit = Ap.begin() ; iit!=Ap.end() ; ++iit,++i )	m_Ap_c[i] = *iit ;
	i=0 ; for( list<int>::iterator    iit = Ai.begin() ; iit!=Ai.end() ; ++iit,++i )	m_Ai_c[i] = *iit ;
	i=0 ; for( list<double>::iterator dit = Ax.begin() ; dit!=Ax.end() ; ++dit,++i )	m_Ax_c[i] = *dit ;
	//for (int i = 0; i < (int)Ax.size(); ++i)
	//	fprintf(stderr, "%f\n", m_Ax_c[i]);

	//����Rows�Ȃǂ͂���Ȃ�
	for(i = 0; i < (int) rows.size(); ++i){
		rows[i].coefficients.clear();
		rows[i].indice.clear();
	}
	rows.clear();//���ꂾ���őS�ĊJ���ł��邩��

	m_isLinearSolverFieldsReady = true;
}



#ifdef T_USE_UMFPACK
//TODO vector<double d �Ɓ@result��double*�ɂ���
bool TSparseMatrix::SolveLinearSystemUsingUmfpack(const vector<double>& d,vector<double>& result,double threshold ){

	if(!m_isLinearSolverFieldsReady)    initializeLinearSolverFields();
	
	for(int i = 0 ; i < rowmax; ++i )	m_b_c[i] = d[i] ;

	int m = rowmax , n = columnmax ;

	double *null = (double *) NULL ;
	void *Symbolic, *Numeric ;
	(void) umfpack_di_symbolic (m, n, m_Ap_c, m_Ai_c, m_Ax_c, &Symbolic, null, null) ;
	(void) umfpack_di_numeric (m_Ap_c, m_Ai_c, m_Ax_c, Symbolic, &Numeric, null, null) ;
	(void) umfpack_di_solve (UMFPACK_A, m_Ap_c, m_Ai_c, m_Ax_c, m_x_c, m_b_c, Numeric, null, null) ;
	umfpack_di_free_symbolic (&Symbolic) ;
	umfpack_di_free_numeric (&Numeric) ;

	result.resize( n ) ;
	for( int i=0; i < n ; ++i ) result[i] = m_x_c[i] ;

	return true ;
}
#else

bool TSparseMatrix::SolveLinearSystemUsingUmfpack(const vector<double>& d,vector<double>& result,double threshold ){
	//do nothing
	if(!m_isLinearSolverFieldsReady) initializeLinearSolverFields();
	result.resize(GetRowNum());
	return true;
}
#endif






	

#ifdef T_USE_UMFPACK


double *null = (double *) NULL ;
void *Symbolic, *Numeric ;
bool TSparseMatrix::SolveLinearSystemUsingUmfpack(const double* d, double* result,double threshold ){

	if(!m_isLinearSolverFieldsReady) initializeLinearSolverFields();
	
	int m = rowmax , n = columnmax ;

	//double *null    = (double *) NULL ;
	//double control[ UMFPACK_CONTROL ];
	//control[UMFPACK_STRATEGY] = UMFPACK_STRATEGY_SYMMETRIC;
	//control[UMFPACK_SCALE   ] = UMFPACK_SCALE_SUM;
	//control[UMFPACK_IRSTEP  ] = 2;

	//void *Symbolic, *Numeric ;
	
	(void) umfpack_di_symbolic (m, n, m_Ap_c, m_Ai_c, m_Ax_c, &Symbolic, null, null) ;
	(void) umfpack_di_numeric ( m_Ap_c, m_Ai_c, m_Ax_c, Symbolic, &Numeric, null, null) ;
	(void) umfpack_di_solve (UMFPACK_A, m_Ap_c, m_Ai_c, m_Ax_c, result, d, Numeric,null, null) ;//UMFPACK_At�@���������Ώ̂Ȃ̂ŁA�K�v�Ȃ�
	umfpack_di_free_symbolic (&Symbolic) ;
	umfpack_di_free_numeric (&Numeric) ;

	return true ;
#else

bool TSparseMatrix::SolveLinearSystemUsingUmfpack(const double* d, double* result,double threshold ){
	//do nothing
	if(!m_isLinearSolverFieldsReady) initializeLinearSolverFields();
	return true;

#endif
}

void TSparseMatrix::MultSelfTransposeSelf(TSparseMatrix& LtL) {
	SetColumns();

	LtL.Allocate(columnmax, columnmax);
	// �R�R���ǂ����Ă��d��
	for (int i = 0; i < columnmax; ++i) {
		for (int j = i; j < columnmax; ++j) {
			double tmp = 0.;
			Column& coli = columns[i];
			Column& colj = columns[j];
			vector<int>& indi = coli.indice;
			vector<int>& indj = colj.indice;
			vector<double>& coefi = coli.coefficients;
			vector<double>& coefj = colj.coefficients;

			int ki = 0;
			int kj = 0;
			while(true) {
				if (indi[ki] < indj[kj]) {
					if (ki == indi.size()-1) break;
					++ki;
				}else if (indi[ki] > indj[kj]) {
					if (kj == indj.size()-1) break;
					++kj;
				}else {
					tmp += coefi[ki] * coefj[kj];
					if (ki == indi.size()-1 || kj == indj.size()-1) break;
					++ki;
					++kj;
				}
			}
			
			if (tmp != 0) {
//				fprintf(stderr, "tmp = %f\n", tmp);
				LtL.AddToElement(i, j, tmp);
				if (i != j) LtL.AddToElement(j, i, tmp);
			}
		}
	}
}

void TSparseMatrix::MultSelfSelfTranspose(TSparseMatrix &LLt) {
	LLt.Allocate(rowmax, rowmax);
	// �R�R���ǂ����Ă��d��
	for (int i = 0; i < rowmax; ++i) {
		for (int j = i; j < rowmax; ++j) {
			double tmp = 0.;
			Row& rowi = rows[i];
			Row& rowj = rows[j];
			vector<int>& indi = rowi.indice;
			vector<int>& indj = rowj.indice;
			vector<double>& coefi = rowi.coefficients;
			vector<double>& coefj = rowj.coefficients;

			int ki = 0;
			int kj = 0;
			while(true) {
				if (indi[ki] < indj[kj]) {
					if (ki == indi.size()-1) break;
					++ki;
				} else if (indi[ki] > indj[kj]) {
					if (kj == indj.size()-1) break;
					++kj;
				} else {
					tmp += coefi[ki] * coefj[kj];
					if (ki == indi.size()-1 || kj == indj.size()-1) break;
					++ki;
					++kj;
				}
			}
			
			if (tmp != 0) {
//				fprintf(stderr, "tmp = %f\n", tmp);
				LLt.AddToElement(i, j, tmp);
				if (i != j) LLt.AddToElement(j, i, tmp);
			}
		}
	}
}

int TSparseMatrix::CountElements() {
	int cnt = 0;
	for (int i = 0; i < (int)rows.size(); ++i)
		cnt += (int)rows[i].indice.size();
	return cnt;
}

void TSparseMatrix::TraceMatrix() {
	if (!m_isLinearSolverFieldsReady) {
		for (int i = 0; i < rowmax; ++i) {
			fprintf(stderr, "============================\n");
			fprintf(stderr, "row[%d] : %d elements\n", i, rows[i].indice.size());
			for (int j = 0; j < (int)rows[i].indice.size(); ++j)
				fprintf(stderr, "%d, ", rows[i].indice[j]);
			fprintf(stderr, "\n");
			for (int j = 0; j < (int)rows[i].indice.size(); ++j)
				fprintf(stderr, "%f, ", rows[i].coefficients[j]);
			fprintf(stderr, "\n");
			fprintf(stderr, "============================\n");
		}
	} else {
		for (int i = 0; i < columnmax; ++i) {
			fprintf(stderr, "============================\n");
			fprintf(stderr, "column[%d] : %d elements\n", i, m_Ap_c[i+1] - m_Ap_c[i]);
			for (int j = m_Ap_c[i]; j < m_Ap_c[i+1]; ++j)
				fprintf(stderr, "%d, ", m_Ai_c[j]);
			fprintf(stderr, "\n");
			for (int j = m_Ap_c[i]; j < m_Ap_c[i+1]; ++j)
				fprintf(stderr, "%d, ", m_Ax_c[j]);
			fprintf(stderr, "\n");
			fprintf(stderr, "============================\n");
		}
	}
}







