#include "StdAfx.h"
#include ".\vanimationmanager.h"
#include "VCore.h"

VAnimationManager::VAnimationManager(void)
{
}

VAnimationManager::~VAnimationManager(void)
{
}

void VAnimationManager::update() {
	vector<ILVector3D>& particle = VCore::getInstance()->m_particle;
	//vector<ILVector3D>& particleVel = VCore::getInstance()->m_particleVelocity;
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	{
		vector<ILVector3D>::iterator iter = particle.begin();
		//vector<ILVector3D>::iterator iterVel = particleVel.begin();
		while ( iter != particle.end() ) {
			int ix = (int)(iter->data[0] * NUMGRID);
			int iy = (int)(iter->data[1] * NUMGRID);
			int iz = (int)(iter->data[2] * NUMGRID);
		
			if (!vdata[IXGRID(ix, iy, iz)].isInner ||
				!vdata[IXGRID(ix+1, iy, iz)].isInner ||
				!vdata[IXGRID(ix, iy+1, iz)].isInner ||
				!vdata[IXGRID(ix, iy, iz+1)].isInner ||
				!vdata[IXGRID(ix+1, iy+1, iz)].isInner ||
				!vdata[IXGRID(ix, iy+1, iz+1)].isInner ||
				!vdata[IXGRID(ix+1, iy, iz+1)].isInner ||
				!vdata[IXGRID(ix+1, iy+1, iz+1)].isInner) 
			{
				if ( iter + 1 == particle.end() ) {
					particle.pop_back();
					break;
				} else {
					*iter = particle.back();
					particle.pop_back();
					continue;
				}
			}

			//if (ix < 0 || ix >= NUMGRID || iy < 0 || iy >= NUMGRID || iz < 0 || iz >= NUMGRID) {
			//	if ( iter + 1 == particle.end() ) {
			//		particle.pop_back();
			//		particleVel.pop_back();
			//		break;
			//	} else {
			//		*iter = particle.back();
			//		*iterVel = particleVel.back();
			//		particle.pop_back();
			//		particleVel.pop_back();
			//		continue;
			//	}
			//}
			//

			double ux = iter->data[0] * NUMGRID - ix;
			double uy = iter->data[1] * NUMGRID - iy;
			double uz = iter->data[2] * NUMGRID - iz;
			ILVector3D tmp(0, 0, 0);
			tmp += ((1-ux) * (1-uy) * (1-uz)) * vdata[IXGRID(ix, iy, iz)].field;
			tmp += ((1-ux) * uy * (1-uz)) * vdata[IXGRID(ix, iy+1, iz)].field;
			tmp += ((1-ux) * (1-uy) * uz) * vdata[IXGRID(ix, iy, iz+1)].field;
			tmp += ((1-ux) * uy * uz) * vdata[IXGRID(ix, iy+1, iz+1)].field;
			tmp += (ux * (1-uy) * (1-uz)) * vdata[IXGRID(ix+1, iy, iz)].field;
			tmp += (ux * uy * (1-uz)) * vdata[IXGRID(ix+1, iy+1, iz)].field;
			tmp += (ux * (1-uy) * uz) * vdata[IXGRID(ix+1, iy, iz+1)].field;
			tmp += (ux * uy * uz) * vdata[IXGRID(ix+1, iy+1, iz+1)].field;
			tmp.Normalize_Self();
			*iter += tmp * 0.01;
			//*iterVel += tmp * 0.01;
			//*iter += *iterVel;

			++iter;
			//++iterVel;
		}
	}
	
	VCore::getInstance()->m_ogl.RedrawWindow();
}
