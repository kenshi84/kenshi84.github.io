#pragma once
#include "vstate.h"

class VStateAddParticle :
	public VState
{
public:
	VStateAddParticle(void);
	~VStateAddParticle(void);
	
	static inline VStateAddParticle* getInstance(){
		static VStateAddParticle p;
		return &p;
	}
	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
	
};
