#include "StdAfx.h"
#include ".\vcrosssection.h"

VCrossSection::VCrossSection(void)
{
}

VCrossSection::~VCrossSection(void)
{
}

void VCrossSection::CalcAreaType() {
//	fprintf(stderr, "Calculating pixel buffer...");
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	
//	fprintf(stderr, "copying...");
	//Silhouette���R�s�[
	memcpy(m_bufAreaType.GetBufferHead(), m_bufSilhouette.GetBufferHead(), sizeof(COLORREF) * m_bufAreaType.Width() * m_bufAreaType.Height());
	//memcpy(m_bufAreaType.GetBufferHead(), m_bufSilhouette.GetBufferHead(), sizeof(unsigned char) * m_bufAreaType.Width() * m_bufAreaType.Height());
	
	//for (int iy = 0; iy < m_bufSilhouette.Height(); ++iy) 
	//	for (int ix = 0; ix < m_bufSilhouette.Width(); ++ix)
	//		fprintf(stderr, "%08X\n", *m_bufSilhouette.GetPixelp(ix, iy));
	
	//for (int iy = 0; iy < ogl.GetHeight(); ++iy)
	//	for (int ix = 0; ix < ogl.GetWidth(); ++ix)
	//		*m_bufAreaType.GetPixelp(ix, iy) = *m_bufSilhouette.GetPixelp(ix, iy) ? 0 : 3;
	
//	fprintf(stderr, "drawing...");
	
	////���o�b�t�@�o�͂��̂P
	//m_bufAreaType.SaveAsColorImage("buf1.ppm");
	
	//Draw stroke
	int r = 5;
	for (int i = 1; i < (int)m_stroke2D.size(); ++i) {
		vector<CPoint> plist;
		Bresenham(m_stroke2D[i-1], m_stroke2D[i], plist);
		for (int j = 0; j < (int)plist.size(); ++j) {
			CPoint p = plist[j];
			for (int dx = -r; dx <= r; ++dx)
				for (int dy = -r; dy <= r; ++dy) 
					*m_bufAreaType.GetPixelp(p.x+dx, ogl.GetHeight()-1 - p.y-dy) = RGB_RED;
		}
	}
	
	////���o�b�t�@�o�͂��̂Q
	//m_bufAreaType.SaveAsColorImage("buf2.ppm");
	
	//for (int i = 0; i < (int)m_stroke2D.size(); ++i)
	//	*m_bufAreaType.GetPixelp(m_stroke2D[i].x, ogl.GetHeight()-1 - m_stroke2D[i].y) = RGB_GREEN;
	
//	fprintf(stderr, "filling...");
	bool br;
	/* m_bufAreaType=0�ƂȂ�Ƃ����1��2�œh��Ԃ� */
	br = false;
	for (int iy = 0; iy < ogl.GetHeight(); ++iy) {
		for (int ix = 0; ix < ogl.GetWidth(); ++ix)
			if (*m_bufAreaType.GetPixelp(ix, iy) == RGB_WHITE) {
				SeedFillScanLine<COLORREF>(m_bufAreaType, ix, iy, RGB_GREEN);
				br = true;
				break;
			}
		if (br) break;
	}
	////�{���͂���Ȃ�
	//br = false;
	//for (int iy = 0; iy < ogl.GetHeight(); ++iy) {
	//	for (int ix = 0; ix < ogl.GetWidth(); ++ix)
	//		if (*m_bufAreaType.GetPixelp(ix, iy) == RGB_BLACK) {
	//			SeedFillScanLineFast<COLORREF>(m_bufAreaType, ix, iy, RGB_BLUE);
	//			br = true;
	//			break;
	//		}
	//	if (br) break;
	//}
	
	////���o�b�t�@�o�͂��̂R
	//m_bufAreaType.SaveAsColorImage("buf3.ppm");
	
	////�o��
	//FILE* fp = fopen("tmp.dat", "w");
	//for (int iy = 0; iy < ogl.GetHeight(); ++iy) {
	//	fprintf(fp, "y=%d:\n", iy);
	//	for (int ix = 0; ix < ogl.GetWidth(); ++ix) {
	//		fprintf(fp, "%08X\n", *m_bufAreaType.GetPixelp(ix, iy));
	//		//char letter;
	//		//switch(*m_bufAreaType.GetPixelp(ix, iy)) {
	//		//	case RGB_WHITE:
	//		//		letter = 'w';
	//		//		break;
	//		//	case RGB_BLACK:
	//		//		letter = '*';
	//		//		break;
	//		//	case RGB_RED:
	//		//		letter = 'r';
	//		//		break;
	//		//	case RGB_GREEN:
	//		//		letter = 'g';
	//		//		break;
	//		//	case RGB_BLUE:
	//		//		letter = 'b';
	//		//		break;
	//		//	default:
	//		//		letter = 'X';
	//		//}
	//		//fprintf(fp, "%c", letter);
	//	}
	//	fprintf(fp, "\n");
	//}
	//fclose(fp);
	
//	fprintf(stderr, "completed!\n");
}

void VCrossSection::CalcHiddenVtx() {
//	fprintf(stderr, "Calculating Vertices to be hidden...");
	
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	bool br;
	
	//1��2�̂ǂ�����B���ׂ������ׂ�
	COLORREF whichtohide = RGB_WHITE;
	br = false;
	for (int iy = 0; iy < ogl.GetHeight(); ++iy) {
		for (int ix = 0; ix < ogl.GetWidth(); ++ix) {
			if (*m_bufAreaType.GetPixelp(ix, iy) == RGB_GREEN) {
				whichtohide = 
					IsRightSideOfStroke(CPoint(ix, ogl.GetHeight() - 1 - iy), m_stroke2D) 
					? RGB_WHITE 
					: RGB_GREEN;
				br = true;
				break;
			}
		}
		if (br) break;
	}
	
	//�B���ׂ��|���S����ݒ�
	for(int i = 0; i < (int)poly.vertices.size(); ++i) {
		if (m_vproj[i].x < 0 || m_vproj[i].x >= m_bufAreaType.Width()
		||	m_vproj[i].y < 0 || m_vproj[i].y >= m_bufAreaType.Height()) { 
			m_isHiddenVtx[i] = false;
			continue;
		}
		m_isHiddenVtx[i] =
			*m_bufAreaType.GetPixelp(m_vproj[i].x, m_vproj[i].y) == whichtohide
			? true
			: false;
	}

//	fprintf(stderr, "complete!\n");
}

void VCrossSection::CalcVolumeOnCrossSection() {
/*
	Calculate volumes on the cross-section surface
	using projection & boolean pixel buffer
*/
	fprintf(stderr, "Calculating volumes on cross-section ... ");
	
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	for (int i = 0; i < NUMGRID_POW3; ++i)
		vdata[i].isOnCrossSection = false;
	
	ogl.MakeOpenGLCurrent();
	for (int ix = 0; ix < NUMGRID; ++ix)
	for (int iy = 0; iy < NUMGRID; ++iy)
	for (int iz = 0; iz < NUMGRID; ++iz) {
		if (!vdata[IXGRID(ix, iy, iz)].isInner) continue;
		double objx = ix / (double)NUMGRID;
		double objy = iy / (double)NUMGRID;
		double objz = iz / (double)NUMGRID;
		double winx, winy, winz;
		
		ogl.Project(objx, objy, objz, winx, winy, winz);
		int sx = (int)winx;
		int sy = (int)winy;
		if (sx < 0 || sx >= m_bufAreaType.Width() || sy < 0 || sy >= m_bufAreaType.Height()) continue;
		if (*m_bufAreaType.GetPixelp(sx, sy) == RGB_RED)
			vdata[IXGRID(ix, iy, iz)].isOnCrossSection = true;
	}
	wglMakeCurrent(NULL, NULL);
	
	fprintf(stderr, "Completed!\n");
}

void VCrossSection::OnSize(int cx, int cy) {
	m_bufAreaType.Allocate(cx, cy);
	m_bufSilhouette.Allocate(cx, cy);
}

void VCrossSection::ViewChanged() {
	//���o�b�t�@�Ƀ��f���̃V���G�b�g��`��
	fprintf(stderr, "drawing silhouette on back-buffer...");
	
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	
	ogl.PrepareForFrameBufferCopy();
	ogl.OnDraw_Begin();
	
	ILVector3D eyeDir = ogl.getFocusPoint() - ogl.getEyePoint();
	
	glDisable(GL_BLEND);
	glDisable(GL_LIGHTING);
	glShadeModel(GL_FLAT);
	glColor4ub(255, 255, 255, 255);
	
	glBegin(GL_TRIANGLES);
	for( int i = 0 ; i < (int) poly.polygons.size(); ++i)
	{
		ILPolygon &p = poly.polygons[i];
//		if (eyeDir * p.normal > 0) continue;
		glVertex3dv( poly.vertices[ p.vtx[0] ].pos );
		glVertex3dv( poly.vertices[ p.vtx[1] ].pos );
		glVertex3dv( poly.vertices[ p.vtx[2] ].pos );
	}
	glEnd();
	
	glLineWidth(10);
	glBegin(GL_LINES);
	for( int i = 0 ; i < (int) poly.edges.size(); ++i)
	{
		ILWingedEdge &we = poly.edges[i];
		ILPolygon &p0 = poly.polygons[we.p[0]];
		ILPolygon &p1 = poly.polygons[we.p[1]];
		if (eyeDir * p0.normal > 0 || eyeDir * p1.normal > 0) continue;
		glVertex3dv( poly.vertices[ we.v[0] ].pos );
		glVertex3dv( poly.vertices[ we.v[1] ].pos );
	}
	glEnd();
	
	ogl.OnDraw_End();
	
	glEnable(GL_LIGHTING);
	glEnable(GL_BLEND);
	glShadeModel(GL_SMOOTH);
	
	//ogl.m_ColorBuffer.SaveAsColorImage("tmp.ppm");
//	for (int iy = 0; iy < ogl.GetHeight(); ++iy) {
//		for (int ix = 0; ix < ogl.GetWidth(); ++ix) {
//			unsigned char *p = (unsigned char *)ogl.m_ColorBuffer.GetPixelp(ix, iy);
//			*m_bufSilhouette.GetPixelp(ix, ogl.GetHeight()-iy-1) = *p == 0 ? 0 : 3;
////			*m_bufAreaType.GetPixelp(ix, ogl.GetHeight()-iy-1) = *p == 0 ? 0 : 3;
//		}
//	}
	/* copy back buffer */
	memcpy(m_bufSilhouette.GetBufferHead(), ogl.m_ColorBuffer.GetBufferHead(), sizeof(COLORREF) * m_bufSilhouette.Width() * m_bufSilhouette.Height());
	
	fprintf(stderr, "projecting vertices...");
	//�e���_��project�����W���o����
	ogl.MakeOpenGLCurrent();
	for (int i = 0; i < (int)poly.vertices.size(); ++i) {
		ILVector3D winxy;
		ogl.Project(poly.vertices[i].pos, winxy);
		m_vproj[i].x = (int)(winxy.data[0]);
		m_vproj[i].y = (int)(winxy.data[1]);
	}
	wglMakeCurrent(NULL, NULL);
	
	fprintf(stderr, "completed!\n");
}

void VCrossSection::ClearHiddenVtx() {
	for (int i = 0; i < (int)VCore::getInstance()->m_poly.vertices.size(); ++i)
		m_isHiddenVtx[i] = false;
}

void VCrossSection::ClearPointCrossSectionStroke() {
	//VCore* core = VCore::getInstance();
	
	m_strokeNear.clear();
	m_strokeFar.clear();
	m_stroke2D.clear();
}

void VCrossSection::ClearCrossSection() {
	m_shape.clear();
	for (int i = 0; i < NUMGRID_POW3; ++i)
		VCore::getInstance()->m_vdata[i].isOnCrossSection = false;
}

void VCrossSection::AddPointCrossSectionStroke(CPoint point) {
/*
	Add Point to
		VCore::m_strokeCrossSection3DNear
		VCore::m_strokeCrossSection3DFar
		VCrossSection::m_strokeCrossSection2D
*/
	//VCore* core = VCore::getInstance();
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	ILVector3D start, ori;
	
	ogl.k_GetScreenCoordToGlobalLine(point.x, point.y, start, ori);
	ILVector3D n = (ogl.getFocusPoint() - ogl.getEyePoint()).Normalize();
	double r = 0.6;
	double tNear = GetIntersectionLinePlane(start, ori, ogl.getFocusPoint() - r * n, n);
	double tFar = GetIntersectionLinePlane(start, ori, ogl.getFocusPoint() + r * n, n);
	m_strokeNear.push_back(start + tNear*ori);
	m_strokeFar.push_back(start + tFar*ori);
	m_stroke2D.push_back(point);
}

bool VCrossSection::CheckValid() {
/*
	Check if the stroke is too short or has any loops
*/
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	ILPolygonModel& poly = VCore::getInstance()->m_poly;

	if (!m_isValid) {
		fprintf(stderr, "Stroke doesn't cross any polygons!\n");
		return false;
	}
	
	PointInfoOnPolygon pinfo;
	if (GetIntersectionScreenCoordPolygonModel(m_stroke2D.back(), pinfo)) {
		fprintf(stderr, "Stroke is too short!\n");
		return false;
	}
	if (HasLoopInStroke(m_stroke2D)) {
		fprintf(stderr, "Loop is detected!\n");
		return false;
	}
	
	return true;
}

void VCrossSection::CalcCrossSectionShape() {
	fprintf(stderr, "Calculating shape of cross-section ... ");
	
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	m_shape.clear();
	
	vector<int> idList;
	for (int i = 0; i < NUMGRID_POW3; ++i)
		if (vdata[i].isOnCrossSection && vdata[i].isBound)
			idList.push_back(vdata[i].pinfo.polyID);
	
	vector<bool> pdone((int)poly.polygons.size());
	for (int i = 0; i < (int)poly.polygons.size(); ++i)
		pdone[i] = false;
	
	for (int i = 0; i < (int)idList.size(); ++i) {
		int pid = idList[i];
		
		if (pdone[pid]) continue;
		pdone[pid] = true;
		if (!CalcCrossSectionShapeOnePolygon(pid)) continue;
		while(true) {
			ILWingedEdge& e0 = poly.edges[poly.polygons[pid].edges[0]];
			ILWingedEdge& e1 = poly.edges[poly.polygons[pid].edges[1]];
			ILWingedEdge& e2 = poly.edges[poly.polygons[pid].edges[2]];
			int p0 = (e0.p[0] == pid) ? e0.p[1] : e0.p[0];
			int p1 = (e1.p[0] == pid) ? e1.p[1] : e1.p[0];
			int p2 = (e2.p[0] == pid) ? e2.p[1] : e2.p[0];
			if (!pdone[p0]) {
				pdone[p0] = true;
				if (CalcCrossSectionShapeOnePolygon(p0)) {
					pid = p0;
					continue;
				}
			}
			if (!pdone[p1]) {
				pdone[p1] = true;
				if (CalcCrossSectionShapeOnePolygon(p1)) {
					pid = p1;
					continue;
				}
			}
			if (!pdone[p2]) {
				pdone[p2] = true;
				if (CalcCrossSectionShapeOnePolygon(p2)) {
					pid = p2;
					continue;
				}
			}
			break;
		}
	}
	fprintf(stderr, "Completed!\n");
}

bool VCrossSection::CalcCrossSectionShapeOnePolygon(int pid) {
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	
	ILPolygon& p = poly.polygons[pid];
	ILVector3D& v0 = poly.vertices[p.vtx[0]].pos;
	ILVector3D& v1 = poly.vertices[p.vtx[1]].pos;
	ILVector3D& v2 = poly.vertices[p.vtx[2]].pos;
	bool ret = false;
	for (int j = 1; j < (int)m_strokeNear.size(); ++j) {
		ILVector3D& e0 = m_strokeNear[j-1] - m_eyePoint;
		ILVector3D& e1 = m_strokeNear[j]   - m_eyePoint;
		ILVector3D ce_a, ce_b;
		if (!CalcCrossEdge(m_eyePoint, e0, e1, v0, v1, v2, ce_a, ce_b)) continue;
		m_shape.push_back(ce_a);
		m_shape.push_back(ce_b);
		ret = true;
	}
	return ret;
}

void VCrossSection::setEyePoint(ILVector3D v) {
	m_eyePoint = v;
}

bool VCrossSection::CalcIntersectionPointCrossSection(CPoint point, ILVector3D& result) {
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	ILVector3D start, ori;
	ogl.k_GetScreenCoordToGlobalLine(point.x, point.y, start, ori);
	double lt, pt0, pt1;
	for (int i = 1; i < (int)m_strokeNear.size(); ++i) {
		GetIntersectionLinePlane(start, ori, m_eyePoint, m_strokeNear[i-1]-m_eyePoint, m_strokeNear[i]-m_eyePoint, lt, pt0, pt1);
		if (pt0 > 0 && pt1 > 0) {
			result = start + lt * ori;
			int ix = (int)(result.data[0] * NUMGRID);
			int iy = (int)(result.data[1] * NUMGRID);
			int iz = (int)(result.data[2] * NUMGRID);
			if (ix >= 0 && ix < NUMGRID
			&&  iy >= 0 && iy < NUMGRID
			&&  iz >= 0 && iz < NUMGRID
			&&  vdata[IXGRID(ix, iy, iz)].isInner)
				return true;
			else
				return false;
		}
	}
	return false;
}

bool VCrossSection::GetIntersectionScreenCoordPolygonModel(CPoint &point, PointInfoOnPolygon& result) {
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	
	ILVector3D start, ori;
	ogl.k_GetScreenCoordToGlobalLine(point.x, point.y, start, ori);
	
	double dmin = HUGE_VAL;
	bool isInterSec = false;
	for( int i = 0; i < (int) poly.polygons.size(); i++)
	{
		ILPolygon &p = poly.polygons[i];
		if (m_isHiddenVtx[p.vtx[0]] || m_isHiddenVtx[p.vtx[1]] || m_isHiddenVtx[p.vtx[2]]) continue;
		ILVector3D &n  = poly.vertices[p.vtx[0]].norm;
		ILVector3D &v0 = poly.vertices[p.vtx[0]].pos;
		ILVector3D &v1 = poly.vertices[p.vtx[1]].pos;
		ILVector3D &v2 = poly.vertices[p.vtx[2]].pos;
		double dp = ori * n;
		if (dp > 0) continue;
		/*
			start + x[0] * ori = (1 - x[1] - x[2]) * v0 + x[1] * v1 + x[2] * v2;
		*/
		//solve the 3-dimensional linear equation
		double src[9] = {
			ori.data[0], v0.data[0] - v1.data[0], v0.data[0] - v2.data[0],
			ori.data[1], v0.data[1] - v1.data[1], v0.data[1] - v2.data[1],
			ori.data[2], v0.data[2] - v1.data[2], v0.data[2] - v2.data[2]
		};
		double tgt[9];
		SquareMat_CalcInvMatrix<double>(src, tgt, 3);
		double b[3] = {
			v0.data[0] - start.data[0],
			v0.data[1] - start.data[1],
			v0.data[2] - start.data[2]
		};
		double x[3];
		SquareMat_MultVec<double>(tgt, b, x, 3);
		if (x[0] < dmin && x[1] > 0 && x[2] > 0 && x[1] + x[2] < 1) {
			dmin = x[0];
			result.polyID = i;
			result.s = x[1];
			result.t = x[2];
			isInterSec = true;
		}
	}
	return isInterSec;
}
