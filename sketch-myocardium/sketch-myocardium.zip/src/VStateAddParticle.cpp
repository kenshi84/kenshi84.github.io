#include "StdAfx.h"
#include ".\vstateaddparticle.h"

#include "VCore.h"
#include "VCrossSection.h"
#include "VStateDefault.h"

VStateAddParticle::VStateAddParticle(void)
{
}

VStateAddParticle::~VStateAddParticle(void)
{
}

void VStateAddParticle::OnLButtonDown(UINT nFlags, CPoint point) {
	fprintf(stderr, "State Error! - VStateAddParticle::OnLButtonDown\n");
}

void VStateAddParticle::OnLButtonUp(UINT nFlags, CPoint point) {
	VCore::getInstance()->m_state = VStateDefault::getInstance();
}

void VStateAddParticle::OnMouseMove(UINT nFlags, CPoint point) {
	ILVector3D v;
	if (VCrossSection::getInstance()->CalcIntersectionPointCrossSection(point, v)) {
		VCore::getInstance()->m_particle.push_back(v);
		//VCore::getInstance()->m_particleVelocity.push_back(ILVector3D());
	}
}
