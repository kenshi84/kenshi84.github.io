#pragma once
#include "VCore.h"

#define RGB_WHITE	(0xFF000000 | RGB(0xFF, 0xFF, 0xFF))
#define RGB_BLACK	(0xFF000000 | RGB(0   , 0   , 0   ))
#define RGB_RED		(0xFF000000 | RGB(0xFF, 0   , 0   ))
#define RGB_GREEN	(0xFF000000 | RGB(0   , 0xFF, 0   ))
#define RGB_BLUE	(0xFF000000 | RGB(0   , 0   , 0xFF))

class VCrossSection
{
public:
	VCrossSection(void);
	~VCrossSection(void);
	
	static inline VCrossSection* getInstance(){
		static VCrossSection p;
		return &p;
	}
	
	void ClearPointCrossSectionStroke();
	void ClearCrossSection();
	void AddPointCrossSectionStroke(CPoint point);
	void CalcVolumeOnCrossSection();
	void CalcCrossSectionShape();
	void CalcHiddenVtx();
	void ClearHiddenVtx();
	bool CheckValid();
	void setEyePoint(ILVector3D v);
	bool CalcIntersectionPointCrossSection(CPoint point, ILVector3D& result);
	void ViewChanged();
	void CalcAreaType();
	void OnSize(int cx, int cy);
	
	bool GetIntersectionScreenCoordPolygonModel(CPoint &point, PointInfoOnPolygon& result);
	
	bool m_isValid;
	vector<bool> m_isHiddenVtx;
	vector<CPoint> m_vproj;
	
	vector<ILVector3D> m_strokeNear, m_strokeFar;
	vector<CPoint> m_stroke2D;
	
	vector<ILVector3D> m_shape;
private:
	ILVector3D m_eyePoint;
	
	bool CalcCrossSectionShapeOnePolygon(int pid);
	
	ILOGL::CFrameBuf<COLORREF> m_bufAreaType;
	/*
		white : background
		black : unvisited
		red : stroke runs
		blue : one side
		green : another side
	*/
	ILOGL::CFrameBuf<COLORREF> m_bufSilhouette;
};

