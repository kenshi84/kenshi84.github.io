#include "StdAfx.h"
#include ".\vsurfacedatamanager.h"


VSurfaceDataManager::VSurfaceDataManager(void)
{
	//m_strokes3D.clear();
	//m_strokesPointInfo.clear();
}

VSurfaceDataManager::~VSurfaceDataManager(void)
{
}

void VSurfaceDataManager::AddStroke() {
	m_strokesPointInfo.push_back(vector<PointInfoOnPolygon>());
	m_strokes3D.push_back(vector<ILVector3D>());
}
void VSurfaceDataManager::AddPointToStroke(PointInfoOnPolygon pinfo) {
	m_strokesPointInfo.back().push_back(pinfo);
	m_strokes3D.back().push_back(pinfo.GetPosFromPolygonModel(VCore::getInstance()->m_poly));
}

void VSurfaceDataManager::NormalizeAll(){
	vector<SurfaceData>& sdata = VCore::getInstance()->m_sdata;

	for(int i = 0; i < (int)sdata.size(); i++)
		sdata[i].field.Normalize_Self();
}

void VSurfaceDataManager::LaplacianSmooth(){
	vector<SurfaceData>& sdata = VCore::getInstance()->m_sdata;
	
	fprintf(stderr, "Preparing for Laplacian Smoothing on surface ... ");
	int N = (int)sdata.size();
	
	for (int i = 0; i < N; i++) 
		if (sdata[i].isConstraint) {
			m_bx[i] = sdata[i].field.data[0];
			m_by[i] = sdata[i].field.data[1];
			m_bz[i] = sdata[i].field.data[2];
		} else
			m_bx[i] = m_by[i] = m_bz[i] = 0.;

	for (int i = 0; i < N; ++i)
		if (sdata[i].isConstraint) m_LtL.AddElement(i, i, 1.);
	
	fprintf(stderr, "Completed!\n");
	
	fprintf(stderr, "Solving Linear System [Surface] ... ");
	m_LtL.SolveLinearSystem(&m_bx[0], &m_vx[0], &m_by[0], &m_vy[0], &m_bz[0], &m_vz[0]);
	fprintf(stderr, "Completed!\n");
	
	for (int i = 0; i < N; i++) {
		sdata[i].field.data[0] = m_vx[i];
		sdata[i].field.data[1] = m_vy[i];
		sdata[i].field.data[2] = m_vz[i];
	}
	
	for (int i = 0; i < N; ++i)
		if (sdata[i].isConstraint) m_LtL.AddElement(i, i, -1.);
}

//void VSurfaceDataManager::LaplacianSmooth() {
//	SurfaceData*& sdata = VCore::getInstance()->m_sdata;
//	
//	fprintf(stderr, "Preparing for Laplacian Smoothing on surface ... ");
//	int N = (int)VCore::getInstance()->m_poly.vertices.size();
//	
//	for (int i = 0; i < N; i++) 
//		if (sdata[i].isConstraint) {
//			m_bx[i] = sdata[i].field.data[0];
//			m_by[i] = sdata[i].field.data[1];
//			m_bz[i] = sdata[i].field.data[2];
//		} else
//			m_bx[i] = m_by[i] = m_bz[i] = 0.;
//	
//	for (int i = 0; i < N; ++i)
//		if (sdata[i].isConstraint) m_LtL.AddToElement(i, i, 1.);
//	
//	fprintf(stderr, "Completed!\n");
//	
//	fprintf(stderr, "Solving Linear System of field x ... ");
//	m_LtL.SolveLinearSystemUsingUmfpack(m_bx, m_vx);
//	
//	fprintf(stderr, "Completed!\n");
//	
//	fprintf(stderr, "Solving Linear System of field y ... ");
//	m_LtL.SolveLinearSystemUsingUmfpack(m_by, m_vy);
//	fprintf(stderr, "Completed!\n");
//	
//	fprintf(stderr, "Solving Linear System of field z ... ");
//	m_LtL.SolveLinearSystemUsingUmfpack(m_bz, m_vz);
//	fprintf(stderr, "Completed!\n");
//
//	for (int i = 0; i < N; i++) {
//		sdata[i].field.data[0] = m_vx[i];
//		sdata[i].field.data[1] = m_vy[i];
//		sdata[i].field.data[2] = m_vz[i];
//	}
//	
//	for (int i = 0; i < N; ++i)
//		if (sdata[i].isConstraint) m_LtL.AddToElement(i, i, -1.);
//	
//}

void VSurfaceDataManager::CalcLtL(){
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	int N = (int)poly.vertices.size();

	m_LtL.SetSize(N);
	m_bx.resize(N);
	m_by.resize(N);
	m_bz.resize(N);
	m_vx.resize(N);
	m_vy.resize(N);
	m_vz.resize(N);

	fprintf(stderr, "Calculating LtL of Surface Data(size : %d)...", N);
	
	
	for (int i = 0; i < N; ++i) {
		m_LtL.AddElement(i, i, 1.);
		vector<int> vs;
		poly.GetVerticesAroundVertexWithBounrary(i,&vs);
		int M = (int)vs.size();
		double _M = -1./(double)M;
		for (int k = 0; k < M; ++k)
			m_LtL.AddElement(i, vs[k], _M);
	}
	fprintf(stderr, "(L:%d elements)...", m_LtL.CountElements());
	
	m_LtL.MultSelfTransposeSelf();
	fprintf(stderr, "(LtL:%d elememts)...", m_LtL.CountElements());
	
	m_LtL.InitializeToSolve();

	fprintf(stderr, "Completed!\n");
}

//void VSurfaceDataManager::CalcLtL() {
//	ILPolygonModel& poly = VCore::getInstance()->m_poly;
//	int N = (int)poly.vertices.size();
//	TSparseMatrix L;
//	L.Allocate(N, N);
//
//	fprintf(stderr, "Calculating LtL of Surface Data(size : %d)...", N);
//	
//	/* set connective information */
//	for (int i = 0, offi = 0; i < N; ++i, offi+=N) {
//		L.AddToElement(i, i, 1.);
//		vector<int> vs;
//		poly.GetVerticesAroundVertexWithBounrary(i,&vs);
//		int M = (int)vs.size();
//		for (int k = 0; k < M; ++k)
//			L.AddToElement(i, vs[k], -1./(double)M);
//	}
//	fprintf(stderr, "(L:%d elements)...", L.CountElements());
//	
//	//L.TraceMatrix();
//
//	L.MultSelfTransposeSelf(m_LtL);
//	//L.MultSelfSelfTranspose(m_LtL);
//	fprintf(stderr, "(LtL:%d elememts)...", m_LtL.CountElements());
//	m_LtL.initializeLinearSolverFields();
//	
//	fprintf(stderr, "Completed!\n");
//}

void VSurfaceDataManager::ClearData() {
	vector<SurfaceData>& sdata = VCore::getInstance()->m_sdata;
	
	for (int i = 0; i < (int)sdata.size(); i++)
		sdata[i] = SurfaceData();

	m_strokes3D.clear();
	m_strokesPointInfo.clear();
}

void VSurfaceDataManager::SetConstraints() {
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	vector<SurfaceData>& sdata = VCore::getInstance()->m_sdata;
	
	for (int i = 0; i < (int)sdata.size(); ++i) {
		sdata[i].field[0] = 0.;
		sdata[i].field[1] = 0.;
		sdata[i].field[2] = 0.;
		sdata[i].isConstraint = false;
	}
	
	for (int i = 0; i < (int)m_strokesPointInfo.size(); ++i) {
		PointInfoOnPolygon p0, p1;
		ILVector3D v0, v1;
		p0 = m_strokesPointInfo[i].front();
		v0 = m_strokes3D[i].front();
		for (int j = 1; j < (int)m_strokesPointInfo[i].size(); ++j) {
			p1 = m_strokesPointInfo[i][j];
			v1 = m_strokes3D[i][j];
			ILVector3D w = v1 - v0;
			for (int i = 0; i < 3; ++i) {
				sdata[poly.polygons[p0.polyID].vtx[i]].field += w;
				sdata[poly.polygons[p0.polyID].vtx[i]].isConstraint = true;
			}
			p0 = p1;
			v0 = v1;
		}
	}
	
	NormalizeAll();
}

void VSurfaceDataManager::SimpleSmooth() {
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	vector<SurfaceData>& sdata = VCore::getInstance()->m_sdata;
	
	for (int i = 0; i < (int)sdata.size(); ++i)
	{
		if (sdata[i].isConstraint)
			continue;
		vector<int> vs;
		poly.GetVerticesAroundVertexWithBounrary(i, &vs);
		ILVector3D w(0,0,0);
		for (int j = 0; j < (int)vs.size(); ++j)
			w += sdata[vs[j]].field;
		w /= (double)vs.size();
		sdata[i].field = w;
	}
}

void VSurfaceDataManager::RemoveNonTangential() {
	vector<SurfaceData>& sdata = VCore::getInstance()->m_sdata;
	
	for (int i = 0; i < (int)sdata.size(); i++) {
		ILVector3D& n = VCore::getInstance()->m_poly.vertices[i].norm;
		sdata[i].field -= (sdata[i].field * n) * n;
	}
}
