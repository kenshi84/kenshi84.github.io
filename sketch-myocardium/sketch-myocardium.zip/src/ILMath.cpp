#include "StdAfx.h"
#include "ILMath.h"
#ifdef ILMATH_ENABLE_UMFPACK_MATRIX_SOLVER
#include "SparseMatSolve/SparseMatSolve.h"
#endif


// Just the ordinary vector operations
vector<double>& operator*= (vector<double>& vec,const double scalar ){
	for( int i=0;i<(int)vec.size();i++ )
		vec[i] = scalar * vec[i] ;
	return vec ;
}
vector<double> operator* (const double scalar,const vector<double>& vec ){
	vector<double> result ;
	result.resize( vec.size() ) ;
	for( int i=0;i<(int)vec.size();i++ )
		result[i] = scalar * vec[i] ;
	return result ;
}
vector<double> operator* (const vector<double>& vec,const double scalar ){
	vector<double> result ;
	result.resize( vec.size() ) ;
	for( int i=0;i<(int)vec.size();i++ )
		result[i] = scalar * vec[i] ;
	return result ;
}
double operator* ( const vector<double>& vec1,const vector<double>& vec2 ){
	assert( vec1.size() == vec2.size() ) ;
	double result = 0 ;
	for( int i=0;i<(int)vec1.size();i++ )
		result += vec1[i] * vec2[i] ;
	return result ;
}

vector<double> operator+ ( const vector<double>& vec1,const vector<double>& vec2 ){
	assert( vec1.size() == vec2.size() ) ;
	vector<double> result ;
	result.resize( vec1.size() ) ;
	for( int i=0;i<(int)vec1.size();i++ )
		result[i] = vec1[i] + vec2[i] ;
	return result ;
}

vector<double> operator- ( const vector<double> vec ){
	vector<double> result ;
	result.resize( vec.size() ) ;
	for( int i=0;i<(int)vec.size();i++ )
		result[i] = -vec[i] ;
	return result ;
}

vector<double> operator- ( const vector<double>& vec1,const vector<double>& vec2 ){
	assert( vec1.size() == vec2.size() ) ;
	vector<double> result ;
	result.resize( vec1.size() ) ;
	for( int i=0;i<(int)vec1.size();i++ )
		result[i] = vec1[i] - vec2[i] ;
	return result ;
}




double operator* ( CSparseMatrix::Row& vec1,CSparseMatrix::Row& vec2 ){
	double result = 0 ;
	vector<int>::iterator v1id = vec1.indice.begin() ;
	vector<int>::iterator v2id = vec2.indice.begin() ;
	vector<double>::iterator v1cf = vec1.coefficients.begin() ;
	vector<double>::iterator v2cf = vec2.coefficients.begin() ;
	while( v1id != vec1.indice.end() && v2id != vec2.indice.end() ){
		if( *v1id == *v2id ){
			result += *v1cf * *v2cf ;
			v1id++ ;	v2id++ ;	v1cf++ ;	v2cf++ ;
		} else if( *v1id > *v2id ){
			v2id++ ;	v2cf++ ;
		} else {
			v1id++ ;	v1cf++ ;
		}
	}
	return result ;
}

vector<double> CSparseMatrix::operator* (const vector<double>& vec ){
	assert( GetColumnNum() == vec.size() ) ;
	vector<double> result ;
	result.resize( GetRowNum() ) ;
	for( int row=0;row<GetRowNum();row++ )
		result[row] = RowMulVector( row,vec ) ;
	return result ;
}

ILMatrix16 ILMatrix16::GetInvMatrix(){
	if( fabs(SquareMat_CalcDeterminant(data,4))<VSN )	return false ;
	ILMatrix16 ret ;
	SquareMat_CalcInvMatrix(GetTransposeMatrix().data,ret.data,4) ;
	return ret.GetTransposeMatrix() ;
}

bool ILMatrix16::GetInvMatrix_Self(){
	if( fabs(SquareMat_CalcDeterminant(data,4))<VSN )	return false ;
	ILMatrix16 tmp ;
	SquareMat_CalcInvMatrix(GetTransposeMatrix().data,tmp.data,4) ;
	memcpy( data,tmp.GetTransposeMatrix().data,sizeof(double)*16 ) ;
	return true ;
}

void ILMatrix16::SetIdentity(){
	memset(data,0,sizeof(double)*16);
	data[0]=1.0f;
	data[5]=1.0f;
	data[10]=1.0f;
	data[15]=1.0f;
}
void ILMatrix16::SetAsRotateX(double angle){
	SetIdentity();
	double c=(double)cos((double)angle);
	double s=(double)sin((double)angle);
	data[5]=c;		//data[5]=c;
	data[9]=-s;		//data[6]=-s;
	data[6]=s;		//data[9]=s;
	data[10]=c;		//data[10]=c;
}
void ILMatrix16::SetAsRotateY(double angle){
	SetIdentity();
	double c=(double)cos((double)angle);
	double s=(double)sin((double)angle);
	data[0]=c;
	data[8]=s;		//data[2]=-s;
	data[2]=-s;		//data[8]=s;
	data[10]=c;		//data[10]=c;
}
void ILMatrix16::SetAsRotateZ(double angle){
	SetIdentity();
	double c=(double)cos((double)angle);
	double s=(double)sin((double)angle);
	data[0]=c;
	data[4]=-s;		//data[1]=s;
	data[1]=s;		//data[4]=s;
	data[5]=c;		//data[5]=c;
}

bool ILMatrix16::RotateAlongArbitraryAxis(const ILVector3D& axis 
										 ,double cosangle,double sinangle){
	if(cosangle==1.0f && sinangle==0.0f)	{
		SetIdentity();
		return true;
	}
	if(axis.Length()==0.0f){
		SetIdentity() ;
		return false;
	}
	ILVector3D ax=axis;
	if(!ax.Normalize_Self())	assert(0);

	double u,v,w;
	u=ax.data[0];
	v=ax.data[1];
	w=ax.data[2];

	SetIdentity();
	data[0]=u*u+(1-u*u)*cosangle;
	data[4]=u*v*(1-cosangle)-w*sinangle;
	data[8]=u*w*(1-cosangle)+v*sinangle;
	data[1]=u*v*(1-cosangle)+w*sinangle;
	data[5]=v*v+(1-v*v)*cosangle;
	data[9]=v*w*(1-cosangle)-u*sinangle;
	data[2]=u*w*(1-cosangle)-v*sinangle;
	data[6]=v*w*(1-cosangle)+u*sinangle;
	data[10]=w*w+(1-w*w)*cosangle;
	/*
	data[0]=u*u+(1-u*u)*cosangle;
	data[1]=u*v*(1-cosangle)-w*sinangle;
	data[2]=u*w*(1-cosangle)+v*sinangle;
	data[4]=u*v*(1-cosangle)+w*sinangle;
	data[5]=v*v+(1-v*v)*cosangle;
	data[6]=v*w*(1-cosangle)-u*sinangle;
	data[8]=u*w*(1-cosangle)-v*sinangle;
	data[9]=v*w*(1-cosangle)+u*sinangle;
	data[10]=w*w+(1-w*w)*cosangle;
	*/
	return true;
}
bool ILMatrix16::VirtualTrackBall(const double cx,const double cy
								 ,const double dx,const double dy){
	if(dx==0.0f && dy == 0.0f)
		return false;

	ILVector3D v1(cx,cy,1),v2(cx+dx,cy+dy,1);
	RotateAlongArbitraryAxis(v1^v2,cos(v1,v2),sin(v1,v2));

	return true;
}

void ILMatrix16::GetRotCenterAxisAndAngle(ILVector3D& cent,double& angle){
	double Q[4] ;	// quaternion
	{
		ILMatrix16 tp = GetTransposeMatrix() ;
		double T = tp[0] + tp[5] + tp[10] + 1 ;	// Trace
		
		if( T > 0 ){
			double S = 0.5 / sqrt(T) ;
			Q[0] = ( tp[9] - tp[6] ) * S ;
			Q[1] = ( tp[2] - tp[8] ) * S ;
			Q[2] = ( tp[4] - tp[1] ) * S ;
			Q[3] = 0.25 / S ;
		} else {
			switch(MAX3ID(tp[0],tp[5],tp[10])){
			case 0:
				{
					double S = sqrt( 1.0 + tp[0] - tp[5] - tp[10] ) * 2;
					
					Q[0] = 0.5 / S;
					Q[1] = (tp[1] + tp[4] ) / S;
					Q[2] = (tp[2] + tp[8] ) / S;
					Q[3] = (tp[6] + tp[9] ) / S;
				} break ;
			case 1:
				{
					double S  = sqrt( 1.0 + tp[5] - tp[0] - tp[10] ) * 2;
					
					Q[0] = (tp[1] + tp[4] ) / S;
					Q[1] = 0.5 / S;
					Q[2] = (tp[6] + tp[9] ) / S;
					Q[3] = (tp[2] + tp[8] ) / S;
				} break ;
			case 2:
				{
					double S  = sqrt( 1.0 + tp[10] - tp[0] - tp[5] ) * 2;
					
					Q[0] = (tp[2] + tp[8] ) / S;
					Q[1] = (tp[6] +tp[9] ) / S;
					Q[2] = 0.5 / S;
					Q[3] = (tp[1] + tp[4] ) / S;
				} break ;
			}
		}
	}

	angle = acos(Q[3])*2 ;
	cent.Set(Q[0],Q[1],Q[2]) ;
	cent.Normalize_Self() ;
}

void ILMatrix16::DecomposeIntoRotZoomTranslate_byNaiveMethod(ILVector3D& rotAxis,double& rotAngle
	,double& zoomFactor,ILVector3D& translate){

	ILVector3D cent ;
	translate = (*this) * cent ;

	ILMatrix16 tmp;
	tmp.SetAsTranslateMatrix(-translate) ;

	ILMatrix16 newthis = tmp * (*this) ;

	ILVector3D x1(1,0,0) ;
	ILVector3D x1_ = newthis * x1 ;
	zoomFactor = x1_.Length() ;
	double zf_inv = 1/zoomFactor ;

	tmp.SetAsZoomMatrix(zf_inv,zf_inv,zf_inv) ;
	newthis = tmp * newthis ;

	newthis.GetRotCenterAxisAndAngle(rotAxis,rotAngle) ;
}







//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CSparseMatrix::CSparseMatrix():columnmax(0) {
	m_isLinearSolverFieldsReady = false;
	m_Ap_c = 0;
	m_Ai_c = 0;
	m_Ax_c = 0;
	m_b_c  = 0;
	m_x_c  = 0;

}

CSparseMatrix::~CSparseMatrix(){
	if(m_isLinearSolverFieldsReady){
		if(m_Ap_c != 0) delete m_Ap_c;
		if(m_Ai_c != 0) delete m_Ai_c;
		if(m_Ax_c != 0) delete m_Ax_c;
		if(m_b_c != 0)  delete m_b_c;
		if(m_x_c != 0)  delete m_x_c;
	}
}


void CSparseMatrix::SetChanged(){
	rowidmap.resize( rows.size() ) ;
	rowidmap_inv.resize( rows.size() ) ;
	for( int i=0;i<(int)rowidmap.size();i++ ){
		rowidmap[i] = rowidmap_inv[i] = i ;
	}
	vector< list<int> > columns_l(columnmax) ;
	for( int i=0;i<(int)rows.size();i++ ){
		for( int j=0;j<(int)rows[i].indice.size();j++ ){
			columns_l[ rows[i].indice[j] ].push_back( i ) ; //push_back for vector
		}
	}
	columns.resize( columnmax ) ;
	for( int i=0;i<columnmax;i++ )           copy<int>( columns_l[i] , columns[i] ) ;
}



/*
//call only when all elements of matrix are set.
void CSparseMatrix::SetChanged(){
	rowidmap.resize(     rows.size() ) ;
	rowidmap_inv.resize( rows.size() ) ;
	for( int i=0; i < (int)rowidmap.size(); ++i ){
		rowidmap[i] = rowidmap_inv[i] = i ;
	}
	columns.resize( columnmax ) ;
	for( int i=0;i<(int)rows.size();i++ ){
		for( int j=0;j<(int)rows[i].indice.size();j++ ){
			columns[ rows[i].indice[j] ].push_back( i ) ;	//push_back for vector
		}
	}
}

*/
/*swap�f�[�^���̂�swap����͕̂s�\. index��swap����
e.x. 
             id_inv   1 2 3 4    id 1 2 3 4
swap (1,4)            4     1       4     1
swap (2,4)              1   2       2 4          
                      4 1 3 2       2 4 3 1 <-data�����猩���������w���Ă���index  data[1]��raw[2] data[2]��raw[4]
					  ��row���猩��data�̈ʒu,�@raw[1]��data[4] row[2]��data[1]
*/
void CSparseMatrix::SwapRow( int row1,int row2 ){
	//raw  --> data ��index
	int tmp            = rowidmap_inv[row1] ;
	rowidmap_inv[row1] = rowidmap_inv[row2] ;
	rowidmap_inv[row2] = tmp ;
	
	//data --> row ��index  data��index�ɒ����Ă���swap����
	tmp = rowidmap[ rowidmap_inv[row1] ] ;
	rowidmap[ rowidmap_inv[row1] ] = rowidmap[ rowidmap_inv[row2] ] ;
	rowidmap[ rowidmap_inv[row2] ] = tmp ;
}

void CSparseMatrix::GetColumn( int columnnum,Column& column ){
	column.indice.clear() ;
	column.coefficients.clear() ;
	
	vector<int>& old_clm = columns[columnnum] ;
	double* clm_full = new double[rows.size()] ;
	memset( clm_full,0,sizeof(double)*rows.size() ) ;
	for( int i=0;i<(int)old_clm.size();i++ ){
		int rowid = rowidmap[ old_clm[i] ] ;
		clm_full[ rowid ] = GetElement( rowid,columnnum ) ;
	}
	column.indice.resize( old_clm.size() ) ;
	column.coefficients.resize( old_clm.size() ) ;
	int id = 0 ;
	for( int i=0;i<(int)rows.size();i++ ){
		if( clm_full[i] != 0 ){
			column.indice[id] = i ;
			column.coefficients[id] = clm_full[i] ;
			id++ ;
		}
	}
	delete[] clm_full ;
}




bool CSparseMatrix::t_GetTransposeMatrix(CSparseMatrix& transposed){
	transposed.Clear() ;
	transposed.rows.resize( columnmax ) ;
	transposed.columnmax = (int)rows.size() ;


	vector< list<int> >    rows_indices(columnmax) ;
	vector< list<double> > rows_coefs(columnmax) ;

	for( int i = 0 ; i < (int)rows.size() ; ++i ){
		Row& r = rows[ rowidmap_inv[i] ] ;
		for( int j = 0 ; j < (int)r.indice.size(); ++j ){
			rows_indices[ r.indice[j] ].push_back( i ) ; //push_back for vector
			rows_coefs[ r.indice[j] ].push_back( r.coefficients[j] );
		}
	}
	
	for( int i=0;i<(int)rows.size(); ++i){
		copy<int>( rows_indices[i],transposed.rows[i].indice ) ;
		copy<double>( rows_coefs[i],transposed.rows[i].coefficients ) ;
	}

	transposed.SetChanged() ;
	return true ;
}




bool CSparseMatrix::GetTransposeMatrix(CSparseMatrix& transposed){
	transposed.Clear() ;
	transposed.rows.resize( columnmax ) ;
	transposed.columnmax = (int)rows.size() ;
#if 1
	vector< list<int> >    rows_indices(columnmax) ;
	vector< list<double> > rows_coefs(columnmax) ;

	for( int i=0;i<(int)rows.size();i++ ){
		Row& r = rows[ rowidmap_inv[i] ] ;
		for( int j=0;j<(int)r.indice.size();j++ ){
			rows_indices[ r.indice[j] ].push_back( i ) ; //push_back for vector
			rows_coefs[ r.indice[j] ].push_back( r.coefficients[j] );
		}
	}
	
	for( int i=0;i<(int)rows.size();i++ ){
		copy<int>( rows_indices[i],transposed.rows[i].indice ) ;
		copy<double>( rows_coefs[i],transposed.rows[i].coefficients ) ;
	}
#else
	for( int i=0;i<(int)rows.size();i++ ){
		Row& r = rows[ rowidmap_inv[i] ] ;
		for( int j=0;j<(int)r.indice.size();j++ ){
			transposed.rows[ r.indice[j] ].indice.push_back( i ) ; //push_back for vector
			transposed.rows[ r.indice[j] ].coefficients.push_back( r.coefficients[j] );
		}
	}
#endif
	transposed.SetChanged() ;
	return true ;
}




/*

bool CSparseMatrix::GetTransposeMatrix(CSparseMatrix& transposed){
	transposed.Clear() ;
	transposed.rows.resize( columnmax ) ;
	transposed.columnmax = (int)rows.size() ;

	for( int i=0;i<(int)rows.size();i++ ){
		Row& r = rows[ rowidmap_inv[i] ] ;
		for( int j=0;j<(int)r.indice.size();j++ ){
			transposed.rows[ r.indice[j] ].indice.push_back( i ) ;	//push_back for vector
			transposed.rows[ r.indice[j] ].coefficients.push_back( r.coefficients[j] );
		}
	}
	transposed.SetChanged() ;
	return true ;
}
*/
bool CSparseMatrix::GetPseudoInverseMatrix(CSparseMatrix& pseudo){
	CSparseMatrix transposed ;
	GetTransposeMatrix( transposed ) ;

	CSparseMatrix matToInvert = (*this) * transposed ;

	int size = matToInvert.GetColumnNum() ;
	assert( matToInvert.GetColumnNum() == matToInvert.GetRowNum() ) ;

	double* matToInvert_C = matToInvert.ConvertToCArray() ;
	double* inverted_C = new double[ size*size ] ;
	memset( inverted_C,0,sizeof(double)*size*size ) ;

	if( !SquareMat_CalcInvMatrix( matToInvert_C,inverted_C,size ) ){
		delete[] matToInvert_C ;
		delete[] inverted_C ;
		return false ;
	}

	CSparseMatrix inverted ;
	inverted.ConvertFromCArray( inverted_C,size,size ) ;

	pseudo.Clear() ;
	pseudo = transposed * inverted ;

	delete[] matToInvert_C ;
	delete[] inverted_C ;

	return true ;
}

double* CSparseMatrix::ConvertToCArray(){
	int row_num = GetRowNum() ;
	int col_num = GetColumnNum() ;
	double* result = new double[ row_num * col_num ] ;
	memset( result,0,sizeof(double)*row_num*col_num ) ;
	for( int r = 0 ; r < row_num ; r++ ){
		Row row ;
		GetRow( r,row ) ;
		for( int i = 0 ; i < (int)row.indice.size() ; i++ ){
			int idx = row.indice[i] ;
			double val = row.coefficients[i] ;
			result[ r*col_num + row.indice[i] ] = row.coefficients[i] ;
		}
	}
	return result ;
}

void CSparseMatrix::ConvertFromCArray(double* c_mat,int row_num,int column_num ){
	Clear() ;
	Allocate( row_num,column_num ) ;
	for( int row=0;row<row_num;row++) for( int col=0;col<column_num;col++ ){
		if( c_mat[ row*column_num + col ] != 0 )
			SetElement( row,col,c_mat[ row*column_num + col ] ) ;
	}
	SetChanged() ;
}
/*
double CSparseMatrix::RowMulVector( const int rownum,const vector<double> vec ){
	assert( columnmax == vec.size() ) ;
	Row& r = rows[rowidmap_inv[rownum]] ;
	double result = 0 ;
	for( int i=0;i<(int)r.indice.size();i++ )
		result += r.coefficients[i] * vec[ r.indice[i] ] ;
	return result ;
}
*/

void CSparseMatrix::MultiplyRow( int rownum,double val ){
	Row& r = rows[rowidmap_inv[rownum]] ;
	for( int i=0;i<(int)r.coefficients.size();i++ )
		r.coefficients[i] *= val ;
}



// rows[dest_rownum] = rows[dest_rownum] + rows[src_rownum] * srcrow_mul ;
void CSparseMatrix::AddRows( int dest_rownum,int src_rownum,double srcrow_mul ){
	Row& dest = rows[rowidmap_inv[dest_rownum]] ;
	Row& src = rows[rowidmap_inv[src_rownum]] ;
	Row newrow ;
	newrow.indice.resize( dest.indice.size()+src.indice.size() ) ;	// maximum element number.
	newrow.coefficients.resize( newrow.indice.size() ) ;
	int newrow_idx = 0 ;
	int dest_idx = 0 ;
	int src_idx = 0 ;
	while( dest_idx != dest.indice.size() || src_idx != src.indice.size() ){
		bool bUseDest ;
		if( dest.indice.size() == dest_idx )	bUseDest = false ;
		else if( src.indice.size() == src_idx )	bUseDest = true ;
		else if( dest.indice[dest_idx] == src.indice[src_idx] ){	// increment both
			newrow.indice[newrow_idx] = dest.indice[dest_idx] ;
			newrow.coefficients[newrow_idx]
				= dest.coefficients[dest_idx] + src.coefficients[src_idx] * srcrow_mul ;
			newrow_idx++ ;
			dest_idx++ ;
			src_idx++ ;
			continue ;
		} else {
			bUseDest = (dest.indice[dest_idx] <= src.indice[src_idx]) ;
		}

		if( bUseDest ){
			newrow.indice[newrow_idx] = dest.indice[dest_idx] ;
			newrow.coefficients[newrow_idx] = dest.coefficients[dest_idx] ;
			dest_idx++ ;
			newrow_idx++ ;
		} else {
			newrow.indice[newrow_idx] = src.indice[src_idx] ;
			newrow.coefficients[newrow_idx] = src.coefficients[src_idx] * srcrow_mul ;
			src_idx++ ;
			newrow_idx++ ;
		}
	}
	newrow.indice.resize( newrow_idx ) ;
	newrow.coefficients.resize( newrow_idx ) ;

	dest = newrow ;
}

void CSparseMatrix::TraceMatrix(){
	for( int row = 0 ; row < (int)rows.size() ; row++ ){
		Row r ;
		GetRow( row,r ) ;
		int clm_id = 0 ;
		for( int column = 0 ; column < columnmax ; column++ ){
			if( clm_id >= (int)r.indice.size() || column < r.indice[clm_id] ){	
				TRACE( " 0" ) ;
			}
			else
			{
				TRACE( " -" ) ;
				clm_id++;
				//TRACE( " %f",r.coefficients[clm_id++] ) ;
			}
		}
		TRACE("\n") ;

				/*
#ifdef TRACE_EXIST
				TRACE( " 0" ) ;
#else	//TRACE_EXIST
				fprintf(stderr," 0") ;
#endif	//TRACE_EXIST
			} else {
				assert( column == r.indice[clm_id] ) ;
#ifdef TRACE_EXIST
				TRACE( " %f",r.coefficients[clm_id++] ) ;
#else	//TRACE_EXIST
				fprintf(stderr," %f",r.coefficients[clm_id++] ) ;
#endif	//TRACE_EXIST
			}
		}
#ifdef TRACE_EXIST
		TRACE("\n") ;
#else	//TRACE_EXIST
		fprintf(stderr,"\n") ;
#endif	//TRACE_EXIST
*/

	}
}

void CSparseMatrix::TraceVector( vector<double>& vec ){
	for( int i=0;i<(int)vec.size();i++ ){
#ifdef TRACE_EXIST
		TRACE(" %f",vec[i] ) ;
#else
		fprintf(stderr," %f",vec[i] ) ;
#endif
	}
#ifdef TRACE_EXIST
		TRACE("\n") ;
#else	//TRACE_EXIST
	fprintf(stderr,"\n") ;
#endif	//TRACE_EXIST
}

void CSparseMatrix::TransformToReducedRowEchelonMatrix( vector<int>* FreeColumns ){
	if( FreeColumns )	FreeColumns->clear() ;

	double* columns = new double[rows.size()] ;
	int dbg_rowsize = (int)rows.size() ;

	int startrow = 0 ;
	int column ;
	for( column = 0 ; column < columnmax ; column++ ){
		memset( columns,0,sizeof(double)*rows.size() ) ;
		for( int row = 0 ; row < startrow ; row++ )
			columns[row] = GetElement( row,column ) ;
		// find pivot row
		int pivot_row_id = -1 ;
		double pivot_val = -1 ;
		for( int pivot_candidate = startrow ; pivot_candidate < (int)rows.size() ; ++pivot_candidate ){
			columns[pivot_candidate] = GetElement( pivot_candidate,column ) ;
			double val = fabs( columns[pivot_candidate] ) ;
			if( pivot_val < val ){
				pivot_val = val ;
				pivot_row_id = pivot_candidate ;
			}
		}
		if( pivot_val == 0 ){
			// No pivot found (all zero). So contunue without incrementing startrow.
			if( FreeColumns )		FreeColumns->push_back( column ) ;
			continue ;
		}

		if( startrow != pivot_row_id ){	// Exchange rows
			double tmp = columns[startrow] ;
			columns[startrow] = columns[pivot_row_id] ;
			columns[pivot_row_id] = tmp ;
			SwapRow( startrow,pivot_row_id ) ;
		}
		
		MultiplyRow( startrow,1/columns[startrow] ) ;
		for( int del_row = 0;del_row < (int)rows.size();++del_row )
			if( del_row != startrow )
				AddRows( del_row,startrow,-columns[del_row] ) ;

		startrow++ ;
		if( startrow == rows.size() ){
			column++ ;
			break ;
		}
	}

	if( FreeColumns ) for( ;column < columnmax ; column++ )
			FreeColumns->push_back( column ) ;

	delete[] columns ;
}








#ifdef ILMATH_ENABLE_UMFPACK_MATRIX_SOLVER

bool CSparseMatrix::SolveLinearSystemUsingUmfpack(const vector<double>& d,vector<double>& result,double threshold ){
	int m = (int)rows.size() , n = columnmax ;

	if(m_isLinearSolverFieldsReady)
	{		
		int index = 0;
		for( int row_i = 0; row_i < (int)rows.size(); ++row_i ){
			Row& row = rows[row_i] ;
			for( vector<double>::iterator it = row.coefficients.begin();  it != row.coefficients.end(); ++it){ //int idx=0;idx< (int)row.coefficients.size() ;++idx){
				m_Ax_c[index] = *it ;
				++index;
			}
		}
		for(int i = 0 ; i < n ; ++i ) m_b_c[i] = d[i] ;
	}else{

		m_isLinearSolverFieldsReady = true;

		list<int> Ap,Ai ;
		list<double>Ax ;

		
		int i=0 ;

		for( int row_i = 0; row_i < (int)rows.size(); ++row_i ){
			Ap.push_back(i) ;
			Row& row = rows[row_i] ;
			for( int idx=0;idx< (int)row.indice.size() ;++idx,++i ){
				Ai.push_back(row.indice[idx]) ;
				Ax.push_back(row.coefficients[idx]) ;
			}
		}
		Ap.push_back(i) ;

		
		m_Ap_c = new int[    Ap.size() ] ;
		m_Ai_c = new int[    Ai.size() ] ;
		m_Ax_c = new double[ Ax.size() ] ;
		m_b_c  = new double[     m     ] ;							assert( d.size() == m ) ;
		m_x_c  = new double[     n     ] ;

		i=0 ; for( list<int>::iterator iit = Ap.begin() ; iit!=Ap.end() ; ++iit,++i )	    m_Ap_c[i] = *iit ;
		i=0 ; for( list<int>::iterator iit = Ai.begin() ; iit!=Ai.end() ; ++iit,++i )	    m_Ai_c[i] = *iit ;
		i=0 ; for( list<double>::iterator dit = Ax.begin() ; dit!=Ax.end() ; ++dit,++i )	m_Ax_c[i] = *dit ;
		for( i=0;i<n;++i )	m_b_c[i] = d[i] ;

	}

	double *null = (double *) NULL ;
	void *Symbolic, *Numeric ;
	(void) umfpack_di_symbolic (m, n, m_Ap_c, m_Ai_c, m_Ax_c, &Symbolic, null, null) ;
	(void) umfpack_di_numeric (m_Ap_c, m_Ai_c, m_Ax_c, Symbolic, &Numeric, null, null) ;
	(void) umfpack_di_solve (UMFPACK_At, m_Ap_c, m_Ai_c, m_Ax_c, m_x_c, m_b_c, Numeric, null, null) ;
	umfpack_di_free_symbolic (&Symbolic) ;
	umfpack_di_free_numeric (&Numeric) ;

	result.resize( n ) ;
	for( int i=0;i<n;++i ) result[i] = m_x_c[i] ;

	return true ;
}

#endif	// ILMATH_ENABLE_UMFPACK_MATRIX_SOLVER




// Solve linear system G x = d
bool CSparseMatrix::SolveLinearSystem( const vector<double>& d,vector<double>& result,double threshold ){
#ifndef ILMATH_ENABLE_UMFPACK_MATRIX_SOLVER
	// solve by using conjugate gradient method.
	// G = (*this), x = result, d = d
	// see "Conjugate Gradient Method.pdf" in my directory or,
	// http://www.ees.nmt.edu/Geop/Classes/GEOP529/Docs/cg.pdf	int rowmax = rows.size() ;

	int rowmax = (int)rows.size() ;
	assert( d.size() == rowmax ) ;
	if( d*d == 0 ){
		result.clear() ;
		result.resize( d.size(),0 ) ;
		return true ;
	}

	CSparseMatrix& G = *this ;
	CSparseMatrix Gt ;
	G.GetTransposeMatrix(Gt) ;

	vector<double> m_k( columnmax,0 ) ;
	vector<double> m_kp( columnmax ) ;
	vector<double> p_km( columnmax,0 ) ;
	vector<double> p_k( columnmax ) ;

	double beta_km = 0 ;
	double beta_k ;

	vector<double> s_k(rowmax) ;
	vector<double> s_kp(rowmax) ;
	vector<double> r_k(columnmax) ;
	vector<double> r_kp(columnmax) ;

	s_k = -d ;
	r_k = Gt * s_k ;

	int k ;
	for( k=0;k<columnmax;k++ ){
		// Step 1
		p_k = -r_k + beta_km * p_km ;
		
		// Step 2
		double r_k_norm = r_k*r_k ;
		vector<double> G_pk ;
		G_pk = G * p_k ;
		double G_pk_norm = G_pk*G_pk ;
		double alpha_k = r_k_norm / G_pk_norm ;

		// Step 3
		m_kp = m_k + alpha_k * p_k ;

		// Step 4
		s_kp = s_k + alpha_k * G_pk ;

		// Step 5
		r_kp = Gt * s_kp ;

		// Step 6
		double r_kp_norm = r_kp * r_kp ;
		beta_k = r_kp_norm / r_k_norm ;

		// Copy
		m_k = m_kp ;
		p_km = p_k ;
		beta_km = beta_k ;
		s_k = s_kp ;
		r_k = r_kp ;


		if( r_kp_norm < threshold )	break ;
	}

	result = m_k ;
	return k != columnmax ;
#else


	/*

	// ILMATH_ENABLE_UMFPACK_MATRIX_SOLVER is defined
	list<int> Ap,Ai ;
	list<double>Ax ;

	int m = (int)rows.size() , n = columnmax ;
#if 1
	CSparseMatrix tr ;
	GetTransposeMatrix(tr) ;

	int i=0 ;
	for( int row_i=0;row_i< (int)tr.rows.size();++row_i ){
		Ap.push_back(i) ;
		Row& row = tr.rows[row_i] ;
		for( int idx=0;idx< (int)row.indice.size() ;++idx,++i ){
			Ai.push_back(row.indice[idx]) ;
			Ax.push_back(row.coefficients[idx]) ;
		}
	}
	Ap.push_back(i) ;
#else
	int i=0 ;
	for( int row_i=0;row_i<rows.size();++row_i ){
		Ap.push_back(i) ;
		Row& row = rows[row_i] ;
		for( int idx=0;idx<row.indice.size() ;++idx,++i ){
			Ai.push_back(row.indice[idx]) ;
			Ax.push_back(row.coefficients[idx]) ;
		}
	}
	Ap.push_back(i) ;
#endif

	int* Ap_c = new int[Ap.size()] ;
	int* Ai_c = new int[Ai.size()] ;
	double* Ax_c = new double[Ax.size()] ;
	double* b_c = new double[m] ;							assert( d.size() == m ) ;
	double* x_c = new double[n] ;

	i=0 ; for( list<int>::iterator iit = Ap.begin() ; iit!=Ap.end() ; ++iit,++i )	Ap_c[i] = *iit ;
	i=0 ; for( list<int>::iterator iit = Ai.begin() ; iit!=Ai.end() ; ++iit,++i )	Ai_c[i] = *iit ;
	i=0 ; for( list<double>::iterator dit = Ax.begin() ; dit!=Ax.end() ; ++dit,++i )	Ax_c[i] = *dit ;
	for( i=0;i<n;++i )	b_c[i] = d[i] ;

	double *null = (double *) NULL ;
	void *Symbolic, *Numeric ;
	(void) umfpack_di_symbolic (m, n, Ap_c, Ai_c, Ax_c, &Symbolic, null, null) ;
	(void) umfpack_di_numeric (Ap_c, Ai_c, Ax_c, Symbolic, &Numeric, null, null) ;
	(void) umfpack_di_solve (UMFPACK_A, Ap_c, Ai_c, Ax_c, x_c, b_c, Numeric, null, null) ;
	umfpack_di_free_symbolic (&Symbolic) ;
	umfpack_di_free_numeric (&Numeric) ;

	result.resize( n ) ;
	for( int i=0;i<n;++i ) result[i] = x_c[i] ;

	delete[] Ap_c ;
	delete[] Ai_c ;
	delete[] Ax_c ;
	delete[] b_c ;
	delete[] x_c ;

	return true ;

	*/


	return SolveLinearSystemUsingUmfpack( d,result,threshold );

#endif	// ILMATH_ENABLE_UMFPACK_MATRIX_SOLVER
}



void CSparseMatrix::CalcNullSpace( vector< vector<double> >& result ){
	result.clear() ;
	// Copy this
	CSparseMatrix mat = *this ;

	// No pivot columns correspond to free variables
	vector<int> FreeColumns ;
	mat.TransformToReducedRowEchelonMatrix( &FreeColumns ) ;

	// no pivots. this means Null space is an empty space
	if( FreeColumns.size() == 0 )	return ;

	for( int i=0;i<(int)FreeColumns.size();i++ ){
		vector<double> answer( mat.GetColumnNum(),0 ) ;

		int onefreecolumn_id = FreeColumns[i] ;

		int piv_id = 0 ;
		int freeclm_id = 0 ;
		for( int clm=0;clm<mat.GetColumnNum();clm++ ){
			if( freeclm_id < (int)FreeColumns.size() && clm == FreeColumns[freeclm_id] ){
				freeclm_id++ ;
				continue ;
			}
			answer[clm] = - mat.GetElement( piv_id++,onefreecolumn_id ) ;
		}

		answer[ onefreecolumn_id ] = 1 ;

		result.push_back( answer ) ;
	}

}





void CSparseMatrix::CalcNullSpace( CSparseMatrix& result ){
	vector< vector<double> > vec_result ;

	CalcNullSpace( vec_result ) ;

	result.Allocate( columnmax,(int)vec_result.size() ) ;
	for( int i=0;i<(int)vec_result.size();i++ ){
		vector<double>& clm = vec_result[i] ;
		for( int j=0;j<(int)clm.size();j++ ){
			if( clm[j] != 0 ){
				result.SetElement( j,i,clm[j] ) ;
			}
		}
	}
	result.SetChanged() ;
}


CSparseMatrix CSparseMatrix::operator*( CSparseMatrix& right ){

		int dbg_left_row = GetRowNum() ;
		int dbg_left_column = GetColumnNum() ;
		int dbg_right_row = right.GetRowNum() ;
		int dbg_right_column = right.GetColumnNum() ;

	assert( GetColumnNum() == right.GetRowNum() ) ;
	CSparseMatrix result ;
	result.Allocate( GetRowNum(),right.GetColumnNum() ) ;

	for( int clm=0;clm<right.GetColumnNum();clm++ ){
		Column column ;
		right.GetColumn( clm,column ) ;

		Row row ;
		for( int rw=0;rw<GetRowNum();rw++ ){
			GetRow( rw,row ) ;
			double val = row * column ;
			if( val != 0 ){
				result.SetElement( rw,clm,val ) ;
			}
		}
	}

	result.SetChanged() ;
	return result ;
}

double SquareMat_CalcDeterminant( double* src,int dim ){
	if( dim <= 0 )	return 0 ;
	if( dim == 1 )	return *src ;
	if( dim == 2 )	return src[0]*src[3] - src[1]*src[2] ;
	if( dim == 3 )	return src[0]*src[4]*src[8]+src[3]*src[7]*src[2]+src[1]*src[5]*src[6]
		- src[2]*src[4]*src[6] - src[1]*src[3]*src[8] - src[0]*src[5]*src[7] ;

	int dim_s = dim-1 ;
	double* tmp = new double[ dim_s*dim_s ] ;
	double result = 0 ;
	int i,ii ;
	for( i=0;i<dim;i++ ){
		for( ii=0;ii<dim_s;ii++ ){
			if( ii < i )	memcpy( &tmp[ii*dim_s],&src[ii*dim+1],sizeof(double)*dim_s ) ;
			else			memcpy( &tmp[ii*dim_s],&src[(ii+1)*dim+1],sizeof(double)*dim_s ) ;
		}
		result += src[i*dim] * pow(-1,i) * SquareMat_CalcDeterminant( tmp,dim_s ) ;
	}
	delete[] tmp ;

	return result ;
}

float SquareMat_CalcDeterminant( float* src,int dim ){
	if( dim <= 0 )	return 0 ;
	if( dim == 1 )	return *src ;
	if( dim == 2 )	return src[0]*src[3] - src[1]*src[2] ;
	if( dim == 3 )	return src[0]*src[4]*src[8]+src[3]*src[7]*src[2]+src[1]*src[5]*src[6]
		- src[2]*src[4]*src[6] - src[1]*src[3]*src[8] - src[0]*src[5]*src[7] ;

	int dim_s = dim-1 ;
	float* tmp = new float[ dim_s*dim_s ] ;
	float result = 0 ;
	int i,ii ;
	for( i=0;i<dim;i++ ){
		for( ii=0;ii<dim_s;ii++ ){
			if( ii < i )	memcpy( &tmp[ii*dim_s],&src[ii*dim+1],sizeof(float)*dim_s ) ;
			else			memcpy( &tmp[ii*dim_s],&src[(ii+1)*dim+1],sizeof(float)*dim_s ) ;
		}
		result += (float) (src[i*dim] * pow(-1,i) * SquareMat_CalcDeterminant( tmp,dim_s )) ;
	}
	delete[] tmp ;

	return result ;
}

// The poisson solver
// Find x that minimizes ��|��x - v|^2 with constraints.
// constraints_and_region elements... -DBL_MAX:Outside DBL_MAX:Inside Otherwise: boundary condition
void SolvePoisson( CImage<vec2d>& v , CImage<double>& constraints_and_region , CImage<double>& result ){
	CImage<double>& c_r = constraints_and_region ;

	const int w = v.width , h = v.height ;

	{	// check if input is valid
		if( w != c_r.width || h != c_r.height ) throw std::exception( "Invalid input" ) ;
	}

	for( int iy=0;iy<h;++iy ) for( int ix=0;ix<w;++ix ) {
		v.GetPixel(ix,iy)[0] = - v.GetPixel(ix,iy)[0] ;
		v.GetPixel(ix,iy)[1] = - v.GetPixel(ix,iy)[1] ;
	}
	vector<CPoint> locs ;
	CImage<int> idxs ;
	idxs.Allocate( w,h ) ;
	{
		memset( idxs.pBits,0xff,sizeof(int)*w*h ) ;
		list<CPoint> l_locs ;
		for( int iy=0;iy<h;++iy ) for( int ix=0;ix<w;++ix ) {
			if( c_r.GetPixel(ix,iy) == DBL_MAX ){ // in ��. A variable.
				idxs.GetPixel(ix,iy) = (int)l_locs.size() ;
				l_locs.push_back( CPoint(ix,iy) ) ;
			}
		}
		copy(l_locs,locs) ;
	}
	// locs.size() == the number of variables

	vector<double> d(locs.size(),0) ;

	CSparseMatrix sm ;
	sm.Allocate( (int)locs.size(),(int)locs.size() ) ;

	static const int mat[4][2] = { {-1,0},{1,0},{0,-1},{0,1} } ;
	static const int mat2[4][2] = { {-1,0},{0,0},{0,-1},{0,0} } ;

	for( int pi=0;pi<(int)locs.size();++pi ){
		CPoint& p = locs[pi] ;			// central position
		for( int j=0;j<4;++j ){
			CPoint q( p.x+mat[j][0],p.y+mat[j][1] ) ;

			if( q.x<0||q.x>=w||q.y<0||q.y>=h ) continue ;

			sm.AddToElement(pi,pi,1) ;
			if( c_r.GetPixel( q.x,q.y ) == DBL_MAX ){	// in ��
				int qi = idxs.GetPixel(q.x,q.y) ;
				assert( qi != -1 ) ;
				sm.AddToElement(pi,qi,-1) ;
			} else if( c_r.GetPixel( q.x,q.y ) != -DBL_MAX ){	// on Boundary (constraint)
				d[pi] += c_r.GetPixel( q.x,q.y ) ;
			} else {
				assert(0) ;
			}

			{
				double Vpq_vec[2] = {
					v.GetPixel(p.x+mat2[j][0],p.y+mat2[j][1])[0] ,
					v.GetPixel(p.x+mat2[j][0],p.y+mat2[j][1])[1]
				} ;
/*				double Vpq_vec[2] = {
					0.5 * (v.GetPixel(p.x,p.y)[0]+v.GetPixel(q.x,q.y)[0]) ,
					0.5 * (v.GetPixel(p.x,p.y)[1]+v.GetPixel(q.x,q.y)[1])
				} ;*/
				d[pi] += Vpq_vec[0]*mat[j][0] + Vpq_vec[1]*mat[j][1] ;
			}
		}
	}
	sm.SetChanged() ;

	vector<double> x;

	sm.SolveLinearSystem( d,x,0.00001 ) ;

	/*{
		TRACE("--solve..\n") ;
		vector<double> xans = sm*x ;
		for( int i=0;i<xans.size();++i ){
			TRACE("%d : %f,%f\n",i,xans[i],d[i]) ;
		}
		TRACE("--solve ok\n") ;
	}*/

	result.Allocate( w,h ) ;
	memset(result.pBits,0,sizeof(double)*w*h) ;
	for( int i=0;i<(int)locs.size();++i ){
		result.GetPixel( locs[i].x,locs[i].y ) = x[i] ;
	}

	// Trace result
	/*{
		TRACE("\nResult-in\n") ;
		for( int iy=0;iy<h-1;++iy ){
			for( int ix=0;ix<w-1;++ix ) {
				double vvv[2] = {
					result.GetPixel(ix+1,iy)-result.GetPixel(ix,iy)-v.GetPixel(ix,iy)[0] ,
					result.GetPixel(ix,iy+1)-result.GetPixel(ix,iy)-v.GetPixel(ix,iy)[1] ,
				} ;
				if( c_r.GetPixel(ix,iy) != DBL_MAX )	TRACE("\t*****") ;
				else TRACE("\t%2.3f",vvv[0]*vvv[0]+vvv[1]*vvv[1] ) ;
			}
			TRACE("\n") ;
		}
	}*/
}
