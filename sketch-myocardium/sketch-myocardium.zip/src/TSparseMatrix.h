#pragma once

#include "ILMath.h"

//#define T_USE_UMFPACK


class TSparseMatrix
{
public:
	struct Ind_Coef {
		vector<int>		indice ;
		vector<double>	coefficients ;
	};
	typedef Ind_Coef Row;
	typedef Ind_Coef Column ;

protected:		//commented by kenshi
	vector<Row> rows;
	int rowmax;

	vector<Column> columns ;
	int columnmax;

	bool m_isLinearSolverFieldsReady;
	int*    m_Ap_c;
	int*    m_Ai_c;
	double* m_Ax_c;
	double* m_b_c;
	double* m_x_c;

	int m_Ap_size;
	int m_Ai_size;
	int m_Ax_size;

public:

	TSparseMatrix()   ;
	~TSparseMatrix()  ;
	int CountElements();
	void SetColumns() ;

	void initializeLinearSolverFields();
	bool SolveLinearSystemUsingUmfpack(const vector<double>& d,vector<double>& result,double threshold = 0.000000001 );
	bool SolveLinearSystemUsingUmfpack(const         double* d, double*        result,double threshold = 0.000000001 );

	// print elements
	void TraceMatrix() ;

	int GetRowNum(){	return rowmax;    }
	int GetColumnNum(){	return columnmax ;}
	void Clear(){	    Allocate(0,0) ;	  }

	// Allocate() should be called in advance
	void Allocate( int rownum,int columnnum ){
		rows.clear() ;	
		rows.resize(rownum) ;
		columnmax = columnnum ;
		rowmax    = rownum;
	}



	void AddToElement( int row,int column,double val ){
		if (!m_isLinearSolverFieldsReady) {
			assert( 0 <= row && row < GetRowNum() ) ;
			assert( 0 <= column && column < columnmax ) ;
			Row& r = rows[ row] ;
			// adding at the tail is much quicker than other insertion
			if( r.indice.empty() || r.indice.back() < column ){
				r.indice.push_back( column ) ;
				r.coefficients.push_back( val ) ;
			} else {
				vector<int>::iterator    it_id   = r.indice.begin() ;
				vector<double>::iterator it_coef = r.coefficients.begin() ;
				for( ; it_id != r.indice.end() ; it_id++,it_coef++ ){
					if( *it_id >= column ){
						if( *it_id > column ){
							r.indice.insert( it_id,column ) ;
							r.coefficients.insert( it_coef,val ) ;
						} else {
							*it_coef += val ;
						}
						break ;
					}
				}
			}
		} else {
			for (int i = m_Ap_c[column]; i < m_Ap_c[column+1]; i++)
				if (m_Ai_c[i] == row) {
					m_Ax_c[i] += val;
					break;
				}
		}
	}
	
	double GetElement( int row,int column ){
		assert( row >= 0 && row < rowmax ) ;
		assert( column >= 0 && column < columnmax ) ;
		if (!m_isLinearSolverFieldsReady) {
			Row& r = rows[ row ] ;
			for( int i=0;i<(int)r.indice.size();i++ )
				if( r.indice[i] == column )	return r.coefficients[i] ;
			return 0 ;
		} else {
			for (int i = m_Ap_c[column]; i < m_Ap_c[column+1]; ++i)
				if (row == m_Ai_c[i])
					return m_Ax_c[i];
			return 0;
		}
	}

	void MultSelfTransposeSelf(TSparseMatrix& LtL);
	void MultSelfSelfTranspose(TSparseMatrix& LLt);
};
