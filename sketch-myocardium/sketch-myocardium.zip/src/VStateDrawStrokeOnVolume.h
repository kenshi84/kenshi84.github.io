#pragma once
#include "vstate.h"

class VStateDrawStrokeOnVolume :
	public VState
{
public:
	
	static inline VStateDrawStrokeOnVolume* getInstance(){
		static VStateDrawStrokeOnVolume p;
		return &p;
	}
	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);
	bool m_isValid;
};
