#include "StdAfx.h"
#include ".\vmenulistener.h"
#include "VDrawer.h"
#include "VVolumeDataManager.h"
#include "VectorFields.h"

VMenuListener::VMenuListener(void)
{
}

VMenuListener::~VMenuListener(void)
{
}

void VMenuListener::OnCommandSmoothOnSurface(){
	VCore::getInstance()->m_tick = 100;
	VSurfaceDataManager::getInstance()->SetConstraints();
#ifdef V_USE_LAPLACIAN
	VSurfaceDataManager::getInstance()->LaplacianSmooth();
#else
	for (int i = 0; i < V_NUMITER; ++i)
		VSurfaceDataManager::getInstance()->SimpleSmooth();
#endif
	VSurfaceDataManager::getInstance()->RemoveNonTangential();
	VSurfaceDataManager::getInstance()->NormalizeAll();
	
	//VDrawer::getInstance()->m_flags =
	//	VDrawer::_AXIS
	//	| VDrawer::_EDGES
	//	| VDrawer::_SDATA
	//	| VDrawer::_SSTROKES;
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMenuListener::OnCommandSmoothOnVolume() {
	VVolumeDataManager::getInstance()->SetConstraints();
#ifdef V_USE_LAPLACIAN
	VVolumeDataManager::getInstance()->LaplacianSmooth();
#else
	for (int i = 0; i < V_NUMITER; ++i)
		VVolumeDataManager::getInstance()->SimpleSmooth();
#endif
	VVolumeDataManager::getInstance()->NormalizeAll();
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMenuListener::OnEditClearall(){
	VSurfaceDataManager::getInstance()->ClearData();
	VVolumeDataManager::getInstance()->ClearData();
	
	VCore::getInstance()->m_UndoFlags.clear();
	VCore::getInstance()->m_RedoFlags.clear();
	VCore::getInstance()->m_RedoStrokesSurface.clear();
	VCore::getInstance()->m_RedoStrokesVolume.clear();
	
	VCore::getInstance()->m_pView->GetDocument()->SetModifiedFlag(FALSE);
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMenuListener::OnFileNew() {
	VSurfaceDataManager::getInstance()->m_strokesPointInfo.clear();
	VSurfaceDataManager::getInstance()->m_strokes3D.clear();
	VVolumeDataManager::getInstance()->m_strokes.clear();
}

void VMenuListener::OnFileLoad3DModel() {
	CString FileName;
	CFileDialog dlgFile(
		TRUE,									// ��� TRUE : FileOpen
		_T("obj"),								// �f�t�H���g�̊g���q
		_T("*.obj"),							// �����t�@�C����
		OFN_FILEMUSTEXIST,						// �_�C�A���O�̐ݒ�t���O�F�����̃t�@�C��
		_T("Obj(*.obj)|*.obj|All Files(*.*)|*.*||")	// �t�B���^
		);

	if (dlgFile.DoModal() == IDOK)
	{
		FileName = dlgFile.GetPathName();//�I���t�@�C�����擾
	}
	//delete dlgFile;
	if (FileName != "")
	{
		CVectorFieldsDoc* pDoc = VCore::getInstance()->m_pView->GetDocument();
//		if (pDoc->IsModified() == TRUE)
			pDoc->SaveModified();
		AfxGetApp()->m_pDocManager->OnFileNew();
		VCore::getInstance()->Load3DModel(FileName.GetBuffer());
		VCore::getInstance()->m_ogl.RedrawWindow();
	}
}

void VMenuListener::OnFileExportResult() {
	CString FileName;
	CFileDialog dlgFile(
		FALSE,									// ��� TRUE : FileOpen
		_T("txt"),								// �f�t�H���g�̊g���q
		_T("*.txt"),							// �����t�@�C����
		OFN_OVERWRITEPROMPT,						// �_�C�A���O�̐ݒ�t���O�F�����̃t�@�C��
		_T("Text(*.txt)|*.txt|All(*.*)|*.*||")	// �t�B���^
		);

	if (dlgFile.DoModal() == IDOK)
	{
		FileName = dlgFile.GetPathName();//�I���t�@�C�����擾
	}
	if (FileName != "")
	{
		VVolumeDataManager::getInstance()->ExportResultToFile(FileName.GetBuffer());
	}
}

void VMenuListener::OnFileExportVolume() {
	CString FileName;
	CFileDialog dlgFile(
		FALSE,									// ��� TRUE : FileOpen
		_T("txt"),								// �f�t�H���g�̊g���q
		_T("*.txt"),							// �����t�@�C����
		OFN_OVERWRITEPROMPT,						// �_�C�A���O�̐ݒ�t���O�F�����̃t�@�C��
		_T("Text(*.txt)|*.txt|All(*.*)|*.*||")	// �t�B���^
		);

	if (dlgFile.DoModal() == IDOK)
	{
		FileName = dlgFile.GetPathName();//�I���t�@�C�����擾
	}
	if (FileName != "")
	{
		VVolumeDataManager::getInstance()->ExportVolumeToFile(FileName.GetBuffer());
	}
}

void VMenuListener::OnDrawEdges() {
	int &flags = VDrawer::getInstance()->m_flags;
	if (flags & VDrawer::_EDGES)
		flags &= ~VDrawer::_EDGES;
	else
		flags |= VDrawer::_EDGES;
	
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMenuListener::OnDrawFaces() {
	int &flags = VDrawer::getInstance()->m_flags;
	if (flags & VDrawer::_FACES)
		flags &= ~VDrawer::_FACES;
	else
		flags |= VDrawer::_FACES;
	
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMenuListener::OnDrawStrokesonsurface() {
	int &flags = VDrawer::getInstance()->m_flags;
	if (flags & VDrawer::_SSTROKES)
		flags &= ~VDrawer::_SSTROKES;
	else
		flags |= VDrawer::_SSTROKES;
	
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMenuListener::OnDrawStrokesonvolume() {
	int &flags = VDrawer::getInstance()->m_flags;
	if (flags & VDrawer::_VSTROKES)
		flags &= ~VDrawer::_VSTROKES;
	else
		flags |= VDrawer::_VSTROKES;
	
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMenuListener::OnDrawFieldonsurface() {
	int &flags = VDrawer::getInstance()->m_flags;
	if (flags & VDrawer::_SDATA)
		flags &= ~VDrawer::_SDATA;
	else
		flags |= VDrawer::_SDATA;
	
	VCore::getInstance()->m_ogl.RedrawWindow();
}
void VMenuListener::OnDrawFieldonvolume() {
	int &flags = VDrawer::getInstance()->m_flags;
	if (flags & VDrawer::_VDATA)
		flags &= ~VDrawer::_VDATA;
	else
		flags |= VDrawer::_VDATA;
	
	VCore::getInstance()->m_ogl.RedrawWindow();
}
void VMenuListener::OnDrawCsshape() {
	int &flags = VDrawer::getInstance()->m_flags;
	if (flags & VDrawer::_CSSHAPE)
		flags &= ~VDrawer::_CSSHAPE;
	else
		flags |= VDrawer::_CSSHAPE;
	
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMenuListener::OnDrawAxis() {
	int &flags = VDrawer::getInstance()->m_flags;
	if (flags & VDrawer::_AXIS)
		flags &= ~VDrawer::_AXIS;
	else
		flags |= VDrawer::_AXIS;
	
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMenuListener::OnEditUndo() {
	bool flag = VCore::getInstance()->m_UndoFlags.back();
	VCore::getInstance()->m_UndoFlags.pop_back();
	VCore::getInstance()->m_RedoFlags.push_back(flag);
	if (flag) {
		vector<ILVector3D> stroke3D = VSurfaceDataManager::getInstance()->m_strokes3D.back();
		vector<PointInfoOnPolygon> strokePointInfo = VSurfaceDataManager::getInstance()->m_strokesPointInfo.back();
		VSurfaceDataManager::getInstance()->m_strokes3D.pop_back();
		VSurfaceDataManager::getInstance()->m_strokesPointInfo.pop_back();
		pair<vector<ILVector3D>, vector<PointInfoOnPolygon> > p(stroke3D, strokePointInfo);
		VCore::getInstance()->m_RedoStrokesSurface.push_back(p);
	} else {
		vector<ILVector3D> stroke = VVolumeDataManager::getInstance()->m_strokes.back();
		VVolumeDataManager::getInstance()->m_strokes.pop_back();
		VCore::getInstance()->m_RedoStrokesVolume.push_back(stroke);
	}
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMenuListener::OnEditRedo() {
	bool flag = VCore::getInstance()->m_RedoFlags.back();
	VCore::getInstance()->m_RedoFlags.pop_back();
	VCore::getInstance()->m_UndoFlags.push_back(flag);
	if (flag) {
		vector<ILVector3D> stroke3D = VCore::getInstance()->m_RedoStrokesSurface.back().first;
		vector<PointInfoOnPolygon> strokePointInfo = VCore::getInstance()->m_RedoStrokesSurface.back().second;
		VCore::getInstance()->m_RedoStrokesSurface.pop_back();
		VSurfaceDataManager::getInstance()->m_strokes3D.push_back(stroke3D);
		VSurfaceDataManager::getInstance()->m_strokesPointInfo.push_back(strokePointInfo);
	} else {
		vector<ILVector3D> stroke = VCore::getInstance()->m_RedoStrokesVolume.back();
		VCore::getInstance()->m_RedoStrokesVolume.pop_back();
		VVolumeDataManager::getInstance()->m_strokes.push_back(stroke);
	}
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMenuListener::OnFileSaveImage(){
	CString FileName;
	CFileDialog dlgFile(
		FALSE,									// ��� TRUE : FileOpen
		_T("ppm"),								// �f�t�H���g�̊g���q
		_T("*.ppm"),							// �����t�@�C����
		OFN_OVERWRITEPROMPT,						// �_�C�A���O�̐ݒ�t���O�F�����̃t�@�C��
		_T("PPM Files(*.ppm)|*.ppm|All(*.*)|*.*||")	// �t�B���^
		);

	if (dlgFile.DoModal() == IDOK)
	{
		FileName = dlgFile.GetPathName();//�I���t�@�C�����擾
	}
	if (FileName != "")
	{
		////���܂������ˁ`
		//VCore::getInstance()->m_ogl.RedrawWindow(); 
		//ILOGL::CFrameBuf<COLORREF>& ColorBuffer = VCore::getInstance()->m_ogl.m_ColorBuffer;
		//glReadPixels(0,0, ColorBuffer.Width(), ColorBuffer.Height(), GL_RGBA,GL_UNSIGNED_BYTE ,ColorBuffer.GetBufferHead() ) ;
		//ColorBuffer.SaveAsColorImage(FileName.GetBuffer());
	}
}
