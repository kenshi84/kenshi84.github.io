#include "StdAfx.h"
#include ".\vmouselistener.h"
#include "VDrawer.h"

VMouseListener::VMouseListener(void)
{
	m_isLButton = false;
	m_isRButton = false;
	m_isMButton = false;
}

VMouseListener::~VMouseListener(void)
{
}

void VMouseListener::OnLButtonDown(UINT nFlags, CPoint point) {
	m_isLButton = true;
	VCore::getInstance()->m_state->OnLButtonDown(nFlags, point);
	VCore::getInstance()->m_ogl.RedrawWindow();
}
void VMouseListener::OnLButtonUp(UINT nFlags, CPoint point){
	m_isLButton = false;
	VCore::getInstance()->m_state->OnLButtonUp(nFlags, point);
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VMouseListener::OnRButtonDown(UINT nFlags, CPoint point) {
	m_isRButton = true;
	if (nFlags & MK_SHIFT)
		VCore::getInstance()->m_ogl.t_ButtonDownForZoom(point);
	else if (nFlags & MK_CONTROL)
		VCore::getInstance()->m_ogl.t_ButtonDownForTranslate(point);
	else
		VCore::getInstance()->m_ogl.t_ButtonDownForRotate(point);
}

void VMouseListener::OnRButtonUp(UINT nFlags, CPoint point){
	m_isRButton = false;
	VCore::getInstance()->m_ogl.t_ButtonUp();
	VCrossSection::getInstance()->ViewChanged();
}

void VMouseListener::OnMButtonDown(UINT nFlags, CPoint point) {
	m_isMButton = true;
	VCore::getInstance()->m_ogl.t_ButtonDownForZoom(point);
}

void VMouseListener::OnMButtonUp(UINT nFlags, CPoint point){
	m_isMButton = false;
	VCore::getInstance()->m_ogl.t_ButtonUp();
	VCrossSection::getInstance()->ViewChanged();
}

void VMouseListener::OnMouseMove(UINT nFlags, CPoint point){
	if (m_isLButton || m_isRButton || m_isMButton) {
		if (m_isLButton)
			VCore::getInstance()->m_state->OnMouseMove(nFlags, point);
		else
			VCore::getInstance()->m_ogl.t_MouseMove(point);
		VCore::getInstance()->m_ogl.RedrawWindow();
	}
}
