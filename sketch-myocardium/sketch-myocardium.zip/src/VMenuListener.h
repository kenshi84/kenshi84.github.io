#pragma once
#include "VCore.h"
#include "VSurfaceDataManager.h"
#include "VVolumeDataManager.h"
#include "MainFrm.h"

class VMenuListener
{
public:
	VMenuListener(void);
	~VMenuListener(void);
	
	CMainFrame* m_CFrm;
	
	static inline VMenuListener* getInstance(){
		static VMenuListener p;
		return &p;
	}

	/* menu-command */
	void OnCommandSmoothOnSurface();
	void OnCommandSmoothOnVolume();
	void OnEditClearall();
	void OnFileNew();
	void OnFileExportResult();
	void OnFileExportVolume();
	void OnFileLoad3DModel();
	void OnDrawFaces();
	void OnDrawEdges();
	void OnDrawStrokesonsurface();
	void OnDrawStrokesonvolume();
	void OnDrawFieldonsurface();
	void OnDrawFieldonvolume();
	void OnEditUndo();
	void OnEditRedo();
	void OnDrawCsshape();
	void OnDrawAxis();
	void OnFileSaveImage();
};
