#include "StdAfx.h"
#include ".\vstatedrawstrokeonvolume.h"
#include "VCrossSection.h"
#include "VStateDefault.h"
#include "VVolumeDataManager.h"
#include "VDrawer.h"
#include "VMenuListener.h"

void VStateDrawStrokeOnVolume::OnLButtonDown(UINT nFlags, CPoint point) {
	fprintf(stderr, "State Error! - VStateDrawStrokeOnVolume::OnLButtonDown\n");
	//ILVector3D v;
	//if (VCrossSection::getInstance()->CalcIntersectionPointCrossSection(point, v)) {
	//	VVolumeDataManager::getInstance()->m_strokes.push_back(vector<ILVector3D>());
	//	VVolumeDataManager::getInstance()->m_strokes.back().push_back(v);
	//	m_isValid = true;
	//	VCore::getInstance()->m_RedoFlags.clear();
	//	VCore::getInstance()->m_RedoStrokesSurface.clear();
	//	VCore::getInstance()->m_RedoStrokesVolume.clear();
	//} else {
	//	VCore::getInstance()->m_state = VStateDefault::getInstance();
	//	VCore::getInstance()->m_state->OnLButtonDown(nFlags, point);
	//}
}

void VStateDrawStrokeOnVolume::OnLButtonUp(UINT nFlags, CPoint point) {
	VCore::getInstance()->m_state = VStateDefault::getInstance();
	VMenuListener::getInstance()->OnCommandSmoothOnVolume();
}

void VStateDrawStrokeOnVolume::OnMouseMove(UINT nFlags, CPoint point) {
	ILVector3D v;
	if (!m_isValid) return;
	if (VCrossSection::getInstance()->CalcIntersectionPointCrossSection(point, v))
		VVolumeDataManager::getInstance()->m_strokes.back().push_back(v);
	else
		m_isValid = false;
}
