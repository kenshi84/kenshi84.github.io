#include "StdAfx.h"
#include ".\vvolumedatamanager.h"

VVolumeDataManager::VVolumeDataManager(void)
{
	//m_strokes.clear();
	//SetBoundary();
}

VVolumeDataManager::~VVolumeDataManager(void)
{
}

void VVolumeDataManager::ExportVolumeToFile(char* fname) {
	FILE* fp = fopen(fname, "w");
	if (fp == NULL) {
		fprintf(stderr, "Failed to Export!\n");
		return;
	}
	
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	int pos = 0;
	for (int ix = 0; ix < NUMGRID; ++ix) {
		for (int iy = 0; iy < NUMGRID; ++iy) {
			for (int iz = 0; iz < NUMGRID; ++iz) {
				if (vdata[pos].isInner)
					fprintf(fp, "%c", '1');
				else
					fprintf(fp, "%c", '0');
				++pos;
			}
			fprintf(fp, "\n");
		}
		fprintf(fp, "\n");
	}
	fclose(fp);
}

void VVolumeDataManager::ExportResultToFile(char *fname) {
	FILE* fp = fopen(fname, "w");
	if (fp == NULL) {
		fprintf(stderr, "Failed to Export!\n");
		return;
	}
	
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	fprintf(fp, "%d\n", NUMGRID);
	for (int ix = 0; ix < NUMGRID; ++ix) {
		fprintf(fp, "# ix = %d\n", ix);
		for (int iy = 0; iy < NUMGRID; ++iy) {
			fprintf(fp, "# iy = %d\n", iy);
			for (int iz = 0; iz < NUMGRID; ++iz) {
				VolumeData& vd = vdata[IXGRID(ix, iy, iz)];
				if (vd.isInner)
					fprintf(fp, "%f %f %f\n", vd.field.data[0], vd.field.data[1], vd.field.data[2]);
				else
					fprintf(fp, "0 0 0\n");
			}
		}
	}
	fclose(fp);
}

void VVolumeDataManager::SetBoundary() {
	fprintf(stderr, "Setting Volume Boundary ... ");
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;

	for (int i = 0; i < NUMGRID_POW3; ++i)
		vdata[i] = VolumeData();
	
	RayCast(0);
	RayCast(1);
	RayCast(2);
	
	//int cnt = 0;
	//for (int i = 0; i < NUMGRID; ++i)
	//for (int j = 0; j < NUMGRID; ++j)
	//for (int k = 0; k < NUMGRID; ++k)
	//	if (vdata[IXGRID(i,j,k)].isInner)++cnt;
	//
	//fprintf(stderr, "(volume : %d) ... ", cnt);
	fprintf(stderr, "Completed!\n");
}

void VVolumeDataManager::ClearData() {
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	for (int i = 0; i < NUMGRID_POW3; ++i) {
		vdata[i].field[0] = 0.;
		vdata[i].field[1] = 0.;
		vdata[i].field[2] = 0.;
		vdata[i].isConstraint = false;
	}
	m_strokes.clear();
}

void VVolumeDataManager::SimpleSmooth() {	
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	for (int i = 0; i < NUMGRID; ++i) 
		for (int j = 0; j < NUMGRID; ++j) {
			for (int k = 0; k < NUMGRID; ++k)
			{
				VolumeData &vd = vdata[IXGRID(i,j,k)];
				if (!vd.isInner) continue;
				if (vd.isConstraint) continue;
				ILVector3D v;
				//if (vdata[IXGRID(i+1,j,k)].isInner) v += vdata[IXGRID(i+1,j,k)].field;
				//if (vdata[IXGRID(i-1,j,k)].isInner) v += vdata[IXGRID(i-1,j,k)].field;
				//if (vdata[IXGRID(i,j+1,k)].isInner) v += vdata[IXGRID(i,j+1,k)].field;
				//if (vdata[IXGRID(i,j-1,k)].isInner) v += vdata[IXGRID(i,j-1,k)].field;
				//if (vdata[IXGRID(i,j,k+1)].isInner) v += vdata[IXGRID(i,j,k+1)].field;
				//if (vdata[IXGRID(i,j,k-1)].isInner) v += vdata[IXGRID(i,j,k-1)].field;
				//v *= sqrt(2.);
				//if (vdata[IXGRID(i+1,j+1,k)].isInner) v += vdata[IXGRID(i+1,j+1,k)].field;
				//if (vdata[IXGRID(i+1,j-1,k)].isInner) v += vdata[IXGRID(i+1,j-1,k)].field;
				//if (vdata[IXGRID(i-1,j+1,k)].isInner) v += vdata[IXGRID(i-1,j+1,k)].field;
				//if (vdata[IXGRID(i-1,j-1,k)].isInner) v += vdata[IXGRID(i-1,j-1,k)].field;
				//if (vdata[IXGRID(i,j+1,k+1)].isInner) v += vdata[IXGRID(i,j+1,k+1)].field;
				//if (vdata[IXGRID(i,j+1,k-1)].isInner) v += vdata[IXGRID(i,j+1,k-1)].field;
				//if (vdata[IXGRID(i,j-1,k+1)].isInner) v += vdata[IXGRID(i,j-1,k+1)].field;
				//if (vdata[IXGRID(i,j-1,k-1)].isInner) v += vdata[IXGRID(i,j-1,k-1)].field;
				//if (vdata[IXGRID(i+1,j,k+1)].isInner) v += vdata[IXGRID(i+1,j,k+1)].field;
				//if (vdata[IXGRID(i-1,j,k+1)].isInner) v += vdata[IXGRID(i-1,j,k+1)].field;
				//if (vdata[IXGRID(i+1,j,k-1)].isInner) v += vdata[IXGRID(i+1,j,k-1)].field;
				//if (vdata[IXGRID(i-1,j,k-1)].isInner) v += vdata[IXGRID(i-1,j,k-1)].field;
				//v *= sqrt(3/2.);
				if (vdata[IXGRID(i+1,j+1,k+1)].isInner) v += vdata[IXGRID(i+1,j+1,k+1)].field;
				if (vdata[IXGRID(i+1,j+1,k-1)].isInner) v += vdata[IXGRID(i+1,j+1,k-1)].field;
				if (vdata[IXGRID(i+1,j-1,k+1)].isInner) v += vdata[IXGRID(i+1,j-1,k+1)].field;
				if (vdata[IXGRID(i+1,j-1,k-1)].isInner) v += vdata[IXGRID(i+1,j-1,k-1)].field;
				if (vdata[IXGRID(i-1,j+1,k+1)].isInner) v += vdata[IXGRID(i-1,j+1,k+1)].field;
				if (vdata[IXGRID(i-1,j+1,k-1)].isInner) v += vdata[IXGRID(i-1,j+1,k-1)].field;
				if (vdata[IXGRID(i-1,j-1,k+1)].isInner) v += vdata[IXGRID(i-1,j-1,k+1)].field;
				if (vdata[IXGRID(i-1,j-1,k-1)].isInner) v += vdata[IXGRID(i-1,j-1,k-1)].field;
				v.Normalize_Self();
				vdata[IXGRID(i,j,k)].field = v;
			}
	}
}

void VVolumeDataManager::RayCast(const int dir0) {
/* calclate along xyz-directional scanline 
	dir0| axis
	==========
	 0  |  x
	 1  |  y
	 2  |  z
*/
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;

 	for (int i1 = 0; i1 < NUMGRID; ++i1) {
		double v = i1 / (double)NUMGRID;
		for (int i2 = 0; i2 < NUMGRID; ++i2) {
			double w = i2 / (double)NUMGRID;
			list<int> blist;
			for (int k = 0; k < (int)poly.polygons.size(); ++k) {
				ILPolygon &p = poly.polygons[k];
		
				ILVector3D &V0 = poly.vertices[p.vtx[0]].pos;
				ILVector3D &V1 = poly.vertices[p.vtx[1]].pos;
				ILVector3D &V2 = poly.vertices[p.vtx[2]].pos;
				int dir1 = (dir0 + 1) % 3;
				int dir2 = (dir0 + 2) % 3;
				double u0 = V0.data[dir0];
				double v0 = V0.data[dir1];
				double w0 = V0.data[dir2];
				double u1 = V1.data[dir0];
				double v1 = V1.data[dir1];
				double w1 = V1.data[dir2];
				double u2 = V2.data[dir0];
				double v2 = V2.data[dir1];
				double w2 = V2.data[dir2];
				if (v < v0 && v < v1 && v < v2) continue;
				if (v > v0 && v > v1 && v > v2) continue;
				if (w < w0 && w < w1 && w < w2) continue;
				if (w > w0 && w > w1 && w > w2) continue;
				
				/* plane : (1 - s - t) * v0 + s * v1 + t * v2;
				CoordDir1 = v, CoordDir2 = w�̂Ƃ�s, t��
				(1-s-t)*v0 + s*v1 + t*v2 = v;
				(1-s-t)*w0 + s*w1 + t*w2 = w;
				(-v0+v1 -v0+v2)(s) = (v-v0)
				(-w0+w1 -w0+w2)(t)   (w-w0)
				(s) = (-w0+w2 v0-v2 )(v-v0) / ((-v0+v1)*(-w0+w2)-(-v0+v2)*(-w0+w1))
				(t)   ( w0-w1 -v0+v1)(w-w0)
				*/

				double _l = 1. / ((-v0+v1)*(-w0+w2)-(-v0+v2)*(-w0+w1));
				double s = ((-w0+w2)*(v-v0) + ( v0-v2)*(w-w0)) * _l;
				double t = (( w0-w1)*(v-v0) + (-v0+v1)*(w-w0)) * _l;
	
				if (s < 0 || t < 0 || s+t > 1) continue;
				
				double u = (1-s-t)*u0 + s*u1 + t*u2;

				int i0 = (int)(u * NUMGRID);
				if (u * NUMGRID - i0 > 0.5) ++i0;
				blist.push_back(i0);
				VolumeData &vd =
					(dir0 == 0) ? vdata[IXGRID(i0,i1,i2)] :
					(dir0 == 1) ? vdata[IXGRID(i2,i0,i1)] :
								  vdata[IXGRID(i1,i2,i0)];
				vd.isBound = true;
				vd.isConstraint = true;
				vd.pinfo.polyID = k;
				vd.pinfo.s = s;
				vd.pinfo.t = t;
				
			}
			blist.sort();
			int i0 = 0;
			bool flag = false;
			for (list<int>::iterator i = blist.begin(); i != blist.end(); ++i) {
				while (i0 < *i){
					if (dir0 == 0) 
						vdata[IXGRID(i0,i1,i2)].isInner = flag;
					else if (dir0 == 1)
						vdata[IXGRID(i2,i0,i1)].isInner = flag;
					else
						vdata[IXGRID(i1,i2,i0)].isInner = flag;
					++i0;
				}
				if (dir0 == 0) 
					vdata[IXGRID(*i,i1,i2)].isInner = true;
				else if (dir0 == 1)
					vdata[IXGRID(i2,*i,i1)].isInner = true;
				else
					vdata[IXGRID(i1,i2,*i)].isInner = true;
				i0 = *i + 1;
				flag = !flag;
			}
			for (;i0 < NUMGRID; ++i0) 
				if (dir0 == 0) 
					vdata[IXGRID(i0,i1,i2)].isInner = flag;
				else if (dir0 == 1)
					vdata[IXGRID(i2,i0,i1)].isInner = flag;
				else
					vdata[IXGRID(i1,i2,i0)].isInner = flag;
		}
	}
	

}
void VVolumeDataManager::SetConstraints() {
	vector<SurfaceData>& sdata = VCore::getInstance()->m_sdata;
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	
	for (int i = 0; i < (int)vdata.size(); ++i) {
		VolumeData &vd = vdata[i];
		if (!vd.isInner) continue;
		if (!vd.isBound) {
			vd.isConstraint = false;
			continue;
		}
		double &s = vd.pinfo.s;
		double &t = vd.pinfo.t;
		ILVector3D &v0 = sdata[poly.polygons[vd.pinfo.polyID].vtx[0]].field;
		ILVector3D &v1 = sdata[poly.polygons[vd.pinfo.polyID].vtx[1]].field;
		ILVector3D &v2 = sdata[poly.polygons[vd.pinfo.polyID].vtx[2]].field;
		vd.field = (1-s-t)*v0 + s*v1 + t*v2;
		vd.field.Normalize_Self();
		vd.isConstraint = true;
	}
	
	for (int i = 0; i < (int)m_strokes.size(); ++i)
		for (int j = 1; j < (int)m_strokes[i].size(); ++j) {
			ILVector3D &v0 = m_strokes[i][j-1];
			ILVector3D &v1 = m_strokes[i][j];
			int ix = (int)(v0.data[0] * NUMGRID);
			int iy = (int)(v0.data[1] * NUMGRID);
			int iz = (int)(v0.data[2] * NUMGRID);
			vdata[IXGRID(ix, iy, iz)].field = (v1 - v0).Normalize();
			vdata[IXGRID(ix, iy, iz)].isConstraint = true;
		}
}

void VVolumeDataManager::CalcLtL() {
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	m_mapL2V.resize(NUMGRID_POW3);
	vector<int> mapV2L(NUMGRID_POW3);
	
	int N = 0;
	//for (int ix = 0; ix < NUMGRID; ++ix)
	//for (int iy = 0; iy < NUMGRID; ++iy)
	//for (int iz = 0; iz < NUMGRID; ++iz) {
	for (int i = 0; i < NUMGRID_POW3; ++i) {
		if (vdata[i].isInner) {
			m_mapL2V[N] = i;
			mapV2L[i] = N;
			N++;
		} else {
			mapV2L[i] = -1;
		}
	}
	m_mapL2V.resize(N);

	m_LtL.SetSize(N);
	m_bx.resize(N);
	m_by.resize(N);
	m_bz.resize(N);
	m_vx.resize(N);
	m_vy.resize(N);
	m_vz.resize(N);
	
	fprintf(stderr, "Calculating LtL of Volume Data(size: %d)...", N);
	
	for (int i = 0; i < N; ++i) {
		m_LtL.AddElement(i, i, 1);
		int ixyz = m_mapL2V[i];
		//int ix = (ixyz >> (NUMGRID_POW * 2) ) & (NUMGRID - 1);
		//int iy = (ixyz >> NUMGRID_POW       ) & (NUMGRID - 1);
		//int iz =  ixyz                        & (NUMGRID - 1);
		int iz = ixyz % NUMGRID;
		ixyz /= NUMGRID;
		int iy = ixyz % NUMGRID;
		int ix = ixyz / NUMGRID;
		
		//bXYZ : 0->neutral, N->negative, P->positive
		int bN00, b0N0, b00N, bP00, b0P0, b00P,				//	1.
			b0NN, b0NP, b0PN, b0PP,							//	2.
			bN0N, bP0N, bN0P, bP0P,							//	3.
			bNN0, bNP0, bPN0, bPP0,							//	4.
			bNNN, bNNP, bNPN, bNPP, bPNN, bPNP, bPPN, bPPP;	//	5.
		
		bN00 = b0N0 = b00N = bP00 = b0P0 = b00P = -1;
		b0NN = b0NP = b0PN = b0PP = -1;
		bN0N = bP0N = bN0P = bP0P = -1;
		bNN0 = bNP0 = bPN0 = bPP0 = -1;
		bNNN = bNNP = bNPN = bNPP = bPNN = bPNP = bPPN = bPPP = -1;
		
		//	1.
		if (ix > 0) bN00 = mapV2L[IXGRID(ix-1, iy, iz)];
		if (iy > 0) b0N0 = mapV2L[IXGRID(ix, iy-1, iz)];
		if (iz > 0) b00N = mapV2L[IXGRID(ix, iy, iz-1)];
		if (ix < NUMGRID-1) bP00 = mapV2L[IXGRID(ix+1, iy, iz)];
		if (iy < NUMGRID-1) b0P0 = mapV2L[IXGRID(ix, iy+1, iz)];
		if (iz < NUMGRID-1) b00P = mapV2L[IXGRID(ix, iy, iz+1)];
		
		//	2.
		if (iy > 0 && iz > 0)					b0NN = mapV2L[IXGRID(ix, iy-1, iz-1)];
		if (iy > 0 && iz < NUMGRID-1)			b0NP = mapV2L[IXGRID(ix, iy-1, iz+1)];
		if (iy < NUMGRID-1 && iz > 0)			b0PN = mapV2L[IXGRID(ix, iy+1, iz-1)];
		if (iy < NUMGRID-1 && iz < NUMGRID-1)	b0PP = mapV2L[IXGRID(ix, iy+1, iz+1)];
		
		//	3.
		if (iz > 0 && ix > 0)					bN0N = mapV2L[IXGRID(ix-1, iy, iz-1)];
		if (iz > 0 && ix < NUMGRID-1)			bP0N = mapV2L[IXGRID(ix+1, iy, iz-1)];
		if (iz < NUMGRID-1 && ix > 0)			bN0P = mapV2L[IXGRID(ix-1, iy, iz+1)];
		if (iz < NUMGRID-1 && ix < NUMGRID-1)	bP0P = mapV2L[IXGRID(ix+1, iy, iz+1)];
		
		//	4.
		if (ix > 0 && iy > 0)					bNN0 = mapV2L[IXGRID(ix-1, iy-1, iz)];
		if (ix > 0 && iy < NUMGRID-1)			bNP0 = mapV2L[IXGRID(ix-1, iy+1, iz)];
		if (ix < NUMGRID-1 && iy > 0)			bPN0 = mapV2L[IXGRID(ix+1, iy-1, iz)];
		if (ix < NUMGRID-1 && iy < NUMGRID-1)	bPP0 = mapV2L[IXGRID(ix+1, iy+1, iz)];
		
		//	5.
		if (ix > 0 && iy > 0 && iz > 0)							bNNN = mapV2L[IXGRID(ix-1, iy-1, iz-1)];
		if (ix > 0 && iy > 0 && iz < NUMGRID-1)					bNNP = mapV2L[IXGRID(ix-1, iy-1, iz+1)];
		if (ix > 0 && iy < NUMGRID-1 && iz > 0)					bNPN = mapV2L[IXGRID(ix-1, iy+1, iz-1)];
		if (ix > 0 && iy < NUMGRID-1 && iz < NUMGRID-1)			bNPP = mapV2L[IXGRID(ix-1, iy+1, iz+1)];
		if (ix < NUMGRID-1 && iy > 0 && iz > 0)					bPNN = mapV2L[IXGRID(ix+1, iy-1, iz-1)];
		if (ix < NUMGRID-1 && iy > 0 && iz < NUMGRID-1)			bPNP = mapV2L[IXGRID(ix+1, iy-1, iz+1)];
		if (ix < NUMGRID-1 && iy < NUMGRID-1 && iz > 0)			bPPN = mapV2L[IXGRID(ix+1, iy+1, iz-1)];
		if (ix < NUMGRID-1 && iy < NUMGRID-1 && iz < NUMGRID-1)	bPPP = mapV2L[IXGRID(ix+1, iy+1, iz+1)];
		
		int flg = 0;
		int cnt = 0;
		if (bN00 != -1) cnt++;		//	1.
		if (b0N0 != -1) cnt++;
		if (b00N != -1) cnt++;
		if (bP00 != -1) cnt++;
		if (b0P0 != -1) cnt++;
		if (b00P != -1) cnt++;
		if (cnt < 4) {
//			flg = 1;
			if (b0NN != -1) cnt++;		//	2.
			if (b0NP != -1) cnt++;
			if (b0PN != -1) cnt++;
			if (b0PP != -1) cnt++;
			if (bN0N != -1) cnt++;		//	3.
			if (bP0N != -1) cnt++;
			if (bN0P != -1) cnt++;
			if (bP0P != -1) cnt++;
			if (bNN0 != -1) cnt++;		//	4.
			if (bNP0 != -1) cnt++;
			if (bPN0 != -1) cnt++;
			if (bPP0 != -1) cnt++;
			if (cnt < 5) {
//				flg = 2;
				if (bNNN != -1) cnt++;			//	5.
				if (bNNP != -1) cnt++;
				if (bNPN != -1) cnt++;
				if (bNPP != -1) cnt++;
				if (bPNN != -1) cnt++;
				if (bPNP != -1) cnt++;
				if (bPPN != -1) cnt++;
				if (bPPP != -1) cnt++;
			}
		}
		
		double weight = 0;
		if (bN00 != -1) weight += sqrt(6.);		//	1.
		if (b0N0 != -1) weight += sqrt(6.);
		if (b00N != -1) weight += sqrt(6.);
		if (bP00 != -1) weight += sqrt(6.);
		if (b0P0 != -1) weight += sqrt(6.);
		if (b00P != -1) weight += sqrt(6.);
		if (flg > 0) {
			if (b0NN != -1) weight += sqrt(3.);		//	2.
			if (b0NP != -1) weight += sqrt(3.);
			if (b0PN != -1) weight += sqrt(3.);
			if (b0PP != -1) weight += sqrt(3.);
			if (bN0N != -1) weight += sqrt(3.);		//	3.
			if (bP0N != -1) weight += sqrt(3.);
			if (bN0P != -1) weight += sqrt(3.);
			if (bP0P != -1) weight += sqrt(3.);
			if (bNN0 != -1) weight += sqrt(3.);		//	4.
			if (bNP0 != -1) weight += sqrt(3.);
			if (bPN0 != -1) weight += sqrt(3.);
			if (bPP0 != -1) weight += sqrt(3.);
			if (flg > 1) {
				if (bNNN != -1) weight += sqrt(2.);			//	5.
				if (bNNP != -1) weight += sqrt(2.);
				if (bNPN != -1) weight += sqrt(2.);
				if (bNPP != -1) weight += sqrt(2.);
				if (bPNN != -1) weight += sqrt(2.);
				if (bPNP != -1) weight += sqrt(2.);
				if (bPPN != -1) weight += sqrt(2.);
				if (bPPP != -1) weight += sqrt(2.);
			}
		}
		
		if (bN00 != -1) m_LtL.AddElement(i, bN00, -sqrt(6.) / weight);
		if (b0N0 != -1) m_LtL.AddElement(i, b0N0, -sqrt(6.) / weight);
		if (b00N != -1) m_LtL.AddElement(i, b00N, -sqrt(6.) / weight);
		if (bP00 != -1) m_LtL.AddElement(i, bP00, -sqrt(6.) / weight);
		if (b0P0 != -1) m_LtL.AddElement(i, b0P0, -sqrt(6.) / weight);
		if (b00P != -1) m_LtL.AddElement(i, b00P, -sqrt(6.) / weight);
		if (flg > 0) {
			if (b0NN != -1) m_LtL.AddElement(i, b0NN, -sqrt(3.) / weight);
			if (b0NP != -1) m_LtL.AddElement(i, b0NP, -sqrt(3.) / weight);
			if (b0PN != -1) m_LtL.AddElement(i, b0PN, -sqrt(3.) / weight);
			if (b0PP != -1) m_LtL.AddElement(i, b0PP, -sqrt(3.) / weight);
			if (bN0N != -1) m_LtL.AddElement(i, bN0N, -sqrt(3.) / weight);
			if (bP0N != -1) m_LtL.AddElement(i, bP0N, -sqrt(3.) / weight);
			if (bN0P != -1) m_LtL.AddElement(i, bN0P, -sqrt(3.) / weight);
			if (bP0P != -1) m_LtL.AddElement(i, bP0P, -sqrt(3.) / weight);
			if (bNN0 != -1) m_LtL.AddElement(i, bNN0, -sqrt(3.) / weight);
			if (bNP0 != -1) m_LtL.AddElement(i, bNP0, -sqrt(3.) / weight);
			if (bPN0 != -1) m_LtL.AddElement(i, bPN0, -sqrt(3.) / weight);
			if (bPP0 != -1) m_LtL.AddElement(i, bPP0, -sqrt(3.) / weight);
			if (flg > 1) {
				if (bNNN != -1) m_LtL.AddElement(i, bNNN, -sqrt(2.) / weight);
				if (bNNP != -1) m_LtL.AddElement(i, bNNP, -sqrt(2.) / weight);
				if (bNPN != -1) m_LtL.AddElement(i, bNPN, -sqrt(2.) / weight);
				if (bNPP != -1) m_LtL.AddElement(i, bNPP, -sqrt(2.) / weight);
				if (bPNN != -1) m_LtL.AddElement(i, bPNN, -sqrt(2.) / weight);
				if (bPNP != -1) m_LtL.AddElement(i, bPNP, -sqrt(2.) / weight);
				if (bPPN != -1) m_LtL.AddElement(i, bPPN, -sqrt(2.) / weight);
				if (bPPP != -1) m_LtL.AddElement(i, bPPP, -sqrt(2.) / weight);
			}
		}
	}
	
	fprintf(stderr, "(L:%d elements)...", m_LtL.CountElements());
	//int min = 10000;
	//int mini = -1;
	//int minc = 0;
	//for (int i = 0; i < m_LtL.GetSize(); ++i)
	//	if (min > m_LtL.GetColumnSize(i)) {
	//		min = m_LtL.GetColumnSize(i);
	//		mini = i;
	//		minc = 0;
	//	} else if (min == m_LtL.GetColumnSize(i))
	//		++minc;
	//fprintf(stderr, "min = %d(%d)\n", min, minc);
	
	m_LtL.MultSelfTransposeSelf();
	fprintf(stderr, "(LtL:%d elements)...", m_LtL.CountElements());
	
	m_LtL.InitializeToSolve();

	fprintf(stderr, "Completed!\n");
}

//void VVolumeDataManager::CalcLtL() {
//	VolumeData*& vdata = VCore::getInstance()->m_vdata;
//	
//	m_mapL2V.clear();
//	int* mapV2L = new int[1 << (NUMGRID_POW * 3)];
//	
//	int N = 0;
//	for (int ix = 0; ix < NUMGRID; ++ix)
//	for (int iy = 0; iy < NUMGRID; ++iy)
//	for (int iz = 0; iz < NUMGRID; ++iz) {
//		if (vdata[IXGRID(ix, iy, iz)].isInner) {
//			m_mapL2V.push_back(IXGRID(ix, iy, iz));
//			mapV2L[IXGRID(ix, iy, iz)] = N;
//			N++;
//		} else {
//			mapV2L[IXGRID(ix, iy, iz)] = -1;
//		}
//	}
//	
//	TSparseMatrix L;
//	L.Allocate(N, N);
//	
//	fprintf(stderr, "Calculating LtL of Volume Data(size: %d)...", N);
//	
//	for (int i = 0; i < N; ++i) {
//		L.AddToElement(i, i, 1);
//		int ixyz = m_mapL2V[i];
//		int ix = (ixyz >> (NUMGRID_POW * 2) ) & (NUMGRID - 1);
//		int iy = (ixyz >> NUMGRID_POW       ) & (NUMGRID - 1);
//		int iz =  ixyz                        & (NUMGRID - 1);
//		
//		//bXYZ : 0->neutral, N->negative, P->positive
//		int bN00, b0N0, b00N, bP00, b0P0, b00P,				//	1.
//			b0NN, b0NP, b0PN, b0PP,							//	2.
//			bN0N, bP0N, bN0P, bP0P,							//	3.
//			bNN0, bNP0, bPN0, bPP0,							//	4.
//			bNNN, bNNP, bNPN, bNPP, bPNN, bPNP, bPPN, bPPP;	//	5.
//
//		//	1.
//		if (ix > 0) bN00 = mapV2L[IXGRID(ix-1, iy, iz)];
//		if (iy > 0) b0N0 = mapV2L[IXGRID(ix, iy-1, iz)];
//		if (iz > 0) b00N = mapV2L[IXGRID(ix, iy, iz-1)];
//		if (ix < NUMGRID-1) bP00 = mapV2L[IXGRID(ix+1, iy, iz)];
//		if (iy < NUMGRID-1) b0P0 = mapV2L[IXGRID(ix, iy+1, iz)];
//		if (iz < NUMGRID-1) b00P = mapV2L[IXGRID(ix, iy, iz+1)];
//		
//		//	2.
//		if (iy > 0 && iz > 0)					b0NN = mapV2L[IXGRID(ix, iy-1, iz-1)];
//		if (iy > 0 && iz < NUMGRID-1)			b0NP = mapV2L[IXGRID(ix, iy-1, iz+1)];
//		if (iy < NUMGRID-1 && iz > 0)			b0PN = mapV2L[IXGRID(ix, iy+1, iz-1)];
//		if (iy < NUMGRID-1 && iz < NUMGRID-1)	b0PP = mapV2L[IXGRID(ix, iy+1, iz+1)];
//		
//		//	3.
//		if (iz > 0 && ix > 0)					bN0N = mapV2L[IXGRID(ix-1, iy, iz-1)];
//		if (iz > 0 && ix < NUMGRID-1)			bP0N = mapV2L[IXGRID(ix+1, iy, iz-1)];
//		if (iz < NUMGRID-1 && ix > 0)			bN0P = mapV2L[IXGRID(ix-1, iy, iz+1)];
//		if (iz < NUMGRID-1 && ix < NUMGRID-1)	bP0P = mapV2L[IXGRID(ix+1, iy, iz+1)];
//		
//		//	4.
//		if (ix > 0 && iy > 0)					bNN0 = mapV2L[IXGRID(ix-1, iy-1, iz)];
//		if (ix > 0 && iy < NUMGRID-1)			bNP0 = mapV2L[IXGRID(ix-1, iy+1, iz)];
//		if (ix < NUMGRID-1 && iy > 0)			bPN0 = mapV2L[IXGRID(ix+1, iy-1, iz)];
//		if (ix < NUMGRID-1 && iy < NUMGRID-1)	bPP0 = mapV2L[IXGRID(ix+1, iy+1, iz)];
//		
//		//	5.
//		if (ix > 0 && iy > 0 && iz > 0)							bNNN = mapV2L[IXGRID(ix-1, iy-1, iz-1)];
//		if (ix > 0 && iy > 0 && iz < NUMGRID-1)					bNNP = mapV2L[IXGRID(ix-1, iy-1, iz+1)];
//		if (ix > 0 && iy < NUMGRID-1 && iz > 0)					bNPN = mapV2L[IXGRID(ix-1, iy+1, iz-1)];
//		if (ix > 0 && iy < NUMGRID-1 && iz < NUMGRID-1)			bNPP = mapV2L[IXGRID(ix-1, iy+1, iz+1)];
//		if (ix < NUMGRID-1 && iy > 0 && iz > 0)					bPNN = mapV2L[IXGRID(ix-1, iy-1, iz-1)];
//		if (ix < NUMGRID-1 && iy > 0 && iz < NUMGRID-1)			bPNP = mapV2L[IXGRID(ix-1, iy-1, iz+1)];
//		if (ix < NUMGRID-1 && iy < NUMGRID-1 && iz > 0)			bPPN = mapV2L[IXGRID(ix-1, iy+1, iz-1)];
//		if (ix < NUMGRID-1 && iy < NUMGRID-1 && iz < NUMGRID-1)	bPPP = mapV2L[IXGRID(ix-1, iy+1, iz+1)];
//		
//		double weight = 0;
//		if (bN00 != -1) weight += sqrt(6.);		//	1.
//		if (b0N0 != -1) weight += sqrt(6.);
//		if (b00N != -1) weight += sqrt(6.);
//		if (bP00 != -1) weight += sqrt(6.);
//		if (b0P0 != -1) weight += sqrt(6.);
//		if (b00P != -1) weight += sqrt(6.);
//		if (b0NN != -1) weight += sqrt(3.);		//	2.
//		if (b0NP != -1) weight += sqrt(3.);
//		if (b0PN != -1) weight += sqrt(3.);
//		if (b0PP != -1) weight += sqrt(3.);
//		if (bN0N != -1) weight += sqrt(3.);		//	3.
//		if (bP0N != -1) weight += sqrt(3.);
//		if (bN0P != -1) weight += sqrt(3.);
//		if (bP0P != -1) weight += sqrt(3.);
//		if (bNN0 != -1) weight += sqrt(3.);		//	4.
//		if (bNP0 != -1) weight += sqrt(3.);
//		if (bPN0 != -1) weight += sqrt(3.);
//		if (bPP0 != -1) weight += sqrt(3.);
//		if (bNNN != -1) weight += 1.;			//	5.
//		if (bNNP != -1) weight += 1.;
//		if (bNPN != -1) weight += 1.;
//		if (bNPP != -1) weight += 1.;
//		if (bPNN != -1) weight += 1.;
//		if (bPNP != -1) weight += 1.;
//		if (bPPN != -1) weight += 1.;
//		if (bPPP != -1) weight += 1.;
//		
//		if (bN00 != -1) L.AddToElement(i, bN00, -sqrt(6.) / weight);
//		if (b0N0 != -1) L.AddToElement(i, b0N0, -sqrt(6.) / weight);
//		if (b00N != -1) L.AddToElement(i, b00N, -sqrt(6.) / weight);
//		if (bP00 != -1) L.AddToElement(i, bP00, -sqrt(6.) / weight);
//		if (b0P0 != -1) L.AddToElement(i, b0P0, -sqrt(6.) / weight);
//		if (b00P != -1) L.AddToElement(i, b00P, -sqrt(6.) / weight);
//		if (b0NN != -1) L.AddToElement(i, b0NN, -sqrt(3.) / weight);
//		if (b0NP != -1) L.AddToElement(i, b0NP, -sqrt(3.) / weight);
//		if (b0PN != -1) L.AddToElement(i, b0PN, -sqrt(3.) / weight);
//		if (b0PP != -1) L.AddToElement(i, b0PP, -sqrt(3.) / weight);
//		if (bN0N != -1) L.AddToElement(i, bN0N, -sqrt(3.) / weight);
//		if (bP0N != -1) L.AddToElement(i, bP0N, -sqrt(3.) / weight);
//		if (bN0P != -1) L.AddToElement(i, bN0P, -sqrt(3.) / weight);
//		if (bP0P != -1) L.AddToElement(i, bP0P, -sqrt(3.) / weight);
//		if (bNN0 != -1) L.AddToElement(i, bNN0, -sqrt(3.) / weight);
//		if (bNP0 != -1) L.AddToElement(i, bNP0, -sqrt(3.) / weight);
//		if (bPN0 != -1) L.AddToElement(i, bPN0, -sqrt(3.) / weight);
//		if (bPP0 != -1) L.AddToElement(i, bPP0, -sqrt(3.) / weight);
//		if (bNNN != -1) L.AddToElement(i, bNNN, -1. / weight);
//		if (bNNP != -1) L.AddToElement(i, bNNP, -1. / weight);
//		if (bNPN != -1) L.AddToElement(i, bNPN, -1. / weight);
//		if (bNPP != -1) L.AddToElement(i, bNPP, -1. / weight);
//		if (bPNN != -1) L.AddToElement(i, bPNN, -1. / weight);
//		if (bPNP != -1) L.AddToElement(i, bPNP, -1. / weight);
//		if (bPPN != -1) L.AddToElement(i, bPPN, -1. / weight);
//		if (bPPP != -1) L.AddToElement(i, bPPP, -1. / weight);
//	}
//	
//	fprintf(stderr, "(L:%d elements)...", L.CountElements());
//	
//	L.MultSelfTransposeSelf(m_LtL);
//	fprintf(stderr, "(LtL:%d elements)...", m_LtL.CountElements());
//	
//	m_LtL.initializeLinearSolverFields();
//	
//	fprintf(stderr, "Completed!\n");
//
//	delete [] mapV2L;
//}

void VVolumeDataManager::LaplacianSmooth() {
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	fprintf(stderr, "Preparing for Laplacian Smoothing on volume ... ");
	AfxGetApp()->DoWaitCursor(1);
	//m_isBusy = true;
	int N = (int)m_mapL2V.size();
	
	for (int i = 0; i < N; i++) 
		if (vdata[m_mapL2V[i]].isConstraint) {
			m_bx[i] = vdata[m_mapL2V[i]].field.data[0];
			m_by[i] = vdata[m_mapL2V[i]].field.data[1];
			m_bz[i] = vdata[m_mapL2V[i]].field.data[2];
		} else
			m_bx[i] = m_by[i] = m_bz[i] = 0.;

	for (int i = 0; i < N; ++i)
		if (vdata[m_mapL2V[i]].isConstraint) m_LtL.AddElement(i, i, 1.);
	
	fprintf(stderr, "Completed!\n");
	
	fprintf(stderr, "Solving Linear System [Volume] ... ");
	m_LtL.SolveLinearSystem(&m_bx[0], &m_vx [0], &m_by[0], &m_vy[0], &m_bz[0], &m_vz[0]);
	fprintf(stderr, "Completed!\n");
	
	for (int i = 0; i < N; i++) {
		vdata[m_mapL2V[i]].field.data[0] = m_vx[i];
		vdata[m_mapL2V[i]].field.data[1] = m_vy[i];
		vdata[m_mapL2V[i]].field.data[2] = m_vz[i];
	}
	
	for (int i = 0; i < N; ++i)
		if (vdata[m_mapL2V[i]].isConstraint) m_LtL.AddElement(i, i, -1.);
	AfxGetApp()->DoWaitCursor(-1);
	//m_isBusy = false;
}

void VVolumeDataManager::NormalizeAll(){
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	for(int i = 0; i < NUMGRID_POW3; i++)
		vdata[i].field.Normalize_Self();
}
