#pragma once
#include "vstate.h"

class VStateDrawStrokeOnSurface :
	public VState
{
public:
	static inline VStateDrawStrokeOnSurface* getInstance(){
		static VStateDrawStrokeOnSurface p;
		return &p;
	}
	
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);

	bool m_isValid;
};
