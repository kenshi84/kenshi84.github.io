#include "StdAfx.h"
#include ".\vdrawer.h"
#include "VVolumeDataManager.h"
#include "VSurfaceDataManager.h"
#include "VCrossSection.h"

#define COL_EXTRACT(col) ((col)>>16)&0xFF , ((col)>>8)&0xFF, (col)&0xFF

VDrawer::VDrawer(void)
{
	m_flags =
	//	  _AXIS
		  _FACES
	//	| _EDGES
	//	| _VGRID
		| _SDATA
		| _VDATA
		| _SSTROKES
		| _VSTROKES
		| _CSSTROKE
		| _CSSHAPE
		| _PARTICLE
	;
}

VDrawer::~VDrawer(void)
{
}

void VDrawer::drawFaces() {
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	vector<bool>& isHiddenVtx = VCrossSection::getInstance()->m_isHiddenVtx;
	
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glShadeModel(GL_SMOOTH);
	glDisable(GL_CULL_FACE);
	
	glColor4d(0.8, 0.6, 0.4, 0.9);
	glBegin(GL_TRIANGLES);
	
	ILVector3D eyeDir = ogl.getFocusPoint() - ogl.getEyePoint();
	for( int i = 0 ; i < (int) poly.polygons.size(); ++i)
	{
		ILPolygon &p = poly.polygons[i];
		//if (eyeDir * p.normal > 0) continue;
		if (isHiddenVtx[p.vtx[0]] || isHiddenVtx[p.vtx[1]] || isHiddenVtx[p.vtx[2]]) continue;
		glNormal3dv(poly.vertices[ p.vtx[0] ].norm);
		glVertex3dv( poly.vertices[ p.vtx[0] ].pos );
		glNormal3dv(poly.vertices[ p.vtx[1] ].norm);
		glVertex3dv( poly.vertices[ p.vtx[1] ].pos );
		glNormal3dv(poly.vertices[ p.vtx[2] ].norm);
		glVertex3dv( poly.vertices[ p.vtx[2] ].pos );
	}
	
	glEnd();
}

void VDrawer::drawAxis() {
	glDisable(GL_LIGHTING);
	glLineWidth(5);
	glBegin(GL_LINES);
	
	glColor3d(1,0,0);
	glVertex3d(0,0,0);
	glVertex3d(1/4.,0,0);
	glColor3d(0,1,0);
	glVertex3d(0,0,0);
	glVertex3d(0,1/4.,0);
	glColor3d(0,0,1);
	glVertex3d(0,0,0);
	glVertex3d(0,0,1/4.);
	
	glEnd();
	
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	int r = 2;
	glLineWidth(1);
	glColor3f(1, 1, 0);
	glBegin(GL_LINES);
	glVertex3d(0, (int)(NUMGRID / r) / (double)NUMGRID, (int)(NUMGRID / r) / (double)NUMGRID);
	glVertex3d(1, (int)(NUMGRID / r) / (double)NUMGRID, (int)(NUMGRID / r) / (double)NUMGRID);
	glEnd();
	
	glColor3ub(COL_EXTRACT(COL_VGRID));
	glPointSize(10);
	glBegin(GL_POINTS);
	for (int ix = 0; ix < NUMGRID; ++ix)
		for (int iy = 0; iy < NUMGRID; ++iy)
			for (int iz = 0; iz < NUMGRID; ++iz)
				//if (vdata[IXGRID(ix,iy,iz)].isOnCrossSection)
				if (iy == NUMGRID / r && iz == NUMGRID / r)
				if (vdata[IXGRID(ix,iy,iz)].isBound) {
					glEnd();
					glColor3f(1, 0, 0);
					glBegin(GL_POINTS);
					glVertex3d(ix / (double)NUMGRID, iy / (double)NUMGRID, iz / (double)NUMGRID);
					glEnd();
					glColor3ub(COL_EXTRACT(COL_VGRID));
					glBegin(GL_POINTS);
				} else if (vdata[IXGRID(ix,iy,iz)].isInner)
				//if (IXGRID(ix, iy, iz) == 9838) {//VVolumeDataManager::getInstance()->m_mapL2V[2492] == IXGRID(ix, iy, iz)) {
				//	glEnd();
				//	glColor3d(1,0,0);
				//	glPointSize(10);
				//	glBegin(GL_POINTS);
				//	glVertex3d(ix / (double)NUMGRID, iy / (double)NUMGRID, iz / (double)NUMGRID);
				//	glEnd();
				//	glColor3d(0,1,0);
				//	glPointSize(2);
				//	glBegin(GL_POINTS);
				//} else if (vdata[IXGRID(ix, iy, iz)].isInner)
				//if (vdata[IXGRID(ix, iy, iz)].isInner)
					glVertex3d(ix / (double)NUMGRID, iy / (double)NUMGRID, iz / (double)NUMGRID);
	glEnd();
}

void VDrawer::drawEdges() {
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	vector<bool>& isHiddenVtx = VCrossSection::getInstance()->m_isHiddenVtx;
	
	glDisable(GL_LIGHTING);
	glLineWidth(1);
	glColor3ub(COL_EXTRACT(COL_EDGE));
	glBegin(GL_LINES);
	
	for( int i = 0 ; i < (int) poly.edges.size(); ++i)
	{
		ILWingedEdge &we = poly.edges[i];
		//if (isHiddenVtx[we.v[0]] || isHiddenVtx[we.v[1]]) continue;
		glVertex3dv( poly.vertices[ we.v[0] ].pos );
		glVertex3dv( poly.vertices[ we.v[1] ].pos );
	}
	
	glEnd();
	
	//���_�摜�p--------------------
	if (m_flags & _AXIS) {
		vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
		
		glLineWidth(2);
		glColor3ub(255, 255, 0);
		glBegin(GL_LINES);
		vector<int> idList;
		for (int i = 0; i < NUMGRID_POW3; ++i)
			if (vdata[i].isOnCrossSection && vdata[i].isBound)
				idList.push_back(vdata[i].pinfo.polyID);
		
		for (int i = 0; i < (int)idList.size(); ++i) {
			ILPolygon &p = poly.polygons[idList[i]];
			glVertex3dv(poly.vertices[p.vtx[0]].pos);
			glVertex3dv(poly.vertices[p.vtx[1]].pos);
			glVertex3dv(poly.vertices[p.vtx[1]].pos);
			glVertex3dv(poly.vertices[p.vtx[2]].pos);
			glVertex3dv(poly.vertices[p.vtx[2]].pos);
			glVertex3dv(poly.vertices[p.vtx[0]].pos);
		}
		glEnd();
	}
	//---------------------�����܂�
}

void VDrawer::drawSurfaceData() {
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	vector<SurfaceData>& sdata = VCore::getInstance()->m_sdata;
	vector<bool>& isHiddenVtx = VCrossSection::getInstance()->m_isHiddenVtx;

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glColor3ub(COL_EXTRACT(COL_DATA));
	ILVector3D zero(0,0,0);
	
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	ILVector3D eye = ogl.getFocusPoint() - ogl.getEyePoint();

	for(int i = 0; i < (int) poly.vertices.size(); ++i)
	{
		if (poly.vertices[i].norm * eye > 0) continue;
		if (isHiddenVtx[i]) continue;
		if (sdata[i].field == zero) continue;
		
		if (sdata[i].isConstraint) glColor3ub(COL_EXTRACT(COL_DATA_CONSTRAINT));
		drawArrow(poly.vertices[i].pos, sdata[i].field * 0.05);
		if (sdata[i].isConstraint) glColor3ub(COL_EXTRACT(COL_DATA));
	}
}

void VDrawer::drawStrokesOnSurface() {
	vector< vector<ILVector3D> >& strokes = VSurfaceDataManager::getInstance()->m_strokes3D;
	
	glLineWidth(10);
	glDisable(GL_LIGHTING);
	for (int i = 0; i < (int)strokes.size(); i++) {
		if (strokes[i].size() < 3) continue;
		for (int j = 1; j < (int)strokes[i].size(); ++j) {
			int v = 128 + 127 * (j-1) / ((int)strokes[i].size()-1);
			glColor3ub(0, v, v / 2);
			glBegin(GL_LINES);
			glVertex3dv(strokes[i][j-1]);
			glVertex3dv(strokes[i][j]);
			glEnd();
		}
	}
}

void VDrawer::drawStrokesOnVolume() {
	vector< vector<ILVector3D> >& strokes = VVolumeDataManager::getInstance()->m_strokes;

	glLineWidth(10);
	glDisable(GL_LIGHTING);
	for (int i = 0; i < (int)strokes.size(); i++) {
		if (strokes[i].size() < 3) continue;
		for (int j = 1; j < (int)strokes[i].size(); ++j) {
			int v = 128 + 127 * (j-1) / ((int)strokes[i].size()-1);
			glColor3ub(0, v, v / 2);
			glBegin(GL_LINES);
			glVertex3dv(strokes[i][j-1]);
			glVertex3dv(strokes[i][j]);
			glEnd();
		}
	}
}

#include "VVolumeDataManager.h"

void VDrawer::drawVolumeGrid() {
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;

	glColor3ub(COL_EXTRACT(COL_VGRID));
	glPointSize(5);
	glBegin(GL_POINTS);
	for (int ix = 0; ix < NUMGRID; ++ix)
		for (int iy = 0; iy < NUMGRID; ++iy)
			for (int iz = 0; iz < NUMGRID; ++iz)
				//if (vdata[IXGRID(ix,iy,iz)].isInner)
				if (vdata[IXGRID(ix,iy,iz)].isOnCrossSection)
					if (m_flags & _AXIS) {
						if (vdata[IXGRID(ix,iy,iz)].isBound) {
							glEnd();
							glColor3ub(255,0,0);
							glBegin(GL_POINTS);
							glVertex3d(ix / (double)NUMGRID, iy / (double)NUMGRID, iz / (double)NUMGRID);
							glEnd();
							glColor3ub(COL_EXTRACT(COL_VGRID));
							glBegin(GL_POINTS);
						} else continue;
				//if (IXGRID(ix, iy, iz) == 9838) {//VVolumeDataManager::getInstance()->m_mapL2V[2492] == IXGRID(ix, iy, iz)) {
				//	glEnd();
				//	glColor3d(1,0,0);
				//	glPointSize(10);
				//	glBegin(GL_POINTS);
				//	glVertex3d(ix / (double)NUMGRID, iy / (double)NUMGRID, iz / (double)NUMGRID);
				//	glEnd();
				//	glColor3d(0,1,0);
				//	glPointSize(2);
				//	glBegin(GL_POINTS);
				//} else if (vdata[IXGRID(ix, iy, iz)].isInner)
				//if (vdata[IXGRID(ix, iy, iz)].isInner)
					} else
					glVertex3d(ix / (double)NUMGRID, iy / (double)NUMGRID, iz / (double)NUMGRID);
	glEnd();
}

void VDrawer::drawVolumeData() {
	vector<VolumeData>& vdata = VCore::getInstance()->m_vdata;
	
	glColor3ub(COL_EXTRACT(COL_DATA));
	glEnable(GL_LIGHTING);
	ILVector3D zero(0,0,0);
	for (int i = 0; i < NUMGRID; ++i)
		for (int j = 0; j < NUMGRID; ++j)
			for (int k = 0; k < NUMGRID; ++k) {
				if (!vdata[IXGRID(i,j,k)].isInner) continue;
				if (!vdata[IXGRID(i,j,k)].isOnCrossSection) continue;
				if ( vdata[IXGRID(i,j,k)].field == zero) continue;
				double x = i / (double) NUMGRID;
				double y = j / (double) NUMGRID;
				double z = k / (double) NUMGRID;
				if ( vdata[IXGRID(i, j, k)].isConstraint) glColor3ub(COL_EXTRACT(COL_DATA_CONSTRAINT));
				drawArrow(ILVector3D(x,y,z), vdata[IXGRID(i,j,k)].field * 0.03);
				if ( vdata[IXGRID(i, j, k)].isConstraint) glColor3ub(COL_EXTRACT(COL_DATA));
			}
	//int ix = (int)(m_v.data[0] * NUMGRID);
	//int iy = (int)(m_v.data[1] * NUMGRID);
	//int iz = (int)(m_v.data[2] * NUMGRID);
	//double ux = m_v.data[0] * NUMGRID - ix;
	//double uy = m_v.data[1] * NUMGRID - iy;
	//double uz = m_v.data[2] * NUMGRID - iz;
	//ILVector3D tmp;
	//tmp = (1-ux) * (1-uy) * (1-uz) * vdata[IXGRID(ix, iy, iz)].field
	//	+ (1-ux) * uy * (1-uz) * vdata[IXGRID(ix, iy+1, iz)].field
	//	+ (1-ux) * (1-uy) * uz * vdata[IXGRID(ix, iy, iz+1)].field
	//	+ (1-ux) * uy * uz * vdata[IXGRID(ix, iy+1, iz+1)].field
	//	+ ux * (1-uy) * (1-uz) * vdata[IXGRID(ix+1, iy, iz)].field
	//	+ ux * uy * (1-uz) * vdata[IXGRID(ix+1, iy+1, iz)].field
	//	+ ux * (1-uy) * uz * vdata[IXGRID(ix+1, iy, iz+1)].field
	//	+ ux * uy * uz * vdata[IXGRID(ix+1, iy+1, iz+1)].field;
	//tmp.Normalize_Self();
	//glColor3ub(255, 255, 0);
	//drawArrow(m_v, tmp * 0.03);
}

void VDrawer::drawStrokeCrossSection() {
	vector<ILVector3D>& strokeNear = VCrossSection::getInstance()->m_strokeNear;
	vector<ILVector3D>& strokeFar  = VCrossSection::getInstance()->m_strokeFar;
	
	if ((int)strokeNear.size() < 2) return;
	
	glDisable(GL_LIGHTING);
	glColor3ub(COL_EXTRACT(COL_CROSSSECTION));
	glLineWidth(10);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < (int)strokeNear.size(); ++i)
		glVertex3dv(strokeNear[i]);
	glEnd();
	
	//glBegin(GL_LINE_STRIP);
	//for (int i = 0; i < (int)strokeFar.size(); ++i)
	//	glVertex3dv(strokeFar[i]);
	//glEnd();
	//glLineWidth(1);
	//glBegin(GL_LINES);
	//for (int i = 0; i < (int)strokeNear.size(); ++i) {
	//	glVertex3dv(strokeNear[i]);
	//	glVertex3dv(strokeFar[i]);
	//}
	//glEnd();
}

void VDrawer::drawCrossSectionShape() {
	vector<ILVector3D>& csshape = VCrossSection::getInstance()->m_shape;
	glDisable(GL_LIGHTING);
	glColor3ub(COL_EXTRACT(COL_CROSSSECTION));
	
	glLineWidth(10);
	glBegin(GL_LINES);
	//int q = (int)csshape.size() / 4;
	for (int i = 0; i < (int)csshape.size(); i+=2) {
		//int r, g, b;
		//if (i < q) {
		//	r = 0;
		//	g = (0xFF * i) / q;
		//	b = 0xFF;
		//} else if (i < 2*q) {
		//	r = 0;
		//	g = 0xFF;
		//	b = (0xFF * (2*q - i)) / q;
		//} else if (i < 3*q) {
		//	r = (0xFF * (3*q - i)) / q;
		//	g = 0xFF;
		//	b = 0;
		//} else {
		//	r = 0xFF;
		//	g = (0xFF * (4*q - i)) / q;
		//	b = 0;
		//}
		//glColor3ub(r, g, b);
		//glBegin(GL_LINES);
		glVertex3dv(csshape[i]);
		glVertex3dv(csshape[i+1]);
		//glEnd();
	}
	glEnd();
}

void VDrawer::drawParticle() {
	vector<ILVector3D>& particle = VCore::getInstance()->m_particle;
	
	glDisable(GL_LIGHTING);
	glColor3ub(COL_EXTRACT(COL_PARTICLE));
	glPointSize(5);
	glBegin(GL_POINTS);
	
	for (int i = 0; i < (int)particle.size(); ++i)
		glVertex3dv(particle[i]);
	
	glEnd();
}

/* ����`���i�傫����ori�̑傫���ɔ��j */
void VDrawer::drawArrow(ILVector3D& start, ILVector3D& ori) {
	double len = ori.Length();
	
	//���W�ϊ�
	glPushMatrix();
	ILVector3D nori = ori.Normalize();
	ILVector3D ey(0,1,0);
	ILVector3D axis = ey ^ nori;
	double cost = ey * nori;
	double t = acos(cost) * 180 / M_PI;
	glTranslated(start.data[0], start.data[1], start.data[2]);
	glRotated(t, axis.data[0], axis.data[1], axis.data[2]);
	
	//���̐����
	glBegin(GL_TRIANGLE_FAN);
	glVertex3d(0, len, 0);
	glNormal3d(0, 1, 0);
	double r = len / 8;
	for(int i = 0; i <= 6; i++) {
		double a = i * M_PI / 3;
		glVertex3d(r * sin(a), len * 2 / 3, r * cos(a));
		glNormal3d(sin(a), 0, cos(a));
	}
	glEnd();
	glBegin(GL_TRIANGLE_FAN);
	for(int i = 0; i < 6; i++) {
		double a = - i * M_PI / 3;
		glVertex3d(r * sin(a), len * 2 / 3, r * cos(a));
		glNormal3d(0,-1,0);
	}
	glEnd();
	//���̎�
	glBegin(GL_TRIANGLE_STRIP);
	double r2 = len / 32;
	for(int i = 0; i <= 6; i++) {
		double a = - i * M_PI / 3;
		glVertex3d(r2 * sin(a), 0, r2 * cos(a));
		glNormal3d(sin(a), 0, cos(a));
		glVertex3d(r2 * sin(a), len * 2 / 3, r2 * cos(a));
		glNormal3d(sin(a), 0, cos(a));
	}
	glEnd();
	glBegin(GL_TRIANGLE_FAN);
	for(int i = 0; i < 6; i++) {
		double a = - i * M_PI / 3;
		glVertex3d(r2 * sin(a), 0, r2 * cos(a));
		glNormal3d(0,-1,0);
}
	glEnd();

	//���W��߂�
	glPopMatrix();
}

void VDrawer::OnDraw()
{
	ILPolygonModel& poly = VCore::getInstance()->m_poly;
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	vector<SurfaceData>& sdata = VCore::getInstance()->m_sdata;
	
	glEnable(GL_COLOR_MATERIAL);
	
	if (m_flags & _FACES)
		drawFaces();
	
	if (m_flags & _AXIS)
		drawAxis();

	if (m_flags & _EDGES)
		drawEdges();

	if (m_flags & _SDATA)
		drawSurfaceData();

	if (m_flags & _SSTROKES)
		drawStrokesOnSurface();

	if (m_flags & _VSTROKES)
		drawStrokesOnVolume();

	if (m_flags & _VGRID)
		drawVolumeGrid();
	
	if (m_flags & _VDATA)
		drawVolumeData();
	
	if (m_flags & _CSSTROKE)
		drawStrokeCrossSection();
	
	if (m_flags & _CSSHAPE)
		drawCrossSectionShape();
	
	if (m_flags & _PARTICLE)
		drawParticle();
	
}
