#pragma once
#include <vector>

using namespace std;

class KUmfpackSquareMatrix
{
public:
	KUmfpackSquareMatrix(void);
	~KUmfpackSquareMatrix(void);
	
	void SetSize(int N);
	int GetSize(void) {
		return N;
	}
	void SetElement(int row, int col, double val);
	void AddElement(int row, int col, double val);
	double GetElement(int row, int col);
	
	void SolveLinearSystem(const double* b, double* x);
	void SolveLinearSystem(const double* b0, double* x0, const double* b1, double* x1, const double* b2, double* x2);
	
	void MultSelfTransposeSelf(void);
	void InitializeToSolve(void);
	int CountElements(void) {
		int cnt = 0;
		for (int i = 0; i < N; ++i)
			cnt += (int)cols[i].indices.size();
		return cnt;
	}
	void Trace(void);
	int GetColumnSize(int col) {
		return (int)cols[col].indices.size();
	}

private:
	struct Ind_Coef {
		vector<int> indices;
		vector<double> coefficients;
		
		Ind_Coef() {
		}

		Ind_Coef(const Ind_Coef& other)
			: indices(other.indices), coefficients(other.coefficients)
		{}
	};
	
	vector<Ind_Coef> cols;
	int N;
	bool m_isReadyToSolve;
	vector<int> m_Ap, m_Ai;
	vector<double> m_Ax;
};

void printUMFPACK_Info(double Info[]);
