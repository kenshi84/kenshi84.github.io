#include "StdAfx.h"
#include ".\vstatedrawcrosssectionstroke.h"
#include "VCrossSection.h"
#include "VStateDefault.h"
#include "VStateDrawStrokeOnVolume.h"
#include "VDrawer.h"
#include "VMenuListener.h"

void VStateDrawCrossSectionStroke::OnLButtonDown(UINT nFlags, CPoint point) {
	fprintf(stderr, "State Error! - VStateDrawCrossSectionStroke::OnLButtonDown\n");
}

void VStateDrawCrossSectionStroke::OnLButtonUp(UINT nFlags, CPoint point) {
	VDrawer::getInstance()->m_flags &= ~VDrawer::_CSSTROKE;
	
	if(VCrossSection::getInstance()->CheckValid()) {
		//VCrossSection::getInstance()->ViewChanged();
		VCrossSection::getInstance()->CalcAreaType();
		VCrossSection::getInstance()->CalcVolumeOnCrossSection();
		VCrossSection::getInstance()->CalcCrossSectionShape();
		VCrossSection::getInstance()->CalcHiddenVtx();
		
		VCore::getInstance()->m_state = VStateDefault::getInstance();
		VDrawer::getInstance()->m_flags &= ~VDrawer::_SDATA;
		VMenuListener::getInstance()->OnCommandSmoothOnVolume();
	} else {
		VCore::getInstance()->m_state = VStateDefault::getInstance();
		VCrossSection::getInstance()->ClearPointCrossSectionStroke();
	}
	VCore::getInstance()->m_ogl.RedrawWindow();
}

void VStateDrawCrossSectionStroke::OnMouseMove(UINT nFlags, CPoint point) {
	CPoint& pointLast = VCrossSection::getInstance()->m_stroke2D.back();
	int dx = point.x - pointLast.x;
	int dy = point.y - pointLast.y;
	if (dx*dx + dy*dy < 100) return;
	PointInfoOnPolygon pinfo;
	if (GetIntersectionScreenCoordPolygonModel(VCore::getInstance()->m_ogl, point, VCore::getInstance()->m_poly, pinfo))
		VCrossSection::getInstance()->m_isValid = true;
	VCrossSection::getInstance()->AddPointCrossSectionStroke(point);
}
