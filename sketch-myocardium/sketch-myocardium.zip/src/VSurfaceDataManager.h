#pragma once
#include "VCore.h"
//#include "TSparseMatrix.h"
#include "KUmfpackSquareMatrix.h"

class VSurfaceDataManager
{
public:
	VSurfaceDataManager(void);
	~VSurfaceDataManager(void);
	
	static inline VSurfaceDataManager* getInstance(){
		static VSurfaceDataManager p;
		return &p;
	}
	
	void AddStroke();
	void AddPointToStroke(PointInfoOnPolygon pinfo);
	void ClearData();
	void SetConstraints();
	void NormalizeAll();
	void RemoveNonTangential();
	
	/* Laplacian Smoothing */
	void CalcLtL();
	void LaplacianSmooth();
	
	/* Simple One-Scratch Smoothing */
	void SimpleSmooth();
	vector<vector<ILVector3D> > m_strokes3D;
	vector<vector<PointInfoOnPolygon> > m_strokesPointInfo;
private:
	//TSparseMatrix m_LtL;
	KUmfpackSquareMatrix m_LtL;
	vector<double> m_bx, m_by, m_bz;
	vector<double> m_vx, m_vy, m_vz;
};
