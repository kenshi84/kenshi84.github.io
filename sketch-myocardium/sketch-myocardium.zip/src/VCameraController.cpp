#include "StdAfx.h"
#include ".\vcameracontroller.h"

VCameraController::VCameraController(void)
{
}

VCameraController::~VCameraController(void)
{
}
