#include "StdAfx.h"
#include ".\vstatedefault.h"
#include "VSurfaceDataManager.h"
#include "VVolumeDataManager.h"
#include "VStateDrawStrokeOnSurface.h"
#include "VStateDrawStrokeOnVolume.h"
#include "VStateDrawCrossSectionStroke.h"
#include "VStateAddParticle.h"
#include "VCrossSection.h"
#include "VDrawer.h"

void VStateDefault::OnLButtonDown(UINT nFlags, CPoint point) {
	ILOGL& ogl = VCore::getInstance()->m_ogl;
	
	PointInfoOnPolygon pinfo;
	ILVector3D v;
	if(VCrossSection::getInstance()->GetIntersectionScreenCoordPolygonModel(point, pinfo)) {
		VSurfaceDataManager::getInstance()->AddStroke();
		VSurfaceDataManager::getInstance()->AddPointToStroke(pinfo);
		
		VDrawer::getInstance()->m_flags |= VDrawer::_SDATA;
		VStateDrawStrokeOnSurface::getInstance()->m_isValid = true;
		
		VCore::getInstance()->m_RedoFlags.clear();
		VCore::getInstance()->m_RedoStrokesSurface.clear();
		VCore::getInstance()->m_RedoStrokesVolume.clear();
		
		VCore::getInstance()->m_pView->GetDocument()->SetModifiedFlag();
		VCore::getInstance()->m_UndoFlags.push_back(true);
		
		VCore::getInstance()->m_state = VStateDrawStrokeOnSurface::getInstance();
	} else if (VCrossSection::getInstance()->CalcIntersectionPointCrossSection(point, v)) {
		if (nFlags & MK_SHIFT) {
			VCore::getInstance()->m_particle.push_back(v);
			VCore::getInstance()->m_state = VStateAddParticle::getInstance();
		} else {
		
			VVolumeDataManager::getInstance()->m_strokes.push_back(vector<ILVector3D>());
			VVolumeDataManager::getInstance()->m_strokes.back().push_back(v);
			
			VStateDrawStrokeOnVolume::getInstance()->m_isValid = true;
			
			VCore::getInstance()->m_RedoFlags.clear();
			VCore::getInstance()->m_RedoStrokesSurface.clear();
			VCore::getInstance()->m_RedoStrokesVolume.clear();
			
			VCore::getInstance()->m_pView->GetDocument()->SetModifiedFlag();
			VCore::getInstance()->m_UndoFlags.push_back(false);
			
			//VDrawer::getInstance()->m_v = v;
			
			VCore::getInstance()->m_state = VStateDrawStrokeOnVolume::getInstance();
		}
	} else {
		VDrawer::getInstance()->m_flags |= VDrawer::_CSSTROKE;
		VDrawer::getInstance()->m_flags |= VDrawer::_SDATA;

		VCrossSection::getInstance()->ClearPointCrossSectionStroke();
		VCrossSection::getInstance()->ClearCrossSection();
		VCrossSection::getInstance()->ClearHiddenVtx();
		VCrossSection::getInstance()->setEyePoint(ogl.getEyePoint());
		VCrossSection::getInstance()->AddPointCrossSectionStroke(point);
		VCrossSection::getInstance()->m_isValid = false;
		
		VCore::getInstance()->m_state = VStateDrawCrossSectionStroke::getInstance();
	}
}

void VStateDefault::OnLButtonUp(UINT nFlags, CPoint point) {
	fprintf(stderr, "State Error! - VStateDefault::OnLButtonUp()\n");
}

void VStateDefault::OnMouseMove(UINT nFlags, CPoint point) {
	fprintf(stderr, "State Error! - VStateDefault::OnMouseMove()\n");
}
