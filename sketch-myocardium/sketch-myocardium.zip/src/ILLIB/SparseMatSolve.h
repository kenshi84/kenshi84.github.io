#ifndef __SPARSE_MAT_SOLVE_H_INCLUDED__
#define __SPARSE_MAT_SOLVE_H_INCLUDED__

// Written by owada.
// This file should be used in the context of extern "C"{}.

extern "C"
{
#include "cblas.h"
}

extern "C"
{
#include "umfpack.h"
}

#pragma comment(lib, "amd.lib")
#pragma comment(lib, "atlas.lib")
#pragma comment(lib, "cblas.lib")
#pragma comment(lib, "Umfpack_43.lib")

extern "C" long _ftol( double ); //defined by VC6 C libs
extern "C" long _ftol2( double dblSource ) { return _ftol( dblSource ); }

#endif	// __SPARSE_MAT_SOLVE_H_INCLUDED__

