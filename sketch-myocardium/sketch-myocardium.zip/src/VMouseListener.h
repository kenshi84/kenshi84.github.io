#pragma once
#include "VCore.h"
#include "VSurfaceDataManager.h"
#include "VCrossSection.h"

class VMouseListener
{
public:
	VMouseListener(void);
	~VMouseListener(void);
	
	static inline VMouseListener* getInstance(){
		static VMouseListener p;
		return &p;
	}
	
	/* mouse interaction */
	void OnLButtonDown(UINT nFlags, CPoint point);
	void OnLButtonUp(UINT nFlags, CPoint point);
	void OnRButtonDown(UINT nFlags, CPoint point);
	void OnRButtonUp(UINT nFlags, CPoint point);
	void OnMButtonDown(UINT nFlags, CPoint point);
	void OnMButtonUp(UINT nFlags, CPoint point);
	void OnMouseMove(UINT nFlags, CPoint point);

private:
	bool m_isLButton;
	bool m_isRButton;
	bool m_isMButton;

	bool m_isValid;
};
