#pragma once
#include "ILPolygonModel.h"
#include "ILMath.h"
#include "ILOGL.h"
#include "TSparseMatrix.h"

class PointInfoOnPolygon
{
public:
	int polyID;
	double s, t;
	
	PointInfoOnPolygon(void);

	ILVector3D GetPosFromPolygonModel(ILPolygonModel poly) {
		ILPolygon &p = poly.polygons[polyID];
		ILVector3D &v0 = poly.vertices[p.vtx[0]].pos;
		ILVector3D &v1 = poly.vertices[p.vtx[1]].pos;
		ILVector3D &v2 = poly.vertices[p.vtx[2]].pos;
		double d0 = (1-s-t)*v0.data[0] + s*v1.data[0] + t*v2.data[0];
		double d1 = (1-s-t)*v0.data[1] + s*v1.data[1] + t*v2.data[1];
		double d2 = (1-s-t)*v0.data[2] + s*v1.data[2] + t*v2.data[2];
		return ILVector3D(d0, d1, d2);
//		return (1-s-t)*v0 + s*v1 + t*v2;
	}
};

bool GetIntersectionScreenCoordPolygonModel(ILOGL& ogl, CPoint &point, ILPolygonModel& poly, PointInfoOnPolygon& result);
bool GetIntersectionLinePolygonModel(ILVector3D& start, ILVector3D& ori, ILPolygonModel& poly, PointInfoOnPolygon& result);

bool CalcCrossEdge(const ILVector3D &start, const ILVector3D &e0, const ILVector3D &e1, const ILVector3D &v0, const ILVector3D &v1, const ILVector3D &v2, double &t0_a, double &t1_a, double &t0_b, double &t1_b);
bool CalcCrossEdge(const ILVector3D &start, const ILVector3D &e0, const ILVector3D &e1, const ILVector3D &v0, const ILVector3D &v1, const ILVector3D &v2, ILVector3D& ce_a, ILVector3D& ce_b);

void CalcCoefficientsOfImplicitFunction1D(double (*phi)(double), vector<double>& constraints, vector<double>& heights, vector<double>& weight, double& p0, double& p1);
void NormalizeTo1x1x1Box(ILPolygonModel& poly);
bool HasLoopInStroke(vector<CPoint> stroke);
bool Solve2x2Linear(const double m11, const double m12, const double m21, const double m22, const double b1, const double b2, double& x1, double& x2);
void StrokeSmoothOne(vector<CPoint>& stroke);
void StrokeReplotEqualInterval(vector<CPoint>& stroke, int ndiv);
void Bresenham(const CPoint p1, const CPoint p2, vector<CPoint>& plist);
bool GetIntersectionLinePlane(const ILVector3D& lpos, const ILVector3D& lori, const ILVector3D& ppos, const ILVector3D& pbase0, const ILVector3D& pbase1, double& lt, double& pt0, double& pt1);
template<class T> void SeedFill(ILOGL::CFrameBuf<T>& pbuf, int cx, int cy, T val) {
	if (*pbuf.GetPixelp(cx, cy) == val) return;
	T valOld = *pbuf.GetPixelp(cx, cy);
	list<pair<int, int> > plist;
	plist.push_back(pair<int, int>(cx, cy));
	while(!plist.empty()) {
		pair<int, int> xy = plist.back();
		plist.pop_back();
		int x = xy.first;
		int y = xy.second;
		*pbuf.GetPixelp(x, y) = val;
		if (x > 0 && *pbuf.GetPixelp(x-1, y) == valOld) plist.push_back(pair<int, int>(x-1, y));
		if (y > 0 && *pbuf.GetPixelp(x, y-1) == valOld) plist.push_back(pair<int, int>(x, y-1));
		if (x < pbuf.Width() -1 && *pbuf.GetPixelp(x+1, y) == valOld) plist.push_back(pair<int, int>(x+1, y));
		if (y < pbuf.Height()-1 && *pbuf.GetPixelp(x, y+1) == valOld) plist.push_back(pair<int, int>(x, y+1));
	}
}

template<class T> void SeedFillScanLine(ILOGL::CFrameBuf<T>& pbuf, int cx, int cy, T val) {
	if (*pbuf.GetPixelp(cx, cy) == val) return;
	T valOld = *pbuf.GetPixelp(cx, cy);
	list<CPoint> plist;
	plist.push_back(CPoint(cx, cy));
	while(!plist.empty()) {
		CPoint p = plist.back();
		plist.pop_back();
		int xr, xl;
		*pbuf.GetPixelp(p.x, p.y) = val;
		for (xr = p.x + 1; xr < pbuf.Width(); ++xr) {
			if (*pbuf.GetPixelp(xr, p.y) != valOld) {
				xr--;
				break;
			}
			*pbuf.GetPixelp(xr, p.y) = val;
		}
		if (xr == pbuf.Width()) xr--;
		for (xl = p.x - 1; xl >= 0          ; --xl) {
			if (*pbuf.GetPixelp(xl, p.y) != valOld) {
				xl++;
				break;
			}
			*pbuf.GetPixelp(xl, p.y) = val;
		}
		if (xl < 0) xl++;
//		fprintf(stderr, "xl=%d,xr=%d\n", xl, xr);
		if (p.y > 0) {
			for (int x = xl; x < xr; ++x) 
				if (*pbuf.GetPixelp(x, p.y-1) == valOld && *pbuf.GetPixelp(x+1, p.y-1) != valOld) {
//					fprintf(stderr, "hogee\n");
					plist.push_back(CPoint(x, p.y-1));
				}
			if (*pbuf.GetPixelp(xr, p.y-1) == valOld) {
//				fprintf(stderr, "hoge\n");
				plist.push_back(CPoint(xr, p.y-1));
			}
		}
		if (p.y < pbuf.Height() - 1) {
			for (int x = xl; x < xr; ++x) 
				if (*pbuf.GetPixelp(x, p.y+1) == valOld && *pbuf.GetPixelp(x+1, p.y+1) != valOld) {
//					fprintf(stderr, "mogee\n");
					plist.push_back(CPoint(x, p.y+1));
				}
			if (*pbuf.GetPixelp(xr, p.y+1) == valOld) {
//				fprintf(stderr, "moge\n");
				plist.push_back(CPoint(xr, p.y+1));
			}
		}
	}
}

struct ScanLineInfo {
	ScanLineInfo(int xl_, int xr_, int y_, int oy_) {
		xl = xl_;
		xr = xr_;
		y = y_;
		oy = oy_;
	}
	int xl;
	int xr;
	int y;
	int oy;
};

template<class T> void SeedFillScanLineFast(ILOGL::CFrameBuf<T>& pbuf, int cx, int cy, T val) {
	if (*pbuf.GetPixelp(cx, cy) == val) return;
	T valOld = *pbuf.GetPixelp(cx, cy);
	list<ScanLineInfo> stack;

	*pbuf.GetPixelp(cx, cy) = val;
	stack.push_back(ScanLineInfo(cx, cx, cy, -1));
	
	while(!stack.empty()) {
		ScanLineInfo p = stack.back();
		stack.pop_back();
		//���E�ɑ���
		int xl_, xr_;
		for (xl_ = p.xl - 1; xl_ >= 0; --xl_)
			if (*pbuf.GetPixelp(xl_, p.y) == valOld)
				*pbuf.GetPixelp(xl_, p.y) = val;
			else
				break;
		++xl_;
		for (xr_ = p.xr + 1; xr_ < pbuf.Width(); ++xr_)
			if (*pbuf.GetPixelp(xr_, p.y) == valOld)
				*pbuf.GetPixelp(xr_, p.y) = val;
			else
				break;
		--xr_;
		
		bool flag;
		//��(up)�̃��C���𑖍�
		{
			int xu;
			int xlu, xru;
			int yu = p.y - 1;
			flag = false;
			for (xu = xl_; ; ++xu) {
				if (yu == p.oy && xu >= p.xl - 1 && xu <= p.xr + 1) xu = p.xr + 2;
				if (xu > xr_) break;
				if (*pbuf.GetPixelp(xu, yu) == valOld) {
					*pbuf.GetPixelp(xu, yu) = val;
					if (!flag) {
						xlu = xu;
						flag = true;
					} else if (xu == xr_) {
						stack.push_back(ScanLineInfo(xlu, xu, yu, p.y));
						break;
					}
				} else if (flag && *pbuf.GetPixelp(xu, yu) != valOld) {
					xru = xu - 1;
					flag = false;
					stack.push_back(ScanLineInfo(xlu, xru, yu, p.y));
				}
			}
		}
		
		//��(down)�̃��C���𑖍�
		{
			int xd;
			int xld, xrd;
			int yd = p.y + 1;
			flag = false;
			for (xd = xl_; ; ++xd) {
				if (yd == p.oy && xd >= p.xl - 1 && xd <= p.xr + 1) xd = p.xr + 2;
				if (xd > xr_) break;
				if (*pbuf.GetPixelp(xd, yd) == valOld) {
					*pbuf.GetPixelp(xd, yd) = val;
					if (!flag) {
						xld = xd;
						flag = true;
					} else if (xd == xr_) {
						stack.push_back(ScanLineInfo(xld, xd, yd, p.y));
						break;
					}
				} else if (flag && *pbuf.GetPixelp(xd, yd) != valOld) {
					xrd = xd - 1;
					flag = false;
					stack.push_back(ScanLineInfo(xld, xrd, yd, p.y));
				}
		}
		}
	}
}

bool IsRightSideOfStroke(CPoint& p, vector<CPoint>& plist);
