/*
	ILMath.h
	Copyright (C) 2003, Shigeru Owada

	Defined classes :
	ILVector3D
	ILMatrix16
	CSparseMatrix

    Defined C Functions :
	double sin(const ILVector3D& vec1,const ILVector3D& vec2,bool* ErrorOccured=0) ;
	double cos(const ILVector3D& vec1,const ILVector3D& vec2,bool* ErrorOccured=0) ;
	double angle(ILVector3D& v1,ILVector3D& v2) ;
	bool LineClipByBox( double pos[3],double ori[3],ILVector3D box[2]
		,double& result_t1,double& result_t2 ) ;
	bool LineClipByCylinder( double pos[3],double ori[3],double cyl_rx,double cyl_ry,double cyl_zlen
		,double& result_t1,double& result_t2 ) ;
	vector<double>& operator*= (vector<double>& vec,const double scalar ) ;
	vector<double> operator* ( const double scalar,const vector<double>& vec ) ;
	vector<double> operator* ( const vector<double>& vec,const double scalar ) ;
	double operator* (const vector<double>& vec1,const vector<double>& vec2 ) ;		// Dot product
	vector<double> operator+ (const vector<double>& vec1,const vector<double>& vec2 ) ;
	vector<double> operator- ( const vector<double> vec ) ;
	vector<double> operator- (const vector<double>& vec1,const vector<double>& vec2 ) ;
	double operator* ( CSparseMatrix::Row& vec1,CSparseMatrix::Row& vec2 ) ;

    // vector operations
	template<class T> T DotProduct( const T* vec1,const T* vec2,int dim ) ;
	template<class T> HouseholderTransform(T* vec,int dim) ; // used in 

	//square matrix functions
	//num order is 
	//|  0    1     2   ...  dim-1  |
	//| dim dim+1 dim+2 ... 2*dim-1 |
	//|  :    :     :   ...    :    |
	//|                    dim*dim-1|
	//(probably ^^;
	template <class T> bool SquareMat_CalcInvMatrix( T* src,T* targ,int dim ) ;
	template <class T> void SquareMat_MultMatrix( T* src,T* src2,T* targ,int dim ) ;
	template <class T> void SquareMat_MultVec( T* srcmat,T* srcvec,T* targvec,int dim ) ;
	template <class T> void SquareMat_Transpose( T* srcmat,T* targmat,int dim ) ;
	template <class T>  T SquareMat_SolveLinearByLU_Sub_LUDecomposition( int n,T* A,int* ip) ;
	template <class T>  T* SquareMat_SolveLinearByLU( T* A,T* b,int dim) ;
	template <class T> bool SquareMat_DumpSquareMatrix(T* mat,int dim,char* fname) ;
	template <class T> bool DumpVec(T* vec,int dim,char* fname) ;
	// CalcDeterminant �͍ċA������̂ŁA�e���v���[�g�ɂ͂��Ȃ��B
	double SquareMat_CalcDeterminant( double* src,int dim ) ;
	float SquareMat_CalcDeterminant( float* src,int dim ) ;
	
	// tridiagonization.
	// mat : should be square and symmetric.    ��original matrix
	// mat is overwritten by "P" matrix. ( P * mat * Pt = tridiagonal matrix. : Pt = transpose of P)
	// diagonal element is stored in vec1 and second diagonal is stored in vec2 (therefore, length of vec2 is dim-1.)
	template<class T> void Tridiagonize( T* mat,int dim,T* vec1,T* vec2 ) ;

	// Eigen vectors and values
	// mat : should be square and symmetric.
	// eigen vectors are obtained as row vectors of mat
	template <class T> void CalcEigens( T* mat , T* outVec_EigenValues , int dim ,const int MAXITER = 10 ) ;
	

	// PCA (Principal Component Analysis)  PCA essentially computes eigenvectors of covariance matrix of input.
	// Usage is written later.
	// DataPoints : matrix with dataNum*dataDim elements
	// out_cent   : vector with dataDim elements. each PCs is emanating from this point.
	// out_PCs    : matrix with dataDim*dataDim elements. these are principal components.
	// DotProduct( &(DataPoints[i*dataDim]-out_cent),&out_PCs[j*dataDim],dataDim ) returns jth component of data_i.
	template <class T> void PCA( T* DataPoints , int dataNum , int dataDim , T* out_PCs ,T* out_cent=0 ) ;


	// Poisson equation solver. Fast solution requires including/linking UMFPACK by
	// #define ILMATH_ENABLE_UMFPACK_MATRIX_SOLVER.
	// Find x that minimizes ��|��x - v|^2 with constraints.
	// constraints_and_region elements... -DBL_MAX:Outside DBL_MAX:Inside Otherwise: boundary condition
	typedef double vec2d[2] ;
	void SolvePoisson( CImage<vec2d>& v , CImage<double>& constraints_and_region , CImage<double>& result ) ;


	// list <-> vector conversion
	template <class T> void copy(vector<T>& src,list<T>& targ) ;
	template <class T> void copy(list<T>& src,vector<T>& targ) ;
	
	Defined Macros :
    #define BETWEEN(t1,t2,num)	( (t1)<(t2)?((t1)<=(num) && (num)<=(t2)):((t2)<=(num) && (num)<=(t1)))
	#define CLIPUCHAR(a)	((a)<0?0:((a)>255?255:(unsigned char)(a)))

	May contain bugs. Please send comments to: Shigeru Ohwada (ohwada@is.s.u-tokyo.ac.jp) !
*/
/*
CSparseMatrix usage
CSparseMatrix : non-square sparse matrix library.

Usage example 1:
  See CSparseMatrix::operator*(),SolveLinearSystem(),CalcNullSpace()

Example 2:

class CSNSTest {
public:
	CSNSTest(){

		CSparseMatrix mat,tmat ;
		const int rows = 1 ;
		const int columns = 3 ;
		mat.Allocate( rows,columns ) ;
		double matsrc[rows][columns] = {
			{1,1,-1},
		} ;
		for( int i=0;i<rows;i++ )
			for( int j=0;j<columns;j++ )
				if( matsrc[i][j] != 0 )
					mat.SetElement( i,j,matsrc[i][j] ) ;

		mat.SetChanged() ;

		vector< vector<double> > result ;
		mat.CalcNullSpace( result ) ;
		
		TRACE("Null space:\n") ;
		for( int ans_id=0;ans_id < result.size();ans_id++ ){
			vector<double>& ans = result[ans_id] ;
			for( int _x=0;_x<ans.size();_x++ ){
				TRACE("%f\t",ans[_x]) ;
			}
			TRACE("\n") ;
		}
		TRACE("\n") ;
	}
} snstest ;

Example 3 :

class CTest {
public:
	CTest(){
		double mat1_C[4][6] = {
			{ 0,1,0,0,1,0 },
			{ 0,0,1,0,0,1 },
			{ 0,0,0,1,1,1 },
			{ 1,1,1,1,1,1 },
		} ;
		CSparseMatrix mat1 ;
		mat1.ConvertFromCArray( (double*)mat1_C,4,6 ) ;
		mat1.TraceMatrix() ;
		TRACE("---------\n") ;

		CSparseMatrix mat2 ;
		if( !mat1.GetPseudoInverseMatrix( mat2 ) ){
			TRACE("Failed to calculate inverse!\n") ;
		}
		mat2.TraceMatrix() ;
		TRACE("---------\n") ;
		
		CSparseMatrix result ;
		result = mat1 * mat2 ;
		result.TraceMatrix() ;
		TRACE("---------\n") ;
	}
} m_Test ;

*/

/*
usage of tridiagonal
	const int dim=4 ;
	double mat[dim][dim] = {
		{7,5,9,3},
		{0,2,3,5},
		{0,0,3,4},
		{0,0,0,8}
	} ;
	// make symmetric matrix
	for( int i=0;i<dim;++i ) for( int j=0;j<i;++j ){
		mat[i][j] = mat[j][i] ;
	}
	TRACE("\ninput\n") ;
	for( int i=0;i<dim;++i ){
		for( int j=0;j<dim;++j ){
			TRACE("\t%f",mat[i][j]) ;
		}
		TRACE("\n") ;
	}
	
	double P[dim][dim] ;
	memcpy( P,mat,sizeof(double)*dim*dim ) ;
	double d[dim],e[dim-1] ;
	Tridiagonize<double>( (double*)P,dim,d,e ) ;
	double Pt[dim][dim] ;
	for( int i=0;i<dim;++i ) for( int j=0;j<dim;++j ){
		Pt[i][j] = P[j][i] ;
	}
	
	double tmpMat1[dim*dim] ;
	double tmpMat2[dim*dim] ;
	SquareMat_MultMatrix<double>((double*)P,(double*)mat,tmpMat1,dim) ;
	SquareMat_MultMatrix<double>(tmpMat1,(double*)Pt,tmpMat2,dim) ;
	
	TRACE("Result\n") ;
	for( int i=0;i<dim;++i ){
		for( int j=0;j<dim;++j ){
			TRACE("\t%f",tmpMat2[i*dim+j]) ;
		}
		TRACE("\n") ;
	}
	TRACE("diagonal\n") ;
	for( int i=0;i<dim;++i ){
		TRACE("\t%f",d[i]) ;
	}
	TRACE("\nnext diagonal\n") ;
	for( int i=0;i<dim-1;++i ){
		TRACE("\t%f",e[i]) ;
	}
	TRACE("\n") ;
*/
/*
usage of CalcEigens
	const int dim=4 ;
	double mat[dim][dim] = {
		{7,20,8,11},
		{0,9992,12,5},
		{0,0,0,12},
		{0,0,0,228},
	} ;
	// make symmetric matrix
	for( int i=0;i<dim;++i ) for( int j=0;j<i;++j ){
		mat[i][j] = mat[j][i] ;
	}
	double eigenvecs[dim][dim] ;
	memcpy( eigenvecs,mat,sizeof(double)*16 ) ;
	double eigs[dim] ;
	
	CalcEigens<double>( (double*)eigenvecs,eigs,dim ) ;
	
	TRACE("Eigens:\n") ;
	double tmpvec[dim] ;
	for( int i=0;i<dim;++i ){
		SquareMat_MultVec<double>( (double*)mat,eigenvecs[i],tmpvec,dim ) ;
		TRACE("Eigen |(%f,%f,%f,%f):%f|. mat*vec/eigenval = (%f,%f,%f,%f)\n",
			eigenvecs[i][0],eigenvecs[i][1],eigenvecs[i][2],eigenvecs[i][3],eigs[i],
			tmpvec[0]/eigs[i],tmpvec[1]/eigs[i],tmpvec[2]/eigs[i],tmpvec[3]/eigs[i] ) ;
	}
*/
/*
usage of PCA
	const int dataNum = 7 ;
	const int dataDim = 3 ;
	
	double DataPoints[dataNum][dataDim]={
		{10,10,10}, 
		{9,10,11}, 
		{8,7,8}, 
		{60,61,62}, 
		{18,19,18},
		{-100,-100,-101}, 
		{-23,-24,-20}, 
	} ;
#if 1
	double shift[dataDim] = {100.23,100.23,100.23} ;
	for( int i=0;i<dataNum;++i ){
		for( int j=0;j<dataDim;++j )	DataPoints[i][j] += shift[j] ;
	}
#endif
	double cent[dataDim] ;
	double PCs[3][3] ;
	
	PCA<double>( (double*)DataPoints,dataNum,dataDim,(double*)PCs,cent ) ;
	
	TRACE("\n") ;
	for( int i=0;i<dataDim;++i ){
		TRACE("PC%d\t:",i) ;
		for( int j=0;j<dataDim;++j ){
			TRACE("%f ",PCs[i][j] ) ;
		}
		TRACE("\n") ;
	}
	for( int i=0;i<dataDim-1;++i ) for( int j=i+1;j<dataDim;++j ){
		TRACE("DotProduct PC%d * PC%d = %f\n",i,j,DotProduct<double>(PCs[i],PCs[j],dataDim) ) ;
	}
	TRACE("\n") ;
*/
/*
usage of fft :

// FFT. n should be power of 2. negative number indicates inverse FFT.
// x : real part(in/out)
// y : imaginary part(in/out)
template <class T> int fft(int n,T* x,T* y) ;

	int i ;
	const int n=64;
	// x1,y1 = source
	// x2,y2 = freq
	// x3,y3 = recovered source from x2,y2
	static float x1[n],y1[n],x2[n],y2[n],x3[n],y3[n] ;
	for( i=0;i<n;i++){
		x1[i]=x2[i]=6*cos(6*M_PI*i/n)+4*sin(18*M_PI*i/n) ;
		y1[i]=y2[i]=0 ;
	}
	fft<float>(n,x2,y2) ;
//	if( fft<float>(n,x2,y2)) return -1 ;
	for(i=0;i<n;i++){
		x3[i]=x2[i] ; y3[i]=y2[i] ;
	}
	fft<float>(-n,x3,y3) ;
//	if( fft<float>(-n,x3,y3)) return -1 ;

	for( i=0;i<n;++i ){
		TRACE("%4d | %6.3f %6.3f |"
			" %6.3f %6.3f | %6.3f %6.3f\n",
			i,x1[i],y1[i],x2[i],y2[i],x3[i],y3[i]) ;
	}
*/

#ifndef __ILMATH_H_INCLUDED__
#define __ILMATH_H_INCLUDED__
#pragma warning (disable:4786)

#include <memory.h>
#include <cfloat>
#include <cstdio>
#include <cstdlib>
#include <cmath>
#include <cassert>

//#define ILMATH_ENABLE_UMFPACK_MATRIX_SOLVER

#include <vector>
#include <list>
using namespace std ;
#define for if(0);else for

#ifndef VSN
#define VSN 0.00000000001
#endif
#ifndef MIN3
#define MIN3(a,b,c)	((a)<(b)?((a)<(c)?(a):(c)):((b)<(c)?(b):(c)))
#define MAX3(a,b,c)	((a)>(b)?((a)>(c)?(a):(c)):((b)>(c)?(b):(c)))
#define MIN3ID(a,b,c)	((a)<(b)?((a)<(c)?(0):(2)):((b)<(c)?(1):(2)))
#define MAX3ID(a,b,c)	((a)>(b)?((a)>(c)?(0):(2)):((b)>(c)?(1):(2)))
template <class T> T max3(T a,T b,T c){return MAX3(a,b,c);}
template <class T> int max3id(T a,T b,T c){return MAX3ID(a,b,c);}
template <class T> T min3(T a,T b,T c){return MIN3(a,b,c);}
template <class T> int min3id(T a,T b,T c){return MIN3ID(a,b,c);}
#endif
#ifndef MIN
#define MIN(a,b)	((a)<(b)?(a):(b))
#define MAX(a,b)	((a)>(b)?(a):(b))
#endif //MIN

#ifndef CLIPUCHAR
#define CLIPUCHAR(a)	((a)<0?0:((a)>255?255:(unsigned char)(a)))
inline unsigned char ClipUchar(double a){ return CLIPUCHAR(a); }
inline unsigned char ClipUchar(float a){ return CLIPUCHAR(a); }
inline unsigned char ClipUchar(int a){ return CLIPUCHAR(a); }
inline unsigned char ClipUchar(unsigned int a){ return CLIPUCHAR(a); }
#endif

#ifndef M_PI
#define M_PI 3.14159265358979
#endif


#ifndef _WIN32
class CRect {
public:
	int top,bottom,right,left;
};
class CPoint {
public:
	CPoint(int cx=0,int cy=0):x(cx),y(cy){}
	int x,y;
};
#endif		//_WIN32


class ILMatrix16;

class ILVector3D {
public:
	//public properties
	double data[3];
	double x(){return data[0];}
	double y(){return data[1];}
	double z(){return data[2];}
	double& operator[](int id){ return data[id]; }
	double operator[](int id) const { return data[id]; }
	operator double*(){ return data; }

	//Error check
	bool operator!(){ return m_bError ; }
	operator void*() { return m_bError?0:this; }
	void Trace(){
#ifdef TRACE_EXIST
		TRACE("%f %f %f\n",data[0],data[1],data[2]) ;
#else
		fprintf(stderr,"%f %f %f\n",data[0],data[1],data[2]) ;
#endif
	}
public:
	bool m_bError ;
	
public:
	//Constructors
	ILVector3D(double f1=0.0f,double f2=0.0f,double f3=0.0f):m_bError(false){
		data[0]=f1;data[1]=f2;data[2]=f3;
	}
	ILVector3D(double f[3]):m_bError(false){
		if( f ){memcpy(data,f,sizeof(double)*3);}
		else m_bError = true ;
	}
	
/*	inline ILVector3D& operator=(ILVector3D& v){
		memcpy( data,v.data,sizeof(double)*3 ) ;
		return *this ;
	}*/

public:	
	inline void Set(double f1=0.0f,double f2=0.0f,double f3=0.0f){
		data[0]=f1;data[1]=f2;data[2]=f3;
	}
	inline void Set(double* f){
		memcpy(data,f,sizeof(double)*3) ;
	}
	inline void Set(const ILVector3D &v)
	{
		memcpy(data, v.data,sizeof(double)*3);
	}
	// methods
	inline bool Normalize_Self(){
		double len=Length();
		if(len==0.0f){
			m_bError = true ;
			return false;
		}
		data[0]/=len;
		data[1]/=len;
		data[2]/=len;
		return true;
	}
	inline ILVector3D Normalize(){
		double len=Length();
		return ILVector3D(
			data[0]/=len,data[1]/=len,data[2]/=len) ;
	}
	inline double Length_Square() const {
		return data[0]*data[0]+data[1]*data[1]+data[2]*data[2] ;
	}
	inline double Length() const {
		return sqrt(Length_Square());
	}
public:
	// operators
	inline ILVector3D operator=(const ILVector3D& vec1) const {
		memcpy( (void*)data,vec1.data,sizeof(double)*3 ) ;
		return *this ;
	}
	//add
	inline ILVector3D operator+(const ILVector3D& vec1) const {
		return ILVector3D(
			data[0]+vec1.data[0],
			data[1]+vec1.data[1],
			data[2]+vec1.data[2]);
	}
	inline ILVector3D& operator+=(const ILVector3D& vec1){
		data[0]+=vec1.data[0];
		data[1]+=vec1.data[1];
		data[2]+=vec1.data[2];
		return *this ;
	}
	//subtract
	inline ILVector3D operator-(const ILVector3D& vec1) const {
		return ILVector3D(
			data[0]-vec1.data[0],
			data[1]-vec1.data[1],
			data[2]-vec1.data[2]);
	}
	inline ILVector3D& operator-=(const ILVector3D& vec1){
		data[0]-=vec1.data[0];
		data[1]-=vec1.data[1];
		data[2]-=vec1.data[2];
		return *this ;
	}
	// single term operator
	inline ILVector3D operator-() const {
		return (-1)**this ;
	}
	//multiply
	inline ILVector3D operator*(double f) const{
		return ILVector3D(f*data[0],
			f*data[1],f*data[2]);
	}
	inline friend ILVector3D operator*(double f,const ILVector3D& vec1){
		return vec1*f;
	}
	inline ILVector3D& operator*=(double f){
		data[0]*=f;
		data[1]*=f;
		data[2]*=f;
		return *this ;
	}
	//divide
	inline ILVector3D operator/(double f) const{
		ILVector3D result ;
		if( f==0 ){
			result.m_bError = true ;
		} else
			result.Set( data[0]/f,data[1]/f,data[2]/f);
		return result ;
	}
	inline friend ILVector3D operator/(double f,const ILVector3D& vec1){
		return vec1/f;
	}
	inline ILVector3D& operator/=(double f){
		if( f==0){
			m_bError=true ;
			return *this;
		}
		data[0]/=f;
		data[1]/=f;
		data[2]/=f;
		return *this ;
	}
	//dot product
	inline double operator*(const ILVector3D& vec1) const {
		return data[0]*vec1.data[0]+data[1]*vec1.data[1]+data[2]*vec1.data[2];
	}
	//equality
	inline bool operator==(const ILVector3D& vec1) const {
		return data[0] == vec1.data[0] && data[1] == vec1.data[1] && data[2] == vec1.data[2];
	}
	inline bool operator!=(const ILVector3D& vec1) const {
		return !(*this == vec1);
	}
	//cross product
	inline ILVector3D operator^(const ILVector3D& vec1) const {
		return ILVector3D(
			data[1]*vec1.data[2] - data[2]*vec1.data[1],
			data[2]*vec1.data[0] - data[0]*vec1.data[2],
			data[0]*vec1.data[1] - data[1]*vec1.data[0]);
	}
	inline ILVector3D& operator^=(const ILVector3D& vec1){
		double res[3];
		res[0]=data[1]*vec1.data[2]-data[2]*vec1.data[1];
		res[1]=data[2]*vec1.data[0]-data[0]*vec1.data[2];
		res[2]=data[0]*vec1.data[1]-data[1]*vec1.data[0];
		data[0]=res[0];data[1]=res[1];data[2]=res[2];
		return *this ;
	}

	inline ILVector3D RotateAroundVector(ILVector3D& center_vec,double angle){
		ILVector3D cent = center_vec ;
		cent.Normalize() ;
		double x = cent.data[0],y = cent.data[1],z = cent.data[2] ;
		double uut[3][3] = {{x*x,x*y,x*z},{y*x,y*y,y*z},{z*x,z*y,z*z}} ;
		double S[3][3] = {{0,-z,y},{z,0,-x},{-y,x,0}} ;
		const static double I[3][3] = {{1,0,0},{0,1,0},{0,0,1}} ;

		double s = sin(angle) ;
		double c = cos(angle) ;

		double conv_mat[3][3] ;
		for( int i=0;i<3;i++ )for( int j=0;j<3;j++ )
			conv_mat[i][j] = uut[i][j] + c * (I[i][j]-uut[i][j]) + s * S[i][j] ;

		double cx = data[0],cy = data[1],cz = data[2] ;
		return ILVector3D(
			conv_mat[0][0] * cx + conv_mat[0][1] * cy + conv_mat[0][2] * cz ,
			conv_mat[1][0] * cx + conv_mat[1][1] * cy + conv_mat[1][2] * cz ,
			conv_mat[2][0] * cx + conv_mat[2][1] * cy + conv_mat[2][2] * cz );
	}
	
	static inline ILVector3D RotateAroundVector(ILVector3D& src_vec,ILVector3D& center_vec,double angle){
		return src_vec.RotateAroundVector(center_vec,angle) ;
	}


	inline void SetSubtract(const ILVector3D& v1, const ILVector3D& v2){
		data[0] = v1.data[0] - v2.data[0];
		data[1] = v1.data[1] - v2.data[1];
		data[2] = v1.data[2] - v2.data[2];
	}

	
	inline void SetAddition(const ILVector3D& v1, const ILVector3D& v2){
		data[0] = v1.data[0] + v2.data[0];
		data[1] = v1.data[1] + v2.data[1];
		data[2] = v1.data[2] + v2.data[2];
	}


	inline void Set_CoefMultVec(double coef, const ILVector3D& V){
		data[0] = coef * V.data[0];
		data[1] = coef * V.data[1];
		data[2] = coef * V.data[2];
	}

	inline void Add_CoefMultVec(double coef, const ILVector3D& V){
		data[0] += coef * V.data[0];
		data[1] += coef * V.data[1];
		data[2] += coef * V.data[2];
	}
/*
	inline void SetMatMultVec(const ILMatrix16& M, const ILVector3D& v)
	{
		data[0] = M.data[0] * v.data[0] + M.data[4] * v.data[1] + M.data[8]  * v.data[2] + M.data[12];
	    data[1] = M.data[1] * v.data[0] + M.data[5] * v.data[1] + M.data[9]  * v.data[2] + M.data[13];
		data[2] = M.data[2] * v.data[0] + M.data[6] * v.data[1] + M.data[10] * v.data[2] + M.data[14];
	}
*/
	
	inline void SetCrossProd(const ILVector3D& v1, const ILVector3D& v2)
	{
		data[0] = v1.data[1] * v2.data[2] - v1.data[2] * v2.data[1];
		data[1] = v1.data[2] * v2.data[0] - v1.data[0] * v2.data[2];
		data[2] = v1.data[0] * v2.data[1] - v1.data[1] * v2.data[0];
	}

	inline void AddCrossProd(const ILVector3D& v1, const ILVector3D& v2)
	{
		data[0] += v1.data[1] * v2.data[2] - v1.data[2] * v2.data[1];
		data[1] += v1.data[2] * v2.data[0] - v1.data[0] * v2.data[2];
		data[2] += v1.data[0] * v2.data[1] - v1.data[1] * v2.data[0];
	}

	inline void AddCrossProdWithCoef(double c, const ILVector3D& v1, const ILVector3D& v2)
	{
		data[0] += c* (v1.data[1] * v2.data[2] - v1.data[2] * v2.data[1]);
		data[1] += c* (v1.data[2] * v2.data[0] - v1.data[0] * v2.data[2]);
		data[2] += c* (v1.data[0] * v2.data[1] - v1.data[1] * v2.data[0]);
	}
	
	inline void SetGravityCenter(const ILVector3D &v0, const  ILVector3D &v1, const ILVector3D &v2){
		data[0] = ( v0.data[0] + v1.data[0] + v2.data[0]) / 3.0;
		data[1] = ( v0.data[1] + v1.data[1] + v2.data[1]) / 3.0;
		data[2] = ( v0.data[2] + v1.data[2] + v2.data[2]) / 3.0;
	}
	
	inline void Set_V0subtV1_outmult_V2subtV3(const ILVector3D &X0,  const ILVector3D &X1 , const ILVector3D &X2, const ILVector3D &X3)
	{

	}
	
};

inline double sin(const ILVector3D& vec1,const ILVector3D& vec2,bool* ErrorOccured=0){
	double l1=vec1.Length();
	double l2=vec2.Length();
	if(l1*l2==0){
		if( ErrorOccured ) *ErrorOccured = true ;
		return 0;
	}
	if( ErrorOccured ) *ErrorOccured = false ;
	return (vec1^vec2).Length()/(l1*l2);
}

inline double cos(const ILVector3D& vec1,const ILVector3D& vec2,bool* ErrorOccured=0){
	double l1=vec1.Length();
	double l2=vec2.Length();
	if(l1*l2==0){
		if( ErrorOccured ) *ErrorOccured = true ;
		return 0;
	}
	if( ErrorOccured ) *ErrorOccured = false ;
	return (vec1*vec2)/(l1*l2);
}

inline double angle(ILVector3D& v1,ILVector3D& v2){
	return atan2( (v1^v2).Length(),v1*v2 ) ;
}

// solve t for linepos + t * lineori which gives min( | (linepos + t * lineori) - point | )
inline double GetClosestLinePointToPoint(ILVector3D linepos,ILVector3D lineori,ILVector3D point){
	return (point-linepos)*lineori / lineori.Length_Square() ;
}

// solve t for linepos + t * lineori which gives min( | (linepos + t * lineori) - point | )
inline double GetIntersectionLinePlane(ILVector3D linepos,ILVector3D lineori
									   ,ILVector3D planepos,ILVector3D planenorm){
	ILVector3D qb = lineori*planenorm ;
	if( qb[0]==0 && qb[1]==0 && qb[2]==0 )	return DBL_MAX ;
	ILVector3D apb = (planepos-linepos)*planenorm ;
	ILVector3D qb_abs(fabs(qb[0]),fabs(qb[1]),fabs(qb[2])) ;
	int mmid = MAX3ID(qb_abs[0],qb_abs[1],qb_abs[2]) ;
	return apb[mmid]/qb[mmid] ;
}


/*
data[16] spec (Same as OpenGL)

matrix =
	data[0]  data[4]  data[8]  data[12]
	data[1]  data[5]  data[9]  data[13]
	data[2]  data[6]  data[10] data[14]
	data[3]  data[7]  data[11] data[15]
*/

class ILMatrix16 {
public:
	double data[16];
public :
	ILMatrix16(){SetIdentity();}
	ILMatrix16(double* cmat){Set(cmat);}
	ILMatrix16& operator=(const ILMatrix16 src){memcpy(data,src.data,sizeof(double)*16);return*this;}
	ILMatrix16& operator=(const double* src){memcpy(data,src,sizeof(double)*16);return*this;}
	void Set(double* cmat){memcpy(data,cmat,sizeof(double)*16);}
	void Set(float* cmat){for( int i=0;i<16;++i ) data[i]=cmat[i];}
	ILMatrix16 GetInvMatrix() ;
	double& operator[](int i){ return data[i]; }
	operator double*(){ return data; }
	bool GetInvMatrix_Self() ;
	ILMatrix16 GetTransposeMatrix(){
		static const int map_mat[16]={
		0,4,8,12 ,1,5,9,13 ,2,6,10,14 ,3,7,11,15 } ;
		ILMatrix16 ret ; for( int i=0;i<16;i++ )ret[i]=data[map_mat[i]]; return ret ; }
	void SetIdentity();
	void SetZeroMatrix(){memset(data,0,sizeof(double)*16);}
	void SetAsTranslateMatrix(ILVector3D& trans){SetIdentity();memcpy(&data[12],trans.data,sizeof(double)*3);}
	void SetAsZoomMatrix(double xzoom,double yzoom,double zzoom){
		memset(data,0,sizeof(double)*16);data[0]=xzoom;data[5]=yzoom;data[10]=zzoom;data[15]=1;}
	void SetAsRotateX(double angle);
	void SetAsRotateY(double angle);
	void SetAsRotateZ(double angle);
	bool RotateAlongArbitraryAxis(const ILVector3D& axis
		,double cosangle,double sinangle);
	bool RotateAlongArbitraryAxis(const ILVector3D& axis
		,double angle){
		return RotateAlongArbitraryAxis(axis
			,(double)cos(angle),(double)sin(angle));
	}
	bool RotateAlongArbitraryAxis(double x,double y,double z
		,double cosangle,double sinangle){
		return RotateAlongArbitraryAxis(ILVector3D(x,y,z)
			,cosangle,sinangle);
	}
	bool RotateAlongArbitraryAxis(double x,double y,double z,double angle){
		return RotateAlongArbitraryAxis(
			ILVector3D(x,y,z),angle);
	}
	void RotateAlongArbitraryAxis_WithShift(
		ILVector3D& axis_ori,ILVector3D& axis_pos,double angle){
		ILMatrix16 mat1,rot,mat2 ;
		mat1[12] = -axis_pos[0] ;
		mat1[13] = -axis_pos[1] ;
		mat1[14] = -axis_pos[2] ;
		mat2[12] = axis_pos[0] ;
		mat2[13] = axis_pos[1] ;
		mat2[14] = axis_pos[2] ;

		rot.RotateAlongArbitraryAxis(axis_ori,angle) ;

		*this = mat2 * rot * mat1 ;
	}
	bool RotateFromVectorToVector(ILVector3D src,ILVector3D targ){
		src.Normalize_Self() ; targ.Normalize_Self() ;
		ILVector3D cp = src^targ ;
		return RotateAlongArbitraryAxis(cp,src*targ,cp.Length()) ;
	}
	//cx,cy,cx+dx,cy+dy is naturally between -1 and 1.
	bool VirtualTrackBall(const double cx,const double cy
		,const double dx,const double dy);
	void operator*=(ILMatrix16& mat){
		double tmp[16];
		memset(tmp,0,sizeof(double)*16) ;
		int i,j,k;
		for(i=0;i<4;i++)for(j=0;j<4;j++)for(k=0;k<4;k++)
			tmp[j*4+i]+=data[k*4+i]*mat.data[j*4+k];

		memcpy( data,tmp,sizeof(double)*16 ) ;
	}
	ILMatrix16 operator*(const ILMatrix16& mat){
		ILMatrix16 tmp ;
		memset(tmp.data,0,sizeof(double)*16) ;
		for(int i=0;i<4;i++)for(int j=0;j<4;j++)for(int k=0;k<4;k++)
			tmp[i*4+j]+=(*this)[k*4+j]*mat.data[i*4+k];
//		memcpy(data,tmp.data,sizeof(double)*16) ;
		return tmp ;
	}
	void operator*=(const double mat[16]){
		double tmp[16];
		int i,j,k;
		for(i=0;i<16;i++)
			tmp[i]=0.0f;
		
		for(i=0;i<4;i++)for(j=0;j<4;j++)for(k=0;k<4;k++)
			tmp[i*4+j]+=data[k*4+j]*mat[i*4+k];

		memcpy( data,tmp,sizeof(double)*16 ) ;
	}
	ILVector3D operator*(const ILVector3D& v){
		return ILVector3D(
			data[0]*v.data[0]+data[4]*v.data[1]+data[8]*v.data[2]+data[12],
			data[1]*v.data[0]+data[5]*v.data[1]+data[9]*v.data[2]+data[13],
			data[2]*v.data[0]+data[6]*v.data[1]+data[10]*v.data[2]+data[14] ) ;
	}
	ILMatrix16 operator+(const ILMatrix16& mat){
		ILMatrix16 tmp ;
		for(int i=0;i<16;i++)
			tmp[i]=(*this)[i]+mat.data[i];
		return tmp ;
	}
	void operator+=(ILMatrix16& mat){
		for(int i=0;i<16;i++)data[i]+=mat.data[i];
	}

public:
	// Decomposition methods

	// works only when the matrix is rotation matrix (probably)
	void GetRotCenterAxisAndAngle(ILVector3D& cent,double& angle) ;

	// Naive decomposition. may contain a bug.
	void DecomposeIntoRotZoomTranslate_byNaiveMethod(ILVector3D& rotAxis,double& rotAngle
		,double& zoomFactor,ILVector3D& translate) ;
	void ComposeFromRotZoomTranslate_byNaiveMethod(ILVector3D& rotAxis,double rotAngle
		,double zoomFactor,ILVector3D& translate){
		ILMatrix16 transMat , zoomMat , rotateMat ;
		transMat.SetAsTranslateMatrix(translate) ;
		zoomMat.SetAsZoomMatrix(zoomFactor,zoomFactor,zoomFactor) ;
		rotateMat.RotateAlongArbitraryAxis(rotAxis,rotAngle) ;
		*this = transMat * zoomMat * rotateMat ;
	}
		
	
	
	void Trace()
	
	{
		for( int i=0;i<4;i++ ){
			for( int j=0;j<4;j++ ){
				TRACE("%f ",data[j*4+i]) ;
			}
			TRACE("\n") ;
		}
	}


	/*
#ifdef TRACE_EXIST
	void Trace(){
		for( int i=0;i<4;i++ ){
			for( int j=0;j<4;j++ ){
				TRACE("%f ",data[j*4+i]) ;
			}
			TRACE("\n") ;
		}
	}
#else //TRACE_EXIST
	void Trace(){
		for( int i=0;i<4;i++ ){
			for( int j=0;j<4;j++ ){
				fprintf(stderr,"%f ",data[j*4+i]) ;
			}
			fprintf(stderr,"\n") ;
		}
	}
#endif //TRACE_EXIST
	*/
};





/*
data[9] spec (Same as OpenGL)
matrix =
	data[0]  data[3]  data[6]
	data[1]  data[4]  data[7]
	data[2]  data[5]  data[8] 
*/

class ILMatrix9 {
public:
	double data[9];


public :
	ILMatrix9(){SetIdentity();}
	ILMatrix9(double* cmat){Set(cmat);}
	ILMatrix9(double m11, double m12, double m13,
			  double m21, double m22, double m23,
			  double m31, double m32, double m33)
	{
		data[0] = m11;
		data[1] = m21;
		data[2] = m31;
		
		data[3] = m12;
		data[4] = m22;
		data[5] = m32;
		
		data[6] = m13;
		data[7] = m23;
		data[8] = m33;
	}
 inline static double calcDet9(const ILMatrix9 &Mat){
  return   + Mat.data[0] * Mat.data[4] * Mat.data[8] 
        + Mat.data[1] * Mat.data[5] * Mat.data[6] 
     + Mat.data[2] * Mat.data[3] * Mat.data[7] 
      
     - Mat.data[0] * Mat.data[5] * Mat.data[7] 
     - Mat.data[2] * Mat.data[4] * Mat.data[6] 
     - Mat.data[1] * Mat.data[3] * Mat.data[8];
 }
  inline double calcDet9(){
  return   + data[0] * data[4] * data[8] 
        + data[1] * data[5] * data[6] 
     + data[2] * data[3] * data[7] 
      
     - data[0] * data[5] * data[7] 
     - data[2] * data[4] * data[6] 
     - data[1] * data[3] * data[8];
 }

inline bool getInvertSelf(){
  double det = calcDet9();
  if(abs(det) < 0.0000001) return false;
  double detInv = 1.0 / det;
  double tmp[9];
  tmp[0] = detInv * ( data[4] * data[8] - data[7] * data[5]);
  tmp[1] = detInv * ( data[7] * data[2] - data[1] * data[8]);
  tmp[2] = detInv * ( data[1] * data[5] - data[4] * data[2]);

  tmp[3] = detInv * ( data[6] * data[5] - data[3] * data[8]);
  tmp[4] = detInv * ( data[0] * data[8] - data[6] * data[2]);
  tmp[5] = detInv * ( data[3] * data[2] - data[0] * data[5]);

  tmp[6] = detInv * ( data[3] * data[7] - data[6] * data[4]);
  tmp[7] = detInv * ( data[6] * data[1] - data[0] * data[7]);
  tmp[8] = detInv * ( data[0] * data[4] - data[3] * data[1]);
  memcpy(data,tmp,sizeof(double)*9);
  return true; 
 }




 //�����̋t�s���trgt�ɃZ�b�g
 inline bool getInvert(ILMatrix9 &trgt)
 {
  double det = calcDet9();

  if(abs(det) < 0.0000001) return false;
  double detInv = 1.0 / det;
  
  trgt.data[0] = detInv * ( data[4] * data[8] - data[7] * data[5]);
  trgt.data[1] = detInv * ( data[7] * data[2] - data[1] * data[8]);
  trgt.data[2] = detInv * ( data[1] * data[5] - data[4] * data[2]);

  trgt.data[3] = detInv * ( data[6] * data[5] - data[3] * data[8]);
  trgt.data[4] = detInv * ( data[0] * data[8] - data[6] * data[2]);
  trgt.data[5] = detInv * ( data[3] * data[2] - data[0] * data[5]);

  trgt.data[6] = detInv * ( data[3] * data[7] - data[6] * data[4]);
  trgt.data[7] = detInv * ( data[6] * data[1] - data[0] * data[7]);
  trgt.data[8] = detInv * ( data[0] * data[4] - data[3] * data[1]);
  return true;
 }
	void Set(double* cmat){memcpy(data,cmat,sizeof(double)*9);}
	void Set(float* cmat) {for( int i=0;i<9;++i ) data[i]=cmat[i];}
	void SetIdentity(){
		memset(data,0,sizeof(double)*9);
		data[0]=1.0f; data[4]=1.0f; data[8]=1.0f;
	};

	inline
	ILMatrix9 getTransposed(){
		return ILMatrix9(data[0], data[1], data[2],
						 data[3], data[4], data[5],
						 data[6], data[7], data[8]);
		//ILMatrix9 m;
		//m.data[0] = data[0]; m.data[3] = data[1]; m.data[6] = data[2];
		//m.data[1] = data[3]; m.data[4] = data[4]; m.data[7] = data[5];
		//m.data[2] = data[6]; m.data[5] = data[7]; m.data[8] = data[8];
		//return m;
	}

	inline
	void setTransposed(const ILMatrix9& M){
		data[0] = M.data[0]; data[3] = M.data[1], data[6] = M.data[2],
		data[1] = M.data[3]; data[4] = M.data[4], data[7] = M.data[5],
		data[2] = M.data[6]; data[5] = M.data[7], data[8] = M.data[8];
	}


	void transpose_Self(){
		std::swap(data[1], data[3]);
		std::swap(data[2], data[6]);
		std::swap(data[5], data[7]);
		//ILMatrix9 m;
		//m.data[0] = data[0]; m.data[3] = data[1]; m.data[6] = data[2];
		//m.data[1] = data[3]; m.data[4] = data[4]; m.data[7] = data[5];
		//m.data[2] = data[6]; m.data[5] = data[7]; m.data[8] = data[8];
		//this->Set(m.data);
	}

	void multScholar(double a){
		for(int i = 0; i < 9; ++i) data[i] *= a;
	}
	
	inline void SetZero(){
		memset(data,0,sizeof(double)*9);
	}

	double& operator[](int i){ return data[i]; }
	const double operator[](int i) const { return data[i]; }
	operator double*(){ return data; }

	void operator*=(const ILMatrix9& mat){
		double tmp[9];
		memset(tmp,0,sizeof(double)*9) ;
		int i,j,k;
		for(i=0;i<3;i++)for(j=0;j<3;j++)for(k=0;k<3;k++)
			tmp[j*3+i] += data[k*3+i] * mat.data[j*3+k];
		memcpy( data,tmp,sizeof(double)*9 ) ;
	}

	ILMatrix9 operator*(const ILMatrix9& mat){
		double tmp[9] ;
		//memset(tmp.data,0,sizeof(double)*9) ;
		//int i,j,k;
		//for(i=0;i<3;i++)for(j=0;j<3;j++)for(k=0;k<3;k++) 
		//	tmp[j*3+i] += data[k*3+i] * mat.data[j*3+k];//ij�����ɃA�N�Z�X --> j*3 + i
		tmp[0] = data[0] * mat.data[0] + data[3] * mat.data[1] + data[6] * mat.data[2];
		tmp[1] = data[1] * mat.data[0] + data[4] * mat.data[1] + data[7] * mat.data[2];
		tmp[2] = data[2] * mat.data[0] + data[5] * mat.data[1] + data[8] * mat.data[2];

		tmp[3] = data[0] * mat.data[3] + data[3] * mat.data[4] + data[6] * mat.data[5];
		tmp[4] = data[1] * mat.data[3] + data[4] * mat.data[4] + data[7] * mat.data[5];
		tmp[5] = data[2] * mat.data[3] + data[5] * mat.data[4] + data[8] * mat.data[5];
		
		tmp[6] = data[0] * mat.data[6] + data[3] * mat.data[7] + data[6] * mat.data[8];
		tmp[7] = data[1] * mat.data[6] + data[4] * mat.data[7] + data[7] * mat.data[8];
		tmp[8] = data[2] * mat.data[6] + data[5] * mat.data[7] + data[8] * mat.data[8];
		return ILMatrix9(tmp) ;
	}


	ILVector3D operator*(const ILVector3D& v){
		return ILVector3D(
			data[0] * v.data[0] + data[3] * v.data[1] + data[6] * v.data[2],
			data[1] * v.data[0] + data[4] * v.data[1] + data[7] * v.data[2],
			data[2] * v.data[0] + data[5] * v.data[1] + data[8] * v.data[2]) ;
	}
	ILMatrix9 operator+(const ILMatrix9& mat){
		return ILMatrix9(data[0] + mat.data[0], data[3] + mat.data[3], data[6] + mat.data[6],
						 data[1] + mat.data[1], data[4] + mat.data[4], data[7] + mat.data[7],
						 data[2] + mat.data[2], data[5] + mat.data[5], data[8] + mat.data[8]);
//		ILMatrix9 tmp ;
//		for(int i=0;i<9;i++) tmp[i]=(*this)[i]+mat.data[i];
//		return tmp ;
	}
	void operator+=(ILMatrix9& mat){
		data[0]+=mat.data[0];
		data[1]+=mat.data[1];
		data[2]+=mat.data[2];
		data[3]+=mat.data[3];
		data[4]+=mat.data[4];
		data[5]+=mat.data[5];
		data[6]+=mat.data[6];
		data[7]+=mat.data[7];
		data[8]+=mat.data[8];
	}

	inline friend ILMatrix9 operator*(double f,const ILMatrix9& mat1){
		ILMatrix9 tmp;
		for(int i = 0; i < 9;++i) tmp[i] = mat1.data[i] * f;
		return tmp;
	}
	
	ILMatrix9& operator=(const ILMatrix9& src){memcpy(data,src.data,sizeof(double)*9);return*this;}
	ILMatrix9& operator=(const double* src   ){memcpy(data,src,sizeof(double)*9);return*this;}

	void Trace(){
		for( int i=0;i<3;++i ){
			for( int j=0;j<3;++j ){
				TRACE("%f ",data[j*3+i]) ;
			}
			TRACE("\n") ;
		}
	}

	// M = l * l.transpose
	inline void SetMultVectors(const ILVector3D& l, const ILVector3D& r){
		data[0] = l.data[0] * r.data[0];   data[3] = l.data[0] * r.data[1];   data[6] = l.data[0] * r.data[2];
		data[1] = l.data[1] * r.data[0];   data[4] = l.data[1] * r.data[1];   data[7] = l.data[1] * r.data[2];
		data[2] = l.data[2] * r.data[0];   data[5] = l.data[2] * r.data[1];   data[8] = l.data[2] * r.data[2];
	}
	// M += l * l.transpose
	inline void addMultVectors(const ILVector3D& l, const ILVector3D& r){
		data[0] += l.data[0] * r.data[0];   data[3] += l.data[0] * r.data[1];   data[6] += l.data[0] * r.data[2];
		data[1] += l.data[1] * r.data[0];   data[4] += l.data[1] * r.data[1];   data[7] += l.data[1] * r.data[2];
		data[2] += l.data[2] * r.data[0];   data[5] += l.data[2] * r.data[1];   data[8] += l.data[2] * r.data[2];
	}
	
	// M = c * (l * l.transpose)
	inline void SetMultVectorsWithCoef(double c, const ILVector3D& l, const ILVector3D& r){
		data[0] = c * l.data[0] * r.data[0];   data[3] = c * l.data[0] * r.data[1];   data[6] = c * l.data[0] * r.data[2];
		data[1] = c * l.data[1] * r.data[0];   data[4] = c * l.data[1] * r.data[1];   data[7] = c * l.data[1] * r.data[2];
		data[2] = c * l.data[2] * r.data[0];   data[5] = c * l.data[2] * r.data[1];   data[8] = c *l.data[2] * r.data[2];
	}
	
	// M += c * (l * l.transpose)
	inline void AddMultVectorsWithCoef(double c, const ILVector3D& l, const ILVector3D& r){
		data[0] += c * l.data[0] * r.data[0];   data[3] = c * l.data[0] * r.data[1];   data[6] = c * l.data[0] * r.data[2];
		data[1] += c * l.data[1] * r.data[0];   data[4] = c * l.data[1] * r.data[1];   data[7] = c * l.data[1] * r.data[2];
		data[2] += c * l.data[2] * r.data[0];   data[5] = c * l.data[2] * r.data[1];   data[8] = c *l.data[2] * r.data[2];
	}

	// M += d * M 
	inline void addMatMultScholar(double d, const ILMatrix9& M){
		data[0] += d * M.data[0];  data[3] += d * M.data[3];  data[6] += d * M.data[6];
		data[1] += d * M.data[1];  data[4] += d * M.data[4];  data[7] += d * M.data[7];
		data[2] += d * M.data[2];  data[5] += d * M.data[5];  data[8] += d * M.data[8];
	}
	
	inline void setMatMultScholar(double d, const ILMatrix9& M){
		data[0] = d * M.data[0];  data[3] = d * M.data[3];  data[6] = d * M.data[6];
		data[1] = d * M.data[1];  data[4] = d * M.data[4];  data[7] = d * M.data[7];
		data[2] = d * M.data[2];  data[5] = d * M.data[5];  data[8] = d * M.data[8];
	}

	inline void setMultM1M2(ILMatrix9& M1, ILMatrix9& M2){
		data[0] = M1.data[0] * M2.data[0]  +  M1.data[3] * M2.data[1]  +  M1.data[6] * M2.data[2];
		data[1] = M1.data[1] * M2.data[0]  +  M1.data[4] * M2.data[1]  +  M1.data[7] * M2.data[2];
		data[2] = M1.data[2] * M2.data[0]  +  M1.data[5] * M2.data[1]  +  M1.data[8] * M2.data[2];

		data[3] = M1.data[0] * M2.data[3]  +  M1.data[3] * M2.data[4]  +  M1.data[6] * M2.data[5];
		data[4] = M1.data[1] * M2.data[3]  +  M1.data[4] * M2.data[4]  +  M1.data[7] * M2.data[5];
		data[5] = M1.data[2] * M2.data[3]  +  M1.data[5] * M2.data[4]  +  M1.data[8] * M2.data[5];
		
		data[6] = M1.data[0] * M2.data[6]  +  M1.data[3] * M2.data[7]  +  M1.data[6] * M2.data[8];
		data[7] = M1.data[1] * M2.data[6]  +  M1.data[4] * M2.data[7]  +  M1.data[7] * M2.data[8];
		data[8] = M1.data[2] * M2.data[6]  +  M1.data[5] * M2.data[7]  +  M1.data[8] * M2.data[8];
	}
	
	// S(v1) * S(v2).getTranspose����x�Ɍv�Z
	inline void setS1multS2transpose(ILVector3D& v1, ILVector3D& v2)
	{
		data[0] =   v1.data[2] * v2.data[2]  +  v1.data[1] * v2.data[1];
		data[1] = - v1.data[0] * v2.data[1];
		data[2] = - v1.data[0] * v2.data[2];

		data[3] = - v1.data[1] * v2.data[0];
		data[4] =   v1.data[2] * v2.data[2]  +  v1.data[0] * v2.data[0];
		data[5] = - v1.data[1] * v2.data[2];
		
		data[6] = - v1.data[2] * v2.data[0];
		data[7] = - v1.data[2] * v2.data[1];
		data[8] =   v1.data[1] * v2.data[1]  +  v1.data[0] * v2.data[0];
	}

	inline void addS1multS2transpose(ILVector3D& v1, ILVector3D& v2)
	{
		data[0] +=   v1.data[2] * v2.data[2]  +  v1.data[1] * v2.data[1];
		data[1] -=   v1.data[0] * v2.data[1];
		data[2] -=   v1.data[0] * v2.data[2];

		data[3] -=  v1.data[1] * v2.data[0];
		data[4] +=  v1.data[2] * v2.data[2]  +  v1.data[0] * v2.data[0];
		data[5] -=  v1.data[1] * v2.data[2];
		
		data[6] -=  v1.data[2] * v2.data[0];
		data[7] -=  v1.data[2] * v2.data[1];
		data[8] +=  v1.data[1] * v2.data[1]  +  v1.data[0] * v2.data[0];
	}

	inline void addMultM1M2(ILMatrix9& M1, ILMatrix9& M2){
		data[0] += M1.data[0] * M2.data[0]  +  M1.data[3] * M2.data[1]  +  M1.data[6] * M2.data[2];
		data[1] += M1.data[1] * M2.data[0]  +  M1.data[4] * M2.data[1]  +  M1.data[7] * M2.data[2];
		data[2] += M1.data[2] * M2.data[0]  +  M1.data[5] * M2.data[1]  +  M1.data[8] * M2.data[2];

		data[3] += M1.data[0] * M2.data[3]  +  M1.data[3] * M2.data[4]  +  M1.data[6] * M2.data[5];
		data[4] += M1.data[1] * M2.data[3]  +  M1.data[4] * M2.data[4]  +  M1.data[7] * M2.data[5];
		data[5] += M1.data[2] * M2.data[3]  +  M1.data[5] * M2.data[4]  +  M1.data[8] * M2.data[5];
		
		data[6] += M1.data[0] * M2.data[6]  +  M1.data[3] * M2.data[7]  +  M1.data[6] * M2.data[8];
		data[7] += M1.data[1] * M2.data[6]  +  M1.data[4] * M2.data[7]  +  M1.data[7] * M2.data[8];
		data[8] += M1.data[2] * M2.data[6]  +  M1.data[5] * M2.data[7]  +  M1.data[8] * M2.data[8];
	}




};






/*Modified by Takashi*/
class CSparseMatrix  
{
public:
	CSparseMatrix() ;
	virtual ~CSparseMatrix() ;
	void SetChanged() ;

	typedef struct {
		vector<int>		indice ;
		vector<double>	coefficients ;
	} Row ;
	typedef Row	Column ;

protected:
	// Data. if changed, SetChanged() method should be called.
	vector<Row> rows;
	int columnmax;

	//���ۂ̃f�[�^��swap����͖̂���.index���h���l�����ւ��邱�Ƃŋ[���I��swap������
	vector<int>             rowidmap ;			// inputs the old id and returns the new id �f�[�^��i��ڂ����݂�matrix�̉���ڂɂ����邩������
	vector<int>             rowidmap_inv ;		// inputs the new id and returns the old id ����Matrix��i��ڂ����ۂ̃f�[�^�̂ǂ̗�ɂ��邩��Ԃ�. column���擾����Ƃ���data�̏ꏊ����index�𕜌�����K�v���ł���
	vector< vector<int> >	columns ;

	bool m_isLinearSolverFieldsReady;
	int*    m_Ap_c;
	int*    m_Ai_c;
	double* m_Ax_c;
	double* m_b_c;
	double* m_x_c;

public:
	int GetRowNum(){	return (int)rows.size() ; }
	int GetColumnNum(){	return columnmax ;	      }

	//Topology���ς��Ȃ�Step�����̂��߂̊֐�
	void t_SetZeroToCurrentEntries()
	{
		for ( int i = 0; i < (int) rows.size(); ++i){
			vector<double>::iterator it_coef = rows[i].coefficients.begin() ;
			for( ; it_coef != rows[i].coefficients.end(); it_coef++ )
					*it_coef = 0 ;
		}
	}

	//row col�͍����,�si��j�̒l
	inline void t_AddBlocksToExistingEntries_(int row, int col1, ILMatrix9& M1,
		                                               int col2, ILMatrix9& M2)
	{
		Row& r0 = rows[ rowidmap_inv[row   ] ] ;
		Row& r1 = rows[ rowidmap_inv[row +1] ] ;
		Row& r2 = rows[ rowidmap_inv[row +2] ] ;

		vector<int>::iterator    it_id    = r0.indice.begin() ;
		vector<double>::iterator it_coef0 = r0.coefficients.begin() ;
		vector<double>::iterator it_coef1 = r1.coefficients.begin() ;
		vector<double>::iterator it_coef2 = r2.coefficients.begin() ;
		
		while(true){
			if( *it_id == col1 ){ //�K��Hit����
				++it_id; ++it_id; ++it_id;
				*it_coef0 += M1[0] ; ++it_coef0;   *it_coef0 += M1[3] ; ++it_coef0;   *it_coef0 += M1[6] ; ++it_coef0;
				*it_coef1 += M1[1] ; ++it_coef1;   *it_coef1 += M1[4] ; ++it_coef1;   *it_coef1 += M1[7] ; ++it_coef1;
				*it_coef2 += M1[2] ; ++it_coef2;   *it_coef2 += M1[5] ; ++it_coef2;   *it_coef2 += M1[8] ; ++it_coef2;
				break;
			}
			++it_id;    ++it_id;    ++it_id;    ++it_coef0; ++it_coef0; ++it_coef0;
			++it_coef1; ++it_coef1; ++it_coef1; ++it_coef2; ++it_coef2; ++it_coef2; 
		}

		while(true){
			if( *it_id == col2 ){ //�K��Hit����
				++it_id; ++it_id; ++it_id;
				*it_coef0 += M2[0] ; ++it_coef0;   *it_coef0 += M2[3] ; ++it_coef0;   *it_coef0 += M2[6] ; ++it_coef0;
				*it_coef1 += M2[1] ; ++it_coef1;   *it_coef1 += M2[4] ; ++it_coef1;   *it_coef1 += M2[7] ; ++it_coef1;
				*it_coef2 += M2[2] ; ++it_coef2;   *it_coef2 += M2[5] ; ++it_coef2;   *it_coef2 += M2[8] ; ++it_coef2;
				return;
			}
			++it_id;    ++it_id;    ++it_id;    ++it_coef0; ++it_coef0; ++it_coef0;
			++it_coef1; ++it_coef1; ++it_coef1; ++it_coef2; ++it_coef2; ++it_coef2; 
		}
		assert(false);
	}


	//row col�͍����,�si��j�̒l
	inline void t_AddBlocksToExistingEntries_(int row, int col1, ILMatrix9& M1,
		                                               int col2, ILMatrix9& M2, 
													   int col3, ILMatrix9& M3){
		Row& r0 = rows[ rowidmap_inv[row   ] ] ;
		Row& r1 = rows[ rowidmap_inv[row +1] ] ;
		Row& r2 = rows[ rowidmap_inv[row +2] ] ;
		vector<int>::iterator    it_id    = r0.indice.begin() ;
		vector<double>::iterator it_coef0 = r0.coefficients.begin() ;
		vector<double>::iterator it_coef1 = r1.coefficients.begin() ;
		vector<double>::iterator it_coef2 = r2.coefficients.begin() ;
		
		while(true){
			if( *it_id == col1 ){ //�K��Hit����
				++it_id; ++it_id; ++it_id;
				*it_coef0 += M1[0] ; ++it_coef0;   *it_coef0 += M1[3] ; ++it_coef0;   *it_coef0 += M1[6] ; ++it_coef0;
				*it_coef1 += M1[1] ; ++it_coef1;   *it_coef1 += M1[4] ; ++it_coef1;   *it_coef1 += M1[7] ; ++it_coef1;
				*it_coef2 += M1[2] ; ++it_coef2;   *it_coef2 += M1[5] ; ++it_coef2;   *it_coef2 += M1[8] ; ++it_coef2;
				break;
			}
			++it_id;    ++it_id;    ++it_id;    ++it_coef0; ++it_coef0; ++it_coef0;
			++it_coef1; ++it_coef1; ++it_coef1; ++it_coef2; ++it_coef2; ++it_coef2; 
		}

		while(true){
			if( *it_id == col2 ){ //�K��Hit����
				++it_id; ++it_id; ++it_id;
				*it_coef0 += M2[0] ; ++it_coef0;   *it_coef0 += M2[3] ; ++it_coef0;   *it_coef0 += M2[6] ; ++it_coef0;
				*it_coef1 += M2[1] ; ++it_coef1;   *it_coef1 += M2[4] ; ++it_coef1;   *it_coef1 += M2[7] ; ++it_coef1;
				*it_coef2 += M2[2] ; ++it_coef2;   *it_coef2 += M2[5] ; ++it_coef2;   *it_coef2 += M2[8] ; ++it_coef2;
				break;
			}
			++it_id;    ++it_id;    ++it_id;    ++it_coef0; ++it_coef0; ++it_coef0;
			++it_coef1; ++it_coef1; ++it_coef1; ++it_coef2; ++it_coef2; ++it_coef2; 
		}

		while(true){
			if( *it_id == col3 ){ //�K��Hit����
				++it_id; ++it_id; ++it_id;
				*it_coef0 += M3[0] ; ++it_coef0;   *it_coef0 += M3[3] ; ++it_coef0;   *it_coef0 += M3[6] ; ++it_coef0;
				*it_coef1 += M3[1] ; ++it_coef1;   *it_coef1 += M3[4] ; ++it_coef1;   *it_coef1 += M3[7] ; ++it_coef1;
				*it_coef2 += M3[2] ; ++it_coef2;   *it_coef2 += M3[5] ; ++it_coef2;   *it_coef2 += M3[8] ; ++it_coef2;
				return;
			}
			++it_id;    ++it_id;    ++it_id;    ++it_coef0; ++it_coef0; ++it_coef0;
			++it_coef1; ++it_coef1; ++it_coef1; ++it_coef2; ++it_coef2; ++it_coef2; 
		}
	}

	//row col�͍����,�si��j�̒l
	inline void t_AddBlocksToExistingEntries_(int row, int col1, ILMatrix9& M1,
		                                               int col2, ILMatrix9& M2, 
													   int col3, ILMatrix9& M3,
													   int col4, ILMatrix9& M4)
	{
		assert(col1 < col2 && col2 < col3 && col3 < col4 );
		Row& r0 = rows[ rowidmap_inv[row   ] ] ;
		Row& r1 = rows[ rowidmap_inv[row +1] ] ;
		Row& r2 = rows[ rowidmap_inv[row +2] ] ;
		vector<int>::iterator    it_id    = r0.indice.begin() ;	
		vector<double>::iterator it_coef0 = r0.coefficients.begin() ;
		vector<double>::iterator it_coef1 = r1.coefficients.begin() ;
		vector<double>::iterator it_coef2 = r2.coefficients.begin() ;

		while(true){
			if( *it_id == col1 ){ //�K��Hit����
				++it_id; ++it_id; ++it_id;
				*it_coef0 += M1[0] ; ++it_coef0;   *it_coef0 += M1[3] ; ++it_coef0;   *it_coef0 += M1[6] ; ++it_coef0;
				*it_coef1 += M1[1] ; ++it_coef1;   *it_coef1 += M1[4] ; ++it_coef1;   *it_coef1 += M1[7] ; ++it_coef1;
				*it_coef2 += M1[2] ; ++it_coef2;   *it_coef2 += M1[5] ; ++it_coef2;   *it_coef2 += M1[8] ; ++it_coef2;
				break;
			}
			++it_id;    ++it_id;    ++it_id;    ++it_coef0; ++it_coef0; ++it_coef0;
			++it_coef1; ++it_coef1; ++it_coef1; ++it_coef2; ++it_coef2; ++it_coef2; 
		}

		while(true){
			if( *it_id == col2 ){ //�K��Hit����
				++it_id; ++it_id; ++it_id;
				*it_coef0 += M2[0] ; ++it_coef0;   *it_coef0 += M2[3] ; ++it_coef0;   *it_coef0 += M2[6] ; ++it_coef0;
				*it_coef1 += M2[1] ; ++it_coef1;   *it_coef1 += M2[4] ; ++it_coef1;   *it_coef1 += M2[7] ; ++it_coef1;
				*it_coef2 += M2[2] ; ++it_coef2;   *it_coef2 += M2[5] ; ++it_coef2;   *it_coef2 += M2[8] ; ++it_coef2;
				break;
			}
			++it_id;    ++it_id;    ++it_id;    ++it_coef0; ++it_coef0; ++it_coef0;
			++it_coef1; ++it_coef1; ++it_coef1; ++it_coef2; ++it_coef2; ++it_coef2; 
		}

		while(true){
			if( *it_id == col3 ){ //�K��Hit����
				++it_id; ++it_id; ++it_id;
				*it_coef0 += M3[0] ; ++it_coef0;   *it_coef0 += M3[3] ; ++it_coef0;   *it_coef0 += M3[6] ; ++it_coef0;
				*it_coef1 += M3[1] ; ++it_coef1;   *it_coef1 += M3[4] ; ++it_coef1;   *it_coef1 += M3[7] ; ++it_coef1;
				*it_coef2 += M3[2] ; ++it_coef2;   *it_coef2 += M3[5] ; ++it_coef2;   *it_coef2 += M3[8] ; ++it_coef2;
				break;
			}
			++it_id;    ++it_id;    ++it_id;    ++it_coef0; ++it_coef0; ++it_coef0;
			++it_coef1; ++it_coef1; ++it_coef1; ++it_coef2; ++it_coef2; ++it_coef2; 
		}

		while(true){
			if( *it_id == col4 ){ //�K��Hit����
				++it_id; ++it_id; ++it_id;
				*it_coef0 += M4[0] ; ++it_coef0;   *it_coef0 += M4[3] ; ++it_coef0;   *it_coef0 += M4[6] ; ++it_coef0;
				*it_coef1 += M4[1] ; ++it_coef1;   *it_coef1 += M4[4] ; ++it_coef1;   *it_coef1 += M4[7] ; ++it_coef1;
				*it_coef2 += M4[2] ; ++it_coef2;   *it_coef2 += M4[5] ; ++it_coef2;   *it_coef2 += M4[8] ; ++it_coef2;
				return;
			}
			++it_id;    ++it_id;    ++it_id;    ++it_coef0; ++it_coef0; ++it_coef0;
			++it_coef1; ++it_coef1; ++it_coef1; ++it_coef2; ++it_coef2; ++it_coef2; 
		}
		assert(false);
	}



	inline void t_AddBlocksToExistingEntries(int row, int col1, ILMatrix9& M1,
													  int col2, ILMatrix9& M2){
		if(col1 < col2) t_AddBlocksToExistingEntries_(row,col1,M1, col2,M2);
		else            t_AddBlocksToExistingEntries_(row,col2,M2, col1,M1);
	}

	inline void t_AddBlocksToExistingEntries(int row, int col1, ILMatrix9& M1,
		                                              int col2, ILMatrix9& M2,
		                                              int col3, ILMatrix9& M3)
	{
		if(col1 < col2) {
			if(col2 < col3)        t_AddBlocksToExistingEntries_(row, col1,M1, col2,M2, col3,M3);//123
			else if( col1 < col3)  t_AddBlocksToExistingEntries_(row, col1,M1, col3,M3, col2,M2);//132
			else                   t_AddBlocksToExistingEntries_(row, col3,M3, col1,M1, col2,M2);//312     								
		}else{// 2 < 1   
			if(col1 < col3)        t_AddBlocksToExistingEntries_(row, col2,M2, col1,M1, col3,M3);//213
			else if( col2 < col3)  t_AddBlocksToExistingEntries_(row, col2,M2, col3,M3, col1,M1);//231
			else				   t_AddBlocksToExistingEntries_(row, col3,M3, col2,M2, col1,M1);//321
		}
	}



	inline void t_AddBlocksToExistingEntries(int row, int col1, ILMatrix9& M1,
		                                              int col2, ILMatrix9& M2,
		                                              int col3, ILMatrix9& M3,
													  int col4, ILMatrix9& M4)
	{
		if(     col1 < col2 && col1 < col3 && col1 < col4) //234
		{
			if(col2 < col3) {
				if(col3 < col4)        t_AddBlocksToExistingEntries_(row, col1,M1, col2,M2, col3,M3, col4,M4);//234
				else if( col2 < col4)  t_AddBlocksToExistingEntries_(row, col1,M1, col2,M2, col4,M4, col3,M3);//243
				else                   t_AddBlocksToExistingEntries_(row, col1,M1, col4,M4, col2,M2, col3,M3);//423     								
			}else{// 3 < 2   
				if(col2 < col4)        t_AddBlocksToExistingEntries_(row, col1,M1, col3,M3, col2,M2, col4,M4);//324
				else if( col3 < col4)  t_AddBlocksToExistingEntries_(row, col1,M1, col3,M3, col4,M4, col2,M2);//342    
				else				   t_AddBlocksToExistingEntries_(row, col1,M1, col4,M4, col3,M3, col2,M2);//432    
			}
		}
		else if(col2 < col3 && col2 < col4)                //134
		{
			if(col1 < col3) {
				if(col3 < col4)        t_AddBlocksToExistingEntries_(row, col2,M2, col1,M1, col3,M3, col4,M4);//134
				else if( col1 < col4)  t_AddBlocksToExistingEntries_(row, col2,M2, col1,M1, col4,M4, col3,M3);//143
				else                   t_AddBlocksToExistingEntries_(row, col2,M2, col4,M4, col1,M1, col3,M3);//413     								
			}else{// 3 < 1   
				if(col1 < col4)        t_AddBlocksToExistingEntries_(row, col2,M2, col3,M3, col1,M1, col3,M3);//314
				else if( col3 < col4)  t_AddBlocksToExistingEntries_(row, col2,M2, col3,M3, col4,M4, col1,M1);//341
				else				   t_AddBlocksToExistingEntries_(row, col2,M2, col4,M4, col3,M3, col1,M1);//431
			}
		}
		else if(col3 < col4)                               //124
		{
			if(col1 < col2) {
				if(col2 < col4)        t_AddBlocksToExistingEntries_(row, col3,M3, col1,M1, col2,M2, col4,M4);//124
				else if( col1 < col4)  t_AddBlocksToExistingEntries_(row, col3,M3, col1,M1, col4,M4, col2,M2);//142
				else                   t_AddBlocksToExistingEntries_(row, col3,M3, col4,M4, col1,M1, col2,M2);//412     								
			}else{// 2 < 1   
				if(col1 < col4)        t_AddBlocksToExistingEntries_(row, col3,M3, col2,M2, col1,M1, col4,M4);//214
				else if( col2 < col4)  t_AddBlocksToExistingEntries_(row, col3,M3, col2,M2, col4,M4, col1,M1);//241
				else				   t_AddBlocksToExistingEntries_(row, col3,M3, col4,M4, col2,M2, col1,M1);//421
			}
		}
		else//min = col4                                   //123
		{
			if(col1 < col2) {
				if(col2 < col3)        t_AddBlocksToExistingEntries_(row, col4,M4, col1,M1, col2,M2, col3,M3);//123
				else if( col1 < col3)  t_AddBlocksToExistingEntries_(row, col4,M4, col1,M1, col3,M3, col2,M2);//132
				else                   t_AddBlocksToExistingEntries_(row, col4,M4, col3,M3, col1,M1, col2,M2);//312     								
			}else{// 2 < 1   
				if(col1 < col3)        t_AddBlocksToExistingEntries_(row, col4,M4, col2,M2, col1,M1, col3,M3);//213
				else if( col2 < col3)  t_AddBlocksToExistingEntries_(row, col4,M4, col2,M2, col3,M3, col1,M1);//231
				else				   t_AddBlocksToExistingEntries_(row, col4,M4, col3,M3, col2,M2, col1,M1);//321
			}
		}
	}







	//�K���u���b�N�P�ʂœ����g�|���W�[�ɂȂ�
	//row col�͍����,�si��j�̒l
	inline void t_AddBlockToExistingEntries(int row, int col, ILMatrix9& M)
	{
		Row& r0 = rows[ rowidmap_inv[row   ] ] ;
		Row& r1 = rows[ rowidmap_inv[row +1] ] ;
		Row& r2 = rows[ rowidmap_inv[row +2] ] ;

		vector<int>::iterator    it_id   = r0.indice.begin() ;
		
		vector<double>::iterator it_coef0 = r0.coefficients.begin() ;
		vector<double>::iterator it_coef1 = r1.coefficients.begin() ;
		vector<double>::iterator it_coef2 = r2.coefficients.begin() ;
		
		for( ; it_id != r0.indice.end() ; ++it_id, ++it_coef0, ++it_coef1, ++it_coef2 ){
			if( *it_id == col ){ //�K��Hit����
				*it_coef0 += M[0] ;   ++it_coef0; *it_coef0 += M[3] ;    ++it_coef0; *it_coef0 += M[6] ;
				*it_coef1 += M[1] ;   ++it_coef1; *it_coef1 += M[4] ;    ++it_coef1; *it_coef1 += M[7] ;
				*it_coef2 += M[2] ;   ++it_coef2; *it_coef2 += M[5] ;    ++it_coef2; *it_coef2 += M[8] ;
				return ;
			}
		}
	}

	//�Ίp�����݂̂�Matrix�𑫂�
	inline void t_AddDiagonalBlockToExistingEntries(int row, int col, double d0,double d1,double d2)
	{
		Row& r0 = rows[ rowidmap_inv[row   ] ] ;
		Row& r1 = rows[ rowidmap_inv[row +1] ] ;
		Row& r2 = rows[ rowidmap_inv[row +2] ] ;

		vector<int>::iterator    it_id   = r0.indice.begin() ;
		
		vector<double>::iterator it_coef0 = r0.coefficients.begin() ;
		vector<double>::iterator it_coef1 = r1.coefficients.begin() ;
		vector<double>::iterator it_coef2 = r2.coefficients.begin() ;
	
		for( ; it_id != r0.indice.end() ; ++it_id, ++it_coef0, ++it_coef1, ++it_coef2 ){
			if( *it_id == col ){ //�K��Hit����
			 	                        *it_coef0 += d0 ;
				++it_coef1;             *it_coef1 += d1 ;
				++it_coef2; ++it_coef2; *it_coef2 += d2 ;
				return ;
			}
		}
	}

/*	
	void t_AddValueToExistingEntries(int row, int column, double val)
	{
		Row& r = rows[rowidmap_inv[row]] ;

		vector<int>::iterator    it_id   = r.indice.begin() ;
		vector<double>::iterator it_coef = r.coefficients.begin() ;
		for( ; it_id != r.indice.end() ; it_id++,it_coef++ ){
			if( *it_id == column ){ //�K��Hit����
				*it_coef += val ;
				return ;
			}
		}
	}
*/


/*	void t_multValue(double val)
	{
		vector<Row>::iterator     row_it;
		vector<double>::iterator coef_it;
		for(  row_it  = rows.begin(); 
			  row_it != rows.end(); 
			  ++ row_it)
			for(coef_it  = (*row_it).coefficients.begin();
				coef_it != (*row_it).coefficients.end(); 
				++coef_it)

				(*coef_it) *= val;// * (*coef_it);
	}
*/
	
/*
	void t_addSparseMatrixSameTopology(const CSparseMatrix& M)
	{
		if(M.columnmax   != columnmax) return;
		if(M.rows.size() != rows.size()) return; 

		for(int i = 0; i < (int)rows.size(); ++i)
			for(int j = 0; j < (int) rows[i].coefficients.size(); ++j)
				rows[i].coefficients[j] += M.rows[i].coefficients[j];
		
	}
*/
/*
	//F += d * M���s�Ȃ�
	inline void t_addMatSameTopologyMultScholar(double d, const CSparseMatrix& M)
	{
		if(M.columnmax   != columnmax) return;
		if(M.rows.size() != rows.size()) return; 

		for(int i = 0; i < (int)rows.size(); ++i)
			for(int j = 0; j < (int) rows[i].coefficients.size(); ++j){
				rows[i].coefficients[j] += (d * M.rows[i].coefficients[j]);
			}
	}
*/

	//F = a * F + d * M�@����x�ɍs�Ȃ�
	inline void t_multScholarSelf_addMatSameTopologyMultScholar(double a, double d, const CSparseMatrix& M)
	{
		if(M.columnmax   != columnmax) return;
		if(M.rows.size() != rows.size()) return; 

		for(int i = 0; i < (int)rows.size(); ++i)
			for(int j = 0; j < (int) rows[i].coefficients.size(); ++j){
				rows[i].coefficients[j] *= a;
				rows[i].coefficients[j] += (d * M.rows[i].coefficients[j]);		
			}
	}


	//��O�p�̏�ԂŌĂ�
	//�Ίp������3*3�̃u���b�N�𖳎�����,�Ίp�������R�s�[���Ă���
	inline void t_copyUpperTriangleToMakeSymetryIgnoringCentralBlock()
	{
		int numOfRow = GetRowNum();
		int numOfCol = GetColumnNum();

		for(int pivRow = 0; pivRow < numOfRow -3; pivRow += 3)
		{
			int pivCol = pivRow + 3;
			//�u���b�N�̍��オ pivRow, pivCol

			Row& r0 = rows[ rowidmap_inv[pivRow   ] ] ;
			Row& r1 = rows[ rowidmap_inv[pivRow +1] ] ;
			Row& r2 = rows[ rowidmap_inv[pivRow +2] ] ;

			vector<int>::iterator    it_id    = r0.indice.begin() ;
		
			vector<double>::iterator it_coef0 = r0.coefficients.begin() ;
			vector<double>::iterator it_coef1 = r1.coefficients.begin() ;
			vector<double>::iterator it_coef2 = r2.coefficients.begin() ;
			
			for( ; it_id != r0.indice.end() ; ++it_id, ++it_coef0, ++it_coef1, ++it_coef2 ){
				if( *it_id >= pivCol )
				{
					//���̍s�̒l���ɃZ�b�g���Ă��� SetElement(row,col,val);
					SetElement( *it_id ,pivRow     , *it_coef0);
					SetElement( *it_id ,pivRow + 1 , *it_coef1);
					SetElement( *it_id ,pivRow + 2 , *it_coef2);
				}
			}
		}
	}



private:

    //���̃V�����g���[�֐��p
	inline void t_AddThreeValuesToExistingEntries(int row, int column, double d0,double d1,double d2){
		Row& r = rows[rowidmap_inv[row]] ;
		vector<int>::iterator    it_id   = r.indice.begin() ;
		vector<double>::iterator it_coef = r.coefficients.begin() ;
		for( ; it_id != r.indice.end() ; it_id++,it_coef++ ){
			if( *it_id == column ){ //�K��Hit����
				*it_coef = d0; ++it_coef;
				*it_coef = d1; ++it_coef;
				*it_coef = d2;
				return ;
			}
		}
	}

public:
	//��O�p�̏�ԂŌĂ�
	//�Ίp������3*3�̃u���b�N�𖳎�����,�Ίp�������R�s�[���Ă���
	inline void t_copyUpperTriangleToMakeSymetryIgnoringCentralBlock_EntriesAreReady()
	{
		int numOfRow = GetRowNum();
		int numOfCol = GetColumnNum();

		for(int pivRow = 0; pivRow < numOfRow -3; pivRow +=3 )
		{
			int pivCol = pivRow + 3;
			//�u���b�N�̍��オ pivRow, pivCol

			Row& r0 = rows[ rowidmap_inv[pivRow   ] ] ;
			Row& r1 = rows[ rowidmap_inv[pivRow +1] ] ;
			Row& r2 = rows[ rowidmap_inv[pivRow +2] ] ;

			vector<int>::iterator    it_id   = r0.indice.begin() ;
		
			vector<double>::iterator it_coef0 = r0.coefficients.begin() ;
			vector<double>::iterator it_coef1 = r1.coefficients.begin() ;
			vector<double>::iterator it_coef2 = r2.coefficients.begin() ;
			
			for( ; it_id != r0.indice.end() ; ++it_id, ++it_coef0, ++it_coef1, ++it_coef2 ){
				if( *it_id >= pivCol )
				{
					//SetElement( *it_id ,pivRow     , *it_coef0);
					//SetElement( *it_id ,pivRow + 1 , *it_coef1);
					//SetElement( *it_id ,pivRow + 2 , *it_coef2);
					//���̍s�̒l���ɃZ�b�g���Ă���
					t_AddThreeValuesToExistingEntries( *it_id, pivRow, *it_coef0, *it_coef1, *it_coef2);
			
				}
			}
		}
	}







	void Allocate( int rownum,int columnnum ){
		rows.clear() ;	
		rows.resize(rownum) ;
		columnmax = columnnum ;
		SetChanged() ;
	}
	void Clear(){	Allocate(0,0) ;	}

	// Allocate() should be called in advance
	// When the set of SetElement() calls completed, SetChanged() should be called.
	void SetElement( int row,int column,double val ){
		assert( 0 <= row    && row    < GetRowNum() ) ;
		assert( 0 <= column && column < columnmax );

		Row& r = rows[rowidmap_inv[row]] ;
		// adding at the tail is much quicker than other insertion
		if( r.indice.empty() || r.indice.back() < column ){
			r.indice.push_back(       column ) ;
			r.coefficients.push_back( val    ) ;
		} else {
			vector<int>::iterator    it_id   = r.indice.begin() ;
			vector<double>::iterator it_coef = r.coefficients.begin() ;
			for( ; it_id != r.indice.end() ; it_id++,it_coef++ ){
				if( *it_id >= column ){
					if( *it_id > column ){
						r.indice.insert( it_id,column ) ;
						r.coefficients.insert( it_coef,val ) ;
					} else {
						*it_coef = val ;
					}
					break ;
				}
			}
		}
	}

	// AddToElement(a,b,val) == SetElement( a,b,val + GetElement(a,b) )
	void AddToElement( int row,int column,double val ){
		assert( 0 <= row && row < GetRowNum() ) ;
		assert( 0 <= column && column < columnmax ) ;
		Row& r = rows[rowidmap_inv[row]] ;
		// adding at the tail is much quicker than other insertion
		if( r.indice.empty() || r.indice.back() < column ){
			r.indice.push_back( column ) ;
			r.coefficients.push_back( val ) ;
		} else {
			vector<int>::iterator    it_id   = r.indice.begin() ;
			vector<double>::iterator it_coef = r.coefficients.begin() ;
			for( ; it_id != r.indice.end() ; it_id++,it_coef++ ){
				if( *it_id >= column ){
					if( *it_id > column ){
						r.indice.insert( it_id,column ) ;
						r.coefficients.insert( it_coef,val ) ;
					} else {
						*it_coef += val ;
					}
					break ;
				}
			}
		}
	}

	double* ConvertToCArray() ;
	void ConvertFromCArray(double* c_mat,int row_num,int column_num ) ;
	
public:
	// This should be inline
	double GetElement( int row,int column ){
		assert( row >= 0 && row < (int)rows.size() ) ;
		assert( column >= 0 && column < columnmax ) ;
		Row& r = rows[rowidmap_inv[row]] ;
		for( int i=0;i<(int)r.indice.size();i++ )
			if( r.indice[i] == column )	return r.coefficients[i] ;
		return 0 ;
	}
	void SwapRow( int row1,int row2 ) ;
	void GetRow( int rownum,Row& row ){	row = rows[ rowidmap_inv[rownum] ] ; }
	void GetColumn( int columnnum,Column& column ) ;

	void MultiplyRow( int rownum,double val ) ;
	// rows[dest_rownum] = rows[dest_rownum] + rows[src_rownum] * srcrow_mul ;
	void AddRows( int dest_rownum,int src_rownum,double srcrow_mul ) ;

	inline double RowMulVector( const int rownum,const vector<double> vec ){
		assert( columnmax == vec.size() ) ;
		Row& r = rows[rowidmap_inv[rownum]] ;
		double result = 0 ;
		for( int i=0;i<(int)r.indice.size();i++ )
			result += r.coefficients[i] * vec[ r.indice[i] ] ;
		return result ;
	}

	bool t_GetTransposeMatrix(CSparseMatrix& transposed);

	bool GetTransposeMatrix(CSparseMatrix& result) ;
	// the performance of this method is not very good because it once expand the
	// sparse matrix into flat C matrix.
	bool GetPseudoInverseMatrix(CSparseMatrix& result) ;

	// transform to reduced row echelon matrix using SwapRow(),MultiplyRow(),AddRows() methods
	// this is used by GetNullSpace() method.
	// Return value is the number of free variables
	void TransformToReducedRowEchelonMatrix( vector<int>* FreeColumns = 0 ) ;

	// Solve linear system G x = d.
	// if a symbol ILMATH_ENABLE_UMFPACK_MATRIX_SOLVER is defined, UMFPACK library is included
	// and fast matrix computation is performed. In this case, the last argument is ignored.
	// Otherwise, conjugate gradient method is used.
	// G = (*this), x = result, d = d : see "Conjugate Gradient Method.pdf" in my directory or,
	// http://www.ees.nmt.edu/Geop/Classes/GEOP529/Docs/cg.pdf
	bool SolveLinearSystem( const vector<double>& d,vector<double>& result,double threshold = 0.0000000001 ) ;
	bool SolveLinearSystemUsingUmfpack(const vector<double>& d,vector<double>& result,double threshold = 0.000000001 );


	// Calc set of vec x such that (*this) x = 0
	void CalcNullSpace( vector< vector<double> >& result ) ;
	void CalcNullSpace( CSparseMatrix& result ) ;

	CSparseMatrix operator*( CSparseMatrix& right ) ;
	inline vector<double> operator* (const vector<double>& vec ) ;

	// print elements
	void TraceMatrix() ;
	static void TraceVector( vector<double>& vec ) ;
};









///////////////////////////////////////////////////////////////////
////////////// C Functions
///////////////////////////////////////////////////////////////////


// bounding box is describe by two vertices
// line is described by pos[] & ori[]
// line[x,y,z] =  pos[x,y,z] + t * ori[x,y,z]
// solve for mint & maxt (result is stored in result_t1 & result_t2)
// if no intersection found, returns false
#define BETWEEN(t1,t2,num)	( (t1)<(t2)?((t1)<=(num) && (num)<=(t2)):((t2)<=(num) && (num)<=(t1)))
inline bool LineClipByBox( ILVector3D& pos,ILVector3D& ori,ILVector3D box[2]
						  ,double& result_t1,double& result_t2 ){
	bool result_available_flag = false ;
	for( int xyz = 0 ; xyz < 3 ; xyz++ ){
		if( ori[xyz] == 0 ){
			if( !BETWEEN( box[0][xyz],box[1][xyz],pos[xyz] ) )	return false ;
			continue ;
		}
		// ori[xyz] != 0
		double bound_t[2] ;
		bound_t[0] = (box[0][xyz] - pos[xyz])/ori[xyz] ;
		bound_t[1] = (box[1][xyz] - pos[xyz])/ori[xyz] ;

		if( result_available_flag ){
			if( bound_t[0] < bound_t[1] ){
				if( result_t1 < bound_t[0] )	result_t1 = bound_t[0] ;
				if( result_t2 > bound_t[1] )	result_t2 = bound_t[1] ;
			} else {
				if( result_t1 < bound_t[1] )	result_t1 = bound_t[1] ;
				if( result_t2 > bound_t[0] )	result_t2 = bound_t[0] ;
			}
		} else {
			result_available_flag = true ;
			if( bound_t[0] < bound_t[1] ){
				result_t1 = bound_t[0] ;
				result_t2 = bound_t[1] ;
			} else {
				result_t1 = bound_t[1] ;
				result_t2 = bound_t[0] ;
			}
		}
	}
	return result_t1 < result_t2 ;
}

// line[x,y,z] =  pos[x,y,z] + t * ori[x,y,z]
// solve for mint & maxt
// if no intersection found, returns false
// the cylinder is aligned to z-axis (length is 2*cyl_zlen.
// cut ellipse has radius cyl_rx & cyl_ry)
inline bool LineClipByCylinder( ILVector3D& pos,ILVector3D& ori,double cyl_rx,double cyl_ry,double cyl_zlen
						  ,double& result_t1,double& result_t2 ){
	if( cyl_rx==0 || cyl_ry == 0 || cyl_zlen == 0 )	return false ;
	// now cyl_rx * cyl_ry * cyl_zlen != 0
	//bounding box check
	ILVector3D b_box[2] ;
	b_box[0].Set(cyl_rx,cyl_ry,cyl_zlen) ;
	b_box[1].Set(-cyl_rx,-cyl_ry,-cyl_zlen) ;
	if( !LineClipByBox( pos,ori,b_box,result_t1,result_t2 ) )	return false ;
	double rx_2 = cyl_rx * cyl_rx ;
	double ry_2 = cyl_ry * cyl_ry ;
	double a = rx_2*ori[1]*ori[1] + ry_2*ori[0]*ori[0] ;
	double b_dash = ry_2*pos[0]*ori[0] + rx_2*pos[1]*ori[1] ;
	double c = ry_2*pos[0]*pos[0] + rx_2*pos[1]*pos[1] - rx_2*ry_2 ;

	if( a == 0 ){
		// assert( ori[0] == 0 && ori[1] == 0 ) ;
		return pos[0]*pos[0]*ry_2 + pos[1]*pos[1]*rx_2 < rx_2*ry_2 ;
	}
	double det = b_dash*b_dash - a*c ;
	if( det<= 0 ) return false ;

	double sqrt_det = sqrt( det ) ;
	double t1 = (-b_dash - sqrt_det ) / a ;
	double t2 = (-b_dash + sqrt_det ) / a ;
	if( t1>t2 ){ double tmp = t1 ; t1 = t2 ; t2 = tmp ; }
	result_t1 = result_t1 > t1 ? result_t1 : t1 ;
	result_t2 = result_t2 < t2 ? result_t2 : t2 ;

	return result_t1 < result_t2 ;
}

// Just the ordinary vector operations
vector<double>& operator*= (vector<double>& vec,const double scalar ) ;
vector<double> operator* ( const double scalar,const vector<double>& vec ) ;
vector<double> operator* ( const vector<double>& vec,const double scalar ) ;
double operator* (const vector<double>& vec1,const vector<double>& vec2 ) ;		// Dot product
vector<double> operator+ (const vector<double>& vec1,const vector<double>& vec2 ) ;
vector<double> operator- ( const vector<double> vec ) ;
vector<double> operator- (const vector<double>& vec1,const vector<double>& vec2 ) ;

double operator* ( CSparseMatrix::Row& vec1,CSparseMatrix::Row& vec2 ) ;

// square matrix functions
// num order is 
// |  0    1     2   ...  dim-1  |
// | dim dim+1 dim+2 ... 2*dim-1 |
// |  :    :     :   ...    :    |
// |                    dim*dim-1|
//(probably ^^;
//template <class T> bool SquareMat_CalcInvMatrix( T* src,T* targ,int dim ) ;
//template <class T> void SquareMat_MultMatrix( T* src,T* src2,T* targ,int dim ) ;
//template <class T> void SquareMat_MultVec( T* srcmat,T* srcvec,T* targvec,int dim ) ;
//template <class T>  T SquareMat_SolveLinearByLU_Sub_LUDecomposition( int n,T* A,int* ip) ;
//template <class T>  T* SquareMat_SolveLinearByLU( T* A,T* b,int dim) ;

//template <class T> bool SquareMat_DumpSquareMatrix(T* mat,int dim,char* fname) ;
//template <class T> bool DumpVec(T* vec,int dim,char* fname) ;

// X template <class T> T SquareMat_CalcDeterminant( T* src,int dim ) ;
// CalcDeterminant �͍ċA������̂ŁA�e���v���[�g�ɂ͂��Ȃ��B

double SquareMat_CalcDeterminant( double* src,int dim ) ;
float SquareMat_CalcDeterminant( float* src,int dim ) ;

template <class T>  bool SquareMat_CalcInvMatrix( T* src,T* targ,int dim ){
	if( dim <= 0 )	return false ;
	if( dim == 1 ){	if( *src==0 ) return false ; *targ = 1/(*src) ; return true ; }
	if( dim == 2 ){
		T det = src[0]*src[3] - src[1]*src[2] ;
		if( det==0 )	return false ;
		T det_inv = 1/det ;
		targ[0] = src[3]*det_inv ;		targ[1] = -src[1]*det_inv ;
		targ[2] = -src[2]*det_inv ;		targ[3] = src[0]*det_inv ;
		return true ;
	}

	T* adjugate = new T[ dim*dim ] ;	// Adjugate matrix = �]���q�s��
	int dim_s = dim-1 ;
	T* submat = new T[ dim_s*dim_s ] ;
	T det = 0 ;
	int i,j,ii,jj ;
	{	// Calc j == 0 ( includes det calculation )
		for( i=0;i<dim;i++ ){
			for( ii=0;ii<dim_s;ii++ ){
				if( ii < i )	memcpy( &submat[ii*dim_s],&src[ii*dim+1],sizeof(T)*dim_s ) ;
				else			memcpy( &submat[ii*dim_s],&src[(ii+1)*dim+1],sizeof(T)*dim_s ) ;
			}
			// cofactor = �]���q
			T cofactor = pow(-1.0,i) * SquareMat_CalcDeterminant( submat,dim_s ) ;
			adjugate[i] = cofactor ;
			det += src[i*dim] * cofactor ;
		}
	}

	if( det == 0 ){
		delete[] adjugate ;
		delete[] submat ;
		return false ;
	}

	for( i=0;i<dim;i++ )for( j=1;j<dim;j++ ){
		for( ii=0;ii<dim_s;ii++ )for( jj=0;jj<dim_s;jj++ ){
			if( ii < i && jj < j)	submat[ii*dim_s + jj] = src[ii*dim + jj] ;
			else if( ii >= i && jj < j)	submat[ii*dim_s + jj] = src[(ii+1)*dim + jj] ;
			else if( ii < i && jj >= j)	submat[ii*dim_s + jj] = src[ii*dim + (jj+1)] ;
			else /*if( ii >= i && jj >= j)*/ submat[ii*dim_s + jj] = src[(ii+1)*dim + (jj+1)] ;
		}
		adjugate[ j*dim + i ] = pow(-1.0,i+j) * SquareMat_CalcDeterminant( submat,dim_s ) ;
	}

	T det_inv = 1/det ;
	for( i=0;i<dim;i++ )for( j=0;j<dim;j++ ){
		targ[i*dim+j] = det_inv*adjugate[i*dim+j] ;
	}

	delete[] adjugate ;
	delete[] submat ;
	return true ;

}

template <class T>  void SquareMat_MultMatrix( T* src,T* src2,T* targ,int dim ){
	memset( targ,0,sizeof(T)*dim*dim ) ;
	int i,j,k ;
	for( j=0;j<dim;j++ )for( i=0;i<dim;i++ )for( k=0;k<dim;k++ )
		targ[ i*dim+j ] += src[i*dim+k] * src2[k*dim+j] ;
}

template <class T>  void SquareMat_MultVec( T* srcmat, T* srcvec, T* targvec,int dim ){
	memset( targvec,0,sizeof(T)*dim ) ;
	int i,j ;
	for( i=0; i < dim; ++i )for( j = 0; j < dim; ++j )
		targvec[i] += srcmat[i*dim+j] * srcvec[j] ;
}

template <class T> void SquareMat_Transpose( T* srcmat,T* targmat,int dim ){
	for( int i=0;i<dim;++i )for( int j=0;j<dim;++j ){
		targmat[i*dim+j] = srcmat[j*dim+i] ;
	}
}

template <class T> void SquareMat_Transpose( T* mat,int dim ){
	T* tmp = new T[dim*dim] ;
	memcpy(tmp,mat,sizeof(T)*dim*dim) ;
	SquareMat_Transpose<T>(tmp,mat,dim) ;
	delete[] tmp ;
}

// LU decomposition
template <class T>  T SquareMat_SolveLinearByLU_Sub_LUDecomposition( int n,T* A,int* ip){
	int i, j, k, ii, ik;
	T t, u, det;
	
	T* weight = new T[n];    /* weight[0..n-1] �̋L���̈�m�� */
	det = 0;                   /* �s�� */
	for (k = 0; k < n; k++) {  /* �e�s�ɂ��� */
		ip[k] = k;             /* �s�������̏����l */
		u = 0;                 /* ���̍s�̐�Βl�ő�̗v�f�����߂� */
		for (j = 0; j < n; j++) {
			t = (T)fabs(A[k*n+j]);  if (t > u) u = t;
		}
		if (fabs(u)<VSN){
			delete[]weight;return det;
		}/* 0 �Ȃ�s���LU�����ł��Ȃ� */
		weight[k] = 1 / u;     /* �ő��Βl�̋t�� */
	}
	det = 1;                   /* �s�񎮂̏����l */
	for (k = 0; k < n; k++) {  /* �e�s�ɂ��� */
		u = -1;
		for (i = k; i < n; i++) {  /* ��艺�̊e�s�ɂ��� */
			ii = ip[i];            /* �d�݁~��Βl ���ő�̍s�������� */
			t = (T)fabs(A[ii*n+k]) * weight[ii];
			if (t > u) {  u = t;  j = i;  }
		}
		ik = ip[j];
		if (j != k) {
			ip[j] = ip[k];  ip[k] = ik;  /* �s�ԍ������� */
			det = -det;  /* �s����������΍s�񎮂̕������ς�� */
		}
		u = A[ik*n+k];  det *= u;  /* �Ίp���� */
		if (fabs(u)<VSN){
			delete[]weight;return det;
		} /* 0 �Ȃ�s���LU�����ł��Ȃ� */
		for (i = k + 1; i < n; i++) {  /* Gauss�����@ */
			ii = ip[i];
			t = (A[ii*n+k] /= u);
			for (j = k + 1; j < n; j++)
				A[ii*n+j] -= t * A[ik*n+j];
		}
	}
	
	delete[] weight;  /* �L���̈����� */
	return det;           /* �߂�l�͍s�� */
}
// solve for Ax = b
template <class T>  T* SquareMat_SolveLinearByLU( T* A,T* b,int dim){
	T* x = new T[dim] ;
	
	// �s�����̏��
	int *ip = new int[dim] ;
	
	T* A_copy = new T[dim*dim] ;
	memcpy(A_copy,A,sizeof(T)*dim*dim) ;
	// LU����. det = �s��
	T det = SquareMat_SolveLinearByLU_Sub_LUDecomposition<T>(dim, A_copy, ip);
	
	// solve by gauss
//	if (fabs(det) > VSN){
		int i, j, ii;
		T t;
		
		for (i = 0; i < dim; i++) {       /* Gauss�����@�̎c�� */
			ii = ip[i];  t = b[ii];
			for (j = 0; j < i; j++) t -= A_copy[ii*dim+j] * x[j];
			x[i] = t;
		}
		for (i = dim - 1; i >= 0; i--) {  /* ��ޑ�� */
			t = x[i];  ii = ip[i];
			for (j = i + 1; j < dim; j++) t -= A_copy[ii*dim+j] * x[j];
			x[i] = t / A_copy[ii*dim+i];
		}
//	}
	
	delete[] A_copy ;
	delete[] ip ;
	return x ;
}

template <class T> bool SquareMat_DumpSquareMatrix(T* mat,int dim,char* fname){
	FILE* fp = fopen(fname,"w") ;
	if( !fp )	return false ;
	for( int iy=0;iy<dim;iy++ ){
		for( int ix=0;ix<dim;ix++ ){
			fprintf(fp,"%.3f\t",mat[iy*dim+ix]) ;
		}
		fprintf(fp,"\n") ;
	}
	fclose(fp) ;
	return true ;
}

template <class T> bool DumpVec(T* vec,int dim,char* fname){
	FILE* fp = fopen(fname,"w") ;
	if( !fp )	return false ;
	for( int i=0;i<dim;i++ ){
		fprintf(fp,"%.3f\t",vec[i]) ;
	}
	fclose(fp) ;
	return true ;
}

template <class T> void copy(vector<T>& src,list<T>& targ){
	targ.clear() ;
	for( vector<T>::iterator vit = src.begin() ; vit != src.end() ; vit++ )
		targ.push_back(*vit) ;
}

template <class T> void copy(list<T>& src,vector<T>& targ){
	targ.clear() ;
	targ.resize(src.size()) ;
	int idx=0 ;
	for( list<T>::iterator lit = src.begin() ; lit != src.end() ; lit++,idx++ )
		targ[idx] = *lit ;
}

template <class T> void make_sintbl(int n,T* sintbl){
	int i,n2,n4,n8 ;
	double c,s,dc,ds,t ;

	n2=n/2;n4=n/4;n8=n/8 ;
	t=sin(M_PI/n) ;
	dc=2*t*t; ds=sqrt(dc*(2-dc)) ;
	t=2*dc; c=sintbl[n4]=1; s=sintbl[0]=0;
	for(i=1;i<n8;i++){
		c-=dc;dc+=t*c;
		s+=ds; ds-=t*s;
		sintbl[i]=(T)s ;sintbl[n4-i]=(T)c;
	}
	if(n8!=0) sintbl[n8] = (T)sqrt(0.5) ;
	for( i=0;i<n4;i++)
		sintbl[n2-i]=sintbl[i] ;
	for(i=0;i<n2+n4;i++)
		sintbl[i+n2]=-sintbl[i] ;
}

inline void make_bitrev(int n,int* bitrev){
	int i,j,k,n2;
	n2=n/2;i=j=0;
	for(;;){
		bitrev[i]=j;
		if(++i>=n)break ;
		k=n2;
		while(k<=j){j-=k;k/=2;}
		j+=k ;
	}
}

template <class T> int fft(int n,T* x,T* y){
	static int last_n=0;
	static int *bitrev=0 ;
	static T *sintbl=0 ;
	int i,j,k,ik,h,d,k2,n4,inverse ;
	T t,s,c,dx,dy;

	if(n<0){
		n=-n; inverse=1;
	} else inverse=0;
	n4=n/4 ;
	if( n!=last_n || n==0 ){
		last_n=n;
		if(!sintbl)delete[]sintbl ;
		if(!bitrev)delete[]bitrev ;
		if(n==0) return 0 ;
		sintbl=new T[n+n4] ;
		bitrev=new int[n] ;
		make_sintbl(n,sintbl) ;
		make_bitrev(n,bitrev) ;
	}
	for(i=0;i<n;++i){
		j=bitrev[i] ;
		if(i<j){
			t=x[i]; x[i]=x[j]; x[j]=t ;
			t=y[i]; y[i]=y[j]; y[j]=t ;
		}
	}
	for( k=1;k<n;k=k2 ){
		h=0;k2=k+k; d=n/k2;
		for( j=0;j<k;j++){
			c=sintbl[h+n4] ;
			s = (inverse?-1:1)*sintbl[h] ;
			for(i=j;i<n;i+=k2){
			ik=i+k;
			dx=s*y[ik]+c*x[ik] ;
			dy=c*y[ik]-s*x[ik] ;
			x[ik]=x[i]-dx; x[i]+=dx;
			y[ik]=y[i]-dy; y[i]+=dy;
			}
			h+=d ;
		}
	}
	if( !inverse)
		for(i=0;i<n;i++){x[i]/=n;y[i]/=n;}
	return 0 ;
}

template<class T> T DotProduct( const T* vec1,const T* vec2,int dim ){
	T result = 0 ;
	for( int i=0;i<dim;i++ )
		result += vec1[i] * vec2[i] ;
	return result ;
}

template<class T> T HouseholderTransform(T* vec,int dim){
	T* x = vec ;
	int n = dim ;
	int i ;
	T s,t ;

	s = (T)sqrt( DotProduct<T>( x,x,n ) ) ;

	if( s != 0 ){
		if( x[0] < 0 ) s = -s ;
		x[0] += s; t = 1/sqrt(x[0] * s) ;
		for( i=0;i<n;++i ) x[i] *= t ;
	}
	return -s ;
}

template<class T> void Tridiagonize( T* mat,int dim,T* vec1=0,T* vec2=0 ){
	T* d = (vec1?vec1:new T[dim]) ; T* e = (vec2?vec2:new T[dim-1]) ;
	T* a = mat ;
	int n = dim ;

	T* origMat = 0 ;
	if( vec2 ){
		origMat = new T[dim*dim] ;
		memcpy( origMat,mat,sizeof(T)*dim*dim ) ;
	}

	int i, j, k ;
	T s,t,p,q ;
	T *v,*w ;

	for( k=0;k<n-2;++k ){
		v = &a[k*n] ; d[k] = v[k] ;
		e[k] = HouseholderTransform<T>( &v[k+1],n-k-1 ) ;
		if( e[k] == 0 ) continue ;
		for( i=k+1;i<n;++i ){
			s = 0 ;
			for( j=k+1;j<i;++j ) s+= a[j*n+i] * v[j] ;
			for( j=i  ;j<n;++j ) s+= a[i*n+j] * v[j] ;
			d[i] = s ;
		}
		t = DotProduct<T>( &v[k+1],&d[k+1],n-k-1 ) /2 ;

		for( i=n-1;i>k;--i ){
			p = v[i] ; q = d[i]-t*p; d[i] = q;
			for( j=i;j<n;++j )
				a[i*n+j] -= p*d[j] + q*v[j] ;
		}
	}

	if( n>= 2){
		d[n-2] = a[(n-2)*n+(n-2)] ;
		e[n-2] = a[(n-2)*n+(n-1)] ; }
	if( n>= 1)
		d[n-1] = a[(n-1)*n+(n-1)] ;
	for( k=n-1;k>=0;--k ){
		v = &a[k*n] ;
		if( k<n-2 ){
			for( i=k+1;i<n;++i ){
				w=&a[i*n] ;
				t=DotProduct<T>(&v[k+1],&w[k+1],n-k-1) ;
				for( j=k+1;j<n;++j )
					w[j] -= t*v[j] ;
			}
		}
		for( i=0;i<n;++i) v[i] = 0 ;
		v[k] = 1 ;
	}

	if(!vec1) delete[] d ;
	if(!vec2) delete[] e ;

	if( vec2 ){
#if 1
		// weird.. without this, vec2 is slightly different from the correct numbers.
		// this part causes much performce loss.
		T* matInv = new T[dim*dim] ;
		T* tmpMat = new T[dim*dim] ;
		T* triDiagonal = new T[dim*dim] ;

		SquareMat_Transpose<double>(mat,matInv,dim) ;
		SquareMat_MultMatrix<double>( mat,origMat,tmpMat,dim ) ;
		SquareMat_MultMatrix<double>( tmpMat,matInv,triDiagonal,dim ) ;
		for( int i=0;i<dim-1;++i ){
			vec2[i] = triDiagonal[i*dim+(i+1)] ;
		}
		delete[] matInv ;
		delete[] tmpMat ;
		delete[] triDiagonal ;
#endif
		delete[] origMat ;
	}
}

// mat is dim*dim matrix. the resulting eigen vectors are returned.
// outVec_EigenValues is a vector whose size is dim.
// outVec_EigenValues is in decreasing order.
template <class T> void CalcEigens( T* mat , T* outVec_EigenValues , int dim
								  ,const int MAXITER = 100 ){
	// without normalizing an input matrix, the result becomes very errornous (by owada)
	T* a = new T[dim*dim] ;

	T normalizeFactor ;
	{
		const T normalize_max = 100000 ;
		normalizeFactor = 0 ;
		for( int i=0;i<dim*dim;++i ){
			if( normalizeFactor < fabs(mat[i]) ) normalizeFactor = fabs(mat[i]) ;
		}
		normalizeFactor = normalize_max / normalizeFactor ;
		for( int i=0;i<dim*dim;++i ){
			a[i] = mat[i] * normalizeFactor ;
		}
	}

	T* d = outVec_EigenValues ;
	int n = dim ;
	T* e = new T[n] ;
	const T vsn = 1E-6 ;

	int i,j,k,h,iter ;
	double c,s,t,w,x,y ;

	Tridiagonize<T>( a,n,d,&e[1] ) ;
	e[0] = 0 ;
	for( h=n-1;h>0;--h ){
		j=h ;
		while( fabs(e[j]) > vsn * (fabs(d[j-1])+fabs(d[j])))
			--j ;
		if( j==h ) continue ;
		iter = 0 ;
		do{
			if( ++iter > MAXITER ) throw std::exception("Didn't converge.") ;
			w = (d[h-1]-d[h])/2 ;
			t=e[h]*e[h] ;
			s=sqrt(w*w+t); if(w<0) s=-s ;
			x=d[j]-d[h]+t/(w+s); y=e[j+1] ;
			for(k=j;k<h;++k){
				if( fabs(x) >= fabs(y) ){
					t=-y/x; c=1/sqrt(t*t+1) ;
					s=t*c;
				} else {
					t=-x/y; s=1/sqrt(t*t+1) ;
					c=t*s ;
				}
				w=d[k]-d[k+1] ;
				t=(w*s+2*c*e[k+1])*s ;
				d[k] -= t; d[k+1] += t ;
				if(k>j) e[k]=c*e[k]-s*y;
				e[k+1]+=s*(c*w-2*s*e[k+1]);

				// next five lines are not necessary if eigenvector is not required.
				for( i=0;i<n;++i ){
					x=a[k*n+i]; y=a[(k+1)*n+i] ;
					a[k*n+i] = c*x-s*y;
					a[(k+1)*n+i] = s*x+c*y ;
				}
				if( k<h-1){
					x=e[k+1]; y=-s*e[k+2] ;
					e[k+2] *= c ;
				}
			}
		} while( fabs(e[h]) > vsn*(fabs(d[h-1])+fabs(d[h]))) ;
	}

	// sort by eigen values
	for(k=0;k<n-1;++k){
		h=k;t=d[h] ;
		for( i=k+1;i<n;++i ){
			if(fabs(d[i])>fabs(t)){ h=i; t=d[h]; }
		}
		d[h] = d[k] ; d[k] = t ;
		memcpy( e,&a[h*n],sizeof(T)*n ) ;
		memcpy( &a[h*n],&a[k*n],sizeof(T)*n ) ;
		memcpy( &a[k*n],e,sizeof(T)*n ) ;
	}

	for( int i=0;i<n;++i ){
		outVec_EigenValues[i] /= normalizeFactor ;
	}
	memcpy( mat,a,sizeof(T)*n*n ) ;
	delete[] a ;
	delete[] e ;
}

// DataPoints is a matrix with dataNum*dataDim elements
// out_cent is a vector with dataDim elements. each DataPoint is ofset by this value.
// out_PCs is a matrix with dataDim*dataDim elements. principal components.
// DotProduct( &(DataPoints[i*dataDim]-out_cent),&out_PCs[j*dataDim],dataDim ) returns jth component of data_i.
template <class T> void PCA( T* DataPoints , int dataNum , int dataDim , T* out_PCs ,T* out_cent=0 ){
	int N = dataNum ;
	int P = dataDim ;
	T* cent = (out_cent?out_cent:new T[P]) ;
	memset( cent,0,sizeof(T)*P ) ;
	
	int i,j ;
	for( i=0;i<P;++i ){
		for( j=0;j<N;++j ){
			cent[i] += DataPoints[j*P+i] ;
		}
		cent[i] /= (T)N ;
	}

	T* covarianceMat = new T[P*P] ;

	int n ;
	for( i=0;i<P;++i ){
		for( j=0;j<P;++j ){
			T& tgt = covarianceMat[j*P+i] ;
			tgt = 0 ;
			for( n=0;n<N;++n ){
				tgt += (DataPoints[n*P+i]-cent[i]) * (DataPoints[n*P+j]-cent[j]) ;
			}
			tgt /= N-1 ;
		}
	}

	// find eigenvectors of covarianceMat.
	// the result is stored in JointCoefs in decreasing order of their eigenvalues.
	T* variances = new T[P] ;
	memcpy( out_PCs,covarianceMat,sizeof(T)*P*P ) ;
	CalcEigens<double>( out_PCs,variances,P ) ;

/*	{
		// check eigen vectors
		TRACE("\n") ;
		char buf[512] ;
		for( int i=0;i<P;++i ){
			double* eigenvec = &out_PCs[i*P] ;
			double eigenvalue = variances[i] ;

			double proj[3] ;
			SquareMat_MultVec<double>( covarianceMat,eigenvec,proj,3 ) ;
			sprintf(buf,"Eigenvalue%d:%f: (%f,%f,%f) -> (%f,%f,%f)\n",
				i,eigenvalue,
				eigenvec[0],eigenvec[1],eigenvec[2],
				proj[0]/eigenvalue,proj[1]/eigenvalue,proj[2]/eigenvalue ) ;
			TRACE("") ;
		}

	}*/

	delete[] variances ;
	delete[] covarianceMat ;
	if( !out_cent ) delete[] cent ;
}

inline int RoundOff(double a){ int sml = (int)floor(a) ; return a-(double)sml >= 0.5 ? sml+1 : sml ; }
inline int SmallestBeqPow2(int i){ int ret=1 ; while( ret<i ) ret<<=1 ; return ret; }
inline float rand_fl(){ return rand()/(float)(RAND_MAX-1) ; }
inline double RGBtoIntensity(unsigned char* col){
	return (1/3.0)*col[0] + (1/3.0)*col[1] + (1/3.0)*col[2] ;
}

// Poisson solver related
typedef double vec2d[2] ;
template <class T> class CImage {
public :
	CImage():pBits(0),width(-1),height(-1){}
	~CImage(){Clear();}
	void Clear(){
		if( pBits ){ delete[] pBits ; pBits=0; }
		width=height=-1 ;
	}
	void Allocate(int w,int h){
		Clear() ;
		pBits = new T[w*h] ;
		width = w ; height = h ;
	}

	T& GetPixel(int x,int y){
		if( pBits == 0 ) throw std::exception( "No image defined." ) ;
		if( x<0||x>=width || y<0||y>=height ) throw std::exception( "illegal access." ) ;
		return pBits[y*width+x] ;
	}
	T* GetPixelp(int x,int y){
		if( pBits == 0 ) throw std::exception( "No image defined." ) ;
		if( x<0||x>=width || y<0||y>=height ) throw std::exception( "illegal access." ) ;
		return &pBits[y*width+x] ;
	}

public :
	T* pBits ;
	int width,height ;
} ;

void SolvePoisson( CImage<vec2d>& v , CImage<double>& constraints_and_region , CImage<double>& result ) ;

#endif	// __ILMATH_H_INCLUDED__