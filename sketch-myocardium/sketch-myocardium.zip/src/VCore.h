#pragma once
#include "ILOGL.h"
#include "ILPolygonModel.h"
#include "ILUtil_KT.h"
#include "VState.h"
#include "VectorFieldsView.h"

#define NUMGRID_POW 5
#define NUMGRID (1 << NUMGRID_POW)
#define IXGRID(i, j, k) (((((i) << NUMGRID_POW) + (j)) << NUMGRID_POW) + (k))
#define NUMGRID_POW3 (1 << (NUMGRID_POW * 3))

//#define NUMGRID 48
//#define IXGRID(i, j, k) (((((i) * NUMGRID) + (j)) * NUMGRID) + (k))
//#define NUMGRID_POW3 (NUMGRID * NUMGRID * NUMGRID)

#define V_USE_LAPLACIAN
#define V_CALCBOUNDARY
#define V_ANIMATE
#define V_NUMITER 100
#define V_SUBDIVIDE 1

class SurfaceData
{
public:
	SurfaceData(void);
	
	bool isConstraint;
	ILVector3D field;
};

class VolumeData
{
public:
	VolumeData(void);
	
	bool isInner;
	bool isBound;
	bool isConstraint;
	bool isOnCrossSection;
	ILVector3D field;
	PointInfoOnPolygon pinfo;
};

class VCore
{
	VCore(void);
	VCore(const VCore&);
	~VCore(void);
	VCore& operator= (const VCore&);
public:	

	/* core */
	ILOGL m_ogl;
	ILPolygonModel_LOD m_poly;
	VState* m_state;
	
	CVectorFieldsView* m_pView;

	vector<bool> m_UndoFlags;
	vector<bool> m_RedoFlags;
	vector<pair<vector<ILVector3D>, vector<PointInfoOnPolygon> > >  m_RedoStrokesSurface;
	vector<vector<ILVector3D> > m_RedoStrokesVolume;
	
	static inline VCore* getInstance(){
		static VCore p;// = new VCore();
		return &p;
	}

	void Load3DModel(char* fname);
	
	vector<SurfaceData> m_sdata;
	
	vector<VolumeData> m_vdata;

	vector<ILVector3D> m_particle;
	//vector<ILVector3D> m_particleVelocity;

	int m_tick;
};
