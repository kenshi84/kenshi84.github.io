// VectorFieldsDoc.cpp : implementation of the CVectorFieldsDoc class
//

#include "stdafx.h"
#include "VectorFields.h"

#include "VectorFieldsDoc.h"
#include ".\vectorfieldsdoc.h"

#include "VMenuListener.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CVectorFieldsDoc

IMPLEMENT_DYNCREATE(CVectorFieldsDoc, CDocument)

BEGIN_MESSAGE_MAP(CVectorFieldsDoc, CDocument)
	ON_COMMAND(ID_FILE_LOAD3DMODEL, OnFileLoad3dmodel)
	ON_COMMAND(ID_FILE_EXPORTRESULT, OnFileExportresult)
	ON_COMMAND(ID_FILE_EXPORTVOLUME, OnFileExportvolume)
END_MESSAGE_MAP()


// CVectorFieldsDoc construction/destruction

CVectorFieldsDoc::CVectorFieldsDoc()
{
	// TODO: add one-time construction code here

}

CVectorFieldsDoc::~CVectorFieldsDoc()
{
}

BOOL CVectorFieldsDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
	fprintf(stderr, "NEW\n");
	VMenuListener::getInstance()->OnFileNew();

	return TRUE;
}




// CVectorFieldsDoc serialization

void CVectorFieldsDoc::Serialize(CArchive& ar)
{
	vector<vector<PointInfoOnPolygon> >& strokesSurface = VSurfaceDataManager::getInstance()->m_strokesPointInfo;
	vector<vector<ILVector3D> >& strokesVolume = VVolumeDataManager::getInstance()->m_strokes;
	int N, M;
	/*
	.vec file format
	#validity check
	number of polygons
	#surface data
	number of strokes on surface[int]
	number of points in the stroke[int]
	polyID[int]
	s[double]
	t[double]
	...
	#volume data
	number of strokes on volume[int]
	number of points in the stroke[int]
	coord x[double]
	coord y[double]
	coord z[double]
	...
	*/
	if (ar.IsStoring())
	{ 
		ar << (int)VCore::getInstance()->m_poly.polygons.size();
		N = (int)strokesSurface.size();
		ar << N;
		for (int i = 0; i < N; ++i) {
			M = (int)strokesSurface[i].size();
			ar << M;
			for (int j = 0; j < M; ++j) {
				ar << strokesSurface[i][j].polyID;
				ar << strokesSurface[i][j].s;
				ar << strokesSurface[i][j].t;
			}
		}
		N = (int)strokesVolume.size();
		ar << N;
		for (int i = 0; i < N; ++i) {
			M = (int)strokesVolume[i].size();
			ar << M;
			for (int j = 0; j < M; ++j) {
				ar << strokesVolume[i][j].data[0];
				ar << strokesVolume[i][j].data[1];
				ar << strokesVolume[i][j].data[2];
			}
		}
	}
	else
	{
		int numPoly;
		ar >> numPoly;
		m_isValidFile = (numPoly == (int)VCore::getInstance()->m_poly.polygons.size());
		if (!m_isValidFile) {
			GetRoutingFrame()->MessageBox("Selected file is inapproptiate for the current model.");
			return;
		}
		fprintf(stderr, "numPoly = %d\n", numPoly);
		vector<vector<ILVector3D> >& strokesSurface3D = VSurfaceDataManager::getInstance()->m_strokes3D;
		ar >> N;
		strokesSurface.resize(N);
		strokesSurface3D.resize(N);
		for (int i = 0; i < N; ++i) {
			ar >> M;
			strokesSurface[i].resize(M);
			strokesSurface3D[i].resize(M);
			for (int j = 0; j < M; ++j) {
				ar >> strokesSurface[i][j].polyID;
				ar >> strokesSurface[i][j].s;
				ar >> strokesSurface[i][j].t;
				strokesSurface3D[i][j] = strokesSurface[i][j].GetPosFromPolygonModel(VCore::getInstance()->m_poly);
			}
		}
		ar >> N;
		strokesVolume.resize(N);
		for (int i = 0; i < N; ++i) {
			ar >> M;
			strokesVolume[i].resize(M);
			for (int j = 0; j < M; ++j) {
				ar >> strokesVolume[i][j].data[0];
				ar >> strokesVolume[i][j].data[1];
				ar >> strokesVolume[i][j].data[2];
			}
		}
		VCore::getInstance()->m_ogl.RedrawWindow();
	}
}


// CVectorFieldsDoc diagnostics

#ifdef _DEBUG
void CVectorFieldsDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CVectorFieldsDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CVectorFieldsDoc commands

void CVectorFieldsDoc::OnFileLoad3dmodel()
{
	VMenuListener::getInstance()->OnFileLoad3DModel();
}

void CVectorFieldsDoc::OnFileExportresult()
{
	VMenuListener::getInstance()->OnFileExportResult();
}

void CVectorFieldsDoc::OnFileExportvolume()
{
	VMenuListener::getInstance()->OnFileExportVolume();
	//VMenuListener::getInstance()->OnFileSaveImage();
}
