#include "StdAfx.h"
#include ".\vcore.h"
#include "VStateDefault.h"
#include "VVolumeDataManager.h"
#include "VCrossSection.h"
#include "VSurfaceDataManager.h"

SurfaceData::SurfaceData(void)
{
	isConstraint = false;
	field = ILVector3D();
}

VolumeData::VolumeData(void)
{
	isInner = false;
	isBound = false;
	isConstraint = false;
	isOnCrossSection = false;
	pinfo = PointInfoOnPolygon();
	field = ILVector3D();
}

VCore::VCore(void)
{
	fprintf(stderr, "NUMGRID = %d\n", NUMGRID);
	m_vdata.resize(NUMGRID_POW3);
	
	//Load3DModel("default.obj");

	m_state = VStateDefault::getInstance();
}

VCore::~VCore(void)
{
}

void VCore::Load3DModel(char* fname) {
	fprintf(stderr, "Loading %s ... ", fname);
	
	m_poly.LoadPolygonFromFile(fname);
	NormalizeTo1x1x1Box(m_poly);
	m_poly.CalcWingedEdgeFromVerticesPolygons();
	
	fprintf(stderr, "Subdividing ...");
	for (int i = 0; i < V_SUBDIVIDE; ++i) {
		m_poly.subdivision();
		fprintf(stderr, ".");
	}

	//m_poly.ConstructLOD();
	//m_poly.Simplify(100);
	
	m_poly.CalcNormalFromPolygon();
	fprintf(stderr, " Completed!\n");
	
	m_sdata.resize((int)m_poly.vertices.size(), SurfaceData());
#ifdef V_CALCBOUNDARY
	VVolumeDataManager::getInstance()->SetBoundary();
#endif
	VCrossSection::getInstance()->m_vproj.resize(m_poly.vertices.size());
	VCrossSection::getInstance()->m_isHiddenVtx.resize(m_poly.vertices.size());
	VCrossSection::getInstance()->ClearHiddenVtx();
 	
#ifdef V_USE_LAPLACIAN
	VSurfaceDataManager::getInstance()->CalcLtL();
	VVolumeDataManager::getInstance()->CalcLtL();
#endif

	VCrossSection::getInstance()->ViewChanged();
	m_particle.clear();
}
