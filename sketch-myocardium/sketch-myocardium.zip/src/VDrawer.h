#pragma once
#include "VCore.h"

class VDrawer
{
public:
	VDrawer(void);
	~VDrawer(void);
	
	static inline VDrawer* getInstance(){
		static VDrawer p;;
		return &p;
	}

	/* draw function */
	void OnDraw();
	int m_flags;

	//ILVector3D m_v;

	static const _AXIS		= 0x1;
	static const _FACES		= 0x2;
	static const _EDGES		= 0x4;
	static const _VGRID		= 0x8;
	static const _SDATA		= 0x10;
	static const _VDATA		= 0x20;
	static const _SSTROKES	= 0x40;
	static const _VSTROKES	= 0x80;
	static const _CSSTROKE	= 0x100;
	static const _CSSHAPE	= 0x200;
	static const _PARTICLE	= 0x400;
	
private:
	void drawFaces();
	void drawAxis();
	void drawEdges();
	void drawSurfaceData();
	void drawStrokesOnSurface();
	void drawStrokesOnVolume();
	void drawVolumeGrid();
	void drawVolumeData();
	void drawStrokeCrossSection();
	void drawCrossSectionShape();
	void drawParticle();
	
	void drawArrow(ILVector3D& start, ILVector3D& ori);
	
	static const COL_EDGE				= 0x806040;
	static const COL_FACE				= 0x808080;
	static const COL_CROSSSECTION		= 0xFF0000;
	static const COL_DATA				= 0xFF8000;
	static const COL_DATA_CONSTRAINT	= 0x00FF80;
	static const COL_VGRID				= 0x00FF00;
	static const COL_STROKE				= 0x008080;
	static const COL_PARTICLE			= 0xFFFF00;
};
