#include "StdAfx.h"
#include ".\vstatedrawstrokeonsurface.h"
#include "VStateDefault.h"
#include "VSurfaceDataManager.h"
#include "VCrossSection.h"
#include "VMenuListener.h"

void VStateDrawStrokeOnSurface::OnLButtonDown(UINT nFlags, CPoint point) {
	fprintf(stderr, "State Error! - VStateDrawStrokeOnSurface::OnLButtonDown\n");
}

void VStateDrawStrokeOnSurface::OnLButtonUp(UINT nFlags, CPoint point) {
	VCore::getInstance()->m_state = VStateDefault::getInstance();
	VMenuListener::getInstance()->OnCommandSmoothOnSurface();
	//VMenuListener::getInstance()->OnCommandSmoothOnVolume();
}

void VStateDrawStrokeOnSurface::OnMouseMove(UINT nFlags, CPoint point) {
	PointInfoOnPolygon pinfo;
	if (!m_isValid) return;
	if (VCrossSection::getInstance()->GetIntersectionScreenCoordPolygonModel(point, pinfo)) {
		VSurfaceDataManager::getInstance()->AddPointToStroke(pinfo);
	} else
		m_isValid = false;

}
