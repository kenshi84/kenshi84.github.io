#include "StdAfx.h"
#include ".\kumfpacksquarematrix.h"
#include "SparseMatSolve/SparseMatSolve.h"
#include "SparseMatSolve/umfpack.h"

KUmfpackSquareMatrix::KUmfpackSquareMatrix() {
	m_isReadyToSolve = false;
	N = -1;
}

KUmfpackSquareMatrix::~KUmfpackSquareMatrix(void) {
}

void KUmfpackSquareMatrix::SetSize(int N) {
	this->N = N;
	cols.clear();
	cols.resize(N);
}

void KUmfpackSquareMatrix::SetElement(int row, int col, double val) {
	vector<int>& ind = cols[col].indices;
	vector<double>& coef = cols[col].coefficients;

	if (ind.empty()) {
		ind.push_back(row);
		coef.push_back(val);
		m_isReadyToSolve = false;
		return;
	}
	vector<int>::iterator iteri = ind.begin();
	vector<double>::iterator iterc = coef.begin();
	for (int i = 0; i < (int)ind.size(); ++i, ++iteri, ++iterc) {
		if (row < *iteri) {
			ind.insert(iteri, row);
			coef.insert(iterc, val);
			m_isReadyToSolve = false;
			return;
		} else if (row == *iteri) {
			*iterc = val;
			m_Ax[m_Ap[col] + i] = val;
			return;
		}
	}
	ind.push_back(row);
	coef.push_back(val);
	m_isReadyToSolve = false;
}

void KUmfpackSquareMatrix::AddElement(int row, int col, double val) {
	vector<int>& ind = cols[col].indices;
	vector<double>& coef = cols[col].coefficients;

	if (ind.empty()) {
		ind.push_back(row);
		coef.push_back(val);
		return;
	}
	vector<int>::iterator iteri = ind.begin();
	vector<double>::iterator iterc = coef.begin();
	for (int i = 0; i < (int)ind.size(); ++i, ++iteri, ++iterc) {
		if (row < *iteri) {
			ind.insert(iteri, row);
			coef.insert(iterc, val);
			m_isReadyToSolve = false;
			return;
		} else if (row == *iteri) {
			*iterc += val;
			m_Ax[m_Ap[col] + i] += val;
			return;
		}
	}
	ind.push_back(row);
	coef.push_back(val);
	m_isReadyToSolve = false;
}

double KUmfpackSquareMatrix::GetElement(int row, int col) {
	vector<int>& ind = cols[col].indices;
	vector<double>& coef = cols[col].coefficients;
	
	for (int i = 0; i < (int)ind.size(); ++i) {
		if (row == ind[i])
			return coef[i];
		if (row < ind[i])
			return 0.;
	}
	return 0.;
}

void KUmfpackSquareMatrix::InitializeToSolve() {
	fprintf(stderr, "initializing to solve...");
	int M = CountElements();
	
	m_Ap.resize(N+1);
	m_Ai.resize(M);
	m_Ax.resize(M);
	
	int pos = 0;
	for (int i = 0; i < N; ++i) {
		//fprintf(stderr, "i = %d\n", i);
		m_Ap[i] = pos;
		for (int j = 0; j < (int)cols[i].indices.size(); ++j) {
			m_Ai[pos] = cols[i].indices[j];
			m_Ax[pos] = cols[i].coefficients[j];
			++pos;
		}
	}
	m_Ap[N] = pos; // = M;
	
	m_isReadyToSolve = true;
}

void KUmfpackSquareMatrix::SolveLinearSystem(const double* b0, double* x0, const double* b1, double* x1, const double* b2, double* x2) {
	if (!m_isReadyToSolve) InitializeToSolve();
	
	double Control[UMFPACK_CONTROL];
	double Info[UMFPACK_INFO];
	//double *Control = (double*) NULL;
	umfpack_di_defaults(Control);
	Control[UMFPACK_STRATEGY] = UMFPACK_STRATEGY_SYMMETRIC;
	void *Symbolic, *Numeric ;
	
	fprintf(stderr, "symbolic...");
	(void) umfpack_di_symbolic (N, N, &m_Ap[0], &m_Ai[0], &m_Ax[0], &Symbolic, Control, Info) ;
	printUMFPACK_Info(Info);
	fprintf(stderr, "numeric...");
	(void) umfpack_di_numeric (&m_Ap[0], &m_Ai[0], &m_Ax[0], Symbolic, &Numeric, Control, Info) ;
	printUMFPACK_Info(Info);
	fprintf(stderr, "solve0...");
	(void) umfpack_di_solve (UMFPACK_A, &m_Ap[0], &m_Ai[0], &m_Ax[0], x0, b0, Numeric, Control, Info) ;
	printUMFPACK_Info(Info);
	fprintf(stderr, "solve1...");
	(void) umfpack_di_solve (UMFPACK_A, &m_Ap[0], &m_Ai[0], &m_Ax[0], x1, b1, Numeric, Control, Info) ;
	printUMFPACK_Info(Info);
	fprintf(stderr, "solve2...");
	(void) umfpack_di_solve (UMFPACK_A, &m_Ap[0], &m_Ai[0], &m_Ax[0], x2, b2, Numeric, Control, Info) ;
	printUMFPACK_Info(Info);
	umfpack_di_free_symbolic (&Symbolic) ;
	umfpack_di_free_numeric (&Numeric) ;
}

void printUMFPACK_Info(double Info[UMFPACK_INFO]) {
	if (Info[UMFPACK_STATUS] == UMFPACK_OK)
		fprintf(stderr, "OK");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_Ap0_nonzero)
		fprintf(stderr, "Ap0");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_argument_missing)
		fprintf(stderr, "argument missing");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_different_pattern)
		fprintf(stderr, "different_pattern");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_internal_error)
		fprintf(stderr, "internal_error");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_invalid_matrix)
		fprintf(stderr, "invalid_matrix");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_invalid_Numeric_object)
		fprintf(stderr, "invalid_Numeric_object");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_invalid_permutation)
		fprintf(stderr, "invalid_permutation");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_invalid_Symbolic_object)
		fprintf(stderr, "invalid_Symbolic_object");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_invalid_system)
		fprintf(stderr, "invalid_system");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_invalid_triplet)
		fprintf(stderr, "invalid_triplet");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_jumbled_matrix)
		fprintf(stderr, "jumbled_matrix");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_out_of_memory)
		fprintf(stderr, "out_of_memory");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_problem_too_large)
		fprintf(stderr, "problem_too_large");
	else if(Info[UMFPACK_STATUS] ==  UMFPACK_ERROR_row_index_out_of_bounds)
		fprintf(stderr, "row_index_out_of_bounds");
	else
		fprintf(stderr, "other_error");

	fprintf(stderr, ".");
}

void KUmfpackSquareMatrix::SolveLinearSystem(const double* b, double* x) {
	if (!m_isReadyToSolve) InitializeToSolve();
	
	double Control[UMFPACK_CONTROL];
	double Info[UMFPACK_INFO];
	//double *Control = (double*) NULL;
	umfpack_di_defaults(Control);
	Control[UMFPACK_STRATEGY] = UMFPACK_STRATEGY_SYMMETRIC;
	void *Symbolic, *Numeric ;
	
	(void) umfpack_di_symbolic (N, N, &m_Ap[0], &m_Ai[0], &m_Ax[0], &Symbolic, Control, Info) ;
	(void) umfpack_di_numeric (&m_Ap[0], &m_Ai[0], &m_Ax[0], Symbolic, &Numeric, Control, Info) ;
	(void) umfpack_di_solve (UMFPACK_A, &m_Ap[0], &m_Ai[0], &m_Ax[0], x, b, Numeric, Control, Info) ;
	if (Info[UMFPACK_STATUS] == UMFPACK_OK)
		fprintf(stderr, "UMFPACK_OK");
	umfpack_di_free_symbolic (&Symbolic) ;
	umfpack_di_free_numeric (&Numeric) ;
}

void KUmfpackSquareMatrix::MultSelfTransposeSelf(void) {
	vector<Ind_Coef> cols_tmp(cols);
	//for (int i = 0; i < N; ++i) {
	//	int m = (int)cols[i].indices.size();
	//	cols_tmp[i].indices.resize(m);
	//	cols_tmp[i].coefficients.resize(m);
	//	for (int j = 0; j < m; ++j) {
	//		cols_tmp[i].indices[j] = cols[i].indices[j];
	//		cols_tmp[i].coefficients[j] = cols[i].coefficients[j];
	//	}
	//}
	//vector<Ind_Coef> cols_tmp(cols);

	for (int i = 0; i < (int)cols.size(); ++i) {
		cols[i].indices.clear();
		cols[i].coefficients.clear();
	}

	//cols.clear();
	//cols.resize(N);
	for (int i = 0; i < N; ++i) {
		for (int j = i; j < N; ++j) {
			Ind_Coef& coli = cols_tmp[i];
			Ind_Coef& colj = cols_tmp[j];
			double tmp = 0;
			int ki = 0;
			int kj = 0;
			while(true) {
				if (ki == (int)coli.indices.size() || kj == (int)colj.indices.size()) {
					break;
				}
				if (coli.indices[ki] < colj.indices[kj]) {
					++ki;
				}else if (coli.indices[ki] > colj.indices[kj]) {
					++kj;
				}else {
					tmp += coli.coefficients[ki] * colj.coefficients[kj];
					++ki;
					++kj;
				}
			}
			if (tmp != 0) {
				SetElement(i, j, tmp);
				if (i != j) SetElement(j, i, tmp);
			}
		}
	}
	m_isReadyToSolve = false;
}

void KUmfpackSquareMatrix::Trace(void) {
	if (!m_isReadyToSolve) InitializeToSolve();
	
	//FILE* fp = fopen("tmp.txt", "w");
	FILE* fp = stderr;
	fprintf(fp, "Ap = {");
	for (int i = 0; i < (int)m_Ap.size(); ++i)
		fprintf(fp, "%d, ", m_Ap[i]);
	fprintf(fp, "}\nAi = {");
	for (int i = 0; i < (int)m_Ai.size(); ++i)
		fprintf(fp, "%d, ", m_Ai[i]);
	fprintf(fp, "}\nAx = {");
	for (int i = 0; i < (int)m_Ax.size(); ++i)
		fprintf(fp, "%f, ", m_Ax[i]);
	fprintf(fp, "}\n");
	//fclose(fp);
}

