#ifndef __IL_POLYGONMODEL_H_INCLUDED__
#define __IL_POLYGONMODEL_H_INCLUDED__

// Setup
#define ENABLE_LIGHTWAVE_OBJ_LOADER
#define ENABLE_ANN_IN_ILPolygonModel_Equal



#ifdef ENABLE_LIGHTWAVE_OBJ_LOADER
// make sure to put obj2.lib at accessible location
//#pragma comment(lib, "obj2.lib")
#endif	//ENABLE_LIGHTWAVE_OBJ_LOADER

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glaux.h>
#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glaux.lib")

#include "ILMath.h"

#include <queue>


class ILVertex 
{
public:
	ILVector3D pos,norm,uv ;
	int OneEdge ;

public:
	ILVertex():OneEdge(-1){}
	ILVertex( ILVertex* v ){
		*this = *v ;
	}
	ILVertex( const ILVector3D& p,const ILVector3D& n ){ pos=p ; norm=n ;}
	
public:
	//add
	inline ILVertex operator+(const ILVertex& v) const { return ILVertex(pos+v.pos,norm+v.norm) ;}
	inline ILVertex& operator+=(const ILVertex& v){ pos += v.pos ;norm += v.norm ;return *this ;}
	//subtract
	inline ILVertex operator-(const ILVertex& v) const {	return ILVertex(pos-v.pos,norm-v.norm) ;}
	inline ILVertex& operator-=(const ILVertex& v){pos -= v.pos ;norm -= v.norm;return *this ;}
	//multiply
	inline ILVertex operator*(double f) const{	return ILVertex(f*pos,f*norm) ; }
	inline friend ILVertex operator*(double f,const ILVertex& v){return ILVertex(f*(v.pos),f*(v.norm)) ;}
	inline ILVertex& operator*=(double f){	pos *= f;norm *= f;return *this ; }
	//divide
	inline ILVertex operator/(double f) const{ return ILVertex(pos/f,norm/f) ; }
	inline friend ILVertex operator/(double f,const ILVertex& v){	return v/f; }
	inline ILVertex& operator/=(double f){	pos/=f;	norm/=f; return *this ;}
} ;

class ILPolygon 
{
public:
	int vtx[3] ;		// vertices are stored counter-clockwise
	int edges[3] ;		// set only when calculating winged edge structure
	int patchid ;
	ILVector3D normal ;	// set only when CalcNormal() is performed

public:
	ILPolygon(){Setv(0,0,0,0);}
	ILPolygon( ILPolygon* p ){Set(p) ;}
	ILPolygon( const ILPolygon& p ){	Set(p) ; }
	ILPolygon operator=( const ILPolygon& p ){	Set(p) ; return *this ;	}

public:
	void Set(const ILPolygon* p){
		memcpy(vtx,p->vtx,sizeof(int)*3) ;
		memcpy(edges,p->edges,sizeof(int)*3) ;
		normal = p->normal ;
		patchid = p->patchid ;
	}
	void Set ( const ILPolygon& p){Set(&p) ;}
	void Setv( const int v1,const int v2,const int v3,const int patchid=0 ){vtx[0] = v1 ; vtx[1] = v2 ; vtx[2] = v3 ;this->patchid = patchid ;	}
	void Setv( const int v[3] ){memcpy( vtx,v,sizeof(int)*3 ) ; }

	void Flip() {	
		int tmp = vtx[1] ; vtx[1] = vtx[2] ; vtx[2] = tmp ;
		tmp = edges[1] ; edges[1] = edges[2] ; edges[2] = tmp ;
	}
	
	int GetTheOtherVertex(int vtx1,int vtx2){ return (vtx[0]==vtx1?(vtx[1]==vtx2?vtx[2]:vtx[1]):(
		vtx[0]==vtx2?(vtx[1]==vtx1?vtx[2]:vtx[1]):vtx[0])) ; }
	bool ReplaceVertexID(int src,int tgt){
		if     (src == vtx[0]) vtx[0] = tgt;
		else if(src == vtx[1]) vtx[1] = tgt;
		else if(src == vtx[2]) vtx[2] = tgt;
		else return false;
		return true;
	}
	bool ReplaceEdgeID(int src,int tgt){if(src==edges[0])edges[0]=tgt;else if
		(src==edges[1])edges[1]=tgt;else if(src==edges[2])edges[2]=tgt;else return false;return true;}

} ;

class ILWingedEdge {
public:
	bool bEdgeness ;//����臒l���אږʊԂ̊p�x���傫����ΐ�������
	int e[4] ;
	int p[2] ;	// Polygon IDs
	int v[2] ;	// Vertex IDs. v[0] is always smaller than v[1]
	// treated as a sharp edge. set if the angle between the two
	// neighboring two faces is grater than MarchingCubes::edgethreshold
	// before smoothing
	 
	/*
				     \    /
				 e[2] \  / e[0]
				       \/
				       . v[0] ( < v[1] )
				       |
				p[1]   |    p[0]
				       |
				       . v[1]
				       /\
				 e[3] /  \ e[1]
				     /    \
	*/
public:
	ILWingedEdge(){	e[0]=e[1]=e[2]=e[3]=p[0]=p[1]=v[0]=v[1]=-1 ; bEdgeness = false ; }
	ILWingedEdge(const ILWingedEdge& we){	Set(we) ;}

public:
	void Set(const ILWingedEdge& we)
	{
		e[0] = we.e[0] ; e[1] = we.e[1] ; e[2] = we.e[2] ; e[3] = we.e[3] ; 
		p[0] = we.p[0] ; p[1] = we.p[1] ; v[0] = we.v[0] ; v[1] = we.v[1] ;
		bEdgeness = we.bEdgeness ;
	}
	ILWingedEdge operator=(const ILWingedEdge& we){	Set(we) ;	return *this ;	}
	
	bool ReplaceVtxID( int src,int tgt ){
		if(v[0]==src)v[0]=tgt;else if(v[1]==src)v[1]=tgt;else return false;return true ;
	}

	inline void swapDirection(){
		int tmp;
		tmp = v[0];   v[0] = v[1];   v[1] = tmp;
		tmp = p[0];   p[0] = p[1];   p[1] = tmp;
		tmp = e[0];   e[0] = e[3];   e[3] = tmp;
		tmp = e[1];   e[1] = e[2];   e[2] = tmp;
	}

} ;

class ILPolygonModel  
{
public:
	vector < ILVertex >		vertices;
	vector < ILPolygon >	polygons;
	vector < ILWingedEdge > edges ;

	double edgethreshold ;
	int SmoothingTimes ;
	
	void SmoothingUsingLaplacian(int time);
	void subdivision();

public:
	ILPolygonModel() ;
	virtual ~ILPolygonModel();
	virtual void Copy(const ILPolygonModel* pm) ;

	bool Assert_Valid() ;

	void Clear(){
		edgethreshold=-1;SmoothingTimes=0;
		vertices.clear() ;polygons.clear();edges.clear();
	}


#ifdef _DEBUG
	void TRACE_structure() ;
#endif

	bool Equal(ILPolygonModel* pPol) ;
	void ComputeBBox(ILVector3D& vsmall,ILVector3D& vbig)
	{
		vsmall.Set(DBL_MAX,DBL_MAX,DBL_MAX) ; vbig.Set(-DBL_MAX,-DBL_MAX,-DBL_MAX) ;
		for( vector<ILVertex>::iterator sovit = vertices.begin();
		sovit != vertices.end() ; sovit++ ){
			ILVector3D& vp = (*sovit).pos ;
			for( int xyz=0 ; xyz<3 ; xyz++ ){
				if( vp[xyz] < vsmall[xyz] ) vsmall[xyz] = vp[xyz] ;
				if( vp[xyz] > vbig[xyz] ) vbig[xyz] = vp[xyz] ;
			}
		}
	}

	void TranslateAllVertices(const ILVector3D& shft)
	{
		for( vector<ILVertex>::iterator itv = vertices.begin() ;itv != vertices.end() ; itv++ ) 
			(*itv).pos += shft ;
	}
	void TransformAllVerticesByMatrix(ILMatrix16 mat,bool bApplyToNormal=false){
		for( vector<ILVertex>::iterator itv = vertices.begin() ;itv != vertices.end() ; itv++ )	
			(*itv).pos = mat*(*itv).pos ;
		if(bApplyToNormal)
		{ 
			assert(0); 
			return ;
		}
	}


	ILVector3D CalcNormalOfOnePolygon(int pol_id)
	{
		ILPolygon& p = polygons[pol_id] ;
		ILVector3D v1 = vertices[p.vtx[1]].pos-vertices[p.vtx[0]].pos ;
		ILVector3D v2 = vertices[p.vtx[2]].pos-vertices[p.vtx[0]].pos ;
		return (v1^v2).Normalize() ;
	}

		void FlipPolygons(){
		for( vector < ILPolygon >::iterator pit = polygons.begin() ; pit != polygons.end() ; pit++ ) (*pit).Flip() ;
		for( vector < ILVertex >::iterator vit = vertices.begin() ; vit != vertices.end() ; vit++ ) (*vit).norm = -(*vit).norm ;	
	}
	void FlipNormalOnly(){
		for( vector < ILVertex >::iterator vit = vertices.begin() ; vit != vertices.end() ; vit++ ) (*vit).norm = -(*vit).norm ; 
	}

	double GetPolygonArea(int pol_id){
		ILPolygon& p = polygons[pol_id] ;
		ILVector3D& v0 = vertices[p.vtx[0]].pos ;
		ILVector3D& v1 = vertices[p.vtx[1]].pos ;
		ILVector3D& v2 = vertices[p.vtx[2]].pos ;
		return ((v2-v0)^(v1-v0)).Length()*0.5 ;
	}
	double GetSurfaceArea(){
		double ret=0 ;
		for( int i=0;i<(int)polygons.size();i++ ) ret += GetPolygonArea(i) ;
		return ret ;
	}

	// default format is wavefront obj
	bool LoadPolygonFromFile(char* fname) ;
protected :
	void LoadPolygonFromFile_LoadRawFile(char* fname) ;
	bool LoadPolygonFromFile_LoadObjFile(char* fname) ;

//�R�����g�A�E�gby takashi
//#ifdef ENABLE_LIGHTWAVE_OBJ_LOADER 
//	bool LoadPolygonFromFileSub_LoadLWOFile(char* fname) ;
//#endif	//ENABLE_LIGHTWAVE_OBJ_LOADER

public:
	bool WriteObjFile(char* fname) ;
	void NormalizePolygon(double longest=1) ;
	void ZoomPolygon( double zoom,ILVector3D center ) ;
	bool WriteVRML1(const char * filename) ;
	void WriteRAWfile(const char * filename) ;
	void CalcWingedEdgeFromVerticesPolygons() ;
	void CalcNormalFromPolygon() ;// this method does not use ILPolygon::normal
	
	// Assume that edge is set.
	void GetStencilPolygonModelAroundEdge(int edgeID,ILPolygonModel* pResult) ;
	void GetStencilPolygonModelAroundVertex(int vertexID,ILPolygonModel* pResult,vector<int>* pVtxIDMap=0,vector<int>* pEdgeIDMap=0,vector<int>* pPolygonIDMap=0) ;

	//assume that model has boundary
	void GetInfoAroundVertexWithBoundary(int vertexID,ILPolygonModel* pResult,
										vector<int>* pVtxIDMap=0,
										vector<int>* pEdgeIDMap=0,
										vector<int>* pPolygonIDMap=0) ;		//���f�o�b�O
	void GetVerticesAroundVertexWithBounrary(int vertexID, vector<int>* targetVertices);
	void GetEdgesAroundVertexWithBoundary(int vertexID, vector<int>* targetEdges);		
	void GetEsVsAroundVertexWithBoundary(int vertexID, vector<int>* targetEdges,vector<int>* targetVertices);


public :
	enum RENDER_STYLE 
	{
		RS_SMOOTH_SHADED,RS_WIRE_FRAME,
	} ;
	void Render(RENDER_STYLE renderStyle = RS_SMOOTH_SHADED , unsigned int* pDispListIDStorage=0, unsigned char* color=0 ) ;
	static void Render_DeleteDispList(unsigned int& DispListID){ if(glIsList(DispListID)==GL_TRUE) glDeleteLists( DispListID,1 ) ;DispListID=0; }
	static void Render_DispList( unsigned int DispListID ){glCallList(DispListID) ;}

public:
	// edges[edgeid],edges[edges[edgeid].e[1]],edges[edges[edgeid].e[3]]
	// and vertices[edges[edgeid].v[1]],
	// polygons[edges[edgeid].p[0]],polygons[edges[edgeid].p[1]]
	// are simultaneously removed. However, whether the actual instances are
	// removed from array edges,vertices,polygons depends on the last argument.
	// And also note position of vertices[edges[edgeid].v[0]] is not changed.
	bool RemoveEdge(int edgeid,bool bTopologyOnly=false) ;
	bool RemoveEdgePossible(int edgeid) ;

	// The meaning of arguments are given in image file: ILPolygonModel_InsertEdge_TopologyOnly.gif
	bool InsertEdge_TopologyOnly(	int in_VtxID,		int in_EdgeID1,			int in_EdgeID2, 
									int& out_NewVtxID,	int& out_NewEdgeID1,	int& out_NewEdgeID2,
									int& out_NewEdgeID3,int& out_NewPolygonID1,	int& out_NewPolygonID2 ) ;
};

//////
////// ILPolygonModel_LOD : polygon simplification class (inherited from ILPolygonModel) ///////
////// this is a partial implementation of:
////// Garland & Heckbert "Surface Simplification Using Quadric Error Metrics", Siggraph 97
//////
//usage: Only two methods are used.
//
// ILPolygonModel_LOD::ConstructLOD()
// and
// ILPolygonModel_LOD::Simplify(int edgeNumToBeRemoved ) ;
//
// The Simplify method can be called only once after each call of ConstructLOD().
// The reason why I did not combine those two methods is that the user can save the
// LOD structure computed offline in ConstructLOD().
//
/*
//sample code:
void main(){
	ILPolygonModel_LOD lod_gen ;
	lod_gen.Copy((ILPolygonModel*)pSrc) ;
	lod_gen.ConstructLOD() ;
	...
	lod_gen.Simplify(edgeNumToBeRemoved) ;
}
*/


class ILPolygonModel_LOD : public ILPolygonModel 
{
public:
	ILPolygonModel_LOD():bSimplified(false){}
	virtual ~ILPolygonModel_LOD(){}

	// Simplify() method can be called only once after each call of ConstructLOD().
	void Simplify(int edgeNumToBeRemoved ) ;
	void CleanGarbage_AfterSimplification() ;
	void ConstructLOD() ;

protected :

	struct VertexExtDatum {
		bool bRemoved ;
		double Q[16] ;
		int v_idx ;
	} ;

	struct PolygonExtDatum {
		ILVector3D normal ;
		bool bRemoved ;
	} ;

	struct Edge_VPair {
		bool bRemoved ;
		double Q_bar[16] ;
		ILVector3D v_bar ;
		int edge ;
		double error ;
		int valid_id ;
	} ;

	typedef struct {
		int valid_id ;
		vector<Edge_VPair>* pEdgeExtData ;
		int VPair_id ;
		Edge_VPair& GetVPair(){ return (*pEdgeExtData)[VPair_id] ; }
	} EDGE_IN_PQUEUE;

	struct cmp_edge_in_pqueue : binary_function<EDGE_IN_PQUEUE,EDGE_IN_PQUEUE,bool> {
		bool operator()(EDGE_IN_PQUEUE& vp1,EDGE_IN_PQUEUE& vp2) {
			assert( vp1.pEdgeExtData == vp2.pEdgeExtData ) ;
			return vp1.GetVPair().error > vp2.GetVPair().error ;
		}
	};

protected:
	vector<VertexExtDatum>  VertexExtData ;
	vector<Edge_VPair>      EdgeExtData ;
	vector<PolygonExtDatum> PolygonExtData ;
	priority_queue<EDGE_IN_PQUEUE, deque<EDGE_IN_PQUEUE>, cmp_edge_in_pqueue> VPair_Heap ;
	
	bool bSimplified ;
	bool SimplifySub_OneStep() ;

	void RecalcExtDataAndHash(Edge_VPair& pair) ;

	// To proceed the heap,
	//
	//VPair_Heap.pop() ;
	//RemoveEdge(pair.edge,true) ;
	//RecalcExtDataAndHash(pair) ;
	//
	//should be called.
	Edge_VPair& GetNextVPair() ;

public :
	
	
	ILPolygonModel_LOD& operator=(const ILPolygonModel_LOD& src){
		ILPolygonModel::Copy( &src ) ;
		VertexExtData = src.VertexExtData ;
		EdgeExtData = src.EdgeExtData ;
		PolygonExtData = src.PolygonExtData ;
		bSimplified = src.bSimplified ;

		try {
			VPair_Heap_SetupFromEdgeExtData() ;
		} catch( std::exception& ){}
		return *this ;
	}
	void VPair_Heap_SetupFromEdgeExtData() ;
}  ;


#endif	//__IL_POLYGONMODEL_H_INCLUDED__
