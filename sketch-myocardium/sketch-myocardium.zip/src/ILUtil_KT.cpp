#include "StdAfx.h"
#include ".\ilutil_kt.h"

PointInfoOnPolygon::PointInfoOnPolygon(void)
{
	polyID = -1;
}

bool GetIntersectionScreenCoordPolygonModel(ILOGL& ogl, CPoint &point, ILPolygonModel& poly, PointInfoOnPolygon& result) {
	ILVector3D start, ori;
	ogl.k_GetScreenCoordToGlobalLine(point.x, point.y, start, ori);
	return GetIntersectionLinePolygonModel(start, ori, poly, result);
}

bool GetIntersectionLinePolygonModel(ILVector3D& start, ILVector3D& ori, ILPolygonModel& poly, PointInfoOnPolygon& result)
{
	double dmin = HUGE_VAL;
	bool isInterSec = false;
	for( int i = 0; i < (int) poly.polygons.size(); i++)
	{
		ILPolygon &p = poly.polygons[i];
		ILVector3D &n  = poly.vertices[p.vtx[0]].norm;
		ILVector3D &v0 = poly.vertices[p.vtx[0]].pos;
		ILVector3D &v1 = poly.vertices[p.vtx[1]].pos;
		ILVector3D &v2 = poly.vertices[p.vtx[2]].pos;
		double dp = ori * n;
		if (dp > 0) continue;
		/*
			start + x[0] * ori = (1 - x[1] - x[2]) * v0 + x[1] * v1 + x[2] * v2;
		*/
		//solve the 3-dimensional linear equation
		double src[9] = {
			ori.data[0], v0.data[0] - v1.data[0], v0.data[0] - v2.data[0],
			ori.data[1], v0.data[1] - v1.data[1], v0.data[1] - v2.data[1],
			ori.data[2], v0.data[2] - v1.data[2], v0.data[2] - v2.data[2]
		};
		double tgt[9];
		SquareMat_CalcInvMatrix<double>(src, tgt, 3);
		double b[3] = {
			v0.data[0] - start.data[0],
			v0.data[1] - start.data[1],
			v0.data[2] - start.data[2]
		};
		double x[3];
		SquareMat_MultVec<double>(tgt, b, x, 3);
		if (x[0] < dmin && x[1] > 0 && x[2] > 0 && x[1] + x[2] < 1) {
			dmin = x[0];
			result.polyID = i;
			result.s = x[1];
			result.t = x[2];
			isInterSec = true;
		}
	}
	return isInterSec;
}

bool CalcCrossEdge(const ILVector3D &start, const ILVector3D &e0, const ILVector3D &e1, const ILVector3D &v0, const ILVector3D &v1, const ILVector3D &v2, ILVector3D& ce_a, ILVector3D& ce_b) {
	double t0_a, t1_a, t0_b, t1_b;
	
	if (!CalcCrossEdge(start, e0, e1, v0, v1, v2, t0_a, t1_a, t0_b, t1_b)) return false;
	
	ce_a = start + t0_a * e0 + t1_a * e1;
	ce_b = start + t0_b * e0 + t1_b * e1;
	
	return true;
}

bool CalcCrossEdge(const ILVector3D &start, const ILVector3D &e0, const ILVector3D &e1, const ILVector3D &v0, const ILVector3D &v1, const ILVector3D &v2, double &t0_a, double &t1_a, double &t0_b, double &t1_b) {
/*
	��������̕�����
	start + t0 * e0 + t1 * e1 = s0 * v0 + s1 * v1 + s2 * v2     (s0 + s1 + s2 = 1)
	���ȉ��̏ꍇ�ɕ����ĉ���
	1. s0 = 0
		t0, t1, s1, s2 > 0. => crossing at 1-2
	2. s1 = 0
		t0, t1, s2, s0 > 0. => crossing at 2-0
	3. s2 = 0
		t0, t1, s0, s1 > 0. => crossing at 0-1
	����ɂ��̌�A��œ����_��
	2�R
		����2�_��cross-edge
	1�R
		1.
			t0 = 0�Ƃ��ĉ����As0, s1, s2 > 0 �Ȃ�t1������1�R�̓_
		2.
			t1 = 0�Ƃ��ĉ����As0, s1, s2 > 0 �Ȃ�t0������1�R�̓_
	0�R
		���1��2�������ɖ��������Ȃ炻���̓_
*/
	bool flag = false;
	double t0, t1, s0, s1, s2;
	
	// 1.s0 = 0
	double A0[9] = {
		e0.data[0], e1.data[0], -v1.data[0] + v2.data[0],
		e0.data[1], e1.data[1], -v1.data[1] + v2.data[1],
		e0.data[2], e1.data[2], -v1.data[2] + v2.data[2]
	};
	double b0[3] = {
		v2.data[0] - start.data[0],
		v2.data[1] - start.data[1],
		v2.data[2] - start.data[2]
	};
	double *x0 = SquareMat_SolveLinearByLU<double>(A0, b0, 3);
	//x0[3] = {t0, t1, s1}
	t0 = x0[0];
	t1 = x0[1];
	s1 = x0[2];
	delete [] x0;
	if (t0 > 0 && t1 > 0 && s1 > 0 && s1 < 1) {
		t0_a = t0;
		t1_a = t1;
		flag = true;
	}
	
	// 2.s1 = 0
	double A1[9] = {
		e0.data[0], e1.data[0], -v2.data[0] + v0.data[0],
		e0.data[1], e1.data[1], -v2.data[1] + v0.data[1],
		e0.data[2], e1.data[2], -v2.data[2] + v0.data[2]
	};
	double b1[3] = {
		v0.data[0] - start.data[0],
		v0.data[1] - start.data[1],
		v0.data[2] - start.data[2]
	};
	double *x1 = SquareMat_SolveLinearByLU<double>(A1, b1, 3);
	//x1[3] = {t0, t1, s2}
	t0 = x1[0];
	t1 = x1[1];
	s2 = x1[2];
	delete [] x1;
	if (t0 > 0 && t1 > 0 && s2 > 0 && s2 < 1) {
		if (!flag) {
			t0_a = t0;
			t1_a = t1;
		} else {
			t0_b = t0;
			t1_b = t1;
			return true;
		}
		flag = true;
	}

	// 3.s2 = 0
	double A2[9] = {
		e0.data[0], e1.data[0], -v0.data[0] + v1.data[0],
		e0.data[1], e1.data[1], -v0.data[1] + v1.data[1],
		e0.data[2], e1.data[2], -v0.data[2] + v1.data[2]
	};
	double b2[3] = {
		v1.data[0] - start.data[0],
		v1.data[1] - start.data[1],
		v1.data[2] - start.data[2]
	};
	double *x2 = SquareMat_SolveLinearByLU<double>(A2, b2, 3);
	//x2[3] = {t0, t1, s0}
	t0 = x2[0];
	t1 = x2[1];
	s0 = x2[2];
	delete [] x2;
	if (t0 > 0 && t1 > 0 && s0 > 0 && s0 < 1) {
		if (!flag) {
			t0_a = t0;
			t1_a = t1;
		} else {
			t0_b = t0;
			t1_b = t1;
			return true;
		}
		flag = true;
	}

	//t0 = 0
	double A3[9] = {
		e1.data[0], -v0.data[0] + v2.data[0], -v1.data[0] + v2.data[0],
		e1.data[1], -v0.data[1] + v2.data[1], -v1.data[1] + v2.data[1],
		e1.data[2], -v0.data[2] + v2.data[2], -v1.data[2] + v2.data[2]
	};
	double b3[3] = {
		v2.data[0] - start.data[0],
		v2.data[1] - start.data[1],
		v2.data[2] - start.data[2]
	};
	double *x3 = SquareMat_SolveLinearByLU<double>(A3, b3, 3);
	//x3[3] = {t1, s0, s1}
	t1 = x3[0];
	s0 = x3[1];
	s1 = x3[2];
	delete [] x3;
	if (s0 > 0 && s1 > 0 && 1 - s0 - s1 > 0) {
		if (!flag) {
			t0_a = 0;
			t1_a = t1;
		} else {
			t0_b = 0;
			t1_b = t1;
			return true;
		}
		flag = true;
	}

	//t1 = 0
	double A4[9] = {
		e0.data[0], -v0.data[0] + v2.data[0], -v1.data[0] + v2.data[0],
		e0.data[1], -v0.data[1] + v2.data[1], -v1.data[1] + v2.data[1],
		e0.data[2], -v0.data[2] + v2.data[2], -v1.data[2] + v2.data[2]
	};
	double b4[3] = {
		v2.data[0] - start.data[0],
		v2.data[1] - start.data[1],
		v2.data[2] - start.data[2]
	};
	double *x4 = SquareMat_SolveLinearByLU<double>(A4, b4, 3);
	//x3[3] = {t0, s0, s1}
	t0 = x4[0];
	s0 = x4[1];
	s1 = x4[2];
	delete [] x4;
	if (s0 > 0 && s1 > 0 && 1 - s0 - s1 > 0) {
		if (!flag) {
			t0_a = t0;
			t1_a = 0;
		} else {
			t0_b = t0;
			t1_b = 0;
			return true;
		}
		flag = true;
	}
	
	return false;
}
	
void NormalizeTo1x1x1Box(ILPolygonModel& poly) {
/* 
	Scale and translate the model so that it can be
	contained in the area (0,1)x(0,1)x(0,1)
*/
	ILVector3D vsmall, vbig;
	poly.ComputeBBox(vsmall, vbig);
	double smax = -DBL_MAX;
	for(int i = 0; i < 3; i++) {
		double s = vbig.data[i] - vsmall.data[i];
		if (smax < s) smax = s;
	}
	poly.TranslateAllVertices((-0.5) * (vsmall + vbig));
	poly.ZoomPolygon(0.9 / smax, ILVector3D());
	poly.TranslateAllVertices(ILVector3D(0.5,0.5,0.5));
}

void CalcCoefficientsOfImplicitFunction1D(double (*phi)(double x), vector<double>& constraints, vector<double>& heights, vector<double>& weights, double& p0, double& p1) {
	int N = (int)constraints.size();
	double *A = new double[(N+2)*(N+2)];
	for (int i = 0; i < N; ++i) {
		A[(N+2) * i + i] = 0;
		for (int j = i + 1; j < N; ++j)
			A[(N+2) * i + j] = A[(N+2) * j + i] = phi(constraints[i] - constraints[j]);
	}
	for (int i = 0; i < N; ++i) {
		A[(N+2) * i + N] = A[(N+2) * N + i] = 1;
		A[(N+2) * i + N + 1] = A[(N+2) * (N + 1) + i] = constraints[i];
	}
	A[(N+2) * N + N] = A[(N+2) * (N + 1) + N] = A[(N+2) * N + N + 1] = A[(N+2) * (N + 1) + (N + 1)] = 0;
	
	double *b = new double[N+2];
	for (int i = 0; i < N; ++i)
		b[i] = heights[i];
	b[N] = b[N+1] = 0;
	
	double* tmp = SquareMat_SolveLinearByLU<double>(A, b, N + 2);
	weights = vector<double>(N);
	for (int i = 0; i < N; ++i)
		weights[i] = tmp[i];
	p0 = tmp[N];
	p1 = tmp[N+1];

	delete[] tmp;
}

bool HasLoopInStroke(vector<CPoint> stroke) {
	if (stroke.size() < 4) return false;
	
	for (int i = 3; i < (int)stroke.size(); ++i) {
		double v0x, v0y, v1x, v1y;
		double w0x, w0y, w1x, w1y;
		v0x = stroke[i-1].x;
		v0y = stroke[i-1].y;
		v1x = stroke[i].x;
		v1y = stroke[i].y;
		w0x = stroke[0].x;
		w0y = stroke[0].y;
		for (int j = 0; j < i - 3; ++j) {
			w1x = stroke[j+1].x;
			w1y = stroke[j+1].y;
			if (v1x == w0x && v1y == w0y) return true;
			double a, b;
			Solve2x2Linear(v0x-v1x, -w0x+w1x, v0y-v1y, -w0y+w1y, -v1x+w1x, -v1y+w1y, a, b);
			if (0 < a && a < 1 && 0 < b && b < 1) return true;
		}
	}
	return false;
}

bool Solve2x2Linear(double m11, double m12, double m21, double m22, double b1, double b2, double& x1, double& x2) {
	double det = m11*m22 - m12*m21;
	if (abs(det) < 0.0000001) return false;
	double _det = 1. / det;
	x1 = _det * ( m22*b1 - m12*b2);
	x2 = _det * (-m21*b1 + m11*b2);
	return true;
}

void StrokeSmoothOnce(vector<CPoint>& stroke) {
	vector<CPoint> dummy = stroke;
	for (int i = 1; i < (int)stroke.size() - 1; ++i) {
		CPoint p0, p1, p2;
		p0 = dummy[i-1];
		p1 = dummy[i];
		p2 = dummy[i+1];
		stroke[i].x = (p0.x + 2 * p1.x + p2.x) / 4;
		stroke[i].y = (p0.y + 2 * p1.y + p2.y) / 4;
	}
}

void StrokeReplotEqualInterval(vector<CPoint>& stroke, int ndiv) {
}

void Bresenham(CPoint p1, CPoint p2, vector<CPoint>& plist) {
	plist.clear();
	int x1 = p1.x;
	int y1 = p1.y;
	int x2 = p2.x;
	int y2 = p2.y;
	
	int dx = x1 < x2 ? x2 - x1 : x1 - x2;
	int dy = y1 < y2 ? y2 - y1 : y1 - y2;
	
	double m, e;
	int x, y;
	int minx, miny;
	int maxx, maxy;
	
	if (dx > dy) {
		if (x1 < x2) {
			minx = x1;	miny = y1;
			maxx = x2;	maxy = y2;
		} else {
			minx = x2;	miny = y2;
			maxx = x1;	maxy = y1;
		}
		m = dy / (double)dx;
		e = 0;
		for (x = minx, y = miny; x <= maxx; ++x) {
			plist.push_back(CPoint(x, y));
			e += m;
			if (e < 0.5) continue;
			if (miny < maxy)
				++y;
			else
				--y;
			e -= 1;
		}
	} else {
		if (y1 < y2) {
			miny = y1;	minx = x1;
			maxy = y2;	maxx = x2;
		} else {
			miny = y2;	minx = x2;
			maxy = y1;	maxx = x1;
		}
		m = dx / (double)dy;
		e = 0;
		for (y = miny, x = minx; y <= maxy; ++y) {
			plist.push_back(CPoint(x, y));
			e += m;
			if (e < 0.5) continue;
			if (minx < maxx)
				++x;
			else
				--x;
			e -= 1;
		}
	}
}

bool GetIntersectionLinePlane(const ILVector3D& lpos, const ILVector3D& lori, const ILVector3D& ppos, const ILVector3D& pbase0, const ILVector3D& pbase1, double& lt, double& pt0, double& pt1) {
/*
	solve lt, pt0 and pt1 for lpos + lt * lori = ppos + pt0 * pbase0 + pt1 * pbase1
*/
	ILMatrix9 M(
		lori.data[0], -pbase0.data[0], -pbase1.data[0],
		lori.data[1], -pbase0.data[1], -pbase1.data[1],
		lori.data[2], -pbase0.data[2], -pbase1.data[2]);
	if(!M.getInvertSelf()) return false;
	ILVector3D v = M * (ppos - lpos);
	lt = v.data[0];
	pt0 = v.data[1];
	pt1 = v.data[2];

	return true;
}


bool IsRightSideOfStroke(CPoint& p, vector<CPoint>& plist) {
	double minDist = HUGE_VAL;
	int minID = -1;
	for (int i = 1; i < (int)plist.size()-1; ++i) {
		double dx = plist[i].x - p.x;
		double dy = plist[i].y - p.y;
		double r = dx*dx + dy*dy;
		if (minDist > r) {
			minDist = r;
			minID = i;
		}
	}
	ILVector3D a(
		p.x - plist[minID].x, 
		p.y - plist[minID].y, 
		0);
	ILVector3D b(
		plist[minID+1].x - plist[minID-1].x, 
		plist[minID+1].y - plist[minID-1].y, 
		0);
	ILVector3D c = a ^ b;
	return (c.data[2] < 0) ? true : false;
}
