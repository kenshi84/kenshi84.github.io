// ILPolygonModel.cpp: ILPolygonModel �N���X�̃C���v�������e�[�V����
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include <fstream>
#include <cfloat>
#include <cmath>
#include <algorithm>
#include <map>
#include <deque>

#include "ILPolygonModel.h"

#ifdef ENABLE_LIGHTWAVE_OBJ_LOADER
//#include "obj2/obj2.h"
#endif

/*
#ifdef ENABLE_ANN_IN_ILPolygonModel_Equal
#include <AnnTree_Simple.h>
#endif	// ENABLE_ANN_IN_ILPolygonModel_Equal
*/

/*
#if (_MSC_VER == 1200) && (WINVER < 0x0500)
extern "C" long _ftol( double ); //defined by VC6 C libs
extern "C" long _ftol2( double dblSource ) { return _ftol( dblSource );
}
#endif
*/

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// �\�z/����
//////////////////////////////////////////////////////////////////////

ILPolygonModel::ILPolygonModel():edgethreshold(-1),SmoothingTimes(0)
{

}

ILPolygonModel::~ILPolygonModel()
{
	Clear() ;
}//by Takashi
void ILPolygonModel::SmoothingUsingLaplacian(int time){
 ILVector3D  norm, gCenter, lapracian, uv; 
 vector<ILVector3D> newVerticesPosition( vertices.size() );
 vector<ILVector3D> newVerticesUV(       vertices.size() );
 vector<int> Vs,Es;

 for( int count = 0; count < time; ++count){

  for( int i = 0; i < (int) vertices.size(); ++i){
   
   Vs.clear(); 
   Es.clear();
   GetEsVsAroundVertexWithBoundary(i,&Es,&Vs);
   
   norm.   Set( vertices[i].norm );
   gCenter.Set(0,0,0);
   uv.     Set(0,0,0);

   for(int k = 0; k < (int)Vs.size(); ++k)  {
    gCenter += vertices[ Vs[k] ].pos;
    uv      += vertices[ Vs[k] ].uv ;
   }
   uv       /= (double) Vs.size();
   gCenter  /= (double) Vs.size();
   
   newVerticesUV[i].Set( uv );
   lapracian.SetSubtract( vertices[i].pos, gCenter);
   double t = lapracian * norm;
   newVerticesPosition[i].Set( t * norm + gCenter);
  }

  for(int i = 0 ; i < (int) vertices.size(); ++i)
  {
   vertices[i].pos = newVerticesPosition[i];
   vertices[i].uv  = newVerticesUV[i];
  }
 }

}



//by Takashi
//�T�u�f�B�r�W�������|����
void ILPolygonModel::subdivision()
{
 int newVertNum = (int)vertices.size() + (int)polygons.size();
 int oldVertNum = (int)vertices.size();

 vector<ILVertex>     OldVertices = vertices;
 vector<ILWingedEdge> OldEdges    = edges   ;
 vector<ILPolygon>    OldPolygons = polygons;

 //vertex�����
 vertices.resize(newVertNum);
 for(int i = 0; i < (int) OldVertices.size(); ++i) vertices[i] = 
OldVertices[i];

 for(int i = 0; i < (int) OldPolygons.size(); ++i){
  ILPolygon &p  = OldPolygons[     i    ];
  ILVertex  &v0 = OldVertices[ p.vtx[0] ];
  ILVertex  &v1 = OldVertices[ p.vtx[1] ];
  ILVertex  &v2 = OldVertices[ p.vtx[2] ];

  vertices[ oldVertNum + i ].pos. SetGravityCenter( v0.pos , v1.pos , v2.pos );
  //vertices[ oldVertNum + i ].norm.SetGravityCenter( v0.norm, v1.norm, v2.norm);
 }

 //polygon�����
 polygons.clear();
 for(int i = 0; i < (int) OldEdges.size(); ++i){
  ILPolygon p0, p1;

  ILWingedEdge &we = OldEdges[i];
 
  p0.vtx[0] = we.v[0];
  p0.vtx[1] = we.p[1] + oldVertNum;
  p0.vtx[2] = we.p[0] + oldVertNum;  
  p1.vtx[0] = we.v[1];
  p1.vtx[1] = we.p[0] + oldVertNum;
  p1.vtx[2] = we.p[1] + oldVertNum;

  polygons.push_back(p0);
  polygons.push_back(p1);
 }
 edges.clear();

 CalcWingedEdgeFromVerticesPolygons();
 SmoothingUsingLaplacian(2);
}

bool ILPolygonModel::Equal(ILPolygonModel* pPol)
{
	if( vertices.size() != pPol->vertices.size() ) return false ;
	if( polygons.size() != pPol->polygons.size() ) return false ;

	// Incomplete comparison

/* �R�����g�A�E�gby Takashi
#ifdef ENABLE_ANN_IN_ILPolygonModel_Equal
	CAnnTree_Simple<double,int> annTree ;
	annTree.Setup( 9 ) ;

	for( int pi=0;pi<(int)polygons.size();++pi ){
		ILPolygon& pol = polygons[pi] ;
		vector<double> s(9) ;
		for( int i=0;i<3;++i ) for( int j=0;j<3;++j )
			s[i*3+j] = vertices[pol.vtx[i]].pos[j] ;

		sort( s.begin(),s.end() ) ;
		
		double sd[9] ;
		for( int i=0;i<9;++i ) sd[i] = s[i] ;

		annTree.AddElement( sd, pi ) ;
	}
	annTree.ConstructSearchStructure() ;

	for( int pi=0;pi<(int)pPol->polygons.size();++pi ){
		ILPolygon& pol = pPol->polygons[pi] ;
		vector<double> s(9) ;
		for( int i=0;i<3;++i ) for( int j=0;j<3;++j )
			s[i*3+j] = pPol->vertices[pol.vtx[i]].pos[j] ;
		sort( s.begin(),s.end() ) ;
		double sd[9] ;
		for( int i=0;i<9;++i ) sd[i] = s[i] ;

		double dist ;
		annTree.FindMostSimilar( sd,&dist ) ;
		if( dist > VSN ) return false ;
	}
#endif
*/
	return true ;
}

void ILPolygonModel::Copy(const ILPolygonModel* pm){
	Clear() ;
	edges = pm->edges ;
	edgethreshold = pm->edgethreshold ;
	polygons = pm->polygons ;
	SmoothingTimes = pm->SmoothingTimes ;
	vertices = pm->vertices ;
}


bool ILPolygonModel::Assert_Valid(){
	CalcWingedEdgeFromVerticesPolygons() ;
	for( vector<ILWingedEdge>::iterator eit = edges.begin() ;
	eit != edges.end() ; eit++ ){
		ILWingedEdge& we = *eit ;
		if( we.p[0]==-1||we.p[1]==-1 ) continue ;
		ILPolygon& p1 = polygons[we.p[0]] ;
		ILPolygon& p2 = polygons[we.p[1]] ;
		if( p1.vtx[0] == p2.vtx[0] ){ assert( p1.vtx[1]==p2.vtx[2] || p1.vtx[2]==p2.vtx[1] ) ; }
		else if( p1.vtx[0] == p2.vtx[1] ){ assert( p1.vtx[1]==p2.vtx[0] || p1.vtx[2]==p2.vtx[2] ) ; }
		else if( p1.vtx[0] == p2.vtx[2] ){ assert( p1.vtx[1]==p2.vtx[1] || p1.vtx[2]==p2.vtx[0] ) ; }
		else if( p1.vtx[1] == p2.vtx[0] ){ assert( p1.vtx[2]==p2.vtx[2] ) ; }
		else if( p1.vtx[1] == p2.vtx[1] ){ assert( p1.vtx[2]==p2.vtx[0] ) ; }
		else { assert( p1.vtx[1] == p2.vtx[2] && p1.vtx[2] == p2.vtx[1] ) ; }
	}
	return true ;
}


void ILPolygonModel::CalcWingedEdgeFromVerticesPolygons()
{
	edges.clear() ;
	
	vector< list<int> > emanatingedges( vertices.size() ) ;
	for( int polygon_id = 0 ; polygon_id != polygons.size() ; polygon_id++ ){
		ILPolygon& p = polygons[polygon_id] ;
		static const edg_mat[3][2] = {{0,1},{1,2},{2,0}} ;
		
		{	
			// initial normal of the polygon
			ILVector3D vv1 = vertices[p.vtx[1]].pos - vertices[p.vtx[0]].pos;
			ILVector3D vv2 = vertices[p.vtx[2]].pos - vertices[p.vtx[0]].pos;

			p.normal = vv1^vv2;
			p.normal.Normalize_Self();
		}
		
		//edge�𐶐�patch��o�^
		for( int i = 0; i < 3; i++ )
		{
			ILWingedEdge _we ;
			_we.v[0] = p.vtx[edg_mat[i][0]] ;
			_we.v[1] = p.vtx[edg_mat[i][1]] ;

			bool bInverted = false ;
			if( _we.v[0] > _we.v[1] ){ bInverted = true ; int tmp = _we.v[0] ; _we.v[0] = _we.v[1] ; _we.v[1] = tmp ; }
			
			list<int>& emanating = emanatingedges[ _we.v[0] ] ;
			
			list<int>::iterator we_it ;
			for( we_it = emanating.begin() ; we_it != emanating.end() ; we_it++ ){
				if( edges[*we_it].v[1] == _we.v[1] )	break ;
			}
			if( we_it == emanating.end() ){
				edges.push_back( _we ) ;
				emanating.push_back( (int)edges.size()-1 ) ;
				emanatingedges[ _we.v[1] ].push_back( (int)edges.size()-1 ) ;
			}
			
			int edg_id = (we_it == emanating.end() ? (int)edges.size()-1 : *we_it ) ;
			ILWingedEdge& we = edges[edg_id] ;
			
			vertices[we.v[0]].OneEdge = vertices[we.v[1]].OneEdge = edg_id ;

			if( bInverted ) we.p[1] = polygon_id ;
			else			we.p[0] = polygon_id ;
			
			p.edges[i] = edg_id ;
		}
	}
	
	// may have bugs�@TODO �m�F
	//edge��o�^
	for( int polygon_id = 0 ; polygon_id != polygons.size() ; polygon_id++ )
	{
		ILPolygon& p = polygons[polygon_id] ;
		static const edg_mat[3][2] = {{0,1},{1,2},{2,0}} ;
		
		for( int i = 0; i < 3; i++ )
		{
			ILWingedEdge& we = edges[p.edges[i]] ;
			static const edgn_prev_next_mat[3][2] = {{2,1},{0,2},{1,0}} ;
			if( we.v[0] == p.vtx[edg_mat[i][0]] ){	// Not inverted
				assert( we.v[1] == p.vtx[edg_mat[i][1]] ) ;
				we.e[0] = p.edges[edgn_prev_next_mat[i][0]] ;
				we.e[1] = p.edges[edgn_prev_next_mat[i][1]] ;
			} else {
				assert( we.v[1] == p.vtx[edg_mat[i][0]] ) ;
				we.e[3] = p.edges[edgn_prev_next_mat[i][0]] ;
				we.e[2] = p.edges[edgn_prev_next_mat[i][1]] ;
			}
		}
	}
	
	if( edgethreshold <= -1 )
	{
		for( vector < ILWingedEdge >::iterator we_vit = edges.begin() ;
		we_vit != edges.end() ; we_vit++ ){
			(*we_vit).bEdgeness = false ;
		}
	} else {
		for( vector < ILWingedEdge >::iterator we_vit = edges.begin() ;
		we_vit != edges.end() ; we_vit++ ){
			(*we_vit).bEdgeness = (
				polygons[(*we_vit).p[0]].normal[0]*polygons[(*we_vit).p[1]].normal[0] +
				polygons[(*we_vit).p[0]].normal[1]*polygons[(*we_vit).p[1]].normal[1] +
				polygons[(*we_vit).p[0]].normal[2]*polygons[(*we_vit).p[1]].normal[2]
				< edgethreshold ) ;
		}
	}

	vector< vector<double> > lap( vertices.size() ) ;
	const double lambda = 0.63,mew = -0.67 ;
	
	for( int vid=0;vid<(int)lap.size();vid++ ){
		lap[vid].resize(3) ;
	}
	
	for( int sm=0 ; sm < SmoothingTimes ; sm++ ){
		for( int vid=0;vid<(int)lap.size();vid++ ){
			lap[vid][0] = lap[vid][1] = lap[vid][2] = 0 ;
		}
		for( int vid=0;vid<(int)lap.size();vid++ ){
			ILVertex& vt = vertices[vid] ;
			double denom = 0 ;
			for( list<int>::iterator iilit = emanatingedges[vid].begin() ;
			iilit != emanatingedges[vid].end() ; iilit++ ){
				ILWingedEdge& wee = edges[ *iilit ] ;
				ILVertex& vt2 = vertices[ (wee.v[0] == vid ? wee.v[1] : wee.v[0]) ] ;
				double dist = sqrt( (vt.pos[0]-vt2.pos[0])*(vt.pos[0]-vt2.pos[0])
					+ (vt.pos[1]-vt2.pos[1])*(vt.pos[1]-vt2.pos[1])
					+ (vt.pos[2]-vt2.pos[2])*(vt.pos[2]-vt2.pos[2]) ) ;
				
				lap[vid][0] += dist * (vt2.pos[0] - vt.pos[0] ) ;
				lap[vid][1] += dist * (vt2.pos[1] - vt.pos[1] ) ;
				lap[vid][2] += dist * (vt2.pos[2] - vt.pos[2] ) ;
				denom += dist ;
			}
			lap[vid][0] /= denom ;
			lap[vid][1] /= denom ;
			lap[vid][2] /= denom ;
		}
		// Shrinkage
		for( int vid=0;vid<(int)lap.size();vid++ ){
			vertices[vid].pos[0] += lambda * lap[vid][0] ;
			vertices[vid].pos[1] += lambda * lap[vid][1] ;
			vertices[vid].pos[2] += lambda * lap[vid][2] ;
		}
#if 0
		for( int vid=0;vid<(int)lap.size();vid++ ){
			lap[vid][0] = lap[vid][1] = lap[vid][2] = 0 ;
		}
		for( int vid=0;vid<(int)lap.size();vid++ ){
			ILVertex& vt = vertices[vid] ;
			double denom = 0 ;
			for( list<int>::iterator iilit = emanatingedges[vid].begin() ;
			iilit != emanatingedges[vid].end() ; iilit++ ){
				ILWingedEdge& wee = edges[ *iilit ] ;
				ILVertex& vt2 = vertices[ (wee.v[0] == vid ? wee.v[1] : wee.v[0]) ] ;
				double dist = sqrt( (vt.pos[0]-vt2.pos[0])*(vt.pos[0]-vt2.pos[0])
					+ (vt.pos[1]-vt2.pos[1])*(vt.pos[1]-vt2.pos[1])
					+ (vt.pos[2]-vt2.pos[2])*(vt.pos[2]-vt2.pos[2]) ) ;
				
				lap[vid][0] += dist * (vt2.pos[0] - vt.pos[0] ) ;
				lap[vid][1] += dist * (vt2.pos[1] - vt.pos[1] ) ;
				lap[vid][2] += dist * (vt2.pos[2] - vt.pos[2] ) ;
				denom += dist ;
			}
			lap[vid][0] /= denom ;
			lap[vid][1] /= denom ;
			lap[vid][2] /= denom ;
		}
		// Un-shrink
		for( int vid=0;vid<lap.size();vid++ ){
			vertices[vid].pos[0] += mew * lap[vid][0] ;
			vertices[vid].pos[1] += mew * lap[vid][1] ;
			vertices[vid].pos[2] += mew * lap[vid][2] ;
		}
#endif
	}
}




void ILPolygonModel::LoadPolygonFromFile_LoadRawFile(char* fname){
	FILE* fp = fopen( fname,"r" ) ;
	if( !fp )	throw std::exception("Can't load file") ;

	int vnum,pnum ;
	char buf[256] ;

	// Read first line
	fgets( buf,255,fp ) ;
	if( sscanf( buf,"%d %d",&vnum,&pnum ) != 2 ){
		fclose(fp) ;
		throw std::exception("Illegal file") ;
	}

	Clear() ;
	// set size
	vertices.resize( vnum ) ;
	polygons.resize( pnum ) ;


	{	// read vertices
		float fl[3] ;
		for( int i=0;i<vnum;++i ){
			if( fgets( buf,255,fp ) == 0 ){
				fclose(fp);throw std::exception("Illegal file") ;
			}
			if( sscanf( buf,"%f %f %f",&fl[0],&fl[1],&fl[2] ) != 3 ){
				fclose(fp) ;
				throw std::exception("Illegal file") ;
			}

			vertices[i].pos.Set( fl[0],fl[1],fl[2] ) ;
		}
	}

	{	// read triangles
		for( int i=0;i<pnum;++i ){
			if( fgets( buf,255,fp ) == 0 ) throw std::exception("Illegal file") ;
			if( sscanf( buf,"%d %d %d",&polygons[i].vtx[0],&polygons[i].vtx[1],&polygons[i].vtx[2] ) != 3 ){
				fclose(fp) ;
				throw std::exception("Illegal file") ;
			}
		}
	}

	fclose(fp) ;

	CalcWingedEdgeFromVerticesPolygons() ;
}


//Currently the function only read the positions of vertices
// modified by Takashi
bool ILPolygonModel::LoadPolygonFromFile_LoadObjFile(char* fname)
{
	FILE* fp = fopen(fname,"r") ;
	if( !fp ) return false;//	throw std::exception( "Can't load file" ) ;

	vector<ILPolygon>  pols_l ;
	vector<ILVertex>	 vtxs_l ;

	vector<ILVector3D> UVs ;
	vector<ILPolygon>  tmpPolForUV;
	bool uContainMinus = false, 
		 vContainMinus = false;

	char buf[256] ;
	while(fgets(buf,255,fp)){//��s�ǂ�
		char bkup[256];
//		char* bkup = _strdup(buf) ;        //��������R�s�[
		strncpy(bkup, buf, 256);
		char* token = strtok( buf, " \t" );//�ŏ��̃g�[�N�����擾

		if( stricmp( token,"vt" ) == 0 )
		{
			// Texture coordinate
			float vp[2] ;
			ILVector3D vt ;
			sscanf( bkup,"vt %f %f",&vp[0],&vp[1] ) ;
			if(vp[0] < 0) uContainMinus = true;
			if(vp[1] < 0) vContainMinus = true;
			vt.Set( vp[0],vp[1],0 ) ;
			UVs.push_back( vt ) ;
		} 
		else if( stricmp( token,"v" ) == 0 )
		{
			// Vertex location
			float vp[3] ;
			ILVertex v ;
			sscanf( bkup,"v %f %f %f",&vp[0],&vp[1],&vp[2] ) ;
			v.pos.Set( vp[0],vp[1],vp[2] ) ;
			vtxs_l.push_back( v ) ;
		} 
		else if( stricmp( token,"f" ) == 0 )
		{
			// Polygon 
			ILPolygon p ;
			ILPolygon pUV;
			int vtx3 ;
			int vtxnum = sscanf( bkup,"f %d %d %d %d", &p.vtx[0], &p.vtx[1], &p.vtx[2], &vtx3) ;//sscanf�̕Ԃ�l�͐���ɓǂ߂��t�B�[���h�� (/����������2�t�B�[���h�����ǂ߂Ȃ�)
			if( vtxnum < 3 ){
				int tmp ;
				vtxnum = sscanf( bkup,"f %d/%d %d/%d %d/%d %d/%d" ,&p.vtx[0], &pUV.vtx[0],
					                                               &p.vtx[1], &pUV.vtx[1],
																   &p.vtx[2], &pUV.vtx[2],
																   &vtx3,     &tmp)/2 ;
			}
			if( vtxnum < 3 ){
				int tmp ;
				vtxnum = sscanf( bkup,"f %d/%d/%d %d/%d/%d %d/%d/%d %d/%d/%d"
					,&p.vtx[0], &pUV.vtx[0], &tmp,
					 &p.vtx[1], &pUV.vtx[1] ,&tmp,
					 &p.vtx[2], &pUV.vtx[2] ,&tmp,
					 &vtx3,     &tmp,        &tmp)/3 ;
			}

			if( vtxnum < 3 ){
				int tmp ;
				vtxnum = sscanf( bkup,"f %d//%d %d//%d %d//%d %d//%d"
					,&p.vtx[0],&tmp,  &p.vtx[1], &tmp,   &p.vtx[2],&tmp,  &vtx3,&tmp)/2 ;
			}


			// Discard 4th vertex (id is in vtx3)
			--p.vtx[0]   ; --p.vtx[1]   ; --p.vtx[2]   ;
			--pUV.vtx[0] ; --pUV.vtx[1] ; --pUV.vtx[2] ;

			pols_l.push_back( p ) ;
			tmpPolForUV.push_back(pUV) ;
		}
//		free(bkup) ;
	}
	
	fclose(fp) ;

	this->Clear() ;

	//vertices.resize( vtxs_l.size() );
	//polygons.resize( pols_l.size() );
	//for(int i = 0; i < (int)vertices.size(); ++i)
	//	vertices[i] = vtxs_;
	//for(int i = 0; i < (int)polygons.size(); ++i)
	//	polygons[i] = pols_l[i];

	//	copy<ILVertex>( vtxs_l,vertices ) ;
	//vertices.resize(vtxs_l.size());
	//std::copy(vtxs_l.begin(), vtxs_l.end(), vertices.begin());
	vertices.swap(vtxs_l);

	//copy<ILPolygon>( pols_l,polygons ) ;
	//polygons.resize(pols_l.size());
	//std::copy(pols_l.begin(), pols_l.end(), polygons.begin());
	polygons.swap(pols_l);

	//texture coordinate���Z�b�g
	if( UVs.size() != 0){

		if( uContainMinus) for(int i = 0; i < (int) UVs.size(); ++i) UVs[i].data[0] += 1.0;
		if( vContainMinus) for(int i = 0; i < (int) UVs.size(); ++i) UVs[i].data[1] += 1.0;
		
		for(int i = 0; i < (int)tmpPolForUV.size(); ++i){ //vector<ILPolygon>::iterator it = tmpPolForUV.begin(); it != tmpPolForUV.end(); ++it){
			vertices[ polygons[i].vtx[0] ].uv = UVs[ tmpPolForUV[i].vtx[0] ];
			vertices[ polygons[i].vtx[1] ].uv = UVs[ tmpPolForUV[i].vtx[1] ];
			vertices[ polygons[i].vtx[2] ].uv = UVs[ tmpPolForUV[i].vtx[2] ];
		}
	}

	return true;
}


/*
//original
void ILPolygonModel::LoadPolygonFromFile_LoadObjFile(char* fname)
{
	FILE* fp = fopen(fname,"r") ;
	if( !fp )	throw std::exception( "Can't load file" ) ;

	list<ILPolygon> pols_l ;
	list<ILVertex>	vtxs_l ;

	char buf[256] ;
	while(fgets(buf,255,fp)){//��s�ǂ�

		char* bkup = _strdup(buf) ;        //��������R�s�[
		char* token = strtok( buf, " \t" );//�ŏ��̃g�[�N�����擾

		if( stricmp( token,"vt" ) == 0 )
		{
			// Texture coordinate
		} 
		else if( stricmp( token,"v" ) == 0 )
		{
			// Vertex location
			float vp[3] ;
			ILVertex v ;
			sscanf( bkup,"v %f %f %f",&vp[0],&vp[1],&vp[2] ) ;
			v.pos.Set( vp[0],vp[1],vp[2] ) ;
			vtxs_l.push_back( v ) ;
		} 
		else if( stricmp( token,"f" ) == 0 )
		{
			// Polygon 
			ILPolygon p ;
			int vtx3 ;
			int vtxnum = sscanf( bkup,"f %d %d %d %d", &p.vtx[0], &p.vtx[1], &p.vtx[2], &vtx3) ;//sscanf�̕Ԃ�l�͐���ɓǂ߂��t�B�[���h�� (/����������2�t�B�[���h�����ǂ߂Ȃ�)
			if( vtxnum < 3 )
			{
				int tmp ;
				vtxnum = sscanf( bkup,"f %d/%d %d/%d %d/%d %d/%d" ,&p.vtx[0],&tmp,&p.vtx[1],&tmp,&p.vtx[2],&tmp,&vtx3,&tmp)/2 ;
			}
			if( vtxnum < 3 ){
				int tmp ;
				vtxnum = sscanf( bkup,"f %d/%d/%d %d/%d/%d %d/%d/%d %d/%d/%d"
					,&p.vtx[0],&tmp,&tmp,&p.vtx[1],&tmp,&tmp,&p.vtx[2],&tmp,&tmp,&vtx3,&tmp,&tmp)/3 ;
			}

			// Discard 4th vertex (id is in vtx3)
			--p.vtx[0] ; --p.vtx[1] ; --p.vtx[2] ;

			pols_l.push_back( p ) ;
		}
		free(bkup) ;
	}
	
	fclose(fp) ;

	this->Clear() ;

	copy<ILVertex>( vtxs_l,vertices ) ;
	copy<ILPolygon>( pols_l,polygons ) ;
}
*/














#ifdef  ENABLE_LIGHTWAVE_OBJ_LOADER

//tempolary deleted by takashi.

#endif	//ENABLE_LIGHTWAVE_OBJ_LOADER

// implicitfunc�Ƃ��͂Ƃ������A�Ƃ肠�����|���S����vertices,edges,polygons�ɓǂݍ��ށB
bool ILPolygonModel::LoadPolygonFromFile(char* fname){

	string str(fname) ;
	if( stricmp(".raw",str.substr( str.length()-4,str.length()-1 ).c_str()) == 0 ){
		//LoadPolygonFromFile_LoadRawFile(fname) ;
		//CalcWingedEdgeFromVerticesPolygons() ;
		return false;
	} else if( stricmp(".obj",str.substr( str.length()-4,str.length()-1 ).c_str()) == 0 ){
		return LoadPolygonFromFile_LoadObjFile(fname);;			
		//CalcWingedEdgeFromVerticesPolygons() ;

//�R�����g�A�E�g by Takashi
//#ifdef ENABLE_LIGHTWAVE_OBJ_LOADER
//		} else if( stricmp(".lwo",str.substr( str.length()-4,str.length()-1 ).c_str()) == 0 ){
//			LoadPolygonFromFileSub_LoadLWOFile(fname) ;
//			return ;
//#endif
	}

	return false;
}

bool ILPolygonModel::WriteObjFile(char* fname){
	FILE* fp = fopen(fname,"w") ;
	if( !fp )	return false ;
	fprintf(fp,"#Polygon model by ILPolygonModel\n") ;
	for( int i=0;i<(int)vertices.size() ; i++ ){
		ILVertex& v = vertices[i] ;
		fprintf(fp,"v %f %f %f\n",v.pos[0],v.pos[1],v.pos[2]) ;
	}
	for( int i=0;i<(int)polygons.size();i++ ){
		ILPolygon& p = polygons[i] ;
		fprintf(fp,"f %d %d %d\n",p.vtx[0]+1,p.vtx[1]+1,p.vtx[2]+1) ;
	}
	fclose(fp) ;
	return true ;
}

bool ILPolygonModel::WriteVRML1(const char * filename)
{
	ofstream oFile(filename);
	if (!oFile.is_open()) return false;

	oFile << "#VRML V1.0 ascii\n\nSeparator {\n\tCoordinate3 {\n\t\tpoint [" << endl;

	vector<ILVertex>::iterator itv;
	for (itv = vertices.begin(); itv != vertices.end(); itv++)
	{
		oFile << "\t\t\t" << (*itv).pos[0] << "\t" << (*itv).pos[1] << "\t" << (*itv).pos[2] << "," << endl;
	}

	oFile << "\t\t]\n\t}\n\tIndexedFaceSet {\n\t\tcoordIndex [" << endl;

	vector<ILPolygon>::iterator itp;
	for (itp = polygons.begin(); itp != polygons.end(); itp++)
	{
		oFile << "\t\t\t" << (*itp).vtx[0] << ",\t" << (*itp).vtx[1] << ",\t";
		oFile << (*itp).vtx[2] << ",\t-1," << endl;
	}
	oFile << "\t\t]\n\t}\n}" << endl;

	oFile.close();

	return true;
}

void ILPolygonModel::WriteRAWfile(const char* fname){
	FILE* fp = fopen(fname,"w") ;
	if( !fp ) throw std::exception( "cannot open file." ) ;

	fprintf(fp,"%d %d\n",vertices.size(),polygons.size()) ;
	for( int i=0;i<(int)vertices.size() ; i++ ){
		ILVertex& v = vertices[i] ;
		fprintf(fp,"%f %f %f\n",v.pos[0],v.pos[1],v.pos[2]) ;
	}
	for( int i=0;i<(int)polygons.size();i++ ){
		ILPolygon& p = polygons[i] ;
		fprintf(fp,"%d %d %d\n",p.vtx[0],p.vtx[1],p.vtx[2]) ;
	}
	fclose(fp) ;
}


void ILPolygonModel::NormalizePolygon(double longest){
	double bbox[3][2] = {{FLT_MAX,-FLT_MAX},{FLT_MAX,-FLT_MAX},{FLT_MAX,-FLT_MAX}} ;
	for( vector<ILVertex>::iterator v_it = vertices.begin() ;
	v_it != vertices.end() ; v_it++ ){
		ILVertex v = *v_it ;
		if( v.pos[0] < bbox[0][0] )	bbox[0][0] = v.pos[0] ;
		if( v.pos[0] > bbox[0][1] )	bbox[0][1] = v.pos[0] ;
		if( v.pos[1] < bbox[1][0] )	bbox[1][0] = v.pos[1] ;
		if( v.pos[1] > bbox[1][1] )	bbox[1][1] = v.pos[1] ;
		if( v.pos[2] < bbox[2][0] )	bbox[2][0] = v.pos[2] ;
		if( v.pos[2] > bbox[2][1] )	bbox[2][1] = v.pos[2] ;
	}
	double len[3] = {
		bbox[0][1]-bbox[0][0],bbox[1][1]-bbox[1][0],bbox[2][1]-bbox[2][0]
	} ;
	double cent[3] = {
		0.5*(bbox[0][1]+bbox[0][0]),0.5*(bbox[1][1]+bbox[1][0]),0.5*(bbox[2][1]+bbox[2][0])
	} ;
	double scale = longest/MAX3(len[0],len[1],len[2]) ;

	for( vector<ILVertex>::iterator v_it = vertices.begin() ;
	v_it != vertices.end() ; v_it++ ){
		ILVertex& v = *v_it ;
		v.pos[0] = scale * (v.pos[0]-cent[0]) ;
		v.pos[1] = scale * (v.pos[1]-cent[1]) ;
		v.pos[2] = scale * (v.pos[2]-cent[2]) ;
	}
}

void ILPolygonModel::ZoomPolygon( double zoom,ILVector3D center ){
	if( zoom==1 )	return ;
	for( vector<ILVertex>::iterator v_it = vertices.begin() ;
	v_it != vertices.end() ; v_it++ ){
		ILVector3D& v = (*v_it).pos ;
		v = zoom * (v - center) + center ;
	}
}



void ILPolygonModel::CalcNormalFromPolygon(){
	vector < ILVertex >::iterator itv;
	vector < ILPolygon >::iterator itp;

	for (itv = vertices.begin(); itv != vertices.end(); itv++) itv->norm.Set(0,0,0);
	
	for (itp = polygons.begin(); itp != polygons.end(); itp++)
	{
		ILVertex *v[3];
		v[0] = &vertices[itp->vtx[0]];
		v[1] = &vertices[itp->vtx[1]];
		v[2] = &vertices[itp->vtx[2]];
		
		double dv[2][3];
		
		for (int i = 0; i < 3; i++)
		{
			dv[0][i] = v[1]->pos.data[i] - v[0]->pos.data[i];
			dv[1][i] = v[2]->pos.data[i] - v[0]->pos.data[i];
		}
		//Cross Product
		itp->normal.data[0] = dv[0][1] * dv[1][2] - dv[0][2] * dv[1][1];
		itp->normal.data[1] = dv[0][2] * dv[1][0] - dv[0][0] * dv[1][2];
		itp->normal.data[2] = dv[0][0] * dv[1][1] - dv[0][1] * dv[1][0];

		double len = sqrt(
			  itp->normal.data[0] * itp->normal.data[0]
			+ itp->normal.data[1] * itp->normal.data[1]
			+ itp->normal.data[2] * itp->normal.data[2] );
		if( len != 0 ){
			itp->normal.data[0] /= len ;
			itp->normal.data[1] /= len ;
			itp->normal.data[2] /= len ;
			
			for (int i = 0; i < 3; i++){
				v[i]->norm.data[0] += itp->normal.data[0] ;
				v[i]->norm.data[1] += itp->normal.data[1] ;
				v[i]->norm.data[2] += itp->normal.data[2] ;
			}
		}
	}

	//Normalize
	for (itv = vertices.begin(); itv != vertices.end(); itv++)
	{
		double len = itv->norm.Length();
		itv->norm.data[0] /= len;
		itv->norm.data[1] /= len;
		itv->norm.data[2] /= len;
	}
}





void ILPolygonModel::Render(RENDER_STYLE renderStyle, unsigned int* pDispListIDStorage, unsigned char* color)
{

	if( pDispListIDStorage ){
		*pDispListIDStorage = glGenLists( 1 ) ;
		glNewList( *pDispListIDStorage,GL_COMPILE_AND_EXECUTE ) ;
	}
	switch( renderStyle ){
	case RS_SMOOTH_SHADED :
		{
			glBegin( GL_TRIANGLES ) ;
			
			if( color )	glColor3ubv( color ) ;
			else		glColor3ub( 255,255,255 ) ;
			
			for( int pi=0;pi<(int)polygons.size();++pi ){
				glNormal3dv( vertices[ polygons[pi].vtx[0] ].norm ) ;
				glVertex3dv( vertices[ polygons[pi].vtx[0] ].pos ) ;
				glNormal3dv( vertices[ polygons[pi].vtx[1] ].norm ) ;
				glVertex3dv( vertices[ polygons[pi].vtx[1] ].pos ) ;
				glNormal3dv( vertices[ polygons[pi].vtx[2] ].norm ) ;
				glVertex3dv( vertices[ polygons[pi].vtx[2] ].pos ) ;
			}

			glEnd() ;
		} break ;
	case RS_WIRE_FRAME :
		{
			glPolygonMode(GL_FRONT_AND_BACK,GL_LINE) ;
			glDisable(GL_CULL_FACE);
			glBegin( GL_TRIANGLES ) ;
			if( color )	glColor3ubv( color ) ;
			else		glColor3ub( 255,255,255 ) ;
			
			for( int pi=0;pi<(int)polygons.size();++pi )
			{
				glNormal3dv( vertices[ polygons[pi].vtx[0] ].norm ) ;
				glVertex3dv( vertices[ polygons[pi].vtx[0] ].pos ) ;
				glNormal3dv( vertices[ polygons[pi].vtx[1] ].norm ) ;
				glVertex3dv( vertices[ polygons[pi].vtx[1] ].pos ) ;
				glNormal3dv( vertices[ polygons[pi].vtx[2] ].norm ) ;
				glVertex3dv( vertices[ polygons[pi].vtx[2] ].pos ) ;
			}
			
			glEnd() ;
			glEnable(GL_CULL_FACE);
			glPolygonMode(GL_FRONT,GL_FILL) ;
		} break ;
	}

	if(pDispListIDStorage)	glEndList() ;
}

void ILPolygonModel::GetStencilPolygonModelAroundVertex(int vertexID,	ILPolygonModel* pResult,	vector<int>* pVtxIDMap,
														vector<int>* pEdgeIDMap,	vector<int>* pPolygonIDMap)
{
	assert( edges.size()!=0 ) ;
	pResult->Clear() ;

	const int& v0 = vertexID ;
	int ei = vertices[v0].OneEdge ;
	const int v1 = (edges[ei].v[0]==v0 ? edges[ei].v[1] : edges[ei].v[0]) ;
	int vi = v1 ;
	list<int> vs ,es ,ps ;
	vs.push_back( v0 ) ;
	do {
		vs.push_back( vi ) ;
		es.push_back( ei ) ;
		ILWingedEdge& wee = edges[ei] ;
		bool b = (wee.v[0] == v0) ;
		es.push_back( wee.e[b?1:2] ) ;//es�͎Εӂɓ�����edge���܂�
		ps.push_back( wee.p[b?0:1] ) ;

		ei = wee.e[b?0:3] ;
		vi = (edges[ei].v[0] == v0 ? edges[ei].v[1] : edges[ei].v[0]) ;
	} while( vi != v1 ) ;

	if( pVtxIDMap )		copy<int>(vs,*pVtxIDMap) ;
	if( pEdgeIDMap )	copy<int>(es,*pEdgeIDMap) ;
	if( pPolygonIDMap )	copy<int>(ps,*pPolygonIDMap) ;

	pResult->vertices.resize( vs.size() ) ;
	list<int>::iterator iit = vs.begin() ;
	for( int i=0;i<(int)vs.size();++i,++iit )
		pResult->vertices[i].pos = vertices[*iit].pos ;

	pResult->polygons.resize( vs.size()-1 ) ;
	for( int i=0;i<(int)vs.size()-1;++i,++iit )
	{
		pResult->polygons[i].vtx[0] = 0 ;
		pResult->polygons[i].vtx[1] = i+1 ;
		pResult->polygons[i].vtx[2] = i+2 ;
	}
	pResult->polygons.back().vtx[2] = 1 ;

	//pResult->CalcWingedEdgeFromVerticesPolygons() ;//boundary�����̂Ōv�Z���ɂ���

}


//Assume that polygon model has boundary.
void ILPolygonModel::GetInfoAroundVertexWithBoundary(int vertexID,ILPolygonModel* pResult, vector<int>* pVtxIDMap,vector<int>* pEdgeIDMap,vector<int>* pPolygonIDMap) 
{
	assert( edges.size()!=0 ) ;

	bool hasBoundary;

	const int& v0 = vertexID ;
	int ei = vertices[v0].OneEdge ;
	const int v1 = (edges[ei].v[0]==v0 ? edges[ei].v[1] : edges[ei].v[0]) ;
	int vi = v1 ;

	list<int> vs ,es ,ps ;
	vs.push_back( v0 ) ;
	do {
		vs.push_back( vi ) ;
		es.push_back( ei ) ;
		ILWingedEdge& wee = edges[ei] ;
		bool b = (wee.v[0] == v0) ;

		if(wee.e[b?1:2] == -1)
		{
			hasBoundary =true;
			assert(wee.p[b?0:1] == -1);
			break;
		}

		es.push_back( wee.e[b?1:2] ) ;//es�͎Εӂɓ�����edge���܂�
		ps.push_back( wee.p[b?0:1] ) ;

		ei = wee.e[b?0:3] ;
		vi = (edges[ei].v[0] == v0 ? edges[ei].v[1] : edges[ei].v[0]) ;
	} while( vi != v1 ) ;


	//�t�Ɍ������čs��(����ȍ~edge�͑O���瑫���Ă���)
	if(hasBoundary)	
	{
		ei = vertices[v0].OneEdge;
		vi = -1;
		vs.pop_front();//v0����菜��
		while(true)
		{
			ILWingedEdge& wee = edges[ei] ;
			bool b = (wee.v[0] == v0) ;

			if(wee.e[b?3:0] == -1){//boundary�ɓ��B
				assert(wee.p[b?0:1] == -1);
				break;
			}

			es.push_front(wee.e[b?3:0]);//�Εӂ��ɓ����
			
			ei = wee.e[b?2:1] ;
			vi = (edges[ei].v[0] == v0 ? edges[ei].v[1] : edges[ei].v[0]) ;
			if(ei == vertices[v0].OneEdge ) break;//�擪�ɖ߂�

			es.push_front(ei);
			ps.push_front(wee.p[b?1:0]);
			vs.push_front(vi);
		}
		vs.push_front(v0);
	}

	if( pVtxIDMap )		copy<int>(vs,*pVtxIDMap) ;
	if( pEdgeIDMap )	copy<int>(es,*pEdgeIDMap) ;
	if( pPolygonIDMap )	copy<int>(ps,*pPolygonIDMap) ;

	pResult->vertices.resize( vs.size() ) ;
	list<int>::iterator iit = vs.begin()  ;
	for( int i = 0; i < (int)vs.size(); ++i , ++iit ) pResult->vertices[i].pos = vertices[*iit].pos ;
		
	pResult->Clear() ;
	if(hasBoundary)
	{
		pResult->polygons.resize( vs.size()-2 ) ;
		for( int i=0;i<(int)vs.size()-2;++i,++iit ){
			pResult->polygons[i].vtx[0] = 0 ;
			pResult->polygons[i].vtx[1] = i+1 ;
			pResult->polygons[i].vtx[2] = i+2 ;
		}
	}else{
		pResult->polygons.resize( vs.size()-1 ) ;
		for( int i=0;i<(int)vs.size()-1;++i,++iit ){
			pResult->polygons[i].vtx[0] = 0 ;
			pResult->polygons[i].vtx[1] = i+1 ;
			pResult->polygons[i].vtx[2] = i+2 ;
		}
		pResult->polygons.back().vtx[2] = 1 ;
	}
}


void ILPolygonModel::GetVerticesAroundVertexWithBounrary(int vertexID, vector<int>* targetVertices)
{
	assert( edges.size()!=0 ) ;
	bool hasBoundary = false;

	const int& v0 = vertexID ;
	int ei = vertices[v0].OneEdge ;
	const int v1 = (edges[ei].v[0]==v0 ? edges[ei].v[1] : edges[ei].v[0]) ;
	int vi = v1 ;

	list<int> vs;
	do {
		vs.push_back( vi ) ;
		ILWingedEdge& wee = edges[ei] ;
		bool b = (wee.v[0] == v0) ;

		if( wee.e[b?1:2] == -1){
			hasBoundary =true;
			assert(wee.p[b?0:1] == -1);
			break;
		}
		ei = wee.e[b?0:3] ;
		vi = (edges[ei].v[0] == v0 ? edges[ei].v[1] : edges[ei].v[0]) ;
	} while( vi != v1 ) ;

	//�t�Ɍ������čs��(����ȍ~edge�͑O���瑫���Ă���)
	if(hasBoundary)	
	{
		ei = vertices[v0].OneEdge;
		vi = -1;
		
		while(true)
		{
			ILWingedEdge& wee = edges[ei] ;
			bool b = (wee.v[0] == v0) ;

			if(wee.e[b?3:0] == -1) break; //boundary�ɓ��B

			ei = wee.e[b?2:1] ;
			vi = (edges[ei].v[0] == v0 ? edges[ei].v[1] : edges[ei].v[0]) ;
			if(ei == vertices[v0].OneEdge ) break;//�擪�ɖ߂���(���ې擪�ɖ߂邱�Ƃ͖���)
			vs.push_front(vi);
		}
	}
	copy<int>(vs,*targetVertices) ;
}





//todo�\�Ȃ����
void ILPolygonModel::GetEdgesAroundVertexWithBoundary(int vertexID, vector<int>* targetEdges)
{
	assert( edges.size()!=0 ) ;
	bool hasBoundary = false;

	const int& v0 = vertexID ;
	const int& e0 = vertices[v0].OneEdge;
	int ei        = vertices[v0].OneEdge;
	list<int> es;

	do {

		es.push_back( ei ) ;
		ILWingedEdge& wee = edges[ei] ;
		
		bool b = (wee.v[0] == v0) ;

		if( wee.e[b?1:2] == -1)
		{
			hasBoundary =true;
			assert(wee.p[b?0:1] == -1);
			break;
		}
	

		ei = wee.e[b?0:3] ;
	} while( ei != e0 ) ;

	//�t�Ɍ������čs��(����ȍ~edge�͑O���瑫���Ă���)
	if(hasBoundary)	
	{
		ei = vertices[v0].OneEdge;
		
		while(true)
		{
			ILWingedEdge& wee = edges[ei] ;
			bool b = (wee.v[0] == v0) ;

			if(wee.e[b?3:0] == -1) break; //boundary�ɓ��B
			ei = wee.e[b?2:1] ;
			if(ei == vertices[v0].OneEdge ) break;//�擪�ɖ߂���(���ې擪�ɖ߂邱�Ƃ͖���)
			es.push_front(ei);
		}
	}
	copy<int>(es,*targetEdges) ;
}

//todo�\�Ȃ����
void ILPolygonModel::GetEsVsAroundVertexWithBoundary(int vertexID, vector<int>* targetEdges,vector<int>* targetVertices)
{
	assert( edges.size()!=0 ) ;

	bool hasBoundary = false;
	const int& v0 = vertexID ;
	int ei = vertices[v0].OneEdge ;
	const int v1 = (edges[ei].v[0]==v0 ? edges[ei].v[1] : edges[ei].v[0]) ;
	int vi = v1 ;
	list<int> vs, es;

	do {
		vs.push_back( vi ) ;
		es.push_back( ei ) ;
		ILWingedEdge& wee = edges[ei] ;
		bool b = (wee.v[0] == v0) ;

		if( wee.e[b?1:2] == -1){
			hasBoundary =true;
			assert(wee.p[b?0:1] == -1);
			break;
		}
		ei = wee.e[b?0:3] ;
		vi = (edges[ei].v[0] == v0 ? edges[ei].v[1] : edges[ei].v[0]) ;
	} while( vi != v1 ) ;

	//�t�Ɍ������čs��(����ȍ~edge�͑O���瑫���Ă���)
	if(hasBoundary)	{
		ei = vertices[v0].OneEdge;
		vi = -1;

		while(true)
		{
			ILWingedEdge& wee = edges[ei] ;
			bool b = (wee.v[0] == v0) ;

			if(wee.e[b?3:0] == -1) break; //boundary�ɓ��B

			ei = wee.e[b?2:1] ;
			vi = (edges[ei].v[0] == v0 ? edges[ei].v[1] : edges[ei].v[0]) ;
			
			if(ei == vertices[v0].OneEdge ) break;//�擪�ɖ߂���(���ې擪�ɖ߂邱�Ƃ͖���)
			vs.push_front(vi);
			es.push_front(ei);
		}
	}
	copy<int>(vs,*targetVertices) ;
	copy<int>(es,*targetEdges);
}


void ILPolygonModel::GetStencilPolygonModelAroundEdge(int edgeID,ILPolygonModel* pResult){
	ILWingedEdge& we = edges[edgeID] ;
	// Triangle vertex indices are stored in vs.
	list<ILVector3D> vs ;
	vs.push_back( vertices[we.v[0]].pos ) ;
	vs.push_back( vertices[we.v[1]].pos ) ;
	int polygon_num_around_v0 = 0 ;
	{
		int vi = we.v[1] ;
		int ei = we.e[0] ;
		do {
			if( vi<0 ) break ;
			++polygon_num_around_v0 ;

			ILWingedEdge& wwe = edges[ei] ;
			vi = (wwe.v[0] == we.v[0] ? wwe.v[1] : wwe.v[0]) ;
			if( vi<0 ){ /*vs.pop_back();vs.pop_back();*/ break; }
			ei = (wwe.v[0] == we.v[0] ? wwe.e[0] : wwe.e[3]) ;
			vs.push_back(vertices[vi].pos) ;
		} while( vi != we.v[1] ) ;
		vs.pop_back() ;

		const int v_end = polygons[ we.p[0] ].GetTheOtherVertex( we.v[0],we.v[1] ) ;
		vi = polygons[ we.p[1] ].GetTheOtherVertex( we.v[0],we.v[1] ) ;
		ei = (edges[we.e[3]].v[0] == we.v[1] ? edges[we.e[3]].e[0] : edges[we.e[3]].e[3] ) ;
		do {
			if( vi<0 ) break ;

			ILWingedEdge& wwe = edges[ei] ;
			vi = (wwe.v[0] == we.v[1] ? wwe.v[1] : wwe.v[0]) ;
			if( vi<0 ){ /*vs.pop_back();vs.pop_back();*/ break; }
			ei = (wwe.v[0] == we.v[1] ? wwe.e[0] : wwe.e[3]) ;
			vs.push_back(vertices[vi].pos) ;
		} while( vi != v_end ) ;
		vs.pop_back() ;
	}
	pResult->vertices.resize( vs.size() ) ;
	list<ILVector3D>::iterator iit = vs.begin() ;
	for( int i=0;i<(int)vs.size();++i,++iit ){
		pResult->vertices[i].pos = *iit ;
	}
	pResult->polygons.resize( vs.size() ) ;
	pResult->polygons[0].vtx[0] = 0 ;
	pResult->polygons[0].vtx[1] = 1 ;
	pResult->polygons[0].vtx[2] = 2 ;
	for( int i=2;i<polygon_num_around_v0;++i ){
		pResult->polygons[i-1].vtx[0] = 0 ;
		pResult->polygons[i-1].vtx[1] = i ;
		pResult->polygons[i-1].vtx[2] = i+1 ;
	}
	pResult->polygons[polygon_num_around_v0-1].vtx[0] = 1 ;
	pResult->polygons[polygon_num_around_v0-1].vtx[1] = 0 ;
	pResult->polygons[polygon_num_around_v0-1].vtx[2] = polygon_num_around_v0 ;
	for( int i=polygon_num_around_v0;i<(int)vs.size()-1;++i ){
		pResult->polygons[i].vtx[0] = 1 ;
		pResult->polygons[i].vtx[1] = i ;
		pResult->polygons[i].vtx[2] = i+1 ;
	}
	pResult->polygons[vs.size()-1].vtx[0] = 1 ;
	pResult->polygons[vs.size()-1].vtx[1] = (int)vs.size()-1 ;
	pResult->polygons[vs.size()-1].vtx[2] = 2 ;
}

bool ILPolygonModel::RemoveEdgePossible(int edgeid){
	ILWingedEdge& we = edges[edgeid] ;
	ILWingedEdge& e0 = edges[we.e[0]] ;
	ILWingedEdge& e1 = edges[we.e[1]] ;
	ILWingedEdge& e2 = edges[we.e[2]] ;
	ILWingedEdge& e3 = edges[we.e[3]] ;

	int v0_id = we.v[0] ;
	int v1_id = we.v[1] ;
	ILVertex& v0 = vertices[v0_id] ;
	ILVertex& v1 = vertices[v1_id] ;
	
	///// Check if this removal causes nonmanifold mesh.
	{
		int v_neigh_num[2]={0,0} ;

		int start_we_id = v0.OneEdge ;
		int we_id = start_we_id ;
		do{
			ILWingedEdge* pwe = &edges[we_id] ;
			
			v_neigh_num[0]++ ;
//			TRACE("V0 Neighbor eid = %d\n",we_id) ;
			
			if( pwe->v[0]==v0_id ){
				we_id = pwe->e[0] ;
			} else {
				we_id = pwe->e[3] ;
			}
		} while ( we_id != start_we_id ) ;
		
		start_we_id = v1.OneEdge ;
		we_id = start_we_id ;
		do{
			ILWingedEdge* pwe = &edges[we_id] ;
			
			v_neigh_num[1]++ ;
			//TRACE("V1 Neighbor eid = %d\n",we_id) ;
			
			if( pwe->v[0]==v1_id ){
				we_id = pwe->e[0] ;
			} else {
				we_id = pwe->e[3] ;
			}
		} while ( we_id != start_we_id ) ;
		
		if( v_neigh_num[0] <= 3 || v_neigh_num[1] <= 3 ) return false ;

		
		int skip_vid[2] = { e0.v[0]==v0_id?e0.v[1]:e0.v[0] , e2.v[0]==v0_id?e2.v[1]:e2.v[0] } ;
		list<int> v0_neighbor_list ;
		// find v0 neighbors
		int start_id , id ;
		start_id = id = v0.OneEdge ;
		do {
			ILWingedEdge* we = &edges[id] ;
			int neighborid = we->v[0]==v0_id?we->v[1]:we->v[0] ;
			if( neighborid != skip_vid[0] && neighborid != skip_vid[1] )
				v0_neighbor_list.push_back( neighborid ) ;

			id = (we->v[0]==v0_id?we->e[0]:we->e[3]) ;
		} while( id != start_id && id != -1 ) ;

		// check v1 neighbors
		start_id = id = v1.OneEdge ;
		do {
			ILWingedEdge* we = &edges[id] ;
			int neighborid = we->v[0]==v1_id?we->v[1]:we->v[0] ;

			list<int>::iterator iit = v0_neighbor_list.begin() ;
			for( ; iit != v0_neighbor_list.end() ; iit++ ){
				if( neighborid == *iit )	return false ;
			}

			id = (we->v[0]==v1_id?we->e[0]:we->e[3]) ;
		} while( id != start_id && id != -1) ;
	}

	return true ;
}

bool ILPolygonModel::RemoveEdge(int edgeid,bool bTopologyOnly){
	if( !RemoveEdgePossible(edgeid) ) return false ;

	ILWingedEdge& we = edges[edgeid] ;
	ILWingedEdge& e0 = edges[we.e[0]] ;
	ILWingedEdge& e1 = edges[we.e[1]] ;
	ILWingedEdge& e2 = edges[we.e[2]] ;
	ILWingedEdge& e3 = edges[we.e[3]] ;

	/*
	///// Check if this removal causes nonmanifold mesh.
	{
		int v_neigh_num[2]={0,0} ;

		int start_we_id = v0.OneEdge ;
		int we_id = start_we_id ;
		do{
			ILWingedEdge* pwe = &edges[we_id] ;
			
			v_neigh_num[0]++ ;
//			TRACE("V0 Neighbor eid = %d\n",we_id) ;
			
			if( pwe->v[0]==v0_id ){
				we_id = pwe->e[0] ;
			} else {
				we_id = pwe->e[3] ;
			}
		} while ( we_id != start_we_id ) ;
		
		start_we_id = v1.OneEdge ;
		we_id = start_we_id ;
		do{
			ILWingedEdge* pwe = &edges[we_id] ;
			
			v_neigh_num[1]++ ;
			//TRACE("V1 Neighbor eid = %d\n",we_id) ;
			
			if( pwe->v[0]==v1_id ){
				we_id = pwe->e[0] ;
			} else {
				we_id = pwe->e[3] ;
			}
		} while ( we_id != start_we_id ) ;
		
		if( v_neigh_num[0] <= 3 || v_neigh_num[1] <= 3 ) return false ;

		
		int skip_vid[2] = { e0.v[0]==v0_id?e0.v[1]:e0.v[0] , e2.v[0]==v0_id?e2.v[1]:e2.v[0] } ;
		list<int> v0_neighbor_list ;
		// find v0 neighbors
		int start_id , id ;
		start_id = id = v0.OneEdge ;
		do {
			ILWingedEdge* we = &edges[id] ;
			int neighborid = we->v[0]==v0_id?we->v[1]:we->v[0] ;
			if( neighborid != skip_vid[0] && neighborid != skip_vid[1] )
				v0_neighbor_list.push_back( neighborid ) ;

			id = (we->v[0]==v0_id?we->e[0]:we->e[3]) ;
		} while( id != start_id && id != -1 ) ;

		// check v1 neighbors
		start_id = id = v1.OneEdge ;
		do {
			ILWingedEdge* we = &edges[id] ;
			int neighborid = we->v[0]==v1_id?we->v[1]:we->v[0] ;

			list<int>::iterator iit = v0_neighbor_list.begin() ;
			for( ; iit != v0_neighbor_list.end() ; iit++ ){
				if( neighborid == *iit )	return false ;
			}

			id = (we->v[0]==v1_id?we->e[0]:we->e[3]) ;
		} while( id != start_id && id != -1) ;
	}
	*/

	int v0_id    = we.v[0] ;
	int v1_id    = we.v[1] ;
	ILVertex& v0 = vertices[v0_id] ;
	ILVertex& v1 = vertices[v1_id] ;

	if(e0.v[0] == v0_id ){
		if( e1.v[0]==v1_id ){
			assert(e1.p[0]==we.p[0]) ;
			e0.p[1] = e1.p[1] ;
			e0.e[2] = (e1.e[2]==we.e[3] ? we.e[2] : e1.e[2]) ;
			e0.e[3] = e1.e[3] ;
		} else {
			assert(e1.p[1]==we.p[0]) ;
			e0.p[1]=e1.p[0] ;
			e0.e[2] = (e1.e[1]==we.e[3] ? we.e[2] : e1.e[1]) ;
			e0.e[3] = e1.e[0] ;
		}
		polygons[e0.p[1]].ReplaceVertexID(v1_id,v0_id) ;
	} else {
		if( e1.v[0]==v1_id ){
			e0.p[0]=e1.p[1] ;
			e0.e[1] = (e1.e[2]==we.e[3] ? we.e[2] : e1.e[2]) ;
			e0.e[0] = e1.e[3] ;
		} else {
			e0.p[0]=e1.p[0] ;
			e0.e[1] = (e1.e[1]==we.e[3] ? we.e[2] : e1.e[1]) ;
			e0.e[0] = e1.e[0] ;
		}
		polygons[e0.p[0]].ReplaceVertexID(v1_id,v0_id) ;
	}

	if(e2.v[0] == v0_id ){
		if( e3.v[0]==v1_id ){
			e2.p[0]=e3.p[0] ;
			e2.e[0] = (e3.e[0]==we.e[1] ? we.e[0] : e3.e[0]) ;
			e2.e[1] = e3.e[1] ;
		} else {
			e2.p[0]=e3.p[1] ;
			e2.e[0] = (e3.e[3]==we.e[1] ? we.e[0] : e3.e[3]) ;
			e2.e[1] = e3.e[2] ;
		}
		polygons[e2.p[0]].ReplaceVertexID(v1_id,v0_id) ;
	} else {
		if( e3.v[0]==v1_id ){
			e2.p[1]=e3.p[0] ;
			e2.e[3] = (e3.e[0]==we.e[1] ? we.e[0] : e3.e[0]) ;
			e2.e[2] = e3.e[1] ;
		} else {
			e2.p[1]=e3.p[1] ;
			e2.e[3] = (e3.e[3]==we.e[1] ? we.e[0] : e3.e[3]) ;
			e2.e[2] = e3.e[2] ;
		}
		polygons[e2.p[1]].ReplaceVertexID(v1_id,v0_id) ;
	}

	v0.OneEdge = we.e[0] ;
	vertices[ e0.v[0]==v0_id?e0.v[1]:e0.v[0] ].OneEdge = we.e[0] ;
	vertices[ e2.v[0]==v0_id?e2.v[1]:e2.v[0] ].OneEdge = we.e[2] ;

	ILPolygon& mpol1 = polygons[ e0.p[e0.v[0]==v0_id?1:0] ] ;
	for(int i=0;i<3;i++ ){
		if( mpol1.edges[i] == we.e[1] ) mpol1.edges[i] = we.e[0] ;
		else {
			ILWingedEdge& we_ = edges[mpol1.edges[i]] ;
			for( int j=0;j<4;j++ ) if( we_.e[j]==we.e[1] ) we_.e[j] = we.e[0] ;
		}
		if( mpol1.vtx[i] == v1_id )	mpol1.vtx[i] = v0_id ;
	}

	ILPolygon& mpol2 = polygons[ e2.p[e2.v[0]==v0_id?0:1] ] ;
	for(int i=0;i<3;i++ ){
		if( mpol2.edges[i] == we.e[3] ) mpol2.edges[i] = we.e[2] ;
		else {
			ILWingedEdge& we_ = edges[mpol2.edges[i]] ;
			for( int j=0;j<4;j++ ) if( we_.e[j]==we.e[3] ) we_.e[j] = we.e[2] ;
		}
		if( mpol2.vtx[i] == v1_id )	mpol2.vtx[i] = v0_id ;
	}

	int end_we_id , we_id ;
	we_id = (e0.v[0]==v0_id?e0.e[2]:e0.e[1]) ;
	end_we_id = we.e[2] ;
	
	if( we_id != end_we_id) do{
		assert( we_id != we.e[1] && we_id != we.e[3] ) ;

		ILWingedEdge* pwe = &edges[we_id] ;

		if( pwe->v[0]==v1_id ) pwe->v[0]=v0_id ;
		else {assert(pwe->v[1]==v1_id); pwe->v[1]=v0_id ;}

		if( pwe->v[0] > pwe->v[1] ){	// swap
			int tmp=pwe->v[0];pwe->v[0]=pwe->v[1];pwe->v[1]=tmp;
			tmp=pwe->p[0];pwe->p[0]=pwe->p[1];pwe->p[1]=tmp ;
			tmp=pwe->e[0];pwe->e[0]=pwe->e[3];pwe->e[3]=tmp ;
			tmp=pwe->e[1];pwe->e[1]=pwe->e[2];pwe->e[2]=tmp ;
		}

		ILPolygon& pol = polygons[ pwe->v[0]==v0_id?pwe->p[1]:pwe->p[0] ] ;
		pol.ReplaceVertexID( v1_id,v0_id ) ;

		if( pwe->v[0]==v0_id ){
			we_id = pwe->e[2] ;
		} else {
			we_id = pwe->e[1] ;
		}
	} while( we_id != end_we_id ) ;

	// topology manipulation finished.

	// Weak check code
	// the followings should not happen (if enough precheck was perform before
	// edge deletion..)
#ifdef _DEBUG
	{
		int start_we_id = v0.OneEdge ;
		we_id = start_we_id ;
		map<int,ILWingedEdge*> __dupliCheckMap ;
		do{
			ILWingedEdge* pwe = &edges[we_id] ;
			assert( __dupliCheckMap.find(we_id) == __dupliCheckMap.end() ) ;
			//if( __dupliCheckMap.find(we_id) != __dupliCheckMap.end() ) return false ;
			__dupliCheckMap[we_id] = pwe ;
			assert( pwe->v[0] < pwe->v[1] ) ;
			//if( pwe->v[0] >= pwe->v[1] ) return false ;

			for( int i=0;i<4;i++ )for( int j=0;j<4;j++ )
				if(i==j)continue;
				else {assert(pwe->e[i] != pwe->e[j]);}
//				else if(pwe->e[i] == pwe->e[j]) return false ;
			
			assert ( pwe->v[0] == v0_id || pwe->v[1] == v0_id ) ;
			//if( pwe->v[0] != v0_id && pwe->v[1] != v0_id ) return false ;
			for( int i=0;i<4;i++ ){
				assert( pwe->e[i] != edgeid && pwe->e[i] != we.e[1] && pwe->e[i] != we.e[3]) ;
				//if( pwe->e[i] == edgeid || pwe->e[i] == we.e[1] || pwe->e[i] == we.e[3]) return false ;
			}
			if( pwe->v[0]==v0_id ){
				we_id = pwe->e[0] ;
			} else {
				we_id = pwe->e[3] ;
			}
		} while ( we_id != start_we_id ) ;
	}
#endif

	if(!bTopologyOnly){
		int remove_vid = v1_id ;
		int remove_pid[2] = {we.p[0],we.p[1]} ;
		int remove_eid[3] = {edgeid,we.e[1],we.e[3]} ;

		vector < ILVertex > old_vertices = vertices ;
		vector < ILPolygon > old_polygons = polygons ;
		vector < ILWingedEdge > old_edges = edges ;
		
		vertices.resize(old_vertices.size()-1) ;
		polygons.resize(old_polygons.size()-2) ;
		edges.resize(old_edges.size()-3) ;

		int* vid_map = new int[old_vertices.size()] ;
		int* pid_map = new int[old_polygons.size()] ;
		int* eid_map = new int[old_edges.size()] ;

		{
			int id=0;
			for( int i=0;i<(int)old_vertices.size();i++ ){
				if( i != remove_vid ){
					vertices[id] = old_vertices[i] ;
					vid_map[i] = id++ ;
				}
			}
			int dbg_vsize = (int)vertices.size() ;
			assert( id == (int)vertices.size() ) ;
			id=0;
			for( int i=0;i<(int)old_polygons.size();i++ ){
				if( i != remove_pid[0] && i != remove_pid[1] ){
					polygons[id] = old_polygons[i] ;
					pid_map[i] = id++ ;
				}
			}
			assert( id == polygons.size() ) ;
			id=0;
			for( int i=0;i<(int)old_edges.size();i++ ){
				if( i != remove_eid[0] && i != remove_eid[1] && i != remove_eid[2] ){
					edges[id] = old_edges[i] ;
					eid_map[i] = id++ ;
				}
			}
			assert( id == edges.size() ) ;
		}
		for( int i=0;i<(int)vertices.size();i++ ){
			ILVertex& vtx = vertices[i] ;
			vtx.OneEdge = eid_map[vtx.OneEdge] ;
		}
		for( int i=0;i<(int)polygons.size();i++ ){
			ILPolygon& pol = polygons[i] ;
			assert(vid_map[pol.vtx[0]]>=0&&vid_map[pol.vtx[1]]>=0&&vid_map[pol.vtx[2]]>=0) ;
			pol.vtx[0]=vid_map[pol.vtx[0]] ; pol.vtx[1]=vid_map[pol.vtx[1]] ; pol.vtx[2]=vid_map[pol.vtx[2]] ;
			pol.edges[0]=eid_map[pol.edges[0]];pol.edges[1]=eid_map[pol.edges[1]];pol.edges[2]=eid_map[pol.edges[2]];
		}
		for( int i=0;i<(int)edges.size();i++ ){
			ILWingedEdge& we = edges[i] ;
			we.v[0] = vid_map[we.v[0]] ; we.v[1] = vid_map[we.v[1]] ;
			we.p[0] = pid_map[we.p[0]] ; we.p[1] = pid_map[we.p[1]] ;
			we.e[0] = eid_map[we.e[0]] ; we.e[1] = eid_map[we.e[1]] ;
			we.e[2] = eid_map[we.e[2]] ; we.e[3] = eid_map[we.e[3]] ;
		}
		delete[] vid_map ;
		delete[] pid_map ;
		delete[] eid_map ;
	}

	return true ;
}

bool ILPolygonModel::InsertEdge_TopologyOnly( int in_VtxID,int in_EdgeID1,int in_EdgeID2,
	int& out_NewVtxID,int& out_NewEdgeID1,int& out_NewEdgeID2,int& out_NewEdgeID3,
	int& out_NewPolygonID1,int& out_NewPolygonID2 ){
	out_NewVtxID = (int)vertices.size() ;
	out_NewEdgeID1 = (int)edges.size() ;
	out_NewEdgeID2 = (int)out_NewEdgeID1 + 1 ;
	out_NewEdgeID3 = out_NewEdgeID1 + 2 ;
	out_NewPolygonID1 = (int)polygons.size() ;
	out_NewPolygonID2 = out_NewPolygonID1 + 1 ;

	vertices.resize( vertices.size()+1 ) ;
	edges.resize( edges.size()+3 ) ;
	polygons.resize( polygons.size()+2 ) ;

	ILVertex& iv = vertices[in_VtxID] ;
	ILVertex& ov = vertices.back() ;
	ILWingedEdge& ie1 = edges[in_EdgeID1] ;
	ILWingedEdge& ie2 = edges[in_EdgeID2] ;
	ILWingedEdge& oe1 = edges[out_NewEdgeID1] ;
	ILWingedEdge& oe2 = edges[out_NewEdgeID2] ;
	ILWingedEdge& oe3 = edges[out_NewEdgeID3] ;
	ILPolygon& op1 = polygons[out_NewPolygonID1] ;
	ILPolygon& op2 = polygons[out_NewPolygonID2] ;

	// Geometry (simply copy input vertex to output vertex.)
	iv.OneEdge = out_NewEdgeID2 ;
	ov = iv ;

	bool beo[2] = { ie1.v[0] == in_VtxID , ie2.v[0] == in_VtxID } ;
	oe1.v[0] = out_NewVtxID ;
	oe1.v[1] = (beo[0]?ie1.v[1]:ie1.v[0]) ;
	oe1.e[0] = (beo[0]?ie1.e[0]:ie1.e[3]) ;
	oe1.e[1] = (beo[0]?ie1.e[1]:ie1.e[2]) ;
	oe1.e[2] = out_NewEdgeID2 ;
	oe1.e[3] = in_EdgeID1 ;
	oe1.p[0] = (beo[0]?ie1.p[0]:ie1.p[1]) ;
	oe1.p[1] = out_NewPolygonID1 ;

	oe2.v[0] = in_VtxID ;
	oe2.v[1] = out_NewVtxID ;
	oe2.e[0] = in_EdgeID2 ;
	oe2.e[1] = out_NewEdgeID3 ;
	oe2.e[2] = in_EdgeID1 ;
	oe2.e[3] = out_NewEdgeID1 ;
	oe2.p[0] = out_NewPolygonID2 ;
	oe2.p[1] = out_NewPolygonID1 ;

	oe3.v[0] = out_NewVtxID ;
	oe3.v[1] = (beo[1]?ie2.v[1]:ie2.v[0]) ;
	oe3.e[0] = out_NewEdgeID2 ;
	oe3.e[1] = in_EdgeID2 ;
	oe3.e[2] = (beo[1]?ie2.e[2]:ie2.e[1]) ;
	oe3.e[3] = (beo[1]?ie2.e[3]:ie2.e[0]) ;
	oe3.p[0] = out_NewPolygonID2 ;
	oe3.p[1] = (beo[1]?ie2.p[1]:ie2.p[0]) ;

	if( beo[0] ){
		ie1.e[0] = out_NewEdgeID2 ;
		ie1.e[1] = out_NewEdgeID1 ;
		ie1.p[0] = out_NewPolygonID1 ;
	} else {
		ie1.e[3] = out_NewEdgeID2 ;
		ie1.e[2] = out_NewEdgeID1 ;
		ie1.p[1] = out_NewPolygonID1 ;
	}
	if( beo[1] ){
		ie2.e[2] = out_NewEdgeID2 ;
		ie2.e[3] = out_NewEdgeID3 ;
		ie2.p[1] = out_NewPolygonID2 ;
	} else {
		ie2.e[1] = out_NewEdgeID2 ;
		ie2.e[0] = out_NewEdgeID3 ;
		ie2.p[0] = out_NewPolygonID2 ;
	}

	op1.vtx[0] = in_VtxID ;
	op1.vtx[1] = (beo[0]?ie1.v[1]:ie1.v[0]) ;
	op1.vtx[2] = out_NewVtxID ;
	op1.edges[0] = in_EdgeID1 ;
	op1.edges[1] = out_NewEdgeID1 ;
	op1.edges[2] = out_NewEdgeID2 ;

	op2.vtx[0] = in_VtxID ;
	op2.vtx[1] = out_NewVtxID ;
	op2.vtx[2] = (beo[1]?ie2.v[1]:ie2.v[0]) ;
	op2.edges[0] = out_NewEdgeID2 ;
	op2.edges[1] = out_NewEdgeID3 ;
	op2.edges[2] = in_EdgeID2 ;

	{
		ILPolygon& pp1 = polygons[oe1.p[0]] ;
		pp1.ReplaceVertexID(in_VtxID,out_NewVtxID) ;
		pp1.ReplaceEdgeID(in_EdgeID1,out_NewEdgeID1) ;
		for( int i=0;i<3;++i ){
			if( pp1.edges[i] == out_NewEdgeID1 ) continue ;
			for( int j=0;j<4;++j ){
				if( edges[pp1.edges[i]].e[j] == in_EdgeID1 ) edges[pp1.edges[i]].e[j] = out_NewEdgeID1 ;
			}
		}
		ILPolygon& pp2 = polygons[oe3.p[1]] ;
		//pp2.ReplaceVertexID(in_VtxID,out_NewVtxID) ;
		pp2.ReplaceEdgeID(in_EdgeID2,out_NewEdgeID3) ;
		for( int i=0;i<3;++i ){
			if( pp2.edges[i] == out_NewEdgeID3 ) continue ;
			for( int j=0;j<4;++j ){
				if( edges[pp2.edges[i]].e[j] == in_EdgeID2 ) edges[pp2.edges[i]].e[j] = out_NewEdgeID3 ;
			}
		}

		{
			int vco = in_VtxID ;
			int vcn = out_NewVtxID ;
			int ei = out_NewEdgeID1 ;
			do {
				edges[ei].ReplaceVtxID(vco,vcn) ;
				bool b = (edges[ei].v[0]==vcn) ;
				polygons[edges[ei].p[b?0:1]].ReplaceVertexID(vco,vcn) ;
				ei = edges[ei].e[b?0:3] ;
			} while( ei != out_NewEdgeID3 ) ;
		}

	}

	return true ;
}

#ifdef _DEBUG
void ILPolygonModel::TRACE_structure(){
	for( int i=0;i<(int)vertices.size();++i ){
		ILVertex& v = vertices[i] ;
		TRACE("Vertex%d:(%f,%f,%f)\n",i,v.pos[0],v.pos[1],v.pos[2]) ;
	}
	TRACE("-----\n") ;
	for( int i=0;i<(int)edges.size();++i ){
		ILWingedEdge& e = edges[i] ;
		TRACE("Edge%d:%d-%d:%d,%d,%d,%d\n",i,e.v[0],e.v[1]
		,e.e[0],e.e[1],e.e[2],e.e[3]) ;
	}
	TRACE("-----\n") ;
	for( int i=0;i<(int)polygons.size();++i ){
		TRACE("Polygon%d\n\tVertices: ",i) ;
		for( int j=0;j<3;++j ){
			TRACE(" ,%d",polygons[i].vtx[j]) ;
		}
		TRACE("\n\tEdges: ") ;
		for( int j=0;j<3;++j ){
			TRACE(" ,%d",polygons[i].edges[j]) ;
		}
		TRACE("\n") ;
	}
}
#endif _DEBUG

class CTest {
	public :
		CTest(){
			ILPolygonModel pm ;
#if 1
			pm.vertices.resize(5) ;
			pm.polygons.resize(4) ;

			int p_vs[4][3] = {
				{0,1,4},{1,2,4},{2,3,4},{3,0,4},
			} ;
			for( int i=0;i<4;++i ) for( int j=0;j<3;++j )
				pm.polygons[i].vtx[j] = p_vs[i][j] ;
			pm.CalcWingedEdgeFromVerticesPolygons() ;

			TRACE("Polygon Edges\n") ;
			for( int i=0;i<(int)pm.edges.size();++i ){
				ILWingedEdge& e = pm.edges[i] ;
				TRACE("E%d:%d-%d\n",i,e.v[0],e.v[1]) ;
			}
			for( int i=0;i<(int)pm.polygons.size();++i ){
				TRACE("Polygon%d vertices: ",i) ;
				for( int j=0;j<3;++j ){
					TRACE(" %d,",pm.polygons[i].vtx[j]) ;
				}
				TRACE("\nEdges: ") ;
				for( int j=0;j<3;++j ){
					TRACE(" %d,",pm.polygons[i].edges[j]) ;
				}
				TRACE("\n") ;
			}
			TRACE("-------------------\n") ;
			//////
			int ids[6] ;
			pm.InsertEdge_TopologyOnly(4,1,6,
				ids[0],ids[1],ids[2],ids[3],ids[4],ids[5] ) ;

			TRACE("Edges\n") ;
			for( int i=0;i<(int)pm.edges.size();++i ){
				ILWingedEdge& e = pm.edges[i] ;
				TRACE("E%d:%d-%d:",i,e.v[0],e.v[1]) ;
				for(int j=0;j<4;++j) TRACE("%d,",e.e[j]) ;
				TRACE("\n") ;
			}
			TRACE("Polygon Status\n") ;
			for( int i=0;i<(int)pm.polygons.size();++i ){
				TRACE("Vertices: ") ;
				for( int j=0;j<3;++j ){
					TRACE(" %d,",pm.polygons[i].vtx[j]) ;
				}
				TRACE("\nEdges: ") ;
				for( int j=0;j<3;++j ){
					TRACE(" %d,",pm.polygons[i].edges[j]) ;
				}
				TRACE("\n") ;
			}
#else
			pm.vertices.resize(7) ;
			pm.polygons.resize(6) ;

			int p_vs[6][3] = {
				{0,1,2},{0,2,3},{0,3,4},{0,4,5},{0,5,6},{0,6,1},
			} ;
			for( int i=0;i<6;++i ) for( int j=0;j<3;++j )
				pm.polygons[i].vtx[j] = p_vs[i][j] ;
			pm.CalcWingedEdgeFromVerticesPolygons() ;

			TRACE("Polygon Edges\n") ;
			for( int i=0;i<(int)pm.edges.size();++i ){
				ILWingedEdge& e = pm.edges[i] ;
				TRACE("E%d:%d-%d\n",i,e.v[0],e.v[1]) ;
			}
			for( int i=0;i<6;++i ){
				TRACE("\nVertices: ") ;
				for( int j=0;j<3;++j ){
					TRACE(" %d,",pm.polygons[i].vtx[j]) ;
				}
				TRACE("\nEdges: ") ;
				for( int j=0;j<3;++j ){
					TRACE(" %d,",pm.polygons[i].edges[j]) ;
				}
				TRACE("\n") ;
			}
			TRACE("-------------------\n") ;
			//////
			int ids[6] ;
			pm.InsertEdge_TopologyOnly(0,4,10,
				ids[0],ids[1],ids[2],ids[3],ids[4],ids[5] ) ;

			TRACE("Edges\n") ;
			for( int i=0;i<(int)pm.edges.size();++i ){
				ILWingedEdge& e = pm.edges[i] ;
				TRACE("E%d:%d-%d:",i,e.v[0],e.v[1]) ;
				for(int j=0;j<4;++j) TRACE("%d,",e.e[j]) ;
				TRACE("\n") ;
			}
			TRACE("Polygon Status\n") ;
			for( int i=0;i<8;++i ){
				TRACE("\nVertices: ") ;
				for( int j=0;j<3;++j ){
					TRACE(" %d,",pm.polygons[i].vtx[j]) ;
				}
				TRACE("\nEdges: ") ;
				for( int j=0;j<3;++j ){
					TRACE(" %d,",pm.polygons[i].edges[j]) ;
				}
				TRACE("\n") ;
			}
#endif
		}
} ;//test ;























//////////////////////////////////////////////////////////////////////////////////////////
//ILPOLYGONMODEL LOD//////////////////////////////////////////////////////////////////////
void ILPolygonModel_LOD::ConstructLOD()
{

	CalcWingedEdgeFromVerticesPolygons() ;

	//PolygonExtdata//////////////////////////////////////////////////
	//PolygonExtData.clear() ;
	PolygonExtData.resize(polygons.size()) ;
	for(int i=0;i<(int)polygons.size();i++ ){
		PolygonExtData[i].bRemoved = false ;
		PolygonExtData[i].normal = CalcNormalOfOnePolygon(i) ;
	}

	//VertexExtdata//////////////////////////////////////////////////
	VertexExtData.clear() ;
	VertexExtData.resize(vertices.size()) ;

	for( int vi=0;vi<(int)vertices.size();vi++ ){
		ILVertex& v = vertices[vi] ;

		VertexExtData[vi].v_idx = vi ;
		VertexExtData[vi].bRemoved = false ;

		// set Q
		memset(VertexExtData[vi].Q,0,sizeof(double)*16) ;
		ILWingedEdge* start_we,*we ;

		start_we = we = &edges[v.OneEdge] ;
		int pol_id = (vi==we->v[0]?we->p[1]:we->p[0]) ;

		// clockwise. polygon is the leftside
		do{
			ILPolygon& pol = polygons[pol_id] ;
			ILVector3D& normal = PolygonExtData[pol_id].normal ;
			{
				// process..
				double& a = normal[0] ;
				double& b = normal[1] ;
				double& c = normal[2] ;
				double d = -(v.pos * normal) ;
				double Kp[16] = { a*a,a*b,a*c,a*d,  a*b,b*b,b*c,b*d,  a*c,b*c,c*c,c*d,  a*d,b*d,c*d,d*d } ;

				for( int idx = 0; idx < 16 ; ++idx) VertexExtData[vi].Q[idx] += Kp[idx] ;
			}

			if( we->v[0]==vi ){
				pol_id = we->p[1] ;
				we = &edges[we->e[2]] ;
			} else {
				pol_id = we->p[0] ;
				we = &edges[we->e[1]] ;
			}
		} while( we != start_we ) ;

		TRACE("") ;
	}

	//////////////////////////////////////////////////////////////////////////////////////////////////////////
	//EdgeExtData�ɂ���/////////////////////////////////////////////////////////////////////////////////////
	EdgeExtData.clear() ;
	EdgeExtData.resize(edges.size()) ;

	//while(!VPair_Heap.empty())	VPair_Heap.pop() ;

	//EDGE_IN_PQUEUE _epq ;
	for( int ei = 0; ei < (int)edges.size(); ++ei )
	{
		ILWingedEdge& we  = edges[ei] ;
		Edge_VPair& vpair = EdgeExtData[ei] ;
		vpair.bRemoved    = false ;
		vpair.edge        = ei ;
		for(int qi=0;qi<16;++qi) vpair.Q_bar[qi] = VertexExtData[we.v[0]].Q[qi] + VertexExtData[we.v[1]].Q[qi] ;
		vpair.valid_id = 0 ;

		{
			double tmpmat[16] ;
			memcpy( tmpmat,vpair.Q_bar,sizeof(double)*16 ) ; ;
			tmpmat[12]=tmpmat[13]=tmpmat[14]=0;
			tmpmat[15]=1;

			double b[4] = { 0, 0, 0, 1} ;
			double*x = SquareMat_SolveLinearByLU<double>( tmpmat,b,4 ) ;//ILMatrix16���g���΂悢
			vpair.v_bar.Set(x[0],x[1],x[2]) ;
			delete[] x ;
		}

		{
			double vpair_v_bar_homo[ 4 ] = {vpair.v_bar[0],vpair.v_bar[1],vpair.v_bar[2],1} ;
			double vpair_v_bar_tmp[  4 ] ;
			SquareMat_MultVec( vpair.Q_bar, vpair_v_bar_homo, vpair_v_bar_tmp, 4 ) ;
			
			vpair.error =
				vpair_v_bar_tmp[0] * vpair_v_bar_homo[0]+
				vpair_v_bar_tmp[1] * vpair_v_bar_homo[1]+
				vpair_v_bar_tmp[2] * vpair_v_bar_homo[2]+
				vpair_v_bar_tmp[3] * vpair_v_bar_homo[3] ;
		}
		
/*		_epq.pEdgeExtData = &EdgeExtData ;
		_epq.VPair_id = ei ;
		_epq.valid_id = vpair.valid_id ;

		VPair_Heap.push(_epq) ;*/
	}

	VPair_Heap_SetupFromEdgeExtData() ;
	bSimplified = false ;
}










void ILPolygonModel_LOD::VPair_Heap_SetupFromEdgeExtData(){
	if( EdgeExtData.size() != edges.size() || EdgeExtData.size()==0 ){
		throw std::exception("VPair_Heap_SetupFromEdgeExtData(): Edge data is not defined!") ;
	}

	while(!VPair_Heap.empty())	VPair_Heap.pop() ;

	EDGE_IN_PQUEUE _epq;
	for( int ei = 0; ei < (int)edges.size(); ++ei )
	{
		//ILWingedEdge& we = edges[ei] ;
		Edge_VPair& vpair = EdgeExtData[ei] ;

		_epq.pEdgeExtData = &EdgeExtData ;
		_epq.VPair_id     = ei ;
		_epq.valid_id     = vpair.valid_id ;

		VPair_Heap.push(_epq) ;
	}
}









void ILPolygonModel_LOD::CleanGarbage_AfterSimplification(){
	//remove deleted vertices/edges/polygons
	vector<int> vtx_id_map( vertices.size() ) ;
	vector<int> edg_id_map( edges.size() ) ;
	vector<int> pol_id_map( polygons.size() ) ;

	list < ILVertex >     vertices_lis ;
	list < ILPolygon >    polygons_lis ;
	list < ILWingedEdge > edges_lis ;

	{
		int num=0;
		for( int i=0;i<(int)vertices.size();i++ ){
			if( !VertexExtData[i].bRemoved ){
				vtx_id_map[i]=num++ ;
				vertices_lis.push_back(vertices[i]) ;
			}
		}
		vertices.resize(num) ;
		list < ILVertex >::iterator it = vertices_lis.begin() ;
		for( int i=0;i<num;i++,it++ )
			vertices[i] = *it ;

	}

	{
		int num=0;
		for( int i=0;i<(int)polygons.size();i++ ){
			if( !PolygonExtData[i].bRemoved ){
				pol_id_map[i]=num++ ;
				polygons_lis.push_back(polygons[i]) ;
			}
		}
		polygons.resize(num) ;
		list < ILPolygon >::iterator it = polygons_lis.begin() ;
		for( int i=0;i<num;i++,it++ )
			polygons[i] = *it ;

	}

	{
		int num=0;
		for( int i=0;i<(int)edges.size();i++ ){
			if( !EdgeExtData[i].bRemoved ){
				edg_id_map[i]=num++ ;
				edges_lis.push_back(edges[i]) ;
			}
		}
		edges.resize(num) ;
		list < ILWingedEdge >::iterator it = edges_lis.begin() ;
		for( int i=0;i<num;i++,it++ )
			edges[i] = *it ;

	}

	for( int i=0;i<(int)vertices.size();i++ ){
		ILVertex& vtx = vertices[i] ;
		vtx.OneEdge = edg_id_map[vtx.OneEdge] ;
	}
	for( int i=0;i<(int)polygons.size();i++ ){
		ILPolygon& pol = polygons[i] ;
		assert(vtx_id_map[pol.vtx[0]]>=0&&vtx_id_map[pol.vtx[1]]>=0&&vtx_id_map[pol.vtx[2]]>=0) ;
		pol.vtx[0]=vtx_id_map[pol.vtx[0]] ; pol.vtx[1]=vtx_id_map[pol.vtx[1]] ; pol.vtx[2]=vtx_id_map[pol.vtx[2]] ;
		pol.edges[0]=edg_id_map[pol.edges[0]];pol.edges[1]=edg_id_map[pol.edges[1]];pol.edges[2]=edg_id_map[pol.edges[2]];
	}
	for( int i=0;i<(int)edges.size();i++ ){
		ILWingedEdge& we = edges[i] ;
		we.v[0] = vtx_id_map[we.v[0]] ; we.v[1] = vtx_id_map[we.v[1]] ;
		we.p[0] = pol_id_map[we.p[0]] ; we.p[1] = pol_id_map[we.p[1]] ;
		we.e[0] = edg_id_map[we.e[0]] ; we.e[1] = edg_id_map[we.e[1]] ;
		we.e[2] = edg_id_map[we.e[2]] ; we.e[3] = edg_id_map[we.e[3]] ;
	}

//	patches.clear() ;
	VertexExtData.clear() ;
	EdgeExtData.clear() ;
	PolygonExtData.clear() ;
}






void ILPolygonModel_LOD::Simplify(int num){
	if( bSimplified ){
		throw std::exception( "Simplify() method can be called only once after each call of ConstructLOD()." ) ;
	}
	bSimplified = true ;
	if( VPair_Heap.empty() ){
		throw std::exception( "No LOD data to be simplified." ) ;
	}

	for( int i=0;i<num;i++ )
		if(!SimplifySub_OneStep())	break ;

	//CleanGarbage_AfterSimplification() ;
}







ILPolygonModel_LOD::Edge_VPair& ILPolygonModel_LOD::GetNextVPair(){
	while( !VPair_Heap.empty() && 
		   (VPair_Heap.top().valid_id != VPair_Heap.top().GetVPair().valid_id ||
		    VPair_Heap.top().GetVPair().bRemoved                              ||
		    !RemoveEdgePossible(VPair_Heap.top().GetVPair().edge) ) )
	{
		VPair_Heap.pop();
	}
	if(VPair_Heap.empty())	throw std::exception ("No available next vpair!") ;

	return VPair_Heap.top().GetVPair() ;
}






void ILPolygonModel_LOD::RecalcExtDataAndHash(Edge_VPair& pair){
	ILWingedEdge& we = edges[pair.edge] ;

	assert(
		!EdgeExtData[pair.edge ].bRemoved &&
		!EdgeExtData[  we.e[1] ].bRemoved &&
		!EdgeExtData[  we.e[3] ].bRemoved &&
		!VertexExtData[we.v[1] ].bRemoved &&
		!PolygonExtData[we.p[0]].bRemoved &&
		!PolygonExtData[we.p[1]].bRemoved ) ;

	EdgeExtData[pair.edge ].bRemoved = true ;
	EdgeExtData[  we.e[1] ].bRemoved = true ;
	EdgeExtData[  we.e[3] ].bRemoved = true ;
	VertexExtData[we.v[1] ].bRemoved = true ;
	PolygonExtData[we.p[0]].bRemoved = true ;
	PolygonExtData[we.p[1]].bRemoved = true ;

	int v0_id = we.v[0] ;
	ILVertex& v0 = vertices[we.v[0]] ;
	ILVertex& v1 = vertices[we.v[1]] ;

	VertexExtDatum& v0_ext = VertexExtData[v0_id] ;

	v0.pos = pair.v_bar ;
	for( int i = 0; i < 16; ++i ) v0_ext.Q[i] = pair.Q_bar[i] ;

	// recalc each Q_bar & v_bar of an edge
	int start_we_id , we_id ;
	start_we_id = we_id = we.e[0] ;
	
	// counter-clockwise
	EDGE_IN_PQUEUE _epq ;
	do{
		ILWingedEdge* pwe = &edges[     we_id] ;
		Edge_VPair& vpair = EdgeExtData[we_id] ;
		
		assert(!vpair.bRemoved) ;
		assert( !VertexExtData[pwe->v[0]].bRemoved && !VertexExtData[pwe->v[1]].bRemoved ) ;
		
		for( int i=0;i<16;++i ) 
			vpair.Q_bar[i] = VertexExtData[pwe->v[0]].Q[i] + VertexExtData[pwe->v[1]].Q[i] ;

		{
			double tmpmat[16] ;
			memcpy( tmpmat,vpair.Q_bar,sizeof(double)*16 ) ;
			tmpmat[12]=tmpmat[13]=tmpmat[14]=0;
			tmpmat[15]=1;

			double b[4] = {0,0,0,1} ;
			double*x = SquareMat_SolveLinearByLU<double>( tmpmat,b,4 ) ;
			vpair.v_bar.Set(x[0],x[1],x[2]) ;
			delete[] x ;
		}
		
		{
			double vpair_v_bar_homo[4 ] = {vpair.v_bar[0], vpair.v_bar[1], vpair.v_bar[2], 1} ;
			double vpair_v_bar_tmp[ 4 ];

			SquareMat_MultVec( vpair.Q_bar, vpair_v_bar_homo, vpair_v_bar_tmp, 4 ) ;
			vpair.error =
				vpair_v_bar_tmp[0] * vpair_v_bar_homo[0]+
				vpair_v_bar_tmp[1] * vpair_v_bar_homo[1]+
				vpair_v_bar_tmp[2] * vpair_v_bar_homo[2]+
				vpair_v_bar_tmp[3] * vpair_v_bar_homo[3];
		}

		_epq.valid_id     = ++vpair.valid_id ;//������s�Ȃ����߁A�O�ɓ����Ă����͖����ɂȂ�
		_epq.VPair_id     = we_id ;
		_epq.pEdgeExtData = &EdgeExtData ;
		VPair_Heap.push(_epq) ;

		if( pwe->v[0]==v0_id ) we_id = pwe->e[0] ;
		else                   we_id = pwe->e[3] ;

	} while( we_id != start_we_id ) ;
}







bool ILPolygonModel_LOD::SimplifySub_OneStep(){
	Edge_VPair& pair = GetNextVPair() ;

	VPair_Heap.pop() ;
	RemoveEdge(pair.edge,true) ;
	RecalcExtDataAndHash(pair) ;

	return true ;
}






















