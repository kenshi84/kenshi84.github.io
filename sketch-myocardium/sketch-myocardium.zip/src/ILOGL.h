#ifndef __OPEN_GL_BASIC_WITH_VIRTUAL_TRACK_BALL_H_INCLUDED__
#define __OPEN_GL_BASIC_WITH_VIRTUAL_TRACK_BALL_H_INCLUDED__

/*This class ILOGL should be a member of a MFC View class.
Public methods should be called by the event hander of the View class
which has the same name.
and, edit the "OnEraseBkGnd" handler to return just "TRUE"
*/
#pragma warning (disable:4786)

#pragma comment(lib, "opengl32.lib")
#pragma comment(lib, "glu32.lib")
#pragma comment(lib, "glaux.lib")
//#include "Magick++.h"


#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glaux.h>
#include <cmath>
//#include "VirtualTrackBall.h"
#include "ILMath.h"
#define		TRACKBALL_RADIUS	1

#define CHECK_GL_CONSISTENCY() \
{\
	GLint error = ::glGetError();\
	if (error != GL_NO_ERROR)\
		TRACE("( %s line %d): GL error = %d: %s\n", __FILE__,__LINE__, error, ::gluErrorString(error));\
}

class ILOGL {
public:
	CWnd* m_pWnd ;
	const ILVector3D m_initEyePoint, m_initFocusPoint,m_initUpDirection;

	virtual BOOL OnCreate(CWnd* pWnd){
		m_pWnd = pWnd ;
		m_pDC = new CClientDC(pWnd);
		if( !m_pDC )	return FALSE;
		
		if( !SetupPixelFormat() )	return FALSE;
		
		m_hRC = wglCreateContext( m_pDC->GetSafeHdc() );
		if(!m_hRC)	return FALSE;
		
		if( !wglMakeCurrent( m_pDC->GetSafeHdc(), m_hRC ) )
			return FALSE;
		
		if( !OpenGLInit() )	return FALSE;


//		vtb.Init(tx,ty,tz,rotang,rx,ry,rz);

		return TRUE;
	}
	bool bIsDrawing ; // for thread sync
	float clearColor[4] ;
	virtual void OnDraw_Begin(){
		assert(!bIsDrawing) ;
		bIsDrawing = true ;
		MakeOpenGLCurrent() ;
		//if( m_bStoreFrameBuffer ){
		//	glClearColor( 1,1,1,0 ) ;
		//} else {
			glClearColor( clearColor[0],clearColor[1],clearColor[2],clearColor[3] ) ;
		//}
		glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_ACCUM_BUFFER_BIT );
		glMatrixMode( GL_MODELVIEW ) ;
	}
#if 0
	float zmax,zmin;
	int zconv(float d){ if(d>zmax||d<zmin) return 0 ; return (int)(255 * (d-zmin)/(zmax-zmin)) ; }
#endif
	virtual void OnDraw_End(){
		glFinish();
		if( m_bStoreFrameBuffer ){
			m_bStoreFrameBuffer = false ;
			RECT rect ;	 m_pWnd->GetClientRect(&rect) ;
			assert( rect.right == m_ZBuffer.Width() ) ;
			assert( rect.right == m_ColorBuffer.Width() ) ;
			assert( rect.bottom == m_ZBuffer.Height() ) ;
			assert( rect.bottom == m_ColorBuffer.Height() ) ;
			glReadPixels(0,0,rect.right,rect.bottom,GL_DEPTH_COMPONENT,GL_FLOAT
				,m_ZBuffer.GetBufferHead() ) ;
			glReadPixels(0,0,rect.right,rect.bottom,GL_RGBA,GL_UNSIGNED_BYTE
//			glReadPixels(0,0,rect.right,rect.bottom,GL_BGRA_EXT,GL_UNSIGNED_BYTE
				,m_ColorBuffer.GetBufferHead() ) ;

#if 0
			{
				FILE* fp = fopen("DepthImage.pgm","w") ;
				zmax = 0.5015f ;
				zmin = 0.4985f ;
				fprintf(fp,"P2\n# file\n%d %d\n255\n",m_ColorBuffer.Width(),m_ColorBuffer.Height()) ;
				for( int iy=0;iy<m_ColorBuffer.Height();iy++ ){
					for( int ix=0;ix<m_ColorBuffer.Width();ix++ ){
						float& depth = *m_ZBuffer.GetPixelp(ix,iy) ;
						fprintf( fp,"%d ",zconv(depth)) ;
					}
					fprintf(fp,"\n") ;
				}
				fclose(fp) ;
			}
#endif
		} else
			SwapBuffers( m_pDC->GetSafeHdc() );
		wglMakeCurrent(NULL,NULL);
		bIsDrawing = false ;
	}
	
	void t_DrawBeginForThumbnail(){
		//prepare back buffer
		RECT rect ;
		m_pWnd->GetClientRect(&rect) ;
		if( m_ZBuffer.Width() != rect.right || m_ZBuffer.Height() != rect.bottom )
			m_ZBuffer.Allocate( rect.right,rect.bottom ) ;
		if( m_ColorBuffer.Width() != rect.right || m_ColorBuffer.Height() != rect.bottom )
			m_ColorBuffer.Allocate( rect.right,rect.bottom ) ;

		//draw begine
		assert(!bIsDrawing) ;
		bIsDrawing = true ;
		MakeOpenGLCurrent() ;
		if( m_bStoreFrameBuffer ){
			glClearColor( 1,1,1,0 ) ;
		} else {
			glClearColor( clearColor[0],clearColor[1],clearColor[2],clearColor[3] ) ;
		}
		glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_ACCUM_BUFFER_BIT );
		glMatrixMode( GL_MODELVIEW ) ;
	}
	void t_DrawEndForThumbnail(){
		glFinish();
		m_bStoreFrameBuffer = false ;
		RECT rect ;	 m_pWnd->GetClientRect(&rect) ;
		assert( rect.right == m_ZBuffer.Width() ) ;
		assert( rect.right == m_ColorBuffer.Width() ) ;
		assert( rect.bottom == m_ZBuffer.Height() ) ;
		assert( rect.bottom == m_ColorBuffer.Height() ) ;
		glReadPixels(0,0,rect.right,rect.bottom,GL_DEPTH_COMPONENT,GL_FLOAT
			,m_ZBuffer.GetBufferHead() ) ;
		glReadPixels(0,0,rect.right,rect.bottom,GL_RGBA,GL_UNSIGNED_BYTE
			,m_ColorBuffer.GetBufferHead() ) ;

		wglMakeCurrent(NULL,NULL);
		bIsDrawing = false ;	
	}


	virtual void OnDestroy(){
		MakeOpenGLCurrent() ;
		wglMakeCurrent(0,0);
		wglDeleteContext( m_hRC );
		if( m_pDC )	delete m_pDC;
	}
	virtual void OnSize(int cx, int cy ){
		MakeOpenGLCurrent() ;
		
		if ( cx <= 0 || cy <= 0)	return;
		
		glViewport(0, 0, cx, cy);
		
/*		// select the projection matrix and clear it
		glMatrixMode( GL_PROJECTION );
		glLoadIdentity();

		if ( cx <= 0 || cy <= 0)	return;
		
		glViewport(0, 0, cx, cy);
*/		
		// select the viewing volume
		glMatrixMode( GL_PROJECTION );
		glLoadIdentity();
		gluPerspective(45,cx / (double)cy , 0.01,10000);

		//if( cx > cy )		glOrtho( -cx/(double)cy,cx/(double)cy,-1,1,-2,2 ) ;
		//else				glOrtho( -1,1,-cy/(double)cx,cy/(double)cx,-2,2 ) ;
		//		glOrtho( 0,cx,cy,0,cx<cy?-cy:-cx,cx<cy?cy:cx ) ;
		//		glOrtho( 0,cx,0,cy,10000,-10000 ) ;
		glMatrixMode( GL_MODELVIEW ) ;
		glLoadIdentity();
		gluLookAt(
			eyePoint.data[0],
			eyePoint.data[1],
			eyePoint.data[2],
			focusPoint.data[0],
			focusPoint.data[1],
			focusPoint.data[2],
			upDirection.data[0],
			upDirection.data[1],
			upDirection.data[2]);
		m_ZBuffer.Allocate(cx,cy) ;
		m_ColorBuffer.Allocate(cx,cy) ;
		/*
		if( m_bOnSizeFirstTime ){
			m_bOnSizeFirstTime = false ;
			glMatrixMode(GL_TEXTURE);
			glLoadIdentity();
			glPushMatrix() ;		// gluProjection�̂��߂ɁA�Q�i�s����g�����Ƃɂ���i�[���ق��͉̂�]Only�̍s��j
		}*/
	}
private:
	int PrevViewPort[4] ;
public:
	void Go2DMode(){
		MakeOpenGLCurrent() ;
		CRect rect ;
		m_pWnd->GetClientRect( &rect ) ;

		int cx = rect.right,cy = rect.bottom ;

		glGetIntegerv( GL_VIEWPORT,PrevViewPort) ;

		glMatrixMode( GL_PROJECTION );
		glPushMatrix() ;
		glLoadIdentity();

		glViewport( 0,0,cx,cy ) ;

		// select the viewing volume
		//glOrtho( 0,cx,cy,0,-1,1 ) ;
		gluPerspective(45,cx/(double)cy,0.41,4.41);

		glMatrixMode( GL_MODELVIEW ) ;
		glPushMatrix() ;
		glLoadIdentity() ;

		glMatrixMode( GL_TEXTURE ) ;
		glPushMatrix() ;
		glLoadIdentity() ;

		glDisable( GL_DEPTH_TEST );
	}
	void RecoverFrom2DMode(){
		MakeOpenGLCurrent() ;
		glEnable( GL_DEPTH_TEST );

		glViewport( PrevViewPort[0],PrevViewPort[1],PrevViewPort[2],PrevViewPort[3] ) ;

		glMatrixMode( GL_TEXTURE ) ;
		glPopMatrix() ;
		glMatrixMode( GL_PROJECTION );
		glPopMatrix() ;
		glMatrixMode( GL_MODELVIEW ) ;
		glPopMatrix() ;
	}

	void eyePointInit()
	{
		this->MakeOpenGLCurrent();
		eyePoint = m_initEyePoint;
	
		focusPoint = m_initFocusPoint;
		upDirection = m_initUpDirection;	
		glMatrixMode( GL_MODELVIEW ) ;
		glLoadIdentity();
		gluLookAt(
			eyePoint.data[0],
			eyePoint.data[1],
			eyePoint.data[2],
			focusPoint.data[0],
			focusPoint.data[1],
			focusPoint.data[2],
			upDirection.data[0],
			upDirection.data[1],
			upDirection.data[2]);
		wglMakeCurrent(NULL,NULL);
	}
	void t_ButtonDownForZoom(CPoint pos)
	{
		m_ButtonDown = TRUE;
		m_prevpos = pos;
		m_pWnd->SetCapture();
		m_ButtonDownMotionType = T_BUTTONDOWN_ZOOM;
	}
	void t_ButtonDownForRotate(CPoint& pos)
	{
		m_ButtonDown = TRUE;
		m_prevpos = pos;
		m_pWnd->SetCapture();
		m_ButtonDownMotionType = T_BUTTONDOWN_ROTATE;
		
	}
	void t_ButtonDownForTranslate(CPoint& pos)
	{
		m_ButtonDown = TRUE;
		m_prevpos = pos;
		m_pWnd->SetCapture();
		m_ButtonDownMotionType = T_BUTTONDOWN_TRANSLATE;
		
	}
	virtual bool t_MouseMove(CPoint& pos)
	{
		//�����ŁAModelViewMatrix�̃g�b�v�ɉ�]��̂��̂���������ł��܂�
		if(m_ButtonDown && m_pWnd == m_pWnd->GetCapture()){
			//�{�^����������Ă��Ă��A�������L���v�`���[�������Ă���ꍇ�Ƃ����Ӗ�
			MakeOpenGLCurrent() ;
			CRect rect;
			m_pWnd->GetClientRect(&rect);
			switch( m_ButtonDownMotionType ){
			case T_BUTTONDOWN_ROTATE:
				{
					//��]���v�Z���āA����ModelView�}�g���b�N�X�̓��ɓ����
					//�c���̃h���b�O������
					//���_�ʒueyePoint ���ړ_focusPoint�@������upDirection
					double theta = pos.x - m_prevpos.x;
					double phai =  pos.y - m_prevpos.y;

					theta = - theta / 200;
					phai = -phai/200;
					ILMatrix16 rotThetaMat , rotPhaiMat;
					ILVector3D axisT(upDirection);
					ILVector3D v1 = focusPoint - eyePoint;
					ILVector3D axisP = v1^axisT;//�������̕�������

					rotThetaMat.RotateAlongArbitraryAxis(axisT,theta);
					rotPhaiMat.RotateAlongArbitraryAxis(axisP,phai);
					
					ILVector3D eye = eyePoint - focusPoint;
					//ILVector3D upVec(ux,uy,uz);
					eye = rotPhaiMat * rotThetaMat * eye;
					upDirection = rotPhaiMat * rotThetaMat * upDirection;//�������totTheta������K�v�Ȃ��񂶂�Ȃ����ȁH
					eyePoint = eye + focusPoint;

					//�Ō�Ƀ}�g���b�N�X�ɕω��������Ă���
					glMatrixMode( GL_MODELVIEW );
					glLoadIdentity();//���񏉊������Ă��܂�
					gluLookAt(
						eyePoint.data[0],
						eyePoint.data[1],
						eyePoint.data[2],
						focusPoint.data[0],
						focusPoint.data[1],
						focusPoint.data[2],
						upDirection.data[0],
						upDirection.data[1],
						upDirection.data[2]);
				}
				break;
			case T_BUTTONDOWN_ZOOM:
				{
					//zoom���s��
					double distY = (pos.y - m_prevpos.y)/100.0;
					ILVector3D eyeRay = focusPoint - eyePoint;
					eyeRay.Normalize_Self();
					eyeRay *= distY;//���̕�����������
					ILVector3D newEyeP = eyePoint + eyeRay;
					ILVector3D temp(newEyeP - focusPoint);
					if(temp.Length() > 0.02)
					{
						eyePoint = newEyeP;
					}  
					glMatrixMode(GL_MODELVIEW);
					glLoadIdentity();
					gluLookAt(
						eyePoint.data[0],
						eyePoint.data[1],
						eyePoint.data[2],
						focusPoint.data[0],
						focusPoint.data[1],
						focusPoint.data[2],
						upDirection.data[0],
						upDirection.data[1],
						upDirection.data[2]);
				}
				break;
			case T_BUTTONDOWN_TRANSLATE:
				{
					glMatrixMode(GL_MODELVIEW);
					glLoadIdentity();
					gluLookAt(
						eyePoint.data[0],
						eyePoint.data[1],
						eyePoint.data[2],
						focusPoint.data[0],
						focusPoint.data[1],
						focusPoint.data[2],
						upDirection.data[0],
						upDirection.data[1],
						upDirection.data[2]);

					//���s�ړ����s��
					double distY = (pos.y - m_prevpos.y)/50.0;
					double distX = -(pos.x - m_prevpos.x)/50.0;
					ILVector3D transV(distX,distY,0.0);
					
					ILMatrix16 m;
					glGetDoublev(GL_MODELVIEW_MATRIX, m);
					m.data[12] = 0;m.data[13] = 0;m.data[14] = 0;
					m.GetInvMatrix_Self();
					transV = m * transV;

					eyePoint   = eyePoint   + transV;//���Ԃ��]���K�v�B�������Ă���������l��
					focusPoint = focusPoint + transV;
					
					glMatrixMode(GL_MODELVIEW);
					glLoadIdentity();
					gluLookAt(
						eyePoint.data[0],
						eyePoint.data[1],
						eyePoint.data[2],
						focusPoint.data[0],
						focusPoint.data[1],
						focusPoint.data[2],
						upDirection.data[0],
						upDirection.data[1],
						upDirection.data[2]);
					break;
				}
			}
			m_prevpos=pos;
			wglMakeCurrent(NULL,NULL);
			return TRUE ;
		}
		return FALSE ;

	}
	virtual void t_ButtonUp(){
		if(m_pWnd == m_pWnd->GetCapture()){
			m_ButtonDown=FALSE;
			ReleaseCapture();
		}
	}

	

	void t_eyeRotation(double theta,double phai){
		//��]���v�Z���āA����ModelView�}�g���b�N�X�̓��ɓ����
		//�c���̃h���b�O������
		//���_�ʒueyePoint ���ړ_focusPoint�@������upDirection
		ILMatrix16 rotThetaMat , rotPhaiMat;
		ILVector3D axisT(upDirection);
		ILVector3D v1 = focusPoint - eyePoint;
		ILVector3D axisP = v1^axisT;//�������̕�������
		rotThetaMat.RotateAlongArbitraryAxis(axisT,theta);
		rotPhaiMat.RotateAlongArbitraryAxis(axisP,phai);
		
		ILVector3D eye = eyePoint - focusPoint;
		//ILVector3D upVec(ux,uy,uz);
		eye = rotPhaiMat * rotThetaMat * eye;
		upDirection = rotPhaiMat * rotThetaMat * upDirection;//�������totTheta������K�v�Ȃ��񂶂�Ȃ����ȁH
		eyePoint = eye + focusPoint;
		this->MakeOpenGLCurrent();
		//�Ō�Ƀ}�g���b�N�X�ɕω��������Ă���
		glMatrixMode( GL_MODELVIEW );
		glLoadIdentity();//���񏉊������Ă��܂�
		
		(
			eyePoint.data[0],
			eyePoint.data[1],
			eyePoint.data[2],
			focusPoint.data[0],
			focusPoint.data[1],
			focusPoint.data[2],
			upDirection.data[0],
			upDirection.data[1],
			upDirection.data[2]);
		wglMakeCurrent(NULL,NULL);
	}


	ILVector3D getFocusPoint(){
		return focusPoint;
	}
	ILVector3D getEyePoint(){
		return eyePoint;
	}
	ILVector3D getEyeYDirection(){
		return upDirection;
	}

	void setEyePosition(ILVector3D pos,ILVector3D yDir,ILVector3D focus){
		eyePoint = pos;
		upDirection = yDir;
		focusPoint = focus;
		
		MakeOpenGLCurrent();

		glMatrixMode( GL_MODELVIEW );
		glLoadIdentity();//���񏉊�������
		gluLookAt(
			eyePoint.data[0],
			eyePoint.data[1],
			eyePoint.data[2],
			focusPoint.data[0],
			focusPoint.data[1],
			focusPoint.data[2],
			upDirection.data[0],
			upDirection.data[1],
			upDirection.data[2]);
		wglMakeCurrent(NULL,NULL);
	}

	//�ȉ���Virtual truck ball �𗘗p�������́B�Ƃ肠�����g��Ȃ�
	/*virtual void OnButtonDownForRotate(CPoint& pos){
		m_ButtonDown=TRUE;
		m_prevpos=pos;
		m_pWnd->SetCapture();
		m_ButtonDownMotionType = BUTTONDOWN_ROTATE ;
	}
	virtual void OnButtonDownForTranslate(CPoint& pos){
		OnButtonDownForRotate(pos) ;
		m_ButtonDownMotionType = BUTTONDOWN_TRANSLATE ;
	}
	virtual void OnButtonDownForZoom(CPoint& pos){
		OnButtonDownForRotate(pos) ;
		m_ButtonDownMotionType = BUTTONDOWN_ZOOM ;
	}*/
	// return whether this motion is effective of not
	/*virtual BOOL OnMouseMove(CPoint& pos,ILVector3D* rotCenter=0){
		MakeOpenGLCurrent() ;
		if(m_ButtonDown && m_pWnd == m_pWnd->GetCapture()){
			CRect rect;
			m_pWnd->GetClientRect(&rect);
			switch( m_ButtonDownMotionType ){
			case BUTTONDOWN_ROTATE:
				{
					double siz = rect.right > rect.bottom ? rect.bottom : rect.right ;
					ILVector3D v1,v2 ;
					v1.data[0] = (m_prevpos.x - rect.right/2)*TRACKBALL_RADIUS/siz ;
					v1.data[1] = (m_prevpos.y - rect.bottom/2)*TRACKBALL_RADIUS/siz ;
					v1.data[2] = TRACKBALL_RADIUS ;
					v1.Normalize() ;
					v2.data[0] = (pos.x - rect.right/2)*TRACKBALL_RADIUS/siz ;
					v2.data[1] = (pos.y - rect.bottom/2)*TRACKBALL_RADIUS/siz ;
					v2.data[2] = TRACKBALL_RADIUS ;
					v2.Normalize() ;
					v1 ^= v2 ;
					//				double angle = asin( v1.Length() )/2 ;
					double angle = asin( v1.Length() )*2 ;
					double mat[16] ;
					glMatrixMode( GL_MODELVIEW ) ;
					glGetDoublev( GL_MODELVIEW_MATRIX,mat ) ;
					glLoadIdentity() ;
					int zbound = (rect.right>rect.bottom?rect.right:rect.bottom) ;
					if(rotCenter) glTranslated((*rotCenter)[0],(*rotCenter)[1],(*rotCenter)[2]) ;
//					else glTranslatef( rect.right*0.5f,rect.bottom*0.5f,0 ) ;
					glRotated( 180*angle/M_PI,-v1.data[0],v1.data[1],v1.data[2] ) ;
					if(rotCenter) glTranslated(-(*rotCenter)[0],-(*rotCenter)[1],-(*rotCenter)[2]) ;
//					else glTranslatef( -rect.right*0.5f,-rect.bottom*0.5f,0 ) ;
					glMultMatrixd( mat ) ;
					//				vtb.OnMouseMove( rect,m_prevpos,pos );
				}
				break ;
			case BUTTONDOWN_TRANSLATE :
				{
					
					GLdouble model[16],proj[16] ;
					GLint vp[4] ;
					glGetDoublev( GL_MODELVIEW_MATRIX,model ) ;
					glGetDoublev( GL_PROJECTION_MATRIX,proj ) ;
					glGetIntegerv( GL_VIEWPORT,vp ) ;
					GLdouble newx,newy,newz,oldx,oldy,oldz ;
					gluUnProject( vp[2]-pos.x,pos.y,0.5,model,proj,vp,&newx,&newy,&newz ) ;
					gluUnProject( vp[2]-m_prevpos.x,m_prevpos.y,0.5,model,proj,vp,&oldx,&oldy,&oldz ) ;

					glMatrixMode( GL_MODELVIEW ) ;
					const double factor = 10 ;
					glTranslated( -factor*(newx-oldx),-factor*(newy-oldy),-factor*(newz-oldz) ) ;
				}
				break ;
			case BUTTONDOWN_ZOOM :
				{
					GLfloat zoom = 1 + 0.01f * (m_prevpos.y - pos.y) ;
					if( zoom < 0.01f ) zoom = 0.01f ;
					double mat[16] ;
					glMatrixMode( GL_MODELVIEW ) ;
					glGetDoublev( GL_MODELVIEW_MATRIX,mat ) ;
					glLoadIdentity() ;
					glScalef(zoom,zoom,zoom) ;
					glMultMatrixd( mat ) ;
					glMatrixMode( GL_MODELVIEW ) ;
				}
				break ;
			}
			m_prevpos=pos;
			m_pWnd->RedrawWindow();
			return TRUE ;
		}
		return FALSE ;
	}
	virtual void OnButtonUp(){
		if(m_pWnd == m_pWnd->GetCapture()){
			m_ButtonDown=FALSE;
			ReleaseCapture();
		}
	}*/

	virtual void MakeOpenGLCurrent() {
		wglMakeCurrent( m_pDC->GetSafeHdc(), m_hRC );
	}


	virtual BOOL OutputBitmap( char* filename ){
		RECT rect ;
		m_pWnd->GetClientRect( &rect ) ;
		int o = 4-((rect.right*3) % 4) ;
		o = (o==4?0:o) ;

		const int imgsize = (rect.right*3+o)*rect.bottom ;
		unsigned char* imagebits = new unsigned char[ imgsize ] ;
		if( !imagebits ) return FALSE ;
		MakeOpenGLCurrent() ;
		glReadPixels( 0,0,rect.right,rect.bottom,GL_BGR_EXT
			,GL_UNSIGNED_BYTE,imagebits ) ;
		
		BITMAPFILEHEADER bmfh ;		ZeroMemory( &bmfh,sizeof(BITMAPFILEHEADER) ) ;
		BITMAPINFOHEADER bmih ;			ZeroMemory( &bmih,sizeof(BITMAPINFOHEADER) ) ;
		bmfh.bfType = 0x4d42;  // 'BM'
		bmfh.bfSize = sizeof(BITMAPFILEHEADER)+sizeof(BITMAPINFOHEADER)+imgsize ;
		bmfh.bfOffBits = sizeof(BITMAPFILEHEADER) + sizeof(BITMAPINFOHEADER) ;

		bmih.biSize = sizeof(BITMAPINFOHEADER);
		bmih.biWidth = rect.right ;
		bmih.biHeight = rect.bottom ;
		bmih.biPlanes = 1;
		bmih.biBitCount = 24 ;
		bmih.biCompression = BI_RGB ;
		bmih.biSizeImage = imgsize ;
/*		bmih.biXPelsPerMeter = 0;
		bmih.biYPelsPerMeter = 0;
		bmih.biClrUsed = 0 ;
		bmih.biClrImportant = 0 ;*/

		FILE* fp = fopen( filename,"wb" ) ;
		if( !fp )	goto ErrorEnd ;
		if( fwrite( &bmfh,sizeof( BITMAPFILEHEADER ),1,fp ) < 1 )	goto ErrorEnd ;
		if( fwrite( &bmih,sizeof( BITMAPINFOHEADER ),1,fp ) < 1 )	goto ErrorEnd ;
		if( fwrite( imagebits,1,imgsize,fp ) < (unsigned)imgsize )	goto ErrorEnd ;
		fclose( fp ) ;
		delete[] imagebits ;
		return TRUE ;
ErrorEnd:
		fclose( fp ) ;
		delete[] imagebits ;
		return FALSE ;
	}

	CDC* GetDC(){	return m_pDC ; }
	int GetWidth(){ RECT rect ; m_pWnd->GetClientRect(&rect) ; return rect.right ; }
	int GetHeight(){ RECT rect ; m_pWnd->GetClientRect(&rect) ; return rect.bottom ; }

	void Project( double objx,double objy,double objz,
		double& winx,double& winy,double& winz ){
//		MakeOpenGLCurrent();
		int vp[4] ;
		double model[16],proj[16] ;
		glGetIntegerv(GL_VIEWPORT,vp) ;
		glGetDoublev(GL_MODELVIEW_MATRIX,model) ;
		glGetDoublev(GL_PROJECTION_MATRIX,proj) ;
		gluProject( objx,objy,objz,model,proj,vp,&winx,&winy,&winz ) ;
//		wglMakeCurrent(NULL, NULL);
	}
	void Project( ILVector3D& inVec,ILVector3D& outVec ){
		Project(inVec[0],inVec[1],inVec[2],outVec[0],outVec[1],outVec[2]) ;
	}
	void UnProject( double win_x,double win_y,double win_z,
		double& objx,double& objy,double& objz ){
		int vp[4] ;
		double model[16],proj[16] ;
		MakeOpenGLCurrent();
		glGetIntegerv(GL_VIEWPORT,vp) ;
		glGetDoublev(GL_MODELVIEW_MATRIX,model) ;
		glGetDoublev(GL_PROJECTION_MATRIX,proj) ;
		wglMakeCurrent(NULL, NULL);
		//for (int i = 0; i < 16; i++)
		//	fprintf(stderr, "%f,", model[i]);
		
		gluUnProject( win_x , vp[3]-win_y-1 , win_z , model , proj,vp,&objx,&objy,&objz );
		//fprintf(stderr, "(%f, %f, %f)\n", objx, objy, objz);
	}
	void UnProject( ILVector3D& inVec,ILVector3D& outVec ){
		UnProject(inVec[0],inVec[1],inVec[2],outVec[0],outVec[1],outVec[2]) ;
	}

	void t_calculateWorldPoint(CPoint *point,double depth ,ILVector3D &target)
	{
		MakeOpenGLCurrent();
		//�x�N�g���v�Z�ŁA�`�悵���_�����_�Ɏˉe����
		double wx,wy,wz;
		GLdouble mvMatrix[16],pjMatrix[16];
		GLint viewport[4];
		glGetIntegerv(GL_VIEWPORT, viewport);
		glGetDoublev(GL_MODELVIEW_MATRIX, mvMatrix);
		glGetDoublev(GL_PROJECTION_MATRIX, pjMatrix);
		//���E���W���擾����
		gluUnProject(
			(double)point->x,
			(double)(viewport[3] - point->y), // ���̌v�Z�͂����ł͂�肽���Ȃ��񂾂��ǂ��̕�����������
			depth,
			mvMatrix,
			pjMatrix,
			viewport,
			&wx,
			&wy,
			&wz);
		target.Set(wx,wy,wz);
		wglMakeCurrent(NULL,NULL);
	}	

	void glVertex3D_by2DPoint(int ix,int iy){
		double objpos[3] ;
		UnProject(ix,iy,0.5,objpos[0],objpos[1],objpos[2]) ;
		glVertex3dv(objpos) ;
	}

	void ResetModelView(){
		glMatrixMode( GL_MODELVIEW ) ;
		glLoadIdentity() ;
		RedrawWindow() ;
	}

	void RedrawWindow(){
		if( m_pWnd )	m_pWnd->RedrawWindow() ;
	}
	void YInvert(CPoint& point){ point.y = GetHeight() - point.y - 1 ; }
	double GetProjectedDepth(ILVector3D vec){
		MakeOpenGLCurrent() ;
		double mat[16] ;
		glGetDoublev(GL_MODELVIEW_MATRIX,mat) ;
		glMatrixMode(GL_PROJECTION) ;
		glPushMatrix() ;
		glMultMatrixd(mat) ;
		glGetDoublev(GL_PROJECTION_MATRIX,mat) ;
		double z = vec[0]*mat[2]+vec[1]*mat[6]+vec[2]*mat[10]+mat[14] ;
		glPopMatrix() ;
		return z ;

	}
	void RenderTestModel( ILVector3D center,double radius){
		ILVector3D vs[8] ;
		static float cols[8][3]={
			{(rand()%256)/255.0f,(rand()%256)/255.0f,(rand()%256)/255.0f},
			{(rand()%256)/255.0f,(rand()%256)/255.0f,(rand()%256)/255.0f},
			{(rand()%256)/255.0f,(rand()%256)/255.0f,(rand()%256)/255.0f},
			{(rand()%256)/255.0f,(rand()%256)/255.0f,(rand()%256)/255.0f},
			{(rand()%256)/255.0f,(rand()%256)/255.0f,(rand()%256)/255.0f},
			{(rand()%256)/255.0f,(rand()%256)/255.0f,(rand()%256)/255.0f},
			{(rand()%256)/255.0f,(rand()%256)/255.0f,(rand()%256)/255.0f},
			{(rand()%256)/255.0f,(rand()%256)/255.0f,(rand()%256)/255.0f}} ;
		for( int i=0;i<8;i++ ){
			vs[i].Set( ((i>>0)&1)==1?radius:-radius
			,((i>>1)&1)==1?radius:-radius
			,((i>>2)&1)==1?radius:-radius ) ;
		}
		//   6--7
		//  /| /|
		// 4--5 |
		// | 2|-3
		// |/ |/
		// 0--1
		int pvids[6][4]={{0,2,3,1},{1,3,7,5},{3,2,6,7},{2,0,4,6},{0,1,5,4},{4,5,7,6}} ;

		glDisable(GL_LIGHTING) ;
		glPolygonMode(GL_FRONT,GL_FILL) ;
		glCullFace(GL_BACK) ;
		glEnable(GL_CULL_FACE) ;

		glBegin(GL_QUADS) ;
		for( int i=0;i<6;i++ ){
			ILVector3D norm =
				(vs[pvids[i][1]]-vs[pvids[i][0]])^(vs[pvids[i][2]]-vs[pvids[i][0]]) ;
			glNormal3dv(norm) ;

			for( int j=0;j<4;j++ ){
				glColor3fv(cols[pvids[i][j]]) ;
				glVertex3dv(vs[pvids[i][j]]+center );
			}
		}
		glEnd() ;
	}
public:
	//The programmer doesn't have to call this constructor.
	ILOGL():
	  m_ButtonDown(FALSE),m_pWnd(0),m_pDC(0)
		  ,m_ButtonDownMotionType(BUTTONDOWN_ROTATE),m_bStoreFrameBuffer(false)
		  ,bIsDrawing(false),
		  m_initEyePoint(  -5.0, 0, 0),
		  m_initFocusPoint(0,    0, 0),
		  m_initUpDirection(0,   0, 1)
	{
//		  clearColor[0] = clearColor[1] = clearColor[2] = 1 ;
		 // clearColor[0] = clearColor[1] = clearColor[2] = 0.2f ;
		  clearColor[0] = clearColor[1] = clearColor[2] = 0.0f ;
		  clearColor[3] = 0 ;
	}
private:
	virtual BOOL OpenGLInit(){
		SetDefaultProperties() ;
		return TRUE;
	}
public:
	virtual void SetDefaultProperties(){
		glClearColor( clearColor[0],clearColor[1],clearColor[2],clearColor[3] ) ;
		//glClearColor( 1,1,1,0 ) ;
		glClearDepth( 1.0f );
		glEnable( GL_DEPTH_TEST );
		//���u�����h��ViewDependent-Texture�𒣂邽�߂�
		//Tips
		//glDepthFunc( GL_LEQUAL ) ;
		//glEnable( GL_BLEND );
		//glDisable( GL_BLEND );
		//glBlendFunc( GL_ONE_MINUS_SRC_ALPHA,GL_SRC_ALPHA );
		glBlendFunc( GL_SRC_ALPHA,GL_ONE_MINUS_SRC_ALPHA );
		//glBlendFunc( GL_SRC_ALPHA,GL_DST_ALPHA );
		//glBlendFunc( GL_ONE_MINUS_DST_ALPHA,GL_DST_ALPHA );

		GLfloat lightpos[] = { 1000,1000,-50000,1 };
		//Shading
		GLfloat spec[] = { 0,0,0.05f,1 } ;
		GLfloat diff[] = { 0.8f,0.8f,0.8f,0.5f };
		GLfloat amb[]  = { 0.3f,0.3f,0.3f,0.5f };

		GLfloat shininess = 1.5f ;

		glMaterialfv( GL_FRONT, GL_SPECULAR,  spec );
		glMaterialfv( GL_FRONT, GL_DIFFUSE,   diff );
		glMaterialfv( GL_FRONT, GL_AMBIENT,   amb );
		glMaterialfv( GL_FRONT, GL_SHININESS, &shininess );
		//glLightfv(GL_LIGHT0, GL_POSITION, ligphos);


		GLfloat light_Ambient0[] = { 0.5f , 0.5f , 0.5f , 1};
		GLfloat light_Diffuse0[] = { 1,1,1,1};
		GLfloat light_Specular0[]= { 0.1f , 0.1f , 0.1f , 1};
		glLightfv(GL_LIGHT0,GL_AMBIENT,light_Ambient0);
		glLightfv(GL_LIGHT0,GL_DIFFUSE,light_Diffuse0);
		glLightfv(GL_LIGHT0,GL_SPECULAR,light_Specular0);

		GLfloat light_Ambient1[] = { 0,0,0,1};
		GLfloat light_Diffuse1[] = { 0.5f , 0.5f , 0.5f , 1};
		GLfloat light_Specular1[]= { 0,0,0,1};
		glLightfv(GL_LIGHT1,GL_AMBIENT,light_Ambient1);
		glLightfv(GL_LIGHT1,GL_DIFFUSE,light_Diffuse1);
		glLightfv(GL_LIGHT1,GL_SPECULAR,light_Specular1);
		
		GLfloat light_Ambient2[] = { 0,0,0, 1};
		GLfloat light_Diffuse2[] = { 0.5f , 0.5f , 0.5f , 1};
		GLfloat light_Specular2[]= { 0,0,0,1};
		glLightfv(GL_LIGHT2,GL_AMBIENT,light_Ambient2);
		glLightfv(GL_LIGHT2,GL_DIFFUSE,light_Diffuse2);
		glLightfv(GL_LIGHT2,GL_SPECULAR,light_Specular2);
		
		//glEnable( GL_LIGHT0 );
		//glEnable( GL_LIGHT1 );
		//glEnable( GL_LIGHT2 );
		//glEnable( GL_LIGHTING ) ;
		//glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
		//glEnable( GL_TEXTURE_2D );

		glTexEnvi( GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_MODULATE ) ;
		//glTexEnvi( GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_DECAL ) ;��a�c����̎���
		
		glShadeModel( GL_SMOOTH ) ;
		//glShadeModel( GL_FLAT ) ;
		glPixelStorei( GL_UNPACK_ALIGNMENT,4 ) ;

		glCullFace( GL_BACK ) ;
		
		glPolygonMode( GL_FRONT,GL_FILL ) ;
		glEnable( GL_CULL_FACE ) ;
		//glEnable( GL_NORMALIZE ) ;
		
		//���_�܂��
		eyePoint.Set(0.5, 0.5, 2.);
		focusPoint.Set(  0.5, 0.5, 0.5);
		upDirection.Set(0,1,0);	
	}
private:
	virtual BOOL SetupPixelFormat(){
		static PIXELFORMATDESCRIPTOR pfd = {
			sizeof(PIXELFORMATDESCRIPTOR),  // size of this pfd
				1,                              // version number
				PFD_DRAW_TO_WINDOW |            // support window
				PFD_SUPPORT_OPENGL |          // support OpenGL
				PFD_DOUBLEBUFFER,             // double buffered
				PFD_TYPE_RGBA,                  // RGBA type
				32,                             // 24-bit color depth
				0, 0, 0, 0, 0, 0,               // color bits ignored
				0,                              // no alpha buffer
				0,                              // shift bit ignored
				0,                              // no accumulation buffer
				0, 0, 0, 0,                     // accum bits ignored
				//        32,                             // 32-bit z-buffer
				16,	// NOTE: better performance with 16-bit z-buffer
				0,                              // no stencil buffer
				0,                              // no auxiliary buffer
				PFD_MAIN_PLANE,                 // main layer
				0,                              // reserved
				0, 0, 0                         // layer masks ignored
		};
		
		int pixelformat;
		
		pixelformat = ChoosePixelFormat(m_pDC->GetSafeHdc(), &pfd);
		
		if ( !pixelformat  )	return FALSE;
		
		if ( !SetPixelFormat(m_pDC->GetSafeHdc(), pixelformat, &pfd) )
			return FALSE;
		
		return TRUE;
	}
	HGLRC m_hRC;
	CDC* m_pDC;

protected:
	BOOL m_ButtonDown;
	enum {
		BUTTONDOWN_ROTATE,
		BUTTONDOWN_TRANSLATE,
		BUTTONDOWN_ZOOM,
		T_BUTTONDOWN_ZOOM,
	    T_BUTTONDOWN_ROTATE,
		T_BUTTONDOWN_TRANSLATE,
	} m_ButtonDownMotionType ;
	ILVector3D eyePoint;//������_
	ILVector3D focusPoint;//���Ă�Ă�
	ILVector3D upDirection;//�����


public:
	//Published for the reference from CTSimulatorView
	CPoint m_prevpos;
public :
	// Frame buffer
	template<class T> class CFrameBuf {
	public:
		CFrameBuf():pBuffer(0),width(-1),height(-1){}
		~CFrameBuf(){	CleanUp() ;}
		void CleanUp(){ if(pBuffer)delete[] pBuffer; pBuffer=0;width=height=-1; }
		void Allocate(int width,int height){
			CleanUp() ; this->width = width ; this->height = height ; pBuffer = new T[width*height] ;	}
		T* GetPixelp(int x,int y){
			if( x<0||x>=width||y<0||y>=height||!pBuffer ) return 0 ; return &pBuffer[y*width+x] ;	}
		void SetPixel(int x,int y,T& val){ *GetPixelp(x,y) = val ; }
		int Width(){ return width ; }
		int Height(){ return height ; }
		T* GetBufferHead(){ return pBuffer ; }
		CFrameBuf<T>& operator=(CFrameBuf<T>& src){
			if( src.width == -1 || src.height == -1 ) CleanUp() ;
			else {
				Allocate( src.width,src.height ) ;
				memcpy( pBuffer,src.pBuffer,sizeof(T)*width*height ) ;
			}
			return *this ;
		}
		bool SaveAsDepthImage(char* zbuffilename="DepthImage.pgm"){
			assert( sizeof(T) == sizeof(float) ) ;
			FILE* fp = fopen(zbuffilename,"w") ;
			if( !fp ) return false;
			fprintf(fp,"P2\n# file\n%d %d\n255\n",Width(),Height()) ;
			for( int iy=0;iy<Height();iy++ ){for( int ix=0;ix<Width();ix++ ){
				fprintf(fp,"%d ",ClipUchar(255* (*GetPixelp(ix,iy)))) ;
			}fprintf(fp,"\n") ;}
			fclose(fp) ;
			return true ;
		}
		bool SaveAsColorImage(char* colbuffilename="ColorImage.ppm"){
			assert( sizeof(T)==sizeof(COLORREF) ) ;
			FILE* fp = fopen(colbuffilename,"w") ;
			if(!fp)	return false ;
			fprintf(fp,"P3\n# file\n%d %d\n255\n",Width(),Height()) ;
			for( int iy=0;iy<Height();iy++ ){for( int ix=0;ix<Width();ix++ ){
					unsigned char* pxl = (unsigned char*)GetPixelp(ix,iy) ;
					fprintf( fp,"%d %d %d ",pxl[0],pxl[1],pxl[2]) ;
				}	fprintf(fp,"\n") ;}
			fclose(fp) ;
			return true ;
		}
	protected:
		T* pBuffer ;
		int width,height ;
	} ;
	bool OutputFrameBufferToFiles(char* colbuffilename="ColorImage.ppm",char* zbuffilename="DepthImage.pgm"){
		return  m_ZBuffer.SaveAsDepthImage(zbuffilename) && m_ColorBuffer.SaveAsColorImage(colbuffilename) ;
	}

	// ZBuffer of back buffer is stored in OnDraw_End().
	// Therefore the caller should call OnDraw_End() manually, after calling
	// this method. In this case, the back buffer is not copied to
	// the front buffer.
	// Note that copying zbuffer from onboard frame buffer is really slow.
	void PrepareForFrameBufferCopy(){
		RECT rect ;
		m_pWnd->GetClientRect(&rect) ;
		if( m_ZBuffer.Width() != rect.right || m_ZBuffer.Height() != rect.bottom )
			m_ZBuffer.Allocate( rect.right,rect.bottom ) ;
		if( m_ColorBuffer.Width() != rect.right || m_ColorBuffer.Height() != rect.bottom )
			m_ColorBuffer.Allocate( rect.right,rect.bottom ) ;
		m_bStoreFrameBuffer = true ;
	}
	CFrameBuf<float> m_ZBuffer ;
	CFrameBuf<COLORREF> m_ColorBuffer ;
	bool IsStoringFrameBuffer(){ return m_bStoreFrameBuffer ; }
	void SetStoringFrameBuffer(bool newval=true){ m_bStoreFrameBuffer = newval ; }
	bool GetPixelValueFromStoredFrameBuffer( int x,int y,float* depth=0,COLORREF* color=0 ){
		if( x < 0 || y < 0 || x >= m_ZBuffer.Width() || y >= m_ZBuffer.Height() )	return false ;
//		y = GetHeight()-y-1 ;
		if(depth) *depth = *m_ZBuffer.GetPixelp(x,y) ;
		if(color) *color = *m_ColorBuffer.GetPixelp(x,y) ;
		return true ;
	}
	inline COLORREF GetPixelFromColorBuffer(int x,int y){
		if( x < 0 || y < 0 || x >= m_ColorBuffer.Width() || y >= m_ColorBuffer.Height() ){
			COLORREF c =  ((int)(clearColor[0] * 255.0)<<0) + 
					 ((int)(clearColor[1] * 255.0)<<8) + 
					 ((int)(clearColor[2] * 255.0)<<16);//�w�i�F��Ԃ�
			return c;
		}
		return *m_ColorBuffer.GetPixelp(x,y) ;
	}

	//���̊֐��͕K�v�Ȃ̂��H�I���W�i���ł͂Ȃ��Ȃ��Ă���
	unsigned int GetColID(int x,int y){
		COLORREF col ;
		if( !GetPixelValueFromStoredFrameBuffer(x,y,0,&col) )	return (unsigned int)-1 ;
		return COLORREFtoUINT_ID(col) ;
	}

	bool GetGlobalPositionFromCurrentViewAndStoredFrameBuffer( int x,int y,ILVector3D& result_pos ){
		if( x < 0 || y < 0 || x >= m_ZBuffer.Width() || y >= m_ZBuffer.Height() )	return false ;
		float depth = *m_ZBuffer.GetPixelp(x,y) ;
		if( fabs(depth-1) < VSN ) return false ;	// no object
		MakeOpenGLCurrent() ;
		double modelMat[16],projMat[16] ;int vp[4];
		glGetDoublev(GL_MODELVIEW_MATRIX,modelMat) ;
		glGetDoublev(GL_PROJECTION_MATRIX,projMat) ;
		glGetIntegerv(GL_VIEWPORT,vp) ;
		
		gluUnProject(x,y,depth,modelMat,projMat,vp,&result_pos[0],&result_pos[1],&result_pos[2]) ;
		return true ;
	}
	void GetScreenCoordToGlobalLine(int cx,int cy,ILVector3D& start,ILVector3D& ori){
		MakeOpenGLCurrent() ;
		double modelMat[16],projMat[16] ;int vp[4];
		glGetDoublev(GL_MODELVIEW_MATRIX,modelMat) ;
		glGetDoublev(GL_PROJECTION_MATRIX,projMat) ;
		glGetIntegerv(GL_VIEWPORT,vp) ;

		gluUnProject(cx,cy,0,modelMat,projMat,vp,&start[0],&start[1],&start[2]) ;
		gluUnProject(cx,cy,1,modelMat,projMat,vp,&ori[0],&ori[1],&ori[2]) ;
		
		ori -= start ;
		wglMakeCurrent(NULL,NULL);
	}

	void k_GetScreenCoordToGlobalLine(int cx, int cy, ILVector3D& start, ILVector3D& ori){
		MakeOpenGLCurrent() ;
		double modelMat[16],projMat[16] ;int vp[4];
		glGetDoublev(GL_MODELVIEW_MATRIX,modelMat) ;
		glGetDoublev(GL_PROJECTION_MATRIX,projMat) ;
		glGetIntegerv(GL_VIEWPORT,vp) ;

		start.Set(eyePoint);
		gluUnProject(cx, vp[3] - cy, 0.01, modelMat, projMat, vp, &ori[0], &ori[1], &ori[2]) ;
		
		ori -= start ; 
		ori.Normalize_Self();
		wglMakeCurrent(NULL,NULL);
	}


	ILVector3D GetCurrentViewVectorInLocalCoordinate(){
		ILVector3D pos0,pos1 ;
		UnProject( ILVector3D(0,0,0),pos0 ) ;
		UnProject( ILVector3D(0,0,-1),pos1 ) ;
		return (pos1-pos0).Normalize() ;
	}

	static unsigned int COLORREFtoUINT_ID(COLORREF col){ if( col == 0xFFFFFF )	return (unsigned int)-1 ;
	return 0xffffff&(unsigned int)col ;}
	static void UINT_IDtoRGB(int id,unsigned char* r,unsigned char* g,unsigned char* b){
		unsigned char* ucp = (unsigned char*)&id ;
		*r = ucp[0] ; *g = ucp[1] ; *b = ucp[2] ;
	}
	static COLORREF UINT_IDtoCOLORREF(int id){return 0xFF000000|id ; }

protected:
	bool m_bStoreFrameBuffer ;


	//////////////////////////////////////
public:
	// Offscreen buffer. This buffer is allocated, independent of the
	// window size. (However, reference CDC is necessary)
	class COffscreenBuffer {
	public:
		COffscreenBuffer():pDCRef(0),w(-1),h(-1),pBitmapOld(0),hrc(0),prevHrc(0){}
		void Clear(){
			MakeOpenGLCurrent() ;
			if( pDCRef ){
				assert(pBitmapOld && hrc!=0) ;
				wglMakeCurrent(0,0);
				dc.SelectObject(pBitmapOld);
				wglDeleteContext( hrc );
				UnMakeOpenGLCurrent() ;
			}
			pBitmapOld = 0 ;
			pDCRef=0; w=h=-1 ;
			hrc = 0 ;
			prevHrc = 0 ;
			m_ColorBuffer.CleanUp() ;
			m_ZBuffer.CleanUp() ;
		}
		bool Setup(CDC* pDCRef,int w,int h){
			Clear() ;
			this->pDCRef = pDCRef ;
			this->w = w ; this->h = h ;
			if( w==-1||h==-1 ) return false ;
			dc.CreateCompatibleDC( pDCRef ) ;
			bitmap.CreateCompatibleBitmap(pDCRef, w,h );
			pBitmapOld = dc.SelectObject(&bitmap);

			if(!SetupPixelFormat()){
				CString st ;
				st.Format("Can't create pixel format for offscreen buffer (w,h)=(%d,%d)",w,h) ;
				AfxMessageBox(st) ;
				return false ;
			}
			hrc = wglCreateContext( dc.GetSafeHdc() );	assert(hrc) ;
			if( !hrc ){
				AfxMessageBox("Can't create rendering context for offscreen buffer") ;
				return false ;
			}
			MakeOpenGLCurrent() ;
			SetOglDefaultProperties() ;
			UnMakeOpenGLCurrent() ;

			m_ColorBuffer.Allocate(w,h) ;
			m_ZBuffer.Allocate(w,h) ;
			return true ;
		}
		~COffscreenBuffer(){
			Clear() ;
		}
		void OnDraw_Begin(/*bool bStoreFrameBuffer=false*/){
			MakeOpenGLCurrent() ;
			glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_ACCUM_BUFFER_BIT );
			glMatrixMode( GL_MODELVIEW ) ;
		}
		void OnDraw_End(){
			glFinish();
			glReadPixels(0,0,w,h,GL_DEPTH_COMPONENT,GL_FLOAT,m_ZBuffer.GetBufferHead() ) ;
			glReadPixels(0,0,w,h,GL_RGBA,GL_UNSIGNED_BYTE,m_ColorBuffer.GetBufferHead() ) ;
			UnMakeOpenGLCurrent() ;
		}
		CFrameBuf<float> m_ZBuffer ;
		CFrameBuf<COLORREF> m_ColorBuffer ;

		int w,h ;
		HGLRC hrc;
		CDC dc ;
		CBitmap bitmap,*pBitmapOld ;

		void MakeOpenGLCurrent(){	prevHrc = wglGetCurrentContext() ; wglMakeCurrent( dc.GetSafeHdc(), hrc ) ;	}
		void UnMakeOpenGLCurrent(){	wglMakeCurrent( pDCRef->GetSafeHdc(),prevHrc ) ;	}
	protected:
		BOOL SetupPixelFormat(){
			static PIXELFORMATDESCRIPTOR pfd = {
				sizeof(PIXELFORMATDESCRIPTOR),  // size of this pfd
					1,                              // version number
					PFD_DRAW_TO_BITMAP | PFD_SUPPORT_OPENGL | PFD_SUPPORT_GDI,
					PFD_TYPE_RGBA,32,
					0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					16, 0, 0,
					PFD_MAIN_PLANE ,
					0, 0, 0, 0 };
			int pixelformat ;
			if ( !(pixelformat=ChoosePixelFormat(dc.GetSafeHdc(), &pfd))  )	return FALSE;
			if ( !SetPixelFormat(dc.GetSafeHdc(), pixelformat, &pfd) )	return FALSE;
			
			return TRUE;
		}
		void SetOglDefaultProperties(){
			glClearColor( 1,1,1,0 ) ;
			glClearDepth( 1.0f );
			glEnable( GL_DEPTH_TEST );
			glDisable( GL_BLEND );
			glDisable( GL_LIGHTING ) ;
			glDisable( GL_SMOOTH ) ;
			glShadeModel( GL_FLAT ) ;
			glPixelStorei( GL_UNPACK_ALIGNMENT,4 ) ;
			
			glCullFace( GL_BACK ) ;
			glPolygonMode( GL_FRONT,GL_FILL ) ;

			glDisable( GL_CULL_FACE ) ;

			glViewport( 0,0,w,h ) ;
			glMatrixMode( GL_PROJECTION );
			glLoadIdentity();
			
			//glOrtho( 0,w,h,0,-1,1 ) ;
			gluPerspective(45,w/(double)h,0.02,4.41);

			glMatrixMode( GL_MODELVIEW ) ;
			glLoadIdentity() ;
			glMatrixMode( GL_TEXTURE ) ;
			glLoadIdentity() ;
			glDisable( GL_DEPTH_TEST );
		}
		HGLRC prevHrc ;
		CDC* pDCRef ;
	public:
		bool OutputFrameBufferToFiles(char* colbuffilename="ColorImage.ppm",char* zbuffilename="DepthImage.pgm"){
			FILE* fp = fopen(zbuffilename,"w") ;
			FILE* fp2 = fopen(colbuffilename,"w") ;
			if( !fp || !fp2 ){
				if( fp ) fclose(fp) ; if( fp2 ) fclose(fp2) ;
				return false ;
			}
			fprintf(fp,"P2\n# file\n%d %d\n255\n",m_ZBuffer.Width(),m_ZBuffer.Height()) ;
			fprintf(fp2,"P3\n# file\n%d %d\n255\n",m_ZBuffer.Width(),m_ZBuffer.Height()) ;
			for( int iy=0;iy<m_ZBuffer.Height();iy++ ){
				for( int ix=0;ix<m_ZBuffer.Width();ix++ ){
					fprintf(fp,"%d ",ClipUchar(255* 15*(*m_ZBuffer.GetPixelp(ix,iy)))) ;
					unsigned char* pxl = (unsigned char*)m_ColorBuffer.GetPixelp(ix,iy) ;
					fprintf( fp2,"%d %d %d ",pxl[0],pxl[1],pxl[2]) ;
				}
				fprintf(fp,"\n") ;	fprintf(fp2,"\n") ;
			}
			fclose(fp) ;fclose(fp2) ;
			return true ;
		}


	} ;
};








class ILOGLTexture {
public:
	// Texture pattern
	int width,height,avail_width,avail_height ;
	unsigned char* rgba_image ;
	ILVector3D uvw_scale ;
	unsigned int textureName ;
	CString textureNameString;
	//char textureNameString[256];

public:
	ILOGLTexture():rgba_image(0),textureName(-1){}
	~ILOGLTexture(){CleanUp();}
	
	void CleanUp(){
		if( rgba_image ) delete[] rgba_image ; rgba_image=0;
		if( textureName!=-1 && glIsTexture(textureName) ) glDeleteTextures(1,&textureName) ; textureName=-1;
	}



	void Allocate( int w,int h,unsigned char* srcimg=0 ){
		CleanUp() ;
		avail_width = w ; avail_height = h ;
		width = SmallestBeqPow2(w) ; height = SmallestBeqPow2(h) ;
		uvw_scale[0] = w/(double)width ; uvw_scale[1] = h/(double)height ;
		//uvw_scale[0] = width/(double)w ; uvw_scale[1] = height/(double)h ;
		rgba_image = new unsigned char[width*height*4] ;
		if( srcimg ){ for( int y=0;y<h;y++ ){
			unsigned char* dest = &rgba_image[y*width*4] ;
			unsigned char* src = &srcimg[y*w*4] ;
			memcpy(dest,src,w*4) ;
		}}
	
	}



	void RGBAImageUpdated(){
		if( textureName!=-1 && glIsTexture(textureName) ) glDeleteTextures(1,&textureName) ; textureName=-1;}
	unsigned char* GetPixelp(int x,int y){ return &rgba_image[(y*width+x)*4] ; }
	// Make it half of the original size
	void HalfSize() ;



	ILVector3D ConvToTrueTCoord( ILVector3D& src_tcoord ){
		ILVector3D ret(
			src_tcoord[0]*uvw_scale[0],
			src_tcoord[1]*uvw_scale[1],
			src_tcoord[2]*uvw_scale[2] ) ;
//		ret[0] -= floor(ret[0]) ; ret[1] -= floor(ret[1]) ; ret[2] -= floor(ret[2]) ;
		return ret ;
	}

	ILVector3D ConvToTrueTCoord( double tx,double ty,double tz=0 ){
		return ConvToTrueTCoord( ILVector3D(tx,ty,tz) ) ;
	}


	void DarkenRGBbyAlpha(){
		for( int iy=0;iy<avail_height;iy++ ) for( int ix=0;ix<avail_width;ix++ ) {
			const float factor = 0.5f ;
			unsigned char* pxl = GetPixelp(ix,iy) ;
			float mul = factor * (pxl[3]/255.0f) + (1-factor) ;
			pxl[0] = ClipUchar(mul*pxl[0]) ;
			pxl[1] = ClipUchar(mul*pxl[1]) ;
			pxl[2] = ClipUchar(mul*pxl[2]) ;
		}
	}

	void SetAlphaByKeyColor( unsigned char* keyColor=0 ){
		unsigned char key[3] = {0,0,0};
		if(keyColor!=0) memcpy(key,keyColor,3) ;

		for( int iy=0;iy<avail_height;iy++ ) for( int ix=0;ix<avail_width;ix++ ){
			unsigned char* pxl = GetPixelp(ix,iy) ;
			if( pxl[0]==key[0] && pxl[1]==key[1] && pxl[2]==key[2] ) pxl[3]=0 ;
			else pxl[3] = 255 ;
		}
	}
public :
	ILOGLTexture(const ILOGLTexture& src):rgba_image(0),textureName(-1){
		//*this=src;
		avail_width=src.avail_width;
		avail_height=src.avail_height;
		height=src.height;
		width=src.width;
		if( src.rgba_image ){
			rgba_image=new unsigned char[width*height*4] ;
			memcpy(rgba_image,src.rgba_image,width*height*4) ;
		}
		uvw_scale=src.uvw_scale ;
	}

	ILOGLTexture& operator=(const ILOGLTexture& src){
		CleanUp() ;
		// textureName = src.textureName ;
		width=src.width;height=src.height;avail_width=src.avail_width;avail_height=src.avail_height;
		uvw_scale=src.uvw_scale ;
		if( src.rgba_image ){	rgba_image=new unsigned char[width*height*4] ;
		memcpy(rgba_image,src.rgba_image,width*height*4) ;}

		textureName = -1 ;

		return *this ;
	}

	bool IsAvailable(){ return rgba_image != 0 ; }
	
	void OglBind(bool bRenderRawTexture=false){
		if( !IsAvailable() ) return ;

		if( textureName==-1 || !glIsTexture(textureName) ){
			glPixelStorei(GL_UNPACK_ALIGNMENT,4) ;
			glGenTextures(1,&textureName) ;
			glBindTexture(GL_TEXTURE_2D,textureName) ;
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_S,GL_REPEAT) ;
			glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_WRAP_T,GL_REPEAT) ;
			if(!bRenderRawTexture){
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR) ;
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR) ;
			} else {
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST) ;
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST) ;
			}
			
			if(bRenderRawTexture)
				glTexEnvi(GL_TEXTURE_ENV,GL_TEXTURE_ENV_MODE,GL_REPLACE);
			glTexImage2D(GL_TEXTURE_2D,0,GL_RGBA,width,height,
				0,GL_RGBA,GL_UNSIGNED_BYTE,rgba_image) ;
			
		} else {
			if(bRenderRawTexture){
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_NEAREST) ;
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_NEAREST) ;
			} else {
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MAG_FILTER,GL_LINEAR) ;
				glTexParameteri(GL_TEXTURE_2D,GL_TEXTURE_MIN_FILTER,GL_LINEAR) ;
			}
			glBindTexture(GL_TEXTURE_2D,textureName) ;
		}
	}

	bool ReadFromFile(const char* filename,bool bFitScale=false) ;
	bool WriteToPPMFile(const char* filename){
		FILE* fp = fopen(filename,"w") ;
		if( !fp )	return false ;
		fprintf(fp,"P3\n# file\n%d %d\n255\n",width,height) ;
		for( int y=0;y<height;y++ ){
			unsigned char* pBits = GetPixelp(0,y) ;
			for( int x=0;x<width;x++,pBits+=4 ){
				fprintf( fp,"%d %d %d ",pBits[0],pBits[1],pBits[2]) ;
			}
			fprintf(fp,"\n") ;
		}
		fclose(fp) ;
		return true ;
	}
	bool SaveAsIDRefImg(char* fname){
		FILE* fp = fopen(fname,"w") ;
		if( !fp )	return false ;
		fprintf(fp,"width = %d height = %d\n",width,height) ;
		for( int y=0;y<height;y++ ){
			unsigned char* pBits = GetPixelp(0,y) ;
			for( int x=0;x<width;x++,pBits+=4 ){
				int idx = (0xffffff&RGB(pBits[0],pBits[1],pBits[2])) ;
				fprintf( fp,"%d ",idx ) ;
			}
			fprintf(fp,"\n") ;
		}
		fclose(fp) ;
		return true ;
	}


	void SaveToBinFile(FILE* fp){
		fwrite( &avail_width,sizeof(int),1,fp ) ;
		fwrite( &avail_height,sizeof(int),1,fp ) ;
		if( avail_width <= 0 || avail_height <= 0 ) return ;
		fwrite( uvw_scale,sizeof(double),3,fp ) ;
		for( int iy=0;iy<avail_height;iy++ ){
			fwrite( &rgba_image[iy*width*4],4,avail_width,fp ) ;
		}
	}

	void LoadFromBinFile(FILE* fp){
		CleanUp() ;
		fread( &avail_width,sizeof(int),1,fp ) ;
		fread( &avail_height,sizeof(int),1,fp ) ;
		if( avail_width <= 0 || avail_height <= 0 ) return ;
		Allocate(avail_width,avail_height) ;
		fread( uvw_scale,sizeof(double),3,fp ) ;
		for( int iy=0;iy<avail_height;iy++ ){
			fread( &rgba_image[iy*width*4],4,avail_width,fp ) ;
		}
	}
} ;


#endif	// __OPEN_GL_BASIC_WITH_VIRTUAL_TRACK_BALL_H_INCLUDED__
