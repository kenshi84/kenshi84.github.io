#pragma once
//#include "TSparseMatrix.h"
#include "VCore.h"
#include "KUmfpackSquareMatrix.h"

class VVolumeDataManager
{
public:
	VVolumeDataManager(void);
	~VVolumeDataManager(void);
	
	static inline VVolumeDataManager* getInstance(){
		static VVolumeDataManager p;
		return &p;
	}
	
	void ClearData();
	void SetBoundary();
	void RayCast(const int dir);
	void SetConstraints();
	void NormalizeAll();
	void ExportResultToFile(char* fname);
	void ExportVolumeToFile(char* fname);
	
	/* Laplacian Smoothing */
	void CalcLtL();
	void LaplacianSmooth();	
	
	/* Simple One-Scratch Smoothing */
	void SimpleSmooth();
	
	vector<vector<ILVector3D> > m_strokes;
	bool m_isBusy;

private:
	//TSparseMatrix m_LtL;
	KUmfpackSquareMatrix m_LtL;
	vector<double> m_bx, m_by, m_bz;
	vector<double> m_vx, m_vy, m_vz;
public:
	vector<int> m_mapL2V;
};
