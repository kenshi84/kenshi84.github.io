#pragma once

class VAnimationManager
{
public:
	VAnimationManager(void);
	~VAnimationManager(void);
	
	static inline VAnimationManager* getInstance() {
		static VAnimationManager p;
		return &p;
	}
	
	void update();
};
