// VectorFieldsView.cpp : implementation of the CVectorFieldsView class
//

#include "stdafx.h"
#include "VectorFields.h"
#include "VectorFieldsDoc.h"
#include "VectorFieldsView.h"

#include "VCore.h"
#include "VDrawer.h"
#include "VMenuListener.h"
#include "VMouseListener.h"
#include "VAnimationManager.h"
#include "VVolumeDataManager.h"

#include ".\vectorfieldsview.h"
#include <iostream>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CVectorFieldsView

IMPLEMENT_DYNCREATE(CVectorFieldsView, CView)

BEGIN_MESSAGE_MAP(CVectorFieldsView, CView)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_MBUTTONDOWN()
	ON_WM_MBUTTONUP()
	ON_COMMAND(ID_COMMAND_SMOOTHONSURFACE, OnCommandSmoothonsurface)
	ON_COMMAND(ID_COMMAND_SMOOTHONVOLUME, OnCommandSmoothonvolume)
	ON_WM_TIMER()
	ON_WM_SETCURSOR()
END_MESSAGE_MAP()

// CVectorFieldsView construction/destruction

CVectorFieldsView::CVectorFieldsView()
{
	// TODO: add construction code here
	VCore::getInstance()->m_pView = this;
}

CVectorFieldsView::~CVectorFieldsView()
{
}

BOOL CVectorFieldsView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CVectorFieldsView drawing

void CVectorFieldsView::OnDraw(CDC* /*pDC*/)
{
	CVectorFieldsDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	VCore::getInstance()->m_ogl.OnDraw_Begin();

	VDrawer::getInstance()->OnDraw();


	VCore::getInstance()->m_ogl.OnDraw_End();

	// TODO: add draw code for native data here
}


// CVectorFieldsView printing

BOOL CVectorFieldsView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CVectorFieldsView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CVectorFieldsView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}


// CVectorFieldsView diagnostics

#ifdef _DEBUG
void CVectorFieldsView::AssertValid() const
{
	CView::AssertValid();
}

void CVectorFieldsView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CVectorFieldsDoc* CVectorFieldsView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CVectorFieldsDoc)));
	return (CVectorFieldsDoc*)m_pDocument;
}
#endif //_DEBUG


// CVectorFieldsView message handlers

int CVectorFieldsView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	VCore::getInstance()->m_ogl.OnCreate(this);
	SetTimer(1, 50, NULL);
	
	// TODO :  �����ɓ���ȍ쐬�R�[�h��ǉ����Ă��������B

	return 0;
}

void CVectorFieldsView::OnDestroy()
{
	CView::OnDestroy();
	
	VCore::getInstance()->m_ogl.OnDestroy();
	// TODO : �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����܂��B
}

void CVectorFieldsView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);
	VCore::getInstance()->m_ogl.OnSize(cx,cy);

	VCrossSection::getInstance()->OnSize(cx, cy);
	VCrossSection::getInstance()->ViewChanged();
	// TODO : �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����܂��B
}

BOOL CVectorFieldsView::OnEraseBkgnd(CDC* pDC)
{
	// TODO : �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B

	return TRUE;//CView::OnEraseBkgnd(pDC);
}

void CVectorFieldsView::OnLButtonDown(UINT nFlags, CPoint point){
	VMouseListener::getInstance()->OnLButtonDown(nFlags, point);
	CView::OnLButtonDown(nFlags, point);
}

void CVectorFieldsView::OnLButtonUp(UINT nFlags, CPoint point)
{
	VMouseListener::getInstance()->OnLButtonUp(nFlags, point);
	CView::OnLButtonUp(nFlags, point);
}

void CVectorFieldsView::OnMouseMove(UINT nFlags, CPoint point)
{
	VMouseListener::getInstance()->OnMouseMove(nFlags, point);
	CView::OnMouseMove(nFlags, point);
}

void CVectorFieldsView::OnRButtonDown(UINT nFlags, CPoint point)
{
	VMouseListener::getInstance()->OnRButtonDown(nFlags, point);
	CView::OnRButtonDown(nFlags, point);
}

void CVectorFieldsView::OnRButtonUp(UINT nFlags, CPoint point)
{
	VMouseListener::getInstance()->OnRButtonUp(nFlags, point);
	CView::OnRButtonUp(nFlags, point);
}

void CVectorFieldsView::OnMButtonDown(UINT nFlags, CPoint point)
{
	VMouseListener::getInstance()->OnMButtonDown(nFlags, point);
	CView::OnMButtonDown(nFlags, point);
}

void CVectorFieldsView::OnMButtonUp(UINT nFlags, CPoint point)
{
	VMouseListener::getInstance()->OnMButtonUp(nFlags, point);
	CView::OnMButtonUp(nFlags, point);
}

void CVectorFieldsView::OnCommandSmoothonsurface()
{
	VMenuListener::getInstance()->OnCommandSmoothOnSurface();
}

void CVectorFieldsView::OnCommandSmoothonvolume()
{
	VMenuListener::getInstance()->OnCommandSmoothOnVolume();
}

void CVectorFieldsView::OnTimer(UINT nIDEvent)
{
#ifdef V_ANIMATE
	if (!VCore::getInstance()->m_particle.empty())
		VAnimationManager::getInstance()->update();
#endif
	if (VCore::getInstance()->m_tick > 0) {
		VCore::getInstance()->m_tick--;
		ILOGL& ogl = VCore::getInstance()->m_ogl;
		ILMatrix16 rotThetaMat; // , rotPhaiMat;
		ILVector3D axisT(ogl.getEyeYDirection());

		rotThetaMat.RotateAlongArbitraryAxis(axisT,-0.06);
		//rotPhaiMat.RotateAlongArbitraryAxis(axisP,0);
		
		ILVector3D eye = ogl.getEyePoint() - ogl.getFocusPoint();
		//ILVector3D upVec(ux,uy,uz);
		eye = rotThetaMat * eye;
		ogl.setEyePosition(eye + ogl.getFocusPoint(), axisT, ogl.getFocusPoint());
		
		VCore::getInstance()->m_ogl.RedrawWindow();
	}
	CView::OnTimer(nIDEvent);
}

BOOL CVectorFieldsView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message)
{
	//if( nHitTest == HTCLIENT && VVolumeDataManager::getInstance()->m_isBusy ) {
 //       SetCursor(AfxGetApp()->LoadStandardCursor(IDC_WAIT));
 //       return TRUE;
 //   }
	return CView::OnSetCursor(pWnd, nHitTest, message);
}
