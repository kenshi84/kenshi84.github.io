// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "VectorFields.h"

#include "MainFrm.h"
#include ".\mainfrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#include "VCore.h"
#include "VMenuListener.h"
#include "VDrawer.h"

// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(ID_DRAW_EDGES, OnDrawEdges)
	ON_COMMAND(ID_DRAW_FACES, OnDrawFaces)
	ON_COMMAND(ID_DRAW_STROKESONSURFACE, OnDrawStrokesonsurface)
	ON_COMMAND(ID_DRAW_STROKESONVOLUME, OnDrawStrokesonvolume)
	ON_COMMAND(ID_DRAW_FIELDONSURFACE, OnDrawFieldonsurface)
	ON_COMMAND(ID_DRAW_FIELDONVOLUME, OnDrawFieldonvolume)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REDO, OnUpdateEditRedo)
	ON_COMMAND(ID_EDIT_REDO, OnEditRedo)
	ON_UPDATE_COMMAND_UI(ID_DRAW_EDGES, OnUpdateDrawEdges)
	ON_UPDATE_COMMAND_UI(ID_DRAW_FACES, OnUpdateDrawFaces)
	ON_UPDATE_COMMAND_UI(ID_DRAW_FIELDONSURFACE, OnUpdateDrawFieldonsurface)
	ON_UPDATE_COMMAND_UI(ID_DRAW_FIELDONVOLUME, OnUpdateDrawFieldonvolume)
	ON_UPDATE_COMMAND_UI(ID_DRAW_STROKESONSURFACE, OnUpdateDrawStrokesonsurface)
	ON_UPDATE_COMMAND_UI(ID_DRAW_STROKESONVOLUME, OnUpdateDrawStrokesonvolume)
	ON_COMMAND(ID_EDIT_CLEAR_ALL, OnEditClearAll)
	ON_COMMAND(ID_DRAW_CSSHAPE, OnDrawCsshape)
	ON_UPDATE_COMMAND_UI(ID_DRAW_CSSHAPE, OnUpdateDrawCsshape)
	ON_COMMAND(ID_DRAW_AXIS, OnDrawAxis)
	ON_UPDATE_COMMAND_UI(ID_DRAW_AXIS, OnUpdateDrawAxis)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CLEAR_ALL, OnUpdateEditClearAll)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};


// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_bAutoMenuEnable = FALSE;
	VMenuListener::getInstance()->m_CFrm = this;
}

CMainFrame::~CMainFrame()
{
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	// TODO: Delete these three lines if you don't want the toolbar to be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}


// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame message handlers


void CMainFrame::OnDrawEdges()
{
	VMenuListener::getInstance()->OnDrawEdges();
}

void CMainFrame::OnDrawFaces()
{
	VMenuListener::getInstance()->OnDrawFaces();
}

void CMainFrame::OnDrawStrokesonsurface()
{
	VMenuListener::getInstance()->OnDrawStrokesonsurface();
}

void CMainFrame::OnDrawStrokesonvolume()
{
	VMenuListener::getInstance()->OnDrawStrokesonvolume();
}


void CMainFrame::OnDrawFieldonsurface()
{
	VMenuListener::getInstance()->OnDrawFieldonsurface();
}

void CMainFrame::OnDrawFieldonvolume()
{
	VMenuListener::getInstance()->OnDrawFieldonvolume();
}

void CMainFrame::OnEditUndo()
{
	VMenuListener::getInstance()->OnEditUndo();
}

void CMainFrame::OnUpdateEditUndo(CCmdUI *pCmdUI)
{
	if (VCore::getInstance()->m_UndoFlags.empty())
		pCmdUI->Enable(0);
	else
		pCmdUI->Enable(1);
}

void CMainFrame::OnUpdateEditRedo(CCmdUI *pCmdUI)
{
	if (VCore::getInstance()->m_RedoFlags.empty())
		pCmdUI->Enable(0);
	else
		pCmdUI->Enable(1);
}

void CMainFrame::OnEditRedo()
{
	VMenuListener::getInstance()->OnEditRedo();
}

void CMainFrame::OnUpdateDrawEdges(CCmdUI *pCmdUI)
{
	if (VDrawer::getInstance()->m_flags & VDrawer::_EDGES)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CMainFrame::OnUpdateDrawFaces(CCmdUI *pCmdUI)
{
	if (VDrawer::getInstance()->m_flags & VDrawer::_FACES)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CMainFrame::OnUpdateDrawFieldonsurface(CCmdUI *pCmdUI)
{
	if (VDrawer::getInstance()->m_flags & VDrawer::_SDATA)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CMainFrame::OnUpdateDrawFieldonvolume(CCmdUI *pCmdUI)
{
	if (VDrawer::getInstance()->m_flags & VDrawer::_VDATA)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CMainFrame::OnUpdateDrawStrokesonsurface(CCmdUI *pCmdUI)
{
	if (VDrawer::getInstance()->m_flags & VDrawer::_SSTROKES)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CMainFrame::OnUpdateDrawStrokesonvolume(CCmdUI *pCmdUI)
{
	if (VDrawer::getInstance()->m_flags & VDrawer::_VSTROKES)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CMainFrame::OnEditClearAll()
{
	VMenuListener::getInstance()->OnEditClearall();
}

void CMainFrame::OnDrawCsshape()
{
	VMenuListener::getInstance()->OnDrawCsshape();
}

void CMainFrame::OnUpdateDrawCsshape(CCmdUI *pCmdUI)
{
	if (VDrawer::getInstance()->m_flags & VDrawer::_CSSHAPE)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CMainFrame::OnDrawAxis()
{
	VMenuListener::getInstance()->OnDrawAxis();
}

void CMainFrame::OnUpdateDrawAxis(CCmdUI *pCmdUI)
{
	if (VDrawer::getInstance()->m_flags & VDrawer::_AXIS)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CMainFrame::OnUpdateEditClearAll(CCmdUI *pCmdUI)
{
	if (VCore::getInstance()->m_UndoFlags.empty())
		pCmdUI->Enable(0);
	else
		pCmdUI->Enable(1);
}
