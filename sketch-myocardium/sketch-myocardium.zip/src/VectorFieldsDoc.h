// VectorFieldsDoc.h : interface of the CVectorFieldsDoc class
//


#pragma once

class CVectorFieldsDoc : public CDocument
{
protected: // create from serialization only
	CVectorFieldsDoc();
	DECLARE_DYNCREATE(CVectorFieldsDoc)

// Attributes
public:
	bool m_isValidFile;

// Operations
public:

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CVectorFieldsDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnFileLoad3dmodel();
	afx_msg void OnFileExportresult();
	afx_msg void OnFileExportvolume();
};


