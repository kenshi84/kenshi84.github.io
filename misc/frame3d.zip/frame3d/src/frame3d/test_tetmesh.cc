#include "frame3d.hh"
#include <iostream>
#include <sstream>
#include <kt84/util.hh>
#include <kt84/tw_util.hh>
#include <kt84/glfw_util.hh>
#include <kt84/tinyfd_util.hh>
#include <kt84/graphics/graphics_util.hh>
#include <kt84/graphics/DisplayList.hh>
#include <kt84/geometry/CameraFree.hh>
#include <kt84/vector_cast.hh>
#include <kt84/MinSelector.hh>
#include <igl/read_triangle_mesh.h>
#include <igl/tetgen/tetrahedralize.h>
#include <Eigen/Geometry>

using namespace std;
using namespace kt84;
using namespace kt84::graphics_util;
using namespace Eigen;

struct Globals {
    struct {
        glfw_util::InitConfig  cfg;
        glfw_util::LoopControl ctrl;
    } glfw;
    TwBar* bar;
    CameraFree camera;
    double w_boundary = 200;
    char tetgen_switches[64] = "pYq1.414";
    struct {
        MatrixXd V;
        MatrixXi F;
    } trimesh;
    frame3d::TetMesh mesh;
    struct {
        DisplayList edges;
        DisplayList cross;
        DisplayList cube;
#ifdef FRAME3D_FIXED_BOUNDARY
        DisplayList trimesh;
#endif
    } displist;
    struct {
        double fovy = 40;
        bool edges = true;
        bool frames = true;
        bool vizmode = true;
        double frame_scale = 0.01;
#ifdef FRAME3D_FIXED_BOUNDARY
        bool trimesh = true;
#endif
    } drawopt;
    struct {
        double threshold = 0;
        int axis = -1;
    } crosssection;
#ifdef FRAME3D_FIXED_BOUNDARY
    struct {
        OpenVolumeMesh::HalfFaceHandle hf;
        Vector3d plane_origin;
        Vector3d plane_normal;
        Vector3d endpoint;
    } draginfo;
#endif
} g;

void tetrahedralize() {
    MatrixXd TV;
    MatrixXi TT, TF;
    if (igl::tetrahedralize(g.trimesh.V, g.trimesh.F, g.tetgen_switches, TV, TT, TF) != 0) return;
    // I HAVE NO IDEA WHY THIS MAKES A DIFFERENCE (when purely axis-aligned cube is input)!
    for (int i = 0; i < TV.rows(); ++i)
        TV.row(i) += Vector3d::Random() * 0.00000000001;
    
    g.mesh.clear();
    // copy vertices
    g.mesh.reserve_vertices((int)TV.rows());
    for (int i = 0; i < TV.rows(); ++i)
        g.mesh.add_vertex(vector_cast<3, OpenVolumeMesh::Vec3d, Vector3d>(TV.row(i)));
    // copy tets
    g.mesh.reserve_cells((int)TT.rows());
    for (int i = 0; i < TT.rows(); ++i) {
        OpenVolumeMesh::VertexHandle v[4];
        for (int j = 0; j < 4; ++j)
            v[j].idx(TT(i, j));
        g.mesh.add_cell(TT(i, 0), v[1], v[2], v[3]);
    }
#ifndef NDEBUG
    g.mesh.debugInfo_get();
#endif
    g.mesh.precompute();
    cout << "tetmesh statistics:\n" 
        << "vertices: " << g.mesh.n_vertices() << '\n'
        << "tets: " << g.mesh.n_cells() << '\n'
        << "faces: " << g.mesh.n_faces() << '\n'
        << "edges: " << g.mesh.n_edges() << '\n';
    // tet volumes statistics
    double vol_max = 0, vol_min = 1000, vol_avg = 0;
    for (auto tet : g.mesh.cells()) {
        double vol = g.mesh.data(tet).tetCellVolume;
        vol_max = max<double>(vol_max, vol);
        vol_min = min<double>(vol_min, vol);
        vol_avg += vol / g.mesh.n_cells();
    }
    cout << "min/max/avg tet cell volume: " << vol_min << '/' << vol_max << '/' << vol_avg << '\n';
    
    g.displist = {};
}

void read_trimesh(const string& fname) {
    if (!igl::read_triangle_mesh(fname, g.trimesh.V, g.trimesh.F)) return;
    cout << "trimesh statistics:\n"
        << "vertices: " << g.trimesh.V.rows() << '\n'
        << "faces: " << g.trimesh.F.rows() << '\n';
    
    // recenter & rescale
    AlignedBox3d bbox;
    for (int i = 0; i < g.trimesh.V.rows(); ++i)
        bbox.extend(Vector3d(g.trimesh.V.row(i)));
    for (int i = 0; i < g.trimesh.V.rows(); ++i) {
        g.trimesh.V.row(i) -= bbox.center();
        g.trimesh.V.row(i) /= bbox.diagonal().norm();
    }
    
    // reset camera
    g.camera.eye    << 0, 0, 2;
    g.camera.center << 0, 0, 0;
    g.camera.up     << 0, 1, 0;
    
    tetrahedralize();
}

void display() {
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    double aspect_ratio = g.camera.width / static_cast<double>(g.camera.height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(g.drawopt.fovy, aspect_ratio, 0.1, 100);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(g.camera.eye, g.camera.center, g.camera.up);
    
    // zx-grid
    glLineWidth(1);
    glBegin(GL_LINES);
    glColor4d(0.75, 0.75, 0.75, 0.5);
    for (int i = -20; i < 20; ++i) {
        glVertex3d(i, 0, -20);
        glVertex3d(i, 0,  20);
        glVertex3d(-20, 0, i);
        glVertex3d( 20, 0, i);
    }
    glEnd();
    
    // tetmesh edges
    if (g.drawopt.edges) {
        glColor4d(0.5, 0.5, 0.5, 0.5);
        g.displist.edges.render([](){
            glBegin(GL_LINES);
            for (auto e : g.mesh.edges()) {
                if (g.crosssection.axis > -1) {
                    auto p = g.mesh.barycenter(e);
                    if (p[g.crosssection.axis] > g.crosssection.threshold) continue;
                }
                glVertex3d(g.mesh.vertex(g.mesh.edge(e).from_vertex()));
                glVertex3d(g.mesh.vertex(g.mesh.edge(e).to_vertex()));
            }
            glEnd();
        });
    }
    
    // 3D frames on tetmesh vertices
    if (g.drawopt.frames) {
        glLineWidth(2);
        for (auto v : g.mesh.vertices()) {
            auto p = g.mesh.vertex(v);
            if (g.crosssection.axis > -1 && p[g.crosssection.axis] > g.crosssection.threshold) continue;
            glPushMatrix();
            glTranslated(p);
            // rotate by ZYZ angles
            auto& zyz = g.mesh.data(v).zyz;
            glRotated(zyz[2] * 180 / util::pi(), 0, 0, 1);
            glRotated(-90, 1, 0, 0);
            glRotated(zyz[1] * 180 / util::pi(), 0, 0, 1);
            glRotated(90, 1, 0, 0);
            glRotated(zyz[0] * 180 / util::pi(), 0, 0, 1);
            // scale
            glScaled(g.drawopt.frame_scale);
            if (g.drawopt.vizmode)
                g.displist.cube.render([](){
                    glBegin(GL_QUADS);
                    glColor3d(1, 0, 0);
                    glVertex3d( 1, -1, -1);
                    glVertex3d( 1,  1, -1);
                    glVertex3d( 1,  1,  1);
                    glVertex3d( 1, -1,  1);
                    glVertex3d(-1, -1, -1);
                    glVertex3d(-1,  1, -1);
                    glVertex3d(-1,  1,  1);
                    glVertex3d(-1, -1,  1);
                    glColor3d(0, 1, 0);
                    glVertex3d(-1,  1, -1);
                    glVertex3d(-1,  1,  1);
                    glVertex3d( 1,  1,  1);
                    glVertex3d( 1,  1, -1);
                    glVertex3d(-1, -1, -1);
                    glVertex3d(-1, -1,  1);
                    glVertex3d( 1, -1,  1);
                    glVertex3d( 1, -1, -1);
                    glColor3d(0, 0, 1);
                    glVertex3d(-1, -1,  1);
                    glVertex3d( 1, -1,  1);
                    glVertex3d( 1,  1,  1);
                    glVertex3d(-1,  1,  1);
                    glVertex3d(-1, -1, -1);
                    glVertex3d( 1, -1, -1);
                    glVertex3d( 1,  1, -1);
                    glVertex3d(-1,  1, -1);
                    glEnd();
                });
            else
                g.displist.cross.render([](){
                    glBegin(GL_LINES);
                    glColor3d(1, 0, 0);
                    glVertex3d(-1, 0, 0);
                    glVertex3d( 1, 0, 0);
                    glColor3d(0, 1, 0);
                    glVertex3d(0, -1, 0);
                    glVertex3d(0,  1, 0);
                    glColor3d(0, 0, 1);
                    glVertex3d(0, 0, -1);
                    glVertex3d(0, 0,  1);
                    glEnd();
                });
            glPopMatrix();
        }
    }
    
#ifdef FRAME3D_FIXED_BOUNDARY
    // boundary trimesh
    if (g.drawopt.trimesh) {
        g.displist.trimesh.render([](){
            glBegin(GL_TRIANGLES);
            for (auto f : g.mesh.faces()) {
                if (!g.mesh.is_boundary(f)) continue;
                if (g.crosssection.axis > -1) {
                    auto p = g.mesh.barycenter(f);
                    if (p[g.crosssection.axis] > g.crosssection.threshold) continue;
                }
                if (g.mesh.data(f).is_constrained)
                    glColor3d(1, 0, 0);
                else
                    glColor3d(0, 0.7, 1);
                for (auto v : g.mesh.face_vertices(f))
                    glVertex3d(g.mesh.vertex(v));
            }
            glEnd();
        });
    }
    // changing constraint value by dragging
    if (g.draginfo.hf.is_valid()) {
        glLineWidth(5);
        glDisable(GL_DEPTH_TEST);
        glBegin(GL_LINES);
        glColor3d(0, 0.8, 0);
        glVertex3d(g.draginfo.plane_origin);
        glVertex3d(g.draginfo.endpoint);
        glEnd();
        glEnable(GL_DEPTH_TEST);
    }
#endif
    
    TwDraw();
}

namespace glfw_callback {
    void framebuffersize(GLFWwindow* window, int width, int height) {
        g.camera.reshape(width, height);
        glViewport(0, 0, width, height);
        TwWindowSize(width, height);
    }
    void key(GLFWwindow* window, int key, int scancode, int action, int mods) {
        if (kt84::glfw_util::TwEventKeyGLFW3(key, scancode, action, mods))
            return;
    }
    void mousebutton(GLFWwindow* window, int button, int action, int mods) {
        if (TwEventMouseButtonGLFW(button, action))
            return;
        auto actionFlag = glfw_util::parseAction(action);
        auto modFlag = glfw_util::parseMods(mods);
        auto mouse = glfw_util::getCursorPos(window);
        mouse.y = g.camera.height - mouse.y;
        if (actionFlag.press) {
#ifdef FRAME3D_FIXED_BOUNDARY
            if (modFlag.alt)
                return g.camera.mouse_down(mouse.x, mouse.y, 
                    modFlag.ctrl  ? Camera::DragMode::PAN  :
                    modFlag.shift ? Camera::DragMode::ZOOM : Camera::DragMode::ROTATE);
            g.draginfo = {};
            auto clicked = graphics_util::read_and_unproject(mouse.x, mouse.y);
            if (!clicked) return;
            g.draginfo.plane_origin = *clicked;
            MinSelector<int> picked_halfface;
            for (auto hf : g.mesh.halffaces())
                if (g.mesh.is_boundary(hf))
                    picked_halfface.update((vector_cast<3, Vector3d>(g.mesh.barycenter(g.mesh.face_handle(hf))) - *clicked).norm(), hf.idx());
            g.draginfo.hf.idx(picked_halfface.value);
            auto f = g.mesh.face_handle(g.draginfo.hf);
            g.displist.trimesh.invalidate();
            if (modFlag.shift) {    // delete constraint
                g.mesh.data(f).is_constrained = false;
                g.draginfo = {};
                return;
            }
            g.mesh.data(f).is_constrained = true;
            g.draginfo.plane_normal = vector_cast<3, Vector3d>(g.mesh.data(g.draginfo.hf).tetFaceNormal);
            g.draginfo.endpoint = g.draginfo.plane_origin;
#else
            g.camera.mouse_down(mouse.x, mouse.y, 
                modFlag.ctrl  ? Camera::DragMode::PAN  :
                modFlag.shift ? Camera::DragMode::ZOOM : Camera::DragMode::ROTATE);
#endif
        } else {
            g.camera.mouse_up();
#ifdef FRAME3D_FIXED_BOUNDARY
            if (g.draginfo.hf.is_valid()) {
                g.mesh.data(g.mesh.face_handle(g.draginfo.hf)).constraint_value = (g.draginfo.endpoint - g.draginfo.plane_origin).normalized();
                g.draginfo = {};
            }
#endif
        }
    }
    void cursorpos(GLFWwindow* window, double xpos, double ypos) {
        if (TwEventMousePosGLFW(xpos, ypos))
            return;
        ypos = g.camera.height - ypos;
        if (g.camera.drag_mode != Camera::DragMode::NONE)
            return g.camera.mouse_move(xpos, ypos);
#ifdef FRAME3D_FIXED_BOUNDARY
        if (g.draginfo.hf.is_valid()) {
            auto& o = g.draginfo.plane_origin;
            auto& n = g.draginfo.plane_normal;
            auto p = graphics_util::unproject({ xpos, ypos, 0.0 });
            auto& e = g.camera.eye;
            // ((1-t)*e + t*p - o).dot(n) = 0
            // t*(p-e).dot(n) = (o-e).dot(n)
            double t = (o-e).dot(n) / (p-e).dot(n);
            g.draginfo.endpoint = (1-t)* e + t*p;
        }
#endif
    }
    void drop(GLFWwindow* window, int count, const char** names) {
        if (count == 1) read_trimesh(names[0]);
    }
}

string usage() {
    ostringstream oss;
    oss << "> read triangle mesh via drag&drop\n";
#ifdef FRAME3D_FIXED_BOUNDARY
    oss << "> [alt]+drag: rotate camera\n";
    oss << "> [alt]+[shift]+drag: zoom camera\n";
    oss << "> [alt]+[ctrl]+drag: pan camera\n";
    oss << "> click & drag: constrain 2D frame orientation of clicked triangle\n";
    oss << "> [shift]+click: unconstrain clicked triangle\n";
#else
    oss << "> drag: rotate camera\n";
    oss << "> [shift]+drag: zoom camera\n";
    oss << "> [ctrl]+drag: pan camera\n";
#endif
    return oss.str();
}

int main(int argc, char** argv) {
    // callback & draw funcs
    g.glfw.cfg.window.title = "frame3d_test_tetmesh";
    g.glfw.cfg.callback.framebuffersize = glfw_callback::framebuffersize;
    g.glfw.cfg.callback.key             = glfw_callback::key;
    g.glfw.cfg.callback.mousebutton     = glfw_callback::mousebutton;
    g.glfw.cfg.callback.cursorpos       = glfw_callback::cursorpos;
    g.glfw.cfg.callback.drop            = glfw_callback::drop;
    g.glfw.ctrl = glfw_util::init(g.glfw.cfg);
    g.glfw.ctrl.idle_func[0] = display;
    
    // init OpenGL
    glewInit();
    glClearColor(1, 1, 1, 1);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POINT_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);    
    glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
    
    // init AntTweakBar
    TwInit(TW_OPENGL, nullptr);
    g.bar = TwNewBar("frame3d_test_tetmesh");
    TwDefine("frame3d_test_tetmesh alpha=255 size='300 400' valueswidth=150");
    tw_util::AddButton(g.bar, "usage", [](){
        tinyfd_messageBox("frame3d_test_tetmesh: usage", usage().c_str(), "ok", "info", 0);
        cout << usage();
    }, nullptr);
    TwAddSeparator(g.bar, "sep1", nullptr);
    tw_util::AddButton(g.bar, "read_trimesh", [](){
        auto fname = tinyfd_util::openFileDialog("frame3d_test_tetmesh - read trimesh", nullptr, { "*.obj", "*.off", "*.stl", "*.wrl", "*.ply", "*.mesh" }, false);
        if (!fname.empty())
            read_trimesh(fname);
    }, nullptr);
    TwAddSeparator(g.bar, "sep2", nullptr);
    TwAddVarRW(g.bar, "tetgen_switches", TW_TYPE_CSSTRING(64), &g.tetgen_switches, nullptr);
    tw_util::AddButton(g.bar, "tetrahedralize", [](){
        tetrahedralize();
    }, nullptr);
#ifdef FRAME3D_FIXED_BOUNDARY
    TwAddSeparator(g.bar, "sep3", nullptr);
    tw_util::AddButton(g.bar, "compute_boundary_field", [](){
        g.mesh.compute_boundary_field();
    }, nullptr);
#endif
    TwAddSeparator(g.bar, "sep4", nullptr);
    TwAddVarRW(g.bar, "w_boundary", TW_TYPE_DOUBLE, &g.w_boundary, "min=0");
    tw_util::AddButton(g.bar, "compute_field", [](){
        g.mesh.compute_field(g.w_boundary);
    }, nullptr);
    // drawopt
    TwAddVarRW(g.bar, "fovy", TW_TYPE_DOUBLE, &g.drawopt.fovy, "group=drawopt min=1 max=179");
    TwAddVarRW(g.bar, "draw_edges", TW_TYPE_BOOLCPP, &g.drawopt.edges, "group=drawopt");
    TwAddVarRW(g.bar, "draw_frames", TW_TYPE_BOOLCPP, &g.drawopt.frames, "group=drawopt");
    TwAddVarRW(g.bar, "frame_scale", TW_TYPE_DOUBLE, &g.drawopt.frame_scale, "group=drawopt min=0 max=0.1 step=0.001");
    TwAddVarRW(g.bar, "vizmode", TW_TYPE_BOOLCPP, &g.drawopt.vizmode, "group=drawopt true=cubes false=cross");
#ifdef FRAME3D_FIXED_BOUNDARY
    TwAddVarRW(g.bar, "trimesh", TW_TYPE_BOOLCPP, &g.drawopt.trimesh, "group=drawopt");
#endif
    // crosssection
    tw_util::AddVarCB_default(g.bar, "axis", g.crosssection.axis, [](){
        g.displist = {};
    }, "group=crosssection min=-1 max=2");
    tw_util::AddVarCB_default(g.bar, "threshold", g.crosssection.threshold, [](){
        g.displist = {};
    }, "group=crosssection min=-1 max=1 step=0.01");
    
    // read mesh from command line
    if (argc == 2)
        read_trimesh(argv[1]);
    
    g.camera.auto_flip_y = false;
    
    glfw_util::start_loop(g.glfw.ctrl);
}
