#include "frame3d.hh"
#include <iostream>
#include <sstream>
#include <kt84/util.hh>
#include <kt84/tw_util.hh>
#include <kt84/glfw_util.hh>
#include <kt84/glut_clone/geometry.hh>
#include <kt84/graphics/graphics_util.hh>
#include <kt84/geometry/CameraFree.hh>

using namespace std;
using namespace kt84;
using namespace kt84::graphics_util;

static const double pi = kt84::util::pi();

struct Globals {
    glfw_util::InitConfig  glfw_cfg;
    glfw_util::LoopControl glfw_ctrl;
    TwBar* bar;
    CameraFree camera;
    frame3d::ZYZVector zyz_0 = { 0, 0, 0 };
    frame3d::ZYZVector zyz_1 = { 0, 0, 0 };
    frame3d::ZYZVector zyz_t;
    frame3d::SHVector sh_0, sh_1, sh_t;
    double t;
    bool verbose = false;
} g;

namespace glfw_callback {
    void framebuffersize(GLFWwindow* window, int width, int height) {
        g.camera.reshape(width, height);
        glViewport(0, 0, width, height);
        TwWindowSize(width, height);
    }
    void key(GLFWwindow* window, int key, int scancode, int action, int mods) {
        if (kt84::glfw_util::TwEventKeyGLFW3(key, scancode, action, mods))
            return;
    }
    void mousebutton(GLFWwindow* window, int button, int action, int mods) {
        if (TwEventMouseButtonGLFW(button, action))
            return;
        auto actionFlag = glfw_util::parseAction(action);
        auto modFlag = glfw_util::parseMods(mods);
        auto mouse = glfw_util::getCursorPos(window);
        if (actionFlag.press) {
            g.camera.mouse_down(mouse.x, mouse.y, 
                modFlag.ctrl  ? Camera::DragMode::PAN  :
                modFlag.shift ? Camera::DragMode::ZOOM : Camera::DragMode::ROTATE);
        } else {
            g.camera.mouse_up();
        }
    }
    void cursorpos(GLFWwindow* window, double xpos, double ypos) {
        if (TwEventMousePosGLFW(xpos, ypos))
            return;
        if (g.camera.drag_mode != Camera::DragMode::NONE)
            g.camera.mouse_move(xpos, ypos);
    }
}

void interpolate() {
    ostringstream sout;
    sout << "sh_0:\n" << (g.sh_0 = frame3d::zyz2sh(g.zyz_0)) << endl;
    sout << "sh_1:\n" << (g.sh_1 = frame3d::zyz2sh(g.zyz_1)) << endl;
    sout << "sh_t:\n" << (g.sh_t = (1 - g.t) * g.sh_0 + g.t * g.sh_1) << endl;
    sout << "zyz_t:\n" << (g.zyz_t = frame3d::sh2zyz(g.sh_t)) << endl;
    sout << "fitting error: " << (g.sh_t - frame3d::zyz2sh(g.zyz_t)).norm() << endl;
    if (g.verbose)
        cout << sout.str();
}

void display() {
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    double aspect_ratio = g.camera.width / static_cast<double>(g.camera.height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(40, aspect_ratio, 0.1, 100);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    gluLookAt(g.camera.eye, g.camera.center, g.camera.up);
    
    glPushMatrix();
    auto& zyz = g.t == 0 ? g.zyz_0 : g.t == 1 ? g.zyz_1 : g.zyz_t;
    double alpha = zyz[0];
    double beta  = zyz[1];
    double gamma = zyz[2];
    glRotated(gamma * 180 / pi, 0, 0, 1);
    glRotated(-90, 1, 0, 0);
    glRotated(beta * 180 / pi, 0, 0, 1);
    glRotated(90, 1, 0, 0);
    glRotated(alpha * 180 / pi, 0, 0, 1);
    glBegin(GL_QUADS);
    glColor3d(1, 0, 0);
    glVertex3d( 1, -1, -1);
    glVertex3d( 1,  1, -1);
    glVertex3d( 1,  1,  1);
    glVertex3d( 1, -1,  1);
    glVertex3d(-1, -1, -1);
    glVertex3d(-1,  1, -1);
    glVertex3d(-1,  1,  1);
    glVertex3d(-1, -1,  1);
    glColor3d(0, 1, 0);
    glVertex3d(-1,  1, -1);
    glVertex3d(-1,  1,  1);
    glVertex3d( 1,  1,  1);
    glVertex3d( 1,  1, -1);
    glVertex3d(-1, -1, -1);
    glVertex3d(-1, -1,  1);
    glVertex3d( 1, -1,  1);
    glVertex3d( 1, -1, -1);
    glColor3d(0, 0, 1);
    glVertex3d(-1, -1,  1);
    glVertex3d( 1, -1,  1);
    glVertex3d( 1,  1,  1);
    glVertex3d(-1,  1,  1);
    glVertex3d(-1, -1, -1);
    glVertex3d( 1, -1, -1);
    glVertex3d( 1,  1, -1);
    glVertex3d(-1,  1, -1);
    glEnd();
    glColor3d(0, 0, 0);
    glLineWidth(5);
    glutWireCube(2);
    glPopMatrix();
    
    glLineWidth(1);
    glBegin(GL_LINES);
    glColor4d(0.5, 0.5, 0.5, 0.5);
    for (int i = -20; i < 20; ++i) {
        glVertex3d(i, 0, -20);
        glVertex3d(i, 0,  20);
        glVertex3d(-20, 0, i);
        glVertex3d( 20, 0, i);
    }
    glEnd();
    
    TwDraw();
}

int main() {
    g.glfw_cfg.window.title = "frame3d";
    g.glfw_cfg.callback.framebuffersize = glfw_callback::framebuffersize;
    g.glfw_cfg.callback.key             = glfw_callback::key;
    g.glfw_cfg.callback.mousebutton     = glfw_callback::mousebutton;
    g.glfw_cfg.callback.cursorpos       = glfw_callback::cursorpos;
    g.glfw_ctrl = glfw_util::init(g.glfw_cfg);
    
    glewInit();
    TwInit(TW_OPENGL, nullptr);
    
    glClearColor(1, 1, 1, 1);
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glEnable(GL_LINE_SMOOTH);
    glEnable(GL_POINT_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);    
    glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
    
    g.camera.eye << 2, 4, 8;
    g.bar = TwNewBar("frame3d");
    tw_util::AddVarCB<double>(g.bar, "alpha_0", [](const double& value) {
        g.zyz_0[0] = value * pi / 180;
        interpolate();
    }, [](double& value) {
        value = g.zyz_0[0] * 180 / pi;
    }, "min=0 max=360 step=1");
    tw_util::AddVarCB<double>(g.bar, "beta_0", [](const double& value) {
        g.zyz_0[1] = value * pi / 180;
        interpolate();
    }, [](double& value) {
        value = g.zyz_0[1] * 180 / pi;
    }, "min=0 max=360 step=1");
    tw_util::AddVarCB<double>(g.bar, "gamma_0", [](const double& value) {
        g.zyz_0[2] = value * pi / 180;
        interpolate();
    }, [](double& value) {
        value = g.zyz_0[2] * 180 / pi;
    }, "min=0 max=360 step=1");
    tw_util::AddVarCB<double>(g.bar, "alpha_1", [](const double& value) {
        g.zyz_1[0] = value * pi / 180;
        interpolate();
    }, [](double& value) {
        value = g.zyz_1[0] * 180 / pi;
    }, "min=0 max=360 step=1");
    tw_util::AddVarCB<double>(g.bar, "beta_1", [](const double& value) {
        g.zyz_1[1] = value * pi / 180;
        interpolate();
    }, [](double& value) {
        value = g.zyz_1[1] * 180 / pi;
    }, "min=0 max=360 step=1");
    tw_util::AddVarCB<double>(g.bar, "gamma_1", [](const double& value) {
        g.zyz_1[2] = value * pi / 180;
        interpolate();
    }, [](double& value) {
        value = g.zyz_1[2] * 180 / pi;
    }, "min=0 max=360 step=1");
    tw_util::AddVarCB<double>(g.bar, "t", [](const double& value) {
        g.t = value;
        interpolate();
    }, [](double& value) {
        value = g.t;
    }, "min=0 max=1 step=0.01");
    tw_util::AddButton(g.bar, "randomize", [](){
        g.zyz_0.setRandom();
        g.zyz_1.setRandom();
        g.zyz_0 += frame3d::ZYZVector::Constant(1);
        g.zyz_1 += frame3d::ZYZVector::Constant(1);
        g.zyz_0 *= pi;
        g.zyz_1 *= pi;
        interpolate();
    }, nullptr);
    TwAddVarRW(g.bar, "verbose", TW_TYPE_BOOLCPP, &g.verbose, nullptr);
    
    g.glfw_ctrl.idle_func[0] = display;
    glfw_util::start_loop(g.glfw_ctrl);
}
