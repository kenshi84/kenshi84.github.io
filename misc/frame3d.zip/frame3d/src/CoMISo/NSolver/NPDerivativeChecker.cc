#include "NPDerivativeChecker.hh"

namespace COMISO {

NPDerivativeChecker::NPDerivativeChecker() 
{}

NPDerivativeChecker::~NPDerivativeChecker() 
{}

}
