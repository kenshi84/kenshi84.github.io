#include <igl/per_face_normals.h>
#include <igl/read_triangle_mesh.h>
#include <igl/opengl/glfw/Viewer.h>
#include <igl/boundary_loop.h>
#include <igl/list_to_matrix.h>
#include <igl/map_vertices_to_circle.h>
#include <igl/harmonic.h>
#include <igl/lscm.h>
#include <igl/speye.h>
#include <igl/vector_area_matrix.h>
#include <igl/cotmatrix.h>
#include <igl/repdiag.h>
#include <igl/massmatrix.h>
#include <igl/eigs.h>

#include <iostream>

#include <Spectra/SymEigsSolver.h>
#include <Spectra/SymEigsShiftSolver.h>
#include <Spectra/SymGEigsSolver.h>
#include <Spectra/SymGEigsShiftSolver.h>
#include <Spectra/MatOp/SparseSymMatProd.h>

using namespace Eigen;
using namespace Spectra;

using SparseMatrixd = Eigen::SparseMatrix<double>;

void compute_singular_values(const Matrix2d& A, double& sigmaLarge, double& sigmaSmall) {
  Matrix2d B = 0.5 * (A - A.transpose() + A.trace() * Matrix2d::Identity());
  Matrix2d C = A - B;

  double rB = B.norm();
  double rC = C.norm();

  const double inv_sqrt2 = 1.0 / std::sqrt(2);

  sigmaLarge = inv_sqrt2 * (rB + rC);
  sigmaSmall = inv_sqrt2 * std::abs(rB - rC);
}


void compute_distortion_per_face(
  const MatrixXd& V,
  const MatrixXi& F,
  const MatrixXd& V_uv,
  VectorXd& D)
{
  const int nV = V.rows();
  const int nF = F.rows();

  assert(V.cols() == 3);
  assert(F.cols() == 3);
  assert(V_uv.rows() == nV);
  assert(V_uv.cols() == 2);

  // Compute face normal
  Eigen::MatrixXd N;
  igl::per_face_normals(V, F, N);

  D = VectorXd::Zero(nF);
  for (int i = 0; i < nF; ++i) {
    Vector3d N_i = N.row(i);

    Vector3d p0 = V.row(F(i, 0));
    Vector3d p1 = V.row(F(i, 1));
    Vector3d p2 = V.row(F(i, 2));

    Vector3d e0 = (p1 - p0).normalized();
    Vector3d e1 = N_i.cross(e0);

    Matrix2d P;
    P.col(0) << (p1 - p0).norm(), 0;
    P.col(1) << e0.dot(p2 - p0), e1.dot(p2 - p0);

    Vector2d q0 = V_uv.row(F(i, 0));
    Vector2d q1 = V_uv.row(F(i, 1));
    Vector2d q2 = V_uv.row(F(i, 2));

    Matrix2d Q;
    Q << q1 - q0, q2 - q0;

    Matrix2d J = Q * P.inverse();

    double sigmaLarge, sigmaSmall;
    compute_singular_values(J, sigmaLarge, sigmaSmall);
    D(i) = sigmaLarge / sigmaSmall;
  }
}









int main() {
  // Parameters
  int method = 0;           // 0:harmonic, 1:LSCM, 2:SCP
  int laplacianType = 0;    // 0:uniform, 1:cotan
  int viewMode = 1;         // 0:UV, 1:XYZ
  int offset_LSCM = 0;
  double uvScale = 10;
  int fillMode = 1;         // 0:plain, 1:grid, 2:distortion
  int highlightedFace = -1;
  double distortionCutoff = 1.5;

  const auto printParameters = [&]() {
    std::cout << "\nParameters:" << std::endl;
    std::cout << "  method: " << (method == 0 ? "harmonic" : method == 1 ? "LSCM" : "SCP") << std::endl;
    std::cout << "  laplacianType: " << (laplacianType == 0 ? "uniform" : "cotan") << std::endl;
    std::cout << "  offset_LSCM: " << offset_LSCM << std::endl;
    std::cout << "  uvScale: " << uvScale << std::endl;
    std::cout << "  fillMode: " << (fillMode == 0 ? "plain" : fillMode == 1 ? "grid" : "distortion") << std::endl;
    std::cout << "  highlightedFace: " << highlightedFace << std::endl;
    std::cout << "  distortionCutoff: " << distortionCutoff << std::endl;
    std::cout << std::endl;
  };
  printParameters();

  // Load input meshes
  MatrixXd V;
  MatrixXi F;
  if (!igl::read_triangle_mesh(DATA_DIR "/david.obj", V, F)) {
    std::cout << "Failed to read the mesh" << std::endl;
    return 1;
  }

  const int nV = V.rows();
  const int nF = F.rows();

  // Assume input mesh is closed
  std::vector<std::vector<int> > bnd_vec;
  igl::boundary_loop(F, bnd_vec);
  if (bnd_vec.size() != 1) {
    std::cout << "Input mesh is not disc topology!" << std::endl;
    return 1;
  }
  VectorXi bnd;
  igl::list_to_matrix(bnd_vec[0], bnd);

  MatrixXd V_uv;

  igl::opengl::glfw::Viewer viewer;

  auto update = [&]() {
    MatrixXd V_uv_copy = uvScale * V_uv;

    viewer.data().clear_points();
    viewer.data().clear_edges();
    if (viewMode == 0) {
      // Plot the mesh in 2D using the UV coordinates as vertex coordinates
      viewer.data().set_mesh(V_uv_copy, F);
      viewer.core().align_camera_center(V_uv_copy, F);
      viewer.core().set_rotation_type(igl::opengl::ViewerCore::ROTATION_TYPE_NO_ROTATION);

      if (highlightedFace > -1 && highlightedFace < nF) {
        MatrixXd P_from(3, 2), P_to(3, 2);
        for (int i = 0; i < 3; ++i) {
          P_from.row(i) = V_uv_copy.row(F(highlightedFace, i));
          P_to.row(i) = V_uv_copy.row(F(highlightedFace, (i + 1) % 3));
        }
        viewer.data().add_edges(P_from, P_to, RowVector3d(1, 0, 0));
      }

      if (method == 1) {
        // show constrained vertices
        MatrixXd P(2, 2);
        P.row(0) = V_uv_copy.row(bnd(offset_LSCM));
        P.row(1) = V_uv_copy.row(bnd((offset_LSCM + bnd.size()/2) % bnd.size()));
        viewer.data().add_points(P, RowVector3d(0, 0, 0));
        viewer.data().point_size = 10;
      }

    } else {
      // Plot the 3D mesh
      viewer.data().set_mesh(V, F);
      viewer.core().align_camera_center(V, F);
      viewer.core().set_rotation_type(igl::opengl::ViewerCore::ROTATION_TYPE_TRACKBALL);

      if (highlightedFace > -1 && highlightedFace < nF) {
        MatrixXd P_from(3, 3), P_to(3, 3);
        for (int i = 0; i < 3; ++i) {
          P_from.row(i) = V.row(F(highlightedFace, i));
          P_to.row(i) = V.row(F(highlightedFace, (i + 1) % 3));
        }
        viewer.data().add_edges(P_from, P_to, RowVector3d(1, 0, 0));
      }

      if (method == 1) {
        // show constrained vertices
        MatrixXd P(2, 3);
        P.row(0) = V.row(bnd(offset_LSCM));
        P.row(1) = V.row(bnd((offset_LSCM + bnd.size()/2) % bnd.size()));
        viewer.data().add_points(P, RowVector3d(0, 0, 0));
        viewer.data().point_size = 10;
      }
    }
    viewer.data().compute_normals();

    viewer.data().show_texture = fillMode == 1;

    if (fillMode == 0 || fillMode == 1) {
      // plain / grid base color
      viewer.data().uniform_colors(
        Vector3d(0.8, 0.8, 0.8),    // diffuse
        Vector3d(0.1, 0.1, 0.1),    // ambient
        Vector3d(0.3, 0.3, 0.3));   // specular
    }

    if (fillMode == 1) {
      // grid texture
      viewer.data().set_uv(V_uv_copy);
    }

    if (fillMode == 2) {
      // distortion
      VectorXd D;
      compute_distortion_per_face(V, F, V_uv, D);

      // std::cout << "Distortion:\n" << D << std::endl << std::endl;

      D = D.cwiseMin(distortionCutoff);
      D = VectorXd::Constant(nF, distortionCutoff) - D;
      D /= distortionCutoff - 1;

      MatrixXd C(nF, 3);
      C << D, D, D;
      viewer.data().set_colors(C);
    }

    viewer.data().set_face_based(true);
  };

  auto recompute = [&]() {
    if (method == 0) {
      // harmonic: map the boundary to a circle, preserving edge proportions
      Eigen::MatrixXd bnd_uv;
      igl::map_vertices_to_circle(V, bnd, bnd_uv);

      if (laplacianType == 0) {
        // uniform Laplacian
        igl::harmonic(F, bnd, bnd_uv, 1, V_uv);
      } else {
        // cotam Laplacian
        igl::harmonic(V, F, bnd, bnd_uv, 1, V_uv);
      }

    } else if (method == 1) {
      // LSCM: fix two points on the boundary
      VectorXi b(2);
      b(0) = bnd(offset_LSCM);
      b(1) = bnd((offset_LSCM + bnd.size()/2) % bnd.size());

      MatrixXd bc(2, 2);
      bc <<
        0, 0,
        1, 0;

      igl::lscm(V, F, b, bc, V_uv);

    } else {
      // SCP
      const int nV2 = nV * 2;
    
      SparseMatrixd I;
      igl::speye(nV2, nV2, I);

      // Assemble the area matrix (note that A is #Vx2 by #Vx2)
      SparseMatrixd A;
      igl::vector_area_matrix(F, A);

      // Assemble the cotan laplacian matrix
      SparseMatrixd L;
      igl::cotmatrix(V, F, L);

      SparseMatrixd L_flat;
      igl::repdiag(L, 2, L_flat);

      // assemble symmetric positive semi-definite matrix for LSCM energy
      SparseMatrixd Q = -L_flat - 2 * A;

      // Construct B-matrix for the generalized eigen decomposition
      SparseMatrixd M;
      igl::massmatrix(V, F, igl::MASSMATRIX_TYPE_DEFAULT, M);

      SparseMatrixd B(nV2, nV2);
      B.reserve(2 * bnd.size());
      for(int k = 0; k < bnd.size(); k++) {
        int i = bnd[k];
        B.insert(i, i) = M.coeff(i, i);
        B.insert(nV + i, nV + i) = M.coeff(i, i);
      }
      B.finalize();

      // Sparse eigen solve
#if 0
      SparseSymShiftSolve<double> op(Q);
      SymEigsShiftSolver<decltype(op)> eigs(op, 8, 20, -10);
#endif
#if 1
      SymShiftInvert<double, Sparse, Sparse> op(Q, B);
      SparseSymMatProd<double> Bop(B);
      SymGEigsShiftSolver<decltype(op), decltype(Bop), GEigsMode::ShiftInvert> eigs(op, Bop, 8, 20, -10);
#endif
#if 0
      SymShiftInvert<double, Sparse, Sparse> op(Q, B);
      SparseSymMatProd<double> Bop(Q);
      SymGEigsShiftSolver<decltype(op), decltype(Bop), GEigsMode::Buckling> eigs(op, Bop, 5, 11, -1);
#endif
#if 0
      SymShiftInvert<double, Sparse, Sparse> op(Q, B);
      SparseSymMatProd<double> Bop(B);
      SymGEigsShiftSolver<decltype(op), decltype(Bop), GEigsMode::Cayley> eigs(op, Bop, 5, 11, -1);
#endif
    
      // Initialize and compute
      eigs.init();
      int nconv = eigs.compute(SortRule::LargestMagn, 1000, 1e-12);
      std::cout << "nconv = " << nconv << std::endl;
    
      std::cout << std::setprecision(20) << "eigenvalues: " << eigs.eigenvalues().size() << std::endl << eigs.eigenvalues() << std::endl;
      for (int i = 0; i < nconv; ++i) {
        std::ofstream fout(std::string("eigenvector-") + std::to_string(i) + ".txt");
        fout << eigs.eigenvectors().col(i);
      }

      V_uv = MatrixXd::Zero(nV, 2);

      // Retrieve results
      if(eigs.info() != CompInfo::Successful) {
        std::cout << "Error!!! " << (int)eigs.info() << std::endl;
        return;
      }

      // MatrixXd eigenvectors;
      // VectorXd eigenvalues;
      // igl::eigs(Q, B, 15, igl::EIGS_TYPE_SM, eigenvectors, eigenvalues);
    
      // std::cout << std::setprecision(20) << "eigenvalues: " << eigenvalues.size() << std::endl << eigenvalues << std::endl;
      // for (int i = 0; i < eigenvectors.cols(); ++i) {
      //   std::ofstream fout(std::string("eigenvector-") + std::to_string(i) + ".txt");
      //   fout << eigenvectors.col(i);
      // }
    
      V_uv.col(0) = eigs.eigenvectors().col(5).head(nV);
      V_uv.col(1) = eigs.eigenvectors().col(5).tail(nV);
    }
    update();
  };

  viewer.core().background_color << 1, 1, 1, 1;
  viewer.data().show_lines = false;

  std::cout<<R"(
  J    Decrease offset_LSCM
  K    Increase offset_LSCM
  G    Decrease distortionCutoff
  H    Increase distortionCutoff
  N    Decrease uvScale
  M    Increase uvScale
  B    Specify uvScale
  P    Toggle lighting
  O    Specify highlightedFace
  1    Toggle method (harmonic, LSCM, SCP)
  2    Toggle uniform / cotan
  3    Toggle UV / XYZ view
  4    Toggle fill mode (plain, grid, distortion)
)";
  viewer.callback_key_pressed =
    [&](igl::opengl::glfw::Viewer &, unsigned int key, int)
  {
    switch(key)
    {
      case 'J':
      case 'j':
        offset_LSCM += bnd.size() - 1;
        offset_LSCM %= bnd.size();
        printParameters();
        recompute();
        break;
      case 'K':
      case 'k':
        offset_LSCM++;
        offset_LSCM %= bnd.size();
        printParameters();
        recompute();
        break;
      case 'G':
      case 'g':
        distortionCutoff -= 0.1;
        if (distortionCutoff < 1.1) distortionCutoff = 1.1;
        printParameters();
        update();
        break;
      case 'H':
      case 'h':
        distortionCutoff += 0.1;
        printParameters();
        update();
        break;
      case 'N':
      case 'n':
        uvScale *= 0.9;
        printParameters();
        update();
        break;
      case 'M':
      case 'm':
        uvScale *= 1.1;
        printParameters();
        update();
        break;
      case 'B':
      case 'b':
        std::cout << "Input uvScale value: ";
        std::cin >> uvScale;
        printParameters();
        recompute();
        break;
      case 'P':
      case 'p':
        // Toggle lighting
        viewer.core().lighting_factor = 1.0- viewer.core().lighting_factor;
        break;
      case 'O':
      case 'o':
        std::cout << "Input highlightedFace value: ";
        std::cin >> highlightedFace;
        printParameters();
        update();
        break;
      case '1':
        method = (method + 1) % 3;
        printParameters();
        recompute();
        break;
      case '2':
        laplacianType = 1 - laplacianType;
        printParameters();
        recompute();
        break;
      case '3':
        viewMode = 1 - viewMode;
        viewer.core().trackball_angle = Quaternionf::Identity();
        update();
        break;
      case '4':
        fillMode = (fillMode + 1) % 3;
        printParameters();
        update();
        break;
      default:
        return false;
    }
    return true;
  };

  recompute();
  viewer.launch();

  return EXIT_SUCCESS;
}
