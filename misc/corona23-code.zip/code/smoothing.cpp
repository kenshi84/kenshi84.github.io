#include <igl/read_triangle_mesh.h>
#include <igl/opengl/glfw/Viewer.h>
#include <igl/boundary_loop.h>
#include <igl/doublearea.h>
#include <igl/barycenter.h>
#include <igl/per_face_normals.h>
#include <igl/cotmatrix.h>
#include <igl/massmatrix.h>
#include <Eigen/Core>
#include <string>
#include <iostream>

using Eigen::Matrix3d;
using Eigen::Vector3d;
using Eigen::RowVector3d;
using Eigen::MatrixXd;
using Eigen::MatrixXi;
using Eigen::VectorXd;
using Eigen::VectorXi;
using SparseMatrixd = Eigen::SparseMatrix<double>;
using Tripletd = Eigen::Triplet<double>;

void uniformUnweightedLaplacian(
    const int nV,
    const MatrixXi & F,
    SparseMatrixd & L)
{
  L.resize(nV, nV);
  std::vector<Tripletd> IJV;
  for(int f = 0; f < F.rows(); f++)
  {
    for (int c = 0; c < 3; ++c)
    {
      int i = F(f, c);
      int j = F(f, (c + 1) % 3 );
      IJV.emplace_back(i, j, 1.);
      IJV.emplace_back(i, i, -1.);
    }
  }
  L.setFromTriplets(IJV.begin(),IJV.end());
}

void valenceMass(
    const int nV,
    const MatrixXi & F,
    SparseMatrixd & M)
{
  M.resize(nV, nV);
  std::vector<Tripletd> IJV;
  for (int f = 0; f < F.rows(); ++f)
  {
    for (int c = 0; c < 3; ++c)
    {
      int i = F(f, c);
      IJV.emplace_back(i, i, 1.);
    }
  }
  M.setFromTriplets(IJV.begin(),IJV.end());
}

SparseMatrixd invertDiagonal(const SparseMatrixd & M)
{
  SparseMatrixd Minv = M;
  for (int k=0; k < Minv.outerSize(); ++k)
  {
    for (SparseMatrixd::InnerIterator it(Minv,k); it; ++it)
    {
      assert(it.row() == it.col());
      it.valueRef() = 1. / it.value();
    }
  }
  return Minv;
}

void recenter_and_rescale(MatrixXd& V, const MatrixXi& F, int rescaleType/* 0:area-based, other:volume-based */) {
  // Compute centroid and subtract (also important for numerics)
  VectorXd dblA;
  igl::doublearea(V,F,dblA);
  double area = 0.5*dblA.sum();

  MatrixXd BC;
  igl::barycenter(V,F,BC);

  Eigen::RowVector3d centroid(0,0,0);
  for(int i = 0;i<BC.rows();i++)
  {
    centroid += 0.5*dblA(i)/area*BC.row(i);
  }
  V.rowwise() -= centroid;

  if (rescaleType == 0) {
    // Normalize to unit surface area
    V.array() /= sqrt(area);

  } else {
    // Normalize to unit interior volume
    MatrixXd N;
    igl::per_face_normals(V, F, N);
    double volume = 0;
    for (int f = 0; f < F.rows(); ++f) {
      volume += BC.row(f).dot(N.row(f)) * dblA(f);
    }
    volume /= 6.;

    V.array() /= cbrt(volume);
  }
}

int main(int argc, char** argv) {
  if (argc != 2) {
    std::cout << "Usage: smoothing <mesh_file>" << std::endl;
    return 1;
  }

  // Parameters
  double lambda = 1e-5;
  int laplacianType = 1;    // 0:uniform, 1:cotan
  int integrationType = 1;  // 0:forward, 1:backward
  int rescaleType = 0;      // 0:area-based, 1:volume-based
  bool doRescale = true;
  bool useRobust = true;

  const auto printParameters = [&]() {
    std::cout << "Parameters:" << std::endl;
    std::cout << "  lambda: " << lambda << std::endl;
    std::cout << "  laplacianType: " << laplacianType << std::endl;
    std::cout << "  integrationType: " << integrationType << std::endl;
    std::cout << "  rescaleType: " << rescaleType << std::endl;
    std::cout << "  doRescale: " << doRescale << std::endl;
    std::cout << "  useRobust: " << useRobust << std::endl;
  };
  printParameters();

  // Load input meshes
  MatrixXd V;
  MatrixXi F;
  if (!igl::read_triangle_mesh(argv[1], V, F)) {
    std::cout << "Failed to read the mesh" << std::endl;
    return 1;
  }

  recenter_and_rescale(V, F, rescaleType);

  const int nV = V.rows();
  const int nF = F.rows();

  const MatrixXd V_orig = V;

  // Assume input mesh is closed
  std::vector<std::vector<int> > bnd;
  igl::boundary_loop(F, bnd);
  if (!bnd.empty()) {
    std::cout << "Input mesh has boundary!" << std::endl;
    return 1;
  }

  SparseMatrixd L_uniform;
  uniformUnweightedLaplacian(nV, F, L_uniform);

  SparseMatrixd M_valence;
  valenceMass(nV, F, M_valence);

  SparseMatrixd L_cotan_init;
  igl::cotmatrix(V, F, L_cotan_init);

  igl::opengl::glfw::Viewer viewer;
  viewer.core().background_color << 1, 1, 1, 1;

  std::cout<<R"(
  J    Decrease lambda
  K    Increase lambda
  G    Specify lambda
  M    Smooth mesh geometry
  R    Reset mesh geometry
  1    Toggle uniform / cotan
  2    Toggle forward / backward
  3    Toggle rescale method
  4    Toggle rescale on / off
  5    Toggle cMCF / MCF
)";

  const auto update = [&]() {
    if((V.array() != V.array()).any()) {
      std::cout<<"Too degenerate to keep smoothing. Better reset"<<std::endl;
      V = V_orig;
    }
    viewer.data().set_mesh(V, F);
    viewer.data().compute_normals();
    viewer.data().uniform_colors(
      Vector3d(0.5, 0.5, 0.5),    // diffuse
      Vector3d(0.1, 0.1, 0.1),    // ambient
      Vector3d(0.3, 0.3, 0.3));   // specular
    viewer.data().face_based = true;
  };

  viewer.callback_key_pressed = 
    [&](igl::opengl::glfw::Viewer &, unsigned int key, int)
  {
    switch(key)
    {
      case 'J':
      case 'j':
        lambda *= 0.9;
        printParameters();
        break;
      case 'K':
      case 'k':
        lambda *= 1.1;
        printParameters();
        break;
      case 'G':
      case 'g':
        std::cout << "Input lambda value: ";
        std::cin >> lambda;
        printParameters();
        break;
/*
      case 'L':
      case 'l':
        // Toggle lighting
        viewer.core().lighting_factor = 1.0- viewer.core().lighting_factor;
        break;
*/
      case 'M':
      case 'm':
      {
        // Perform smoothing
        const SparseMatrixd* L;
        const SparseMatrixd* M;

        SparseMatrixd L_cotan;
        SparseMatrixd M_barycentric;

        if (laplacianType == 0) {
          L = &L_uniform;
          M = &M_valence;

        } else {
          if (useRobust) {
            L = &L_cotan_init; 
          } else {
            igl::cotmatrix(V, F, L_cotan);
            L = &L_cotan;
          }

          igl::massmatrix(V, F, igl::MASSMATRIX_TYPE_BARYCENTRIC, M_barycentric);
          M = &M_barycentric;
        }

        MatrixXd V_new;
        if (integrationType == 0) {
          V_new = V + lambda * invertDiagonal(*M) * *L * V;
        } else {
          V_new = Eigen::SimplicialLDLT<SparseMatrixd>(*M - lambda * *L).solve(*M * V);
        }
        V = V_new;

        if (doRescale)
          recenter_and_rescale(V, F, rescaleType);

        update();
        break;
      }
      case 'R':
      case 'r':
        V = V_orig;
        update();
        break;
      case '1':
        laplacianType = 1 - laplacianType;
        printParameters();
        break;
      case '2':
        integrationType = 1 - integrationType;
        printParameters();
        break;
      case '3':
        rescaleType = 1 - rescaleType;
        printParameters();
        break;
      case '4':
        doRescale = !doRescale;
        printParameters();
        break;
      case '5':
        useRobust = !useRobust;
        printParameters();
        break;
      default:
        return false;
    }
    return true;
  };

  update();
  viewer.launch();

  return EXIT_SUCCESS;
}
