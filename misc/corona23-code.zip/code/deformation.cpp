#include <igl/read_triangle_mesh.h>
#include <igl/opengl/glfw/Viewer.h>
#include <igl/harmonic.h>
#include <igl/cotmatrix.h>
#include <igl/massmatrix.h>
#include <igl/cotmatrix_entries.h>
#include <igl/min_quad_with_fixed.h>

#include <iostream>

using namespace Eigen;
using SparseMatrixd = Eigen::SparseMatrix<double>;







int main(int argc, char** argv) {
  int method = 0;           // 0:harmonic, 1:biharmonic, 2:ARAP-Sorkine, 3:ARAP-Chao
  int numIter = 10;

  const auto printParameters = [&]() {
    std::cout << "\nParameters:" << std::endl;
    std::cout << "  method: " << (method == 0 ? "harmonic" : method == 1 ? "biharmonic" : method == 2 ? "ARAP-Sorkine" : "ARAP-Chao") << std::endl;
    std::cout << "  numIter: " << numIter << std::endl;
    std::cout << std::endl;
  };
  printParameters();

  // Load input meshes
  MatrixXd V;
  MatrixXi F;
  VectorXi b(4);

  if (argc >= 2 && std::string(argv[1]) == "good") {
    igl::read_triangle_mesh(DATA_DIR "/armadillo_good.obj", V, F);

    b(0) = 4851;    // right foot tip
    b(1) = 2310;    // left foot tip
    b(2) = 498;     // right fingertip
    b(3) = 176;    // left fingertip

  } else {
    igl::read_triangle_mesh(DATA_DIR "/armadillo_bad.obj", V, F);

    b(0) = 3494;    // right foot tip
    b(1) = 2606;    // left foot tip
    b(2) = 233;     // right fingertip
    b(3) = 3202;    // left fingertip
  }

  const int nV = V.rows();
  const int nF = F.rows();

  const MatrixXd V_rest = V;

  const double bbdiagNorm = (V.colwise().maxCoeff() - V.colwise().minCoeff()).norm();
  const Vector3d bbCenter = 0.5 * (V.colwise().maxCoeff() + V.colwise().minCoeff());

  // >>>>> Precomputation -------------

  SparseMatrixd L;
  igl::cotmatrix(V, F, L);

  SparseMatrixd M;
  igl::massmatrix(V, F, igl::MASSMATRIX_TYPE_DEFAULT, M);

  MatrixXd C;
  igl::cotmatrix_entries(V, F, C);

  SparseMatrixd Q1;
  SparseMatrixd Q2;
  igl::harmonic(L, M, 1, Q1);
  igl::harmonic(L, M, 2, Q2);

  igl::min_quad_with_fixed_data<double> harmonic_precomp;
  igl::min_quad_with_fixed_data<double> biharmonic_precomp;
  igl::min_quad_with_fixed_data<double> arap_precomp;

  igl::min_quad_with_fixed_precompute(Q1, b, SparseMatrixd{}, true, harmonic_precomp);
  igl::min_quad_with_fixed_precompute(Q2, b, SparseMatrixd{}, true, biharmonic_precomp);
  igl::min_quad_with_fixed_precompute(SparseMatrixd(-1.0 * L), b, SparseMatrixd{}, true, arap_precomp);

  // <<<<< Precomputation -------------

  double t = 0;

  std::vector<Matrix3d> R(nV, Matrix3d::Identity());      // rotation per vertex

  igl::opengl::glfw::Viewer viewer;

  auto update = [&]() {
    viewer.data().set_mesh(V, F);
    viewer.data().compute_normals();
    viewer.data().show_lines = true;
    viewer.data().uniform_colors(
      Vector3d(0.8, 0.8, 0.8),    // diffuse
      Vector3d(0.1, 0.1, 0.1),    // ambient
      Vector3d(0.3, 0.3, 0.3));   // specular

    // show constrained vertices
    viewer.data().clear_points();
    MatrixXd P(b.size(), 3);
    for (int i = 0; i < b.size(); ++i) {
      P.row(i) = V.row(b(i));
    }
    viewer.data().add_points(P, RowVector3d(0, 0, 0));
    viewer.data().point_size = 20;
  };

  auto compute = [&]() {
    // update constraints
    MatrixXd bc = MatrixXd::Zero(b.size(), 3);

    if (argc >= 3 && std::string(argv[2]) == "translate") {
      bc(0, 0) = 0.5 * bbdiagNorm * std::sin(t);

    } else {
      for (int i = 0; i < b.size(); ++i) {
        Vector3d d = V_rest.row(b(i));
        d -= bbCenter;
        d = AngleAxisd(t, Vector3d::UnitZ()) * d;
        d += bbCenter;
        bc.row(i) = d.transpose() - V_rest.row(b(i));
      }
    }

    if (method == 0 || method == 1) {
      // harmonic or biharmonic
      MatrixXd D;
      igl::min_quad_with_fixed_solve(method == 0 ? harmonic_precomp : biharmonic_precomp, VectorXd::Zero(nV).eval(), bc, VectorXd(), D);
      V = V_rest + D;

    } else {
      // ARAP (Sorkine07 or Chao10)
      for (int i = 0; i < b.size(); ++i)
        bc.row(i) += V_rest.row(b(i));

      for (int iter = 0; iter < numIter; ++iter) {
        if (iter % 2 == 1) {
          // odd iteration -> local step (fix V, compute R)
          std::vector<Matrix3d> S(nV, Matrix3d::Zero());
          if (method == 2) {     // Spokes only (Sorkine07)
            for (int f = 0; f < nF; ++f) {
              for (int i = 0; i < 3; ++i) {
                int v0 = F(f, i);
                int v1 = F(f, (i + 1) % 3);
                Vector3d    edgeVec_rest     = V_rest.row(v1) - V_rest.row(v0);
                RowVector3d edgeVec_deformed = V     .row(v1) - V     .row(v0);
                S[v0] += L.coeffRef(v0, v1) * edgeVec_rest * edgeVec_deformed;
              }
            }

          } else {      // Spokes & rims (Chao10)
            for (int f = 0; f < nF; ++f) {
              for (int i = 0; i < 3; ++i) {
                int v = F(f, i);
                for (int j = 0; j < 3; ++j) {
                  int w0 = F(f, j);
                  int w1 = F(f, (j + 1) % 3);
                  Vector3d    edgeVec_rest     = V_rest.row(w1) - V_rest.row(w0);
                  RowVector3d edgeVec_deformed = V     .row(w1) - V     .row(w0);
                  S[v] += C(f, (j + 2) % 3) * edgeVec_rest * edgeVec_deformed;
                }
              }
            }
          }

          for (int v = 0; v < nV; ++v) {
            Eigen::JacobiSVD<Matrix3d> svd(S[v], Eigen::ComputeFullU | Eigen::ComputeFullV);
            R[v] = svd.matrixV() * svd.matrixU().transpose();
          }

        } else {
          // even iteration -> global step (fix R, compute V)
          MatrixXd B = MatrixXd::Zero(nV, 3);
          if (method == 2) {     // Spokes only (Sorkine07)
            for (int f = 0; f < nF; ++f) {
              for (int i = 0; i < 3; ++i) {
                int v0 = F(f, i);
                int v1 = F(f, (i + 1) % 3);
                Vector3d p0 = V_rest.row(v0);
                Vector3d p1 = V_rest.row(v1);
                double w01 = L.coeffRef(v0, v1);
                Matrix3d R0 = R[v0];
                Matrix3d R1 = R[v1];
                B.row(v0) += 0.5 * w01 * (R0 + R1) * (p1 - p0);
              }
            }

          } else {   // Spokes & rims (Chao10)
            for (int f = 0; f < nF; ++f) {
              Matrix3d R0 = R[F(f, 0)];
              Matrix3d R1 = R[F(f, 1)];
              Matrix3d R2 = R[F(f, 2)];

              for (int i = 0; i < 3; ++i) {
                int v0 = F(f, i);
                int v1 = F(f, (i + 1) % 3);
                int v2 = F(f, (i + 2) % 3);
                Vector3d p0 = V_rest.row(v0);
                Vector3d p1 = V_rest.row(v1);
                Vector3d p2 = V_rest.row(v2);
                Vector3d p01 = p1 - p0;
                Vector3d p02 = p2 - p0;
                double w01 = C(f, (i + 2) % 3);
                double w02 = C(f, (i + 1) % 3);
                B.row(v0) += (1.0 / 3.0) * (R0 + R1 + R2) * (w01 * p01 + w02 * p02);
              }
            }
          }

          igl::min_quad_with_fixed_solve(arap_precomp, B, bc, MatrixXd{}, V);
        }
      }
    }

    update();
  };

  viewer.core().background_color << 1, 1, 1, 1;

  std::cout<<R"(
  N    Generate next frame
  R    Reset

  J    Decrease numIter
  K    Increase numIter
  L    Specify numIter

  M    Perform one ARAP step

  1    Toggle harmonic / biharmonic
  2    Toggle ARAP Sorkine07 / Chao10
)";
  viewer.callback_key_pressed =
    [&](igl::opengl::glfw::Viewer &, unsigned int key, int)
  {
    switch(key)
    {
      case 'N':
      case 'n':
        t += 0.1;
        compute();
        break;
      case 'R':
      case 'r':
        V = V_rest;
        R = std::vector<Matrix3d>(nV, Matrix3d::Identity());
        t = 0;
        update();
        break;
      case 'J':
      case 'j':
        if (numIter > 1) {
          --numIter;
          printParameters();
          compute();
        }
        break;
      case 'K':
      case 'k':
        ++numIter;
        printParameters();
        compute();
        break;
      case 'L':
      case 'l':
        std::cout << "Input numIter value: ";
        std::cin >> numIter;
        if (numIter < 1) numIter = 1;
        printParameters();
        compute();
        break;
      case 'M':
      case 'm':
        if (method == 2 || method == 3) {
          int numIter_temp = numIter;
          numIter = 1;
          compute();
          numIter = numIter_temp;
        }
        break;
      case '1':
        if (method > 1) {
          method = 0;
        } else {
          method = (method + 1) % 2;
        }
        printParameters();
        compute();
        break;
      case '2':
        if (method < 2) {
          method = 2;
        } else {
          method = ((method - 2) + 1) % 2 + 2;
        }
        printParameters();
        compute();
        break;
      default:
        return false;
    }
    return true;
  };

  update();
  viewer.core().align_camera_center(V, F);
  viewer.launch();
}
