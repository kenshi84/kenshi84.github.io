#include <igl/colon.h>
#include <igl/PI.h>
#include <igl/readDMAT.h>
#include <igl/readOFF.h>
#include <igl/min_quad_with_fixed.h>
#include <igl/harmonic.h>
#include <igl/cotmatrix.h>
#include <igl/cotmatrix_entries.h>
#include <igl/massmatrix.h>
#include <igl/opengl/glfw/Viewer.h>
#include <igl/Timer.h>

#include <Eigen/Geometry>
#include <Eigen/StdVector>
#include <vector>
#include <algorithm>
#include <iostream>

using Eigen::Matrix3d;
using Eigen::Vector3d;
using Eigen::RowVector3d;
using Eigen::MatrixXd;
using Eigen::MatrixXi;
using Eigen::VectorXd;
using Eigen::VectorXi;
using SparseMatrixd = Eigen::SparseMatrix<double>;
using Tripletd = Eigen::Triplet<double>;

//------------------------------------------------------------------------------

struct ARAPData
{
  MatrixXd V;                                         // original vertex positions
  MatrixXi F;                                         // triangles
  SparseMatrixd L;                                    // negative semi-definite cotan Laplacian
  MatrixXd C;                                         // #Fx3 cotangent entries
  SparseMatrixd M;                                    // mass matrix
  SparseMatrixd Q;                                    // bi-Laplacian
  MatrixXd K;
  VectorXi b;                                         // list of boundary indices into V
  int max_iter = 10;                                  // maximum inner iterations
  igl::min_quad_with_fixed_data<double> solver_data;  // quadratic solver data
  double bbox_diag = 0;
  double error_tol = 1.e-5;                           // error tolerance relative to bounding box diagonal
  int energy_mode = 1;                                // 0 -> spokes only (Sorkine07), 1 -> spokes & rims (Chao10)
};

bool arap_precomputation(const MatrixXd& V, const MatrixXi& F, const VectorXi& b, ARAPData& arap_data) {
  arap_data.V = V;
  arap_data.F = F;
  arap_data.b = b;

  igl::cotmatrix(V, F, arap_data.L);

  igl::cotmatrix_entries(V, F, arap_data.C);

  igl::massmatrix(V, F, igl::MASSMATRIX_TYPE_DEFAULT, arap_data.M);

  igl::harmonic(arap_data.L, arap_data.M, 2, arap_data.Q);

  // Compute K matrix
  const int nV = V.rows();
  const int nF = F.rows();
  std::vector<std::vector<std::pair<int,int>>> vertexNeighborVertices(nV);
  for (int f = 0; f < nF; ++f) {
    for (int i = 0; i < 3; ++i) {
      int v0 = F(f, i);
      int v1 = F(f, (i + 1) % 3);
      int v2 = F(f, (i + 2) % 3);
      vertexNeighborVertices[v0].emplace_back(v1, v2);
    }
  }

  SparseMatrixd& L = const_cast<SparseMatrixd&>(arap_data.L);
  SparseMatrixd L_check(nV, nV);
  arap_data.K.resize(3 * nV, nV);

  for (int v0 = 0; v0 < nV; ++v0) {
    const int nE = vertexNeighborVertices[v0].size();

    SparseMatrixd A(nV, 2 * nE);
    VectorXd C(2 * nE);

    std::vector<Tripletd> triplets;
    for (int e = 0; e < nE; ++e) {
      int v1, v2;
      std::tie(v1, v2) = vertexNeighborVertices[v0][e];

      int e0 = 2 * e;
      triplets.emplace_back(v0, e0, -1);
      triplets.emplace_back(v1, e0,  1);
      C(e0) = L.coeffRef(v0, v1);

      int e1 = 2 * e + 1;
      triplets.emplace_back(v1, e1, -1);
      triplets.emplace_back(v2, e1,  1);
      C(e1) = L.coeffRef(v1, v2);
    }
    A.setFromTriplets(triplets.begin(), triplets.end());

    SparseMatrixd L_local = A * (MatrixXd(C.asDiagonal()).sparseView() * A.transpose()).eval();

    arap_data.K.block(3 * v0, 0, 3, nV) = V.transpose() * L_local;

    L_check += L_local;
  }

  std::cout << "Sanity check: " <<  (-4.0 * L - L_check).squaredNorm() << std::endl;

  Vector3d bbox_min = V.colwise().minCoeff();
  Vector3d bbox_max = V.colwise().maxCoeff();
  arap_data.bbox_diag = (bbox_max - bbox_min).norm();

#if 1
  return igl::min_quad_with_fixed_precompute(SparseMatrixd(-1.0 * arap_data.L), b, SparseMatrixd{}, true, arap_data.solver_data);
#else
  return igl::min_quad_with_fixed_precompute(arap_data.Q, b, SparseMatrixd{}, true, arap_data.solver_data);
#endif
}

bool arap_solve(const MatrixXd& bc, const ARAPData& arap_data, MatrixXd& U) {
  const int nV = arap_data.V.rows();
  const int nF = arap_data.F.rows();
  SparseMatrixd& L = const_cast<SparseMatrixd&>(arap_data.L);
  SparseMatrixd& M = const_cast<SparseMatrixd&>(arap_data.M);

  for (int iter = 0; iter < arap_data.max_iter; ++iter) {
    // Compute per-vertex covariance matrix
    std::vector<Matrix3d> per_vertex_covariance(nV, Matrix3d::Zero());
    if (arap_data.energy_mode == 0) {     // Spokes only (Sorkine07)
      for (int f = 0; f < nF; ++f) {
        for (int i = 0; i < 3; ++i) {
          int v0 = arap_data.F(f, i);
          int v1 = arap_data.F(f, (i + 1) % 3);
          Vector3d    edgeVec_rest     = arap_data.V.row(v1) - arap_data.V.row(v0);
          RowVector3d edgeVec_deformed =           U.row(v1) -           U.row(v0);
          per_vertex_covariance[v0] += L.coeffRef(v0, v1) * edgeVec_rest * edgeVec_deformed;
        }
      }

    } else if (arap_data.energy_mode == 1) {      // Spokes & rims (Chao10)
      for (int f = 0; f < nF; ++f) {
        for (int i = 0; i < 3; ++i) {
          int v = arap_data.F(f, i);
          for (int j = 0; j < 3; ++j) {
            int w0 = arap_data.F(f, j);
            int w1 = arap_data.F(f, (j + 1) % 3);
            Vector3d    edgeVec_rest     = arap_data.V.row(w1) - arap_data.V.row(w0);
            RowVector3d edgeVec_deformed =           U.row(w1) -           U.row(w0);
            per_vertex_covariance[v] += arap_data.C(f, (j + 2) % 3) * edgeVec_rest * edgeVec_deformed;
          }
        }
      }
    }

    // Fit rotation to each covariance matrix via SVD
    std::vector<Matrix3d> per_vertex_rotation(nV);
    for (int v = 0; v < nV; ++v) {
      Eigen::JacobiSVD<Matrix3d> svd(per_vertex_covariance[v], Eigen::ComputeFullU | Eigen::ComputeFullV);
      per_vertex_rotation[v] = svd.matrixV() * svd.matrixU().transpose();
    }

    MatrixXd R(3, 3 * nV);
    for (int v = 0; v < nV; ++v) {
      R.block<3, 3>(0, 3 * v) = per_vertex_rotation[v];
    }
#if 0
    MatrixXd S = arap_data.K * U;
    MatrixXd R(3, 3 * nV);
    for (int v = 0; v < nV; ++v) {
      Matrix3d S_v = S.block<3, 3>(3 * v, 0);
      Eigen::JacobiSVD<Matrix3d> svd(S_v, Eigen::ComputeFullU | Eigen::ComputeFullV);
      R.block<3, 3>(0, 3 * v) = svd.matrixV() * svd.matrixU().transpose();
    }
#endif
    
    // Compute right hand side
#if 0
    MatrixXd B = -(R * arap_data.K).transpose();
#endif
#if 1
    MatrixXd B = MatrixXd::Zero(nV, 3);
    if (arap_data.energy_mode == 0) {     // Spokes only (Sorkine07)
      for (int f = 0; f < nF; ++f) {
        for (int i = 0; i < 3; ++i) {
          int v0 = arap_data.F(f, i);
          int v1 = arap_data.F(f, (i + 1) % 3);
          Vector3d p0 = arap_data.V.row(v0);
          Vector3d p1 = arap_data.V.row(v1);
          double w01 = L.coeffRef(v0, v1);
          Matrix3d R0 = per_vertex_rotation[v0];
          Matrix3d R1 = per_vertex_rotation[v1];
          B.row(v0) += 0.5 * w01 * (R0 + R1) * (p0 - p1);
        }
      }

    } else if (arap_data.energy_mode == 1) {   // Spokes & rims (Chao10)
      for (int f = 0; f < nF; ++f) {
        // average rotaion from 3 vertices
        Matrix3d R = Matrix3d::Zero();
        for (int i = 0; i < 3; ++i) {
          int v = arap_data.F(f, i);
          R += per_vertex_rotation[v];
        }
        R /= 3;

        for (int i = 0; i < 3; ++i) {
          int v0 = arap_data.F(f, i);
          int v1 = arap_data.F(f, (i + 1) % 3);
          int v2 = arap_data.F(f, (i + 2) % 3);
          Vector3d p0 = arap_data.V.row(v0);
          Vector3d p1 = arap_data.V.row(v1);
          Vector3d p2 = arap_data.V.row(v2);
          Vector3d p01 = p0 - p1;
          Vector3d p02 = p0 - p2;
          double w01 = arap_data.C(f, (i + 2) % 3);
          double w02 = arap_data.C(f, (i + 1) % 3);
          B.row(v0) += R * (w01 * p01 + w02 * p02);
        }
      }
    }
    B *= -1;
#endif
#if 0
    SparseMatrixd Minv;
    igl::invert_diag(M, Minv);
    MatrixXd B = Minv * arap_data.L * arap_data.V;
    for (int v = 0; v < nV; ++v) {
      Vector3d laplacian = B.row(v);
      B.row(v) = per_vertex_rotation[v] * laplacian;
    }
    B = arap_data.L * B;
    B *= -1;
#endif
#if 0
    MatrixXd B_cache = MatrixXd::Zero(nV, 3);
    for (int f = 0; f < nF; ++f) {
      for (int d = 0; d < 3; ++d) {
        int j = arap_data.F(f, d);
        int k = arap_data.F(f, (d + 1) % 3);
        Vector3d p_j = arap_data.V.row(j);
        Vector3d p_k = arap_data.V.row(k);
        double w_jk = L.coeffRef(j, k);
        Matrix3d R_j = per_vertex_rotation[j];
        Matrix3d R_k = per_vertex_rotation[k];
        B_cache.row(j) += 0.5 * w_jk * (R_j + R_k) * (p_j - p_k);
      }
    }
    MatrixXd B = MatrixXd::Zero(nV, 3);
    for (int f = 0; f < nF; ++f) {
      for (int d = 0; d < 3; ++d) {
        int i = arap_data.F(f, d);
        int j = arap_data.F(f, (d + 1) % 3);
        Vector3d p_i = arap_data.V.row(i);
        Vector3d p_j = arap_data.V.row(j);
        double w_ii = L.coeffRef(i, i);
        double w_ij = L.coeffRef(i, j);
        double m_i  = M.coeffRef(i, i);
        Matrix3d R_i = per_vertex_rotation[i];
        Matrix3d R_j = per_vertex_rotation[j];
        B.row(i) += ((-w_ii * w_ij) / m_i) * 0.5 * (R_i + R_j) * (p_i - p_j);

        double m_j  = M.coeffRef(j, j);
        B.row(i) -= (w_ij / m_j) * B_cache.row(j);
      }
    }
    B *= -1;
#endif

    MatrixXd U_old = U;

    // Solve
    if (!igl::min_quad_with_fixed_solve(arap_data.solver_data, B, bc, MatrixXd{}, U))
      return false;

    MatrixXd U_delta = U - U_old;
    if (U_delta.rowwise().norm().maxCoeff() < arap_data.bbox_diag * arap_data.error_tol) {
      std::cout << "Error below tolerance after " << iter << " iterations" << std::endl;
      return true;
    }
  }
  return true;
}


//------------------------------------------------------------------------------


const Eigen::RowVector3d sea_green(70./255.,252./255.,167./255.);
Eigen::MatrixXd V,U;
Eigen::MatrixXi F;
Eigen::VectorXi S,b;
Eigen::RowVector3d mid;
double anim_t = 0.0;
double anim_t_dir = 0.03;
ARAPData arap_data;

bool pre_draw(igl::opengl::glfw::Viewer & viewer)
{
  using namespace Eigen;
  using namespace std;
    MatrixXd bc(b.size(),V.cols());
    for(int i = 0;i<b.size();i++)
    {
      bc.row(i) = V.row(b(i));
      switch(S(b(i)))
      {
        case 0:
        {
          const double r = mid(0)*0.25;
          bc(i,0) += r*sin(0.5*anim_t*2.*igl::PI);
          bc(i,1) -= r+r*cos(igl::PI+0.5*anim_t*2.*igl::PI);
          break;
        }
        case 1:
        {
          const double r = mid(1)*0.15;
          bc(i,1) += r+r*cos(igl::PI+0.15*anim_t*2.*igl::PI);
          bc(i,2) -= r*sin(0.15*anim_t*2.*igl::PI);
          break;
        }
        case 2:
        {
          const double r = mid(1)*0.15;
          bc(i,2) += r+r*cos(igl::PI+0.35*anim_t*2.*igl::PI);
          bc(i,0) += r*sin(0.35*anim_t*2.*igl::PI);
          break;
        }
        default:
          break;
      }
    }

    static int count = 0;
    static double millisec_sum = 0;
    ++count;
    igl::Timer timer;
    timer.start();
    arap_solve(bc,arap_data,U);
    millisec_sum += timer.getElapsedTimeInMilliSec();
    if (count == 10) {
      std::cout << "solve time (ms): " << (millisec_sum / count) << std::endl;
      count = 0;
      millisec_sum = 0;
    }

    std::cout << "Deviation from rest pose: " << (U - V).squaredNorm() << std::endl;

    viewer.data().set_vertices(U);
    viewer.data().compute_normals();
  if(viewer.core().is_animating)
  {
    anim_t += anim_t_dir;
  }
  return false;
}

bool key_down(igl::opengl::glfw::Viewer &viewer, unsigned char key, int mods)
{
  switch(key)
  {
    case ' ':
      viewer.core().is_animating = !viewer.core().is_animating;
      return true;
  }
  return false;
}

int main(int argc, char *argv[])
{
  using namespace Eigen;
  using namespace std;
  igl::readOFF(DATA_DIR "/decimated-knight.off",V,F);
  U=V;
  igl::readDMAT(DATA_DIR "/decimated-knight-selection.dmat",S);

  // vertices in selection
  igl::colon<int>(0,V.rows()-1,b);
  b.conservativeResize(stable_partition( b.data(), b.data()+b.size(), 
   [](int i)->bool{return S(i)>=0;})-b.data());
  // Centroid
  mid = 0.5*(V.colwise().maxCoeff() + V.colwise().minCoeff());
  // Precomputation
  arap_data.max_iter = 100;
  arap_precomputation(V, F, b, arap_data);

  // Set color based on selection
  MatrixXd C(F.rows(),3);
  RowVector3d purple(80.0/255.0,64.0/255.0,255.0/255.0);
  RowVector3d gold(255.0/255.0,228.0/255.0,58.0/255.0);
  for(int f = 0;f<F.rows();f++)
  {
    if( S(F(f,0))>=0 && S(F(f,1))>=0 && S(F(f,2))>=0)
    {
      C.row(f) = purple;
    }else
    {
      C.row(f) = gold;
    }
  }

  // Plot the mesh with pseudocolors
  igl::opengl::glfw::Viewer viewer;
  viewer.data().set_mesh(U, F);
  viewer.data().set_colors(C);
  viewer.callback_pre_draw = &pre_draw;
  viewer.callback_key_down = &key_down;
  viewer.core().is_animating = false;
  viewer.core().animation_max_fps = 30.;
  cout<<
    "Press [space] to toggle animation"<<endl;
  viewer.launch();
}
