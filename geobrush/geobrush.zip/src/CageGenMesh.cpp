#include "StdAfx.h"
#include "CageGenMesh.h"
#include "Core.h"
#include <KLIB/Clock.h>
#include <KLIB/Util.h>
#include <KLIB/TriangleUtil.h>
#include <KLIB/Umfpack.h>
#include <KLIB/CholmodMatrix.h>
#include <vector>
#include <sstream>
using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
MeshSrc& meshSrc = core.meshSrc_;
MeshTgt& meshTgt = core.meshTgt_;
GCMesh& gcmesh = core.gcmesh_;
}

bool CageGenMesh::dbg_use_laplacian_optimization_ = true;
bool CageGenMesh::dbg_show_ = false;

bool CageGenMesh::original_step1_compute_boundary() {
    ClkSimple clk("CageGenMesh::original_step1_compute_boundary");
    // get boundary loop of paramed patch in uv space
    boundary_.clear();
    for (size_t i = 0; i < meshSrc.paramedPatch_.vertices_boundary_.size(); ++i) {
        MeshSrc::VHandle v = meshSrc.paramedPatch_.vertices_boundary_[i];
        Vector2f uv = meshSrc.data(v).expmap_data_.uv_;
        uv = (uv - Vector2f(0.5)) * Config::CAGE_2D_BOUNDARY_SCALING + Vector2f(0.5);
        boundary_.push_back(uv);
    }
    boundary_.setLoop(true);
    size_t targetNumPoints = static_cast<size_t>(boundary_.length() / Config::CAGE_2D_EDGE_LENGTH_AVERAGE);
    boundary_.resample(targetNumPoints);
    
    return true;
}
bool CageGenMesh::original_step2_triangulate() {
    ClkSimple clk("CageGenMesh::original_step2_triangulate");
    // call Triangle
    int nb = static_cast<int>(boundary_.size());
    vector<double> in_pointlist  (2 * nb, 0);
    vector<int   > in_segmentlist(2 * nb, -1);
    for (int i = 0; i < nb; ++i) {
        in_pointlist  [2 * i    ] = boundary_[i].x_;
        in_pointlist  [2 * i + 1] = boundary_[i].y_;
        in_segmentlist[2 * i]     = i;
        in_segmentlist[2 * i + 1] = (i + 1) % nb;
    }
    vector<double> out_pointlist;
    vector<int   > out_trianglelist;
    float area_max = Config::CAGE_2D_EDGE_LENGTH_AVERAGE * Config::CAGE_2D_EDGE_LENGTH_AVERAGE / 2.0f;
    char option[256];   {
        stringstream ss;
        ss << "zpq30YQa" << area_max;
        strcpy(option, ss.str().c_str());
    }
    TriangleUtil::ConformingConstrainedDelaunay(out_pointlist, out_trianglelist, in_pointlist, in_segmentlist, vector<double>(), option);
    
    int n = static_cast<int>(out_pointlist.size() / 2);
    // convert to OpenMesh structure
    clear();
    for (int i = 0; i < n; ++i)
        add_vertex(Vector2d(&out_pointlist[2 * i]).convert<float>());
    
    vector<VHandle> face_vhandles(3);
    for (size_t i = 0; i < out_trianglelist.size() / 3; ++i) {
        for (int j = 0; j < 3; ++j)
            face_vhandles[j] = vertex_handle(out_trianglelist[3 * i + j]);
        add_face(face_vhandles);
    }
    
    // construct kd-tree
    uv_kdTree_.clear();
    uv_kdTree_.reserve(n_vertices());
    for (VIter v = vertices_begin(); v != vertices_end(); ++v)
        uv_kdTree_.push_back(point(v).convert<double>());
    uv_kdTree_.build();
    
    // construct shell-like topology for GCMesh (position information is not available at this moment)
    gcmesh.clear();
    {   // vertices
        for (VIter v = vertices_begin(); v != vertices_end(); ++v)
            for (int i = 0; i < 2; ++i)
                gcmesh.add_vertex(Vector3f());
    }
    {   // side faces
        vector<GCMesh::VHandle> face_vhandles_side(3);
        for (int i0 = 0; i0 < nb; ++i0) {
            int i1 = (i0 + 1) % nb;
            face_vhandles_side[0] = gcmesh.vertex_handle(2 * i0);
            face_vhandles_side[1] = gcmesh.vertex_handle(2 * i0 + 1);
            face_vhandles_side[2] = gcmesh.vertex_handle(2 * i1 + 1);
            gcmesh.add_face(face_vhandles_side);
            face_vhandles_side[0] = gcmesh.vertex_handle(2 * i1 + 1);
            face_vhandles_side[1] = gcmesh.vertex_handle(2 * i1);
            face_vhandles_side[2] = gcmesh.vertex_handle(2 * i0);
            gcmesh.add_face(face_vhandles_side);
        }
    }
    {   // front and back faces
        vector<GCMesh::VHandle> face_vhandles_front(3);
        vector<GCMesh::VHandle> face_vhandles_back (3);
        for (FIter f = faces_begin(); f != faces_end(); ++f) {
            FVIter v = fv_iter(f);
            for (int i = 0; i < 3; ++i, ++v) {
                int j = v.handle().idx();
                face_vhandles_front[i]     = gcmesh.vertex_handle(2 * j);
                face_vhandles_back [2 - i] = gcmesh.vertex_handle(2 * j + 1);
            }
            gcmesh.add_face(face_vhandles_front);
            gcmesh.add_face(face_vhandles_back );
        }
    }
    
    return true;
}
bool CageGenMesh::original_step3_set_configuration() {
    ClkSimple clk("CageGenMesh::original_step3_set_configuration");
    // set VertexT.{original_normal_, line_start_, original_ugrad_}
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        // collect 3 vertices in meshSrc.paramedPatch which are the closest in uv
        Vector2f uv = point(v);
        KdTree2d::SearchResult sr = meshSrc.paramedPatch_.uv_kdTree_.search(uv.convert<double>(), 3);
        Vector3f weights;
        float dist_avg = 0.0f;
        for (int i = 0; i < 3; ++i) {
            weights[i] = static_cast<float>(sr.distances_[i]);
            dist_avg += weights[i] / 3.0f;
        }
        float weight_total = 0.0f;
        for (int i = 0; i < 3; ++i) {
            weights[i] = 1.0f / (weights[i] + dist_avg);
            weight_total += weights[i];
        }
        weights /= weight_total;
        //int n_candidates = 10;
        //KdTree2d::SearchResult sr = meshSrc.paramedPatch_.uv_kdTree_.search(uv.convert<double>(), n_candidates);
        Vector2f triangle_uv [3];
        Vector3f triangle_n  [3];
        Vector3f triangle_xyz[3];
        //Vector3f baryCoord;
        //bool found = false;
        //int cnt = 0;
        //for (int i = 0; ; ++i) {
        //    for (int j = i + 1; ; ++j) {
        //        for (int k = j + 1; k < n_candidates; ++k, ++cnt) {
        //            if (1000 < cnt)
        //                return false;
        //            int indices[3] = { sr.indices_[i], sr.indices_[j], sr.indices_[k] };
        //            for (int m = 0; m < 3; ++m) {
        //                MeshSrc::VHandle w = meshSrc.paramedPatch_.vertices_[indices[m]];
        //                MeshSrc::VertexData& wdata = meshSrc.data(w);
        //                triangle_uv [m] = wdata.expmap_data_.uv_;
        //                triangle_n  [m] = wdata.expmap_normal_;
        //                triangle_xyz[m] = meshSrc.point(w);
        //            }
        //            baryCoord = Util::calcBarycentricCoord<float, 2>(triangle_uv, uv);
        //            if (0 < baryCoord.x_ && 0 < baryCoord.y_ && 0 < baryCoord.z_) {
        //                found = true;
        //                break;
        //            }
        //        }
        //        if (found)
        //            break;
        //    }
        //    if (found)
        //        break;
        //}
        for (int i = 0; i < 3; ++i) {
            MeshSrc::VHandle w = meshSrc.paramedPatch_.vertices_[sr.indices_[i]];
            MeshSrc::VertexData& wdata = meshSrc.data(w);
            triangle_uv [i] = wdata.expmap_data_.uv_;
            triangle_n  [i] = wdata.expmap_normal_;
            triangle_xyz[i] = meshSrc.point(w);
        }
        // set original_normal and original_xyz
        VertexData& vdata = data(v);
        Vector3f& original_normal = vdata.original_normal_;
        Vector3f& original_xyz    = vdata.original_xyz_;
        for (int i = 0; i < 3; ++i) {
            original_normal += weights[i] * triangle_n  [i];
            original_xyz    += weights[i] * triangle_xyz[i];
        }
        original_normal.normalize();
        // set original_ugrad
        /*
        say we have a linear function f in 3D: f(x) = (a | x) + b,   a, x: 3D vectors, b: scalar, (a, b: unknown constants)
        and assume that its gradient vector a is represented as: a = t0*x0 + t1*x1 + t2*x2 where t0 + t1 + t2 = 0
        (i.e., a is a directional vector lying on the plane x0-x1-x2)
        we have the following four conditions:
            f(x0) = f0
            f(x1) = f1
            f(x2) = f2
            t0 + t1 + t2 = 0
        these are enough to solve for t0, t1, t2, and b. The equation looks like:
            | (x0)^2 (x0|x1) (x0|x2) 1 |   |t0|   |f0|
            | (x0|x1) (x1)^2 (x1|x2) 1 | * |t1| = |f1|
            | (x0|x2) (x1|x2) (x2)^2 1 |   |t2|   |f2|
            |    1       1      1    0 |   |b |   |0 |
        */
        Matrix4x4f A;
        Vector4f b;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j)
                A(i, j) = triangle_xyz[i] | triangle_xyz[j];
            A(3, i) = A(i, 3) = 1.0f;
            b[i] = triangle_uv[i].x_;
        }
        Vector4f x;
        bool invertible = A.solve(b, x);
        assert(invertible);
        Vector3f& original_ugrad = vdata.original_ugrad_;
        for (int i = 0; i < 3; ++i)
            original_ugrad += x[i] * triangle_xyz[i];
    }
    
    return true;
}
bool CageGenMesh::original_step4_project_line() {
    ClkSimple clk("CageGenMesh::original_step4_project_line");
    for (size_t i = 0; i < meshSrc.paramedPatch_.vertices_.size(); ++i) {
        MeshSrc::VHandle v = meshSrc.paramedPatch_.vertices_[i];
        Vector3f p = meshSrc.point(v);
        MeshSrc::VertexData& vdata = meshSrc.data(v);
        KdTree2d::SearchResult sr = uv_kdTree_.search(vdata.expmap_data_.uv_.convert<double>(), 3);
        for (int j = 0; j < 3; ++j) {
            VHandle w = vertex_handle(sr.indices_[j]);
            VertexData& wdata = data(w);
            float coef = (p - wdata.original_xyz_) | wdata.original_normal_;
            if (wdata.line_coef_[0] < coef)
                wdata.line_coef_[0] = coef;
            if (coef < wdata.line_coef_[1])
                wdata.line_coef_[1] = coef;
        }
    }
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        VertexData& vdata = data(v);
        float diff = max<float>(vdata.line_coef_[0] - vdata.line_coef_[1], 0.1f);
        vdata.line_coef_[0] += (Config::CAGE_LINE_EXTREMUM_SCALING - 1.0) * diff;
        vdata.line_coef_[1] -= (Config::CAGE_LINE_EXTREMUM_SCALING - 1.0) * diff;
    }
    
    return true;
}
bool CageGenMesh::original_step5_optimize_position() {
    ClkSimple clk("CageGenMesh::original_step5_optimize_position");
    
    int n = n_vertices();
    int nb = static_cast<int>(boundary_.size());
    int ni = n - nb;
    // smoothness constraints (interior)
    CholmodMatrix Li;    {
        vector<CholmodMatrix::Triplet> triplets;
        triplets.reserve(2 * ni * 8);
        for (int i = nb; i < n; ++i) {
            VHandle v = vertex_handle(i);
            for (int j = 0; j < 2; ++j)
                triplets.push_back(CholmodMatrix::Triplet(2 * (i - nb) + j, 2 * i + j, -1));
            int valance = 0;
            for (VVIter w = vv_iter(v); w; ++w)
                ++valance;
            double weight = 1.0 / valance;
            for (VVIter w = vv_iter(v); w; ++w) {
                int iw = w.handle().idx();
                for (int j = 0; j < 2; ++j)
                    triplets.push_back(CholmodMatrix::Triplet(2 * (i - nb) + j, 2 * iw + j, weight));
            }
        }
        Li.init(2 * ni, 2 * n, triplets);
    }
    CholmodMatrix Li_t = Li.transpose();
    
    // smoothness constraints (boundary)
    CholmodMatrix Lb;    {
        vector<CholmodMatrix::Triplet> triplets;
        triplets.reserve(2 * nb * 2);
        for (int i = 0; i < nb; ++i) {
            int i_next = (i + 1) % nb;
            int i_prev = (i + nb - 1) % nb;
            for (int j = 0; j < 2; ++j) {
                triplets.push_back(CholmodMatrix::Triplet(2 * i + j, 2 * i      + j,  -1));
                triplets.push_back(CholmodMatrix::Triplet(2 * i + j, 2 * i_next + j, 0.5));
                triplets.push_back(CholmodMatrix::Triplet(2 * i + j, 2 * i_prev + j, 0.5));
            }
        }
        Lb.init(2 * nb, 2 * n, triplets);
    }
    CholmodMatrix Lb_t = Lb.transpose();
    
    // goal position matrix
    CholmodMatrix C;    {
        vector<CholmodMatrix::Triplet> triplets;
        triplets.reserve(2 * n);
        for (int i = 0; i < 2 * n; ++i)
            triplets.push_back(CholmodMatrix::Triplet(i, i, Config::CAGE_ORIGINAL_POSITION_WEIGHT));
        C.init(2 * n, 2 * n, triplets);
    }
    
    // final left-hand-side matrix
    CholmodMatrix A = dbg_use_laplacian_optimization_ ? (Li_t * Li + Lb_t * Lb + C) : C;
    Umfpack umfpack(2 * n, A.getAp(), A.getAi(), A.getAx());
    
    // right hand side (goal position)
    vector<double> Bx(2 * n, 0), By(2 * n, 0), Bz(2 * n, 0);
    for (int i = 0; i < n; ++i) {
        VHandle v = vertex_handle(i);
        VertexData& vdata = data(v);
        for (int j = 0; j < 2; ++j) {
            Vector3d goal_position = (vdata.original_xyz_ + vdata.line_coef_[j] * vdata.original_normal_).convert<double>();
            Bx[2 * i + j] = Config::CAGE_ORIGINAL_POSITION_WEIGHT * goal_position.x_;
            By[2 * i + j] = Config::CAGE_ORIGINAL_POSITION_WEIGHT * goal_position.y_;
            Bz[2 * i + j] = Config::CAGE_ORIGINAL_POSITION_WEIGHT * goal_position.z_;
        }
    }
    
    // solve!
    vector<double> Xx, Xy, Xz;
    umfpack.solve(Bx, Xx);
    umfpack.solve(By, Xy);
    umfpack.solve(Bz, Xz);
    
    // store resulting position to GCMesh::VertexT::original_position_
    for (int i = 0; i < 2 * n; ++i) {
        GCMesh::VHandle v = gcmesh.vertex_handle(i);
        gcmesh.data(v).original_position_ = Vector3d(Xx[i], Xy[i], Xz[i]).convert<float>();
    }
    
    return true;
}
bool CageGenMesh::cageGen_original() {
    return
        original_step1_compute_boundary()  &&
        original_step2_triangulate()       &&
        original_step3_set_configuration() &&
        original_step4_project_line()      &&
        original_step5_optimize_position();
}

bool CageGenMesh::deformed_step1_set_configuration() {
    ClkSimple clk("CageGenMesh::deformed_step1_set_configuration");
    // set VertexT.{deformed_normal_, deformed_ugrad_, deformed_xyz}
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        // collect 3 vertices in meshTgt.paramedPatch which are the closest in uv
        Vector2f uv = point(v);
        KdTree2d::SearchResult sr = meshTgt.paramedPatch_.uv_kdTree_.search(uv.convert<double>(), 3);
        Vector3f weights;
        float dist_avg = 0.0f;
        for (int i = 0; i < 3; ++i) {
            weights[i] = static_cast<float>(sr.distances_[i]);
            dist_avg += weights[i] / 3.0f;
        }
        float weight_total = 0.0f;
        for (int i = 0; i < 3; ++i) {
            weights[i] = 1.0f / (weights[i] + dist_avg);
            weight_total += weights[i];
        }
        weights /= weight_total;
        Vector2f triangle_uv [3];
        Vector3f triangle_n  [3];
        Vector3f triangle_xyz[3];
        for (int i = 0; i < 3; ++i) {
            MeshTgt::VHandle w = meshTgt.paramedPatch_.vertices_[sr.indices_[i]];
            triangle_uv [i] = meshTgt.data(w).expmap_data_.uv_;
            triangle_n  [i] = meshTgt.normal(w);
            triangle_xyz[i] = meshTgt.point(w);
        }
        // set deformed_normal and deformed_xyz
        VertexData& vdata = data(v);
        Vector3f& deformed_normal = vdata.deformed_normal_;
        Vector3f& deformed_xyz    = vdata.deformed_xyz_;
        deformed_normal.fill(0.0f);
        deformed_xyz   .fill(0.0f);
        for (int i = 0; i < 3; ++i) {
            deformed_normal += weights[i] * triangle_n  [i];
            deformed_xyz    += weights[i] * triangle_xyz[i];
        }
        deformed_normal.normalize();
        
        // set deformed_ugrad
        Matrix4x4f A;
        Vector4f b;
        for (int i = 0; i < 3; ++i) {
            for (int j = 0; j < 3; ++j)
                A(i, j) = triangle_xyz[i] | triangle_xyz[j];
            A(3, i) = A(i, 3) = 1.0f;
            b[i] = triangle_uv[i].x_;
        }
        Vector4f x;
        bool invertible = A.solve(b, x);
        assert(invertible);
        Vector3f& deformed_ugrad = vdata.deformed_ugrad_;
        for (int i = 0; i < 3; ++i)
            deformed_ugrad += x[i] * triangle_xyz[i];
    }
    
    return true;
}
bool CageGenMesh::deformed_step2_optimize_position() {
    ClkSimple clk("CageGenMesh::deformed_step2_optimize_position");
    int n = n_vertices();
    int nb = static_cast<int>(boundary_.size());
    float ratio = meshSrc.expmap_info_.uv_scale_ / meshTgt.expmap_info_.uv_scale_;
    
    // Laplacian constraints
    CholmodMatrix L;    {
        vector<CholmodMatrix::Triplet> triplets;
        triplets.reserve(2 * n * 8);
        for (int i = 0; i < 2 * n; ++i) {
            GCMesh::VHandle v = gcmesh.vertex_handle(i);
            triplets.push_back(CholmodMatrix::Triplet(i, i, -1));
            int valance = 0;
            for (GCMesh::VVIter w = gcmesh.vv_iter(v); w; ++w)
                ++valance;
            double weight = 1.0 / valance;
            for (GCMesh::VVIter w = gcmesh.vv_iter(v); w; ++w) {
                int iw = w.handle().idx();
                triplets.push_back(CholmodMatrix::Triplet(i, iw, weight));
            }
        }
        L.init(2 * n, 2 * n, triplets);
    }
    CholmodMatrix Lt = L.transpose();
    
    // position constraints at the boundary
    CholmodMatrix C;    {
        vector<CholmodMatrix::Triplet> triplets;
        triplets.reserve(nb * 2);
        for (int i = 0; i < nb; ++i) {
            VertexData& vdata = data(vertex_handle(i));
            Vector2d weights;
            weights.x_ = -vdata.line_coef_[1] / (vdata.line_coef_[0] - vdata.line_coef_[1]);
            weights.y_ = 1 - weights.x_;
            /*
            p: original_xyz
            d: original_normal
            line: p + t * d
            t0: line_coef[0], t1: line_coef[1]
            p0 = p + t0 * d
            p1 = p + t1 * d
            d = (p0 - p) / t0 = (p1 - p) / t1
            t1 * p0 - t1 * p = t0 * p1 - t0 * p
            p * (t0 - t1) = -t1 * p0 + t0 * p1
            p = u * p0 + (1 - u) * p1
            u = -t1 / (t0 - t1)
            */
            for (int j = 0; j < 2; ++j)
                triplets.push_back(CholmodMatrix::Triplet(i, 2 * i + j, Config::CAGE_DEFORMED_POSITION_WEIGHT * weights[j]));
        }
        C.init(nb, 2 * n, triplets);
    }
    CholmodMatrix Ct = C.transpose();
    
    // final left-hand-side matrix
    CholmodMatrix A = Lt * L + Ct * C;
    
    VectorVLd Bx, By, Bz;   {        // right hand side
        vector<Vector3f> laplacian(2 * n);  {
            for (int i = 0; i < 2 * n; ++i) {
                GCMesh::VHandle v = gcmesh.vertex_handle(i);
                Vector3f& D = laplacian[i];
                int valance = 0;
                for (GCMesh::VVIter w = gcmesh.vv_iter(v); w; ++w) {
                    ++valance;
                    D += gcmesh.data(w).original_position_;
                }
                D /= static_cast<double>(valance);
                D -= gcmesh.data(v).original_position_;
            }
        }
        VectorVLd RDx(2 * n, 0.0), RDy(2 * n, 0.0), RDz(2 * n, 0.0);
        for (int i = 0; i < n; ++i) {
            VHandle v = vertex_handle(i);
            VertexData& vdata = data(v);
            Matrix3x3f original_frame;  {
                Vector3f& axis0 = vdata.original_normal_;
                Vector3f& axis1 = vdata.original_ugrad_;
                axis1 -= axis0 * (axis0 | axis1);
                axis1.normalize();
                Vector3f axis2 = axis0 % axis1;
                original_frame.setCols(axis0, axis1, axis2);
            }
            Matrix3x3f deformed_frame;  {
                Vector3f& axis0 = vdata.deformed_normal_;
                Vector3f& axis1 = vdata.deformed_ugrad_;
                axis1 -= axis0 * (axis0 | axis1);
                axis1.normalize();
                Vector3f axis2 = axis0 % axis1;
                deformed_frame.setCols(axis0, axis1, axis2);
            }
            Matrix3x3f rot = deformed_frame * original_frame.transpose();
            for (int j = 0; j < 2; ++j) {
                Vector3f& D = laplacian[2 * i + j];
                D = rot * D;        // rotation
                D *= ratio;         // scaling
                RDx[2 * i + j] = static_cast<double>(D.x_);
                RDy[2 * i + j] = static_cast<double>(D.y_);
                RDz[2 * i + j] = static_cast<double>(D.z_);
            }
        }
        // position constraint at the boundary
        VectorVLd Px(nb, 0.0), Py(nb, 0.0), Pz(nb, 0.0);
        for (int i = 0; i < nb; ++i) {
            VertexData& vdata = data(vertex_handle(i));
            Vector3d p = vdata.deformed_xyz_.convert<double>();
            Px[i] = Config::CAGE_DEFORMED_POSITION_WEIGHT * p.x_;
            Py[i] = Config::CAGE_DEFORMED_POSITION_WEIGHT * p.y_;
            Pz[i] = Config::CAGE_DEFORMED_POSITION_WEIGHT * p.z_;
        }
        Bx = Lt * RDx + Ct * Px;
        By = Lt * RDy + Ct * Py;
        Bz = Lt * RDz + Ct * Pz;
    }
    
    // solve!
    Umfpack umfpack(2 * n, A.getAp(), A.getAi(), A.getAx());
    vector<double> Xx, Xy, Xz;
    umfpack.solve(Bx.std_vector(), Xx);
    umfpack.solve(By.std_vector(), Xy);
    umfpack.solve(Bz.std_vector(), Xz);
    
    // store resulting position to GCMesh::VertexT::deformed_position_
    for (int i = 0; i < 2 * n; ++i) {
        GCMesh::VHandle v = gcmesh.vertex_handle(i);
        gcmesh.data(v).deformed_position_ = Vector3d(Xx[i], Xy[i], Xz[i]).convert<float>();
    }
    
    return true;
}
bool CageGenMesh::cageGen_deformed() {
    return
        deformed_step1_set_configuration() &&
        deformed_step2_optimize_position();
}
