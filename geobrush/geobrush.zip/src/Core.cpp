#include "stdafx.h"
#include <vector>
#include <stack>
#include <algorithm>
#include <KLIB/Clock.h>
#include <KLIB/Util.h>
#include <KLIB/TriangleUtil.h>
#include <KLIB/CholmodMatrix.h>
#include "Core.h"
#include "StateParamSrc.h"
#include "StateParamTgt.h"
#include "StatePaint.h"

using namespace std;
using namespace KLIB;

namespace {
}

void Core::ParamSpace::init() {
    buf_src_  .texture_.init(GL_TEXTURE_2D, GL_REPEAT, GL_NEAREST);
    buf_tgt_  .texture_.init(GL_TEXTURE_2D, GL_REPEAT, GL_NEAREST);
    buf_paint_.texture_.init(GL_TEXTURE_2D, GL_CLAMP_TO_EDGE, GL_NEAREST);
    buf_src_  .texture_.allocate(GL_RGBA32F_ARB, Config::PARAMSPACE_REZ, Config::PARAMSPACE_REZ, GL_RGBA);
    buf_tgt_  .texture_.allocate(GL_RGB32F_ARB , Config::PARAMSPACE_REZ, Config::PARAMSPACE_REZ, GL_RGB );
    buf_paint_.texture_.allocate(GL_RGB8       , Config::PARAMSPACE_REZ, Config::PARAMSPACE_REZ, GL_RGB );
}

void Core::initGL() {
    glewInit();
    glBlendFunc(GL_SRC_ALPHA , GL_ONE_MINUS_SRC_ALPHA);
    
    drawer_.init();
    
    paramSpace_.init();

    framebuffer_.init();
    
    StateParamTgt::getInstance()->initGL();
    StatePaint   ::getInstance()->initGL();
    
    loadMesh();
}
void Core::loadMesh() {
    vector<string> file_extensions;
    file_extensions.push_back("obj");
    file_extensions.push_back("off");
    file_extensions.push_back("ply");
    file_extensions.push_back("stl");
    file_extensions.push_back("om");
    string fnameSrc = showFileDialog(true, file_extensions, "Load source mesh");
    if (fnameSrc.empty())
        return;
    string fnameTgt = showFileDialog(true, file_extensions, "Load target mesh");
    if (fnameTgt.empty())
        return;
    meshSrc_.load(fnameSrc);
    meshTgt_.load(fnameTgt);
    gcmesh_.clear();
    cageGenMesh_.clear();
    drawer_.dispList_meshSrc_all_faces_.requestUpdate();
    drawer_.dispList_meshSrc_all_edges_.requestUpdate();
    drawer_.dispList_meshTgt_unparamed_faces_.requestUpdate();
    drawer_.dispList_meshTgt_unparamed_edges_.requestUpdate();
    drawer_.select_dispList_left_ .requestUpdate();
    drawer_.select_dispList_right_.requestUpdate();
    gotoParamSrc();
}

void Core::bake_edit() {
    if (stitchMesh_.n_vertices() == 0)
        return;
    MeshTgt result;
    vector<int> map_src_result(meshSrc_.n_vertices(), -1);
    vector<int> map_tgt_result(meshTgt_.n_vertices(), -1);
    vector<int> map_stitch_result(stitchMesh_.n_vertices(), -1);
    for (size_t i = 0; i < meshSrc_.paramedPatch_.vertices_.size(); ++i) {
        MeshSrc::VHandle& v = meshSrc_.paramedPatch_.vertices_[i];
        MeshSrc::VertexData& v_data = meshSrc_.data(v);
        if (v_data.paint_value_ < 0.0f)
            continue;
        if (v_data.stitch_vid_ != -1)
            continue;
        map_src_result[v.idx()] = result.n_vertices();
        result.add_vertex(v_data.result_position_);
    }
    for (MeshTgt::VIter v = meshTgt_.vertices_begin(); v != meshTgt_.vertices_end(); ++v) {
        MeshTgt::VertexData& v_data = meshTgt_.data(v);
        if (v_data.paramed_ && v_data.paint_value_ >= 0.0f)
            continue;
        if (v_data.stitch_vid_ != -1)
            continue;
        map_tgt_result[v.handle().idx()] = result.n_vertices();
        result.add_vertex(meshTgt_.point(v));
    }
    for (StitchMesh::VIter v = stitchMesh_.vertices_begin(); v != stitchMesh_.vertices_end(); ++v) {
        StitchMesh::VertexData& v_data = stitchMesh_.data(v);
        map_stitch_result[v.handle().idx()] = result.n_vertices();
        result.add_vertex(stitchMesh_.point(v));
    }
    
    vector<MeshTgt::VHandle> face_vhandles(3);
    for (size_t i = 0; i < meshSrc_.paramedPatch_.faces_.size(); ++i) {
        MeshSrc::FHandle& f = meshSrc_.paramedPatch_.faces_[i];
        MeshSrc::FaceData& f_data = meshSrc_.data(f);
        if (!f_data.paint_in_)
            continue;
        MeshSrc::FVIter fv = meshSrc_.fv_iter(f);
        for (int i = 0; i < 3; ++i, ++fv) {
            int stitch_vid = meshSrc_.data(fv).stitch_vid_;
            face_vhandles[i] = result.vertex_handle(stitch_vid == -1 ?
                map_src_result[fv.handle().idx()] : map_stitch_result[stitch_vid]);
        }
        result.add_face(face_vhandles);
    }
    for (MeshTgt::FIter f = meshTgt_.faces_begin(); f != meshTgt_.faces_end(); ++f) {
        MeshTgt::FaceData& f_data = meshTgt_.data(f);
        if (f_data.paramed_ && !f_data.paint_out_)
            continue;
        MeshTgt::FVIter fv = meshTgt_.fv_iter(f);
        for (int i = 0; i < 3; ++i, ++fv) {
            int stitch_vid = meshTgt_.data(fv).stitch_vid_;
            face_vhandles[i] = result.vertex_handle(stitch_vid == -1 ?
                map_tgt_result[fv.handle().idx()] : map_stitch_result[stitch_vid]);
        }
        result.add_face(face_vhandles);
    }
    for (StitchMesh::FIter f = stitchMesh_.faces_begin(); f != stitchMesh_.faces_end(); ++f) {
        StitchMesh::FVIter fv = stitchMesh_.fv_iter(f);
        for (int i = 0; i < 3; ++i, ++fv) {
            StitchMesh::VertexData& fv_data = stitchMesh_.data(fv);
            face_vhandles[i] = result.vertex_handle(map_stitch_result[fv.handle().idx()]);
        }
        result.add_face(face_vhandles);
    }
    meshTgt_.clear();
    meshTgt_ = result;
    meshTgt_.request_face_normals();
    meshTgt_.request_vertex_normals();
    meshTgt_.update_normals();
    std::cout << "vertices: " << meshTgt_.n_vertices() << ", faces: " << meshTgt_.n_faces() << std::endl;
    
    // go to StateParamTgt
    StateParamTgt::getInstance()->clear();
    StatePaint   ::getInstance()->clear();
    state_ = StateParamTgt::getInstance();
    drawer_.dispList_meshTgt_unparamed_faces_.requestUpdate();
    drawer_.dispList_meshTgt_unparamed_edges_.requestUpdate();
    drawer_.select_dispList_right_.requestUpdate();
    
    redrawWindow();
}

void Core::gotoParamSrc() {
    StateParamSrc::getInstance()->clear();
    StateParamTgt::getInstance()->clear();
    StatePaint   ::getInstance()->clear();
    state_ = StateParamSrc::getInstance();
    drawer_.dispList_meshSrc_all_faces_.requestUpdate();
    redrawWindow();
}

Core::Core(void)
: state_(0)
{
    state_ = StateParamSrc::getInstance();
    CholmodMatrix::start();
    srand((unsigned int)time(0));
}

Core::~Core(void) {
    CholmodMatrix::finish();
}
