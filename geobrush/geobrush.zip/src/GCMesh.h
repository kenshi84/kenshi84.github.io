#pragma once
#include <vector>
#include <KLIB/Vector.h>
#include <OpenMesh/Core/Mesh/Traits.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>

struct GCMeshTraits : public OpenMesh::DefaultTraits {
    typedef KLIB::Vector3f Point;
    typedef KLIB::Vector3f Normal;
    VertexTraits {
    public:
        KLIB::Vector3f original_position_;
        KLIB::Vector3f deformed_position_;
    };
    FaceTraits {
    public:
        KLIB::Vector3f original_normal_;
        KLIB::Vector3f deformed_normal_;
        float area_;
        float scalar_;
        FaceT()
            : area_(0)
            , scalar_(0)
        {}
    };
};

class GCMesh : public OpenMesh::TriMesh_ArrayKernelT<GCMeshTraits>
{
public:
    void init_original();      // compute face normal and area
    void init_deformed();        // compute face normal and scalar
    
    struct Data {
        std::vector<float> coord_v_;    // GC for cage vertices
        std::vector<float> coord_n_;    // GC for cage face normals
        KLIB::Vector3f original_position_;
        KLIB::Vector3f deformed_position_;
        bool empty() const { return coord_v_.empty(); }
        void clear() {
            coord_v_.clear();
            coord_n_.clear();
            original_position_ = deformed_position_ = KLIB::Vector3f();
        }
    };
    void compute_coord (Data& gcdata) const;
    void compute_deform(Data& gcdata) const;
    
    // parallelized version (will be implemented?)
    void compute_coord (std::vector<Data>& gcdata) const;
    void compute_deform(std::vector<Data>& gcdata) const;
    
    GCMesh(void) {}
    ~GCMesh(void) {}

private:
    static float GCTriInt(const KLIB::Vector3d& p, const KLIB::Vector3d& v1, const KLIB::Vector3d& v2, const KLIB::Vector3d& e);
};
