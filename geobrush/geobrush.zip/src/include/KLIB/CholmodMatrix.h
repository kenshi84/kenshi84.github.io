#pragma once
#include <cholmod/cholmod.h>
#include <vector>
#include <string>
#include <cassert>
#include "MatrixVL.h"

namespace KLIB {

class CholmodMatrix {
private:
    static cholmod_common common__;
public:
    static void start () { cholmod_start (&common__); }
    static void finish() { cholmod_finish(&common__); }
    static CholmodMatrix identity(int nrow, int ncol) {
        CholmodMatrix result;
        result.A_ = cholmod_speye(nrow, ncol, CHOLMOD_REAL, &common__);
        return result;
    }
    static CholmodMatrix zero(int nrow, int ncol) {
        CholmodMatrix result;
        result.A_ = cholmod_spzeros(nrow, ncol, 1, CHOLMOD_REAL, &common__);
        return result;
    }
private:
    cholmod_sparse* A_;
public:
    // triplet data
    class Triplet {
    public:
        int i_;
        int j_;
        double x_;
        Triplet() : i_(-1), j_(-1), x_(0) {}
        Triplet(int i, int j, double x) : i_(i), j_(j), x_(x) {}
        void set(int i, int j, double x) { i_ = i;    j_ = j;    x_ = x; }
    };
    // constructors
    CholmodMatrix() : A_(0) {}
    CholmodMatrix(int nrow, int ncol, const std::vector<int>& Ti, const std::vector<int>& Tj, const std::vector<double>& Tx) : A_(0) {
        init(nrow, ncol, Ti, Tj, Tx);
    }
    CholmodMatrix(int nrow, int ncol, const std::vector<Triplet>& triplets) : A_(0) {
        init(nrow, ncol, triplets);
    }
    CholmodMatrix(const CholmodMatrix& src) { A_ = cholmod_copy_sparse(src.A_, &common__); }
    ~CholmodMatrix() { cholmod_free_sparse(&A_, &common__); }
    // substitution operator
    CholmodMatrix& operator=(const CholmodMatrix& rhs) {
        cholmod_free_sparse(&A_, &common__);
        A_ = cholmod_copy_sparse(rhs.A_, &common__);
        return *this;
    }
    // initialization
    void init(size_t nrow, size_t ncol, const std::vector<int>& Ti, const std::vector<int>& Tj, const std::vector<double>& Tx) {
        if (Ti.size() != Tj.size() || Tj.size() != Tx.size()) throw "Illegal arguments!";
        cholmod_free_sparse(&A_, &common__);
        size_t nnz = Ti.size();
        cholmod_triplet* T = cholmod_allocate_triplet(nrow, ncol, nnz, 0, CHOLMOD_REAL, &common__);
        memcpy(T->i, &Ti[0], sizeof(int)    * nnz);
        memcpy(T->j, &Tj[0], sizeof(int)    * nnz);
        memcpy(T->x, &Tx[0], sizeof(double) * nnz);
        T->nnz = nnz;
        A_ = cholmod_triplet_to_sparse(T, nnz, &common__);
        cholmod_free_triplet(&T, &common__);
    }
    void init(size_t nrow, size_t ncol, const std::vector<Triplet>& triplets) {
        size_t nnz = triplets.size();
        std::vector<int>    Ti(nnz);
        std::vector<int>    Tj(nnz);
        std::vector<double> Tx(nnz);
        for (size_t k = 0; k < nnz; ++k) {
            const Triplet& t = triplets[k];
            Ti[k] = t.i_;
            Tj[k] = t.j_;
            Tx[k] = t.x_;
        }
        init(nrow, ncol, Ti, Tj, Tx);
    }
    // conversion
    MatrixVLd toDense() const {
        cholmod_dense* X = cholmod_sparse_to_dense(A_, &common__);
        MatrixVLd result(A_->nrow, A_->ncol);
        double* Xx = static_cast<double*>(X->x);
        for (size_t i = 0; i < A_->nrow; ++i) for (size_t j = 0; j < A_->ncol; ++j) {
            result(i, j) = Xx[i + A_->nrow * j];
        }
        cholmod_free_dense(&X, &common__);
        return result;
    }
    // operations
    CholmodMatrix transpose() const {
        CholmodMatrix result;
        result.A_ = cholmod_transpose(A_, 1, &common__);
        return result;
    }
    CholmodMatrix operator+(const CholmodMatrix& rhs) const {
        CholmodMatrix result;
        static double one[2] = {1, 0};
        result.A_ = cholmod_add(A_, rhs.A_, one, one, 1, 1, &common__);
        return result;
    }
    CholmodMatrix operator*(const CholmodMatrix& rhs) const {
        CholmodMatrix result;
        result.A_ = cholmod_ssmult(A_, rhs.A_, 0, 1, 1, &common__);
        return result;
    }
    CholmodMatrix& operator*=(double s) {
        cholmod_dense* S = cholmod_allocate_dense(1, 1, 1, CHOLMOD_REAL, &common__);
        static_cast<double*>(S->x)[0] = s;
        cholmod_scale(S, CHOLMOD_SCALAR, A_, &common__);
        cholmod_free_dense(&S, &common__);
        return *this;
    }
    CholmodMatrix operator*(double s) const {
        CholmodMatrix result(*this);
        result *= s;
        return result;
    }
    KLIB::VectorVLd operator*(const KLIB::VectorVLd& vec) const {
        assert(vec.size() == A_->ncol);
        cholmod_dense* X = cholmod_allocate_dense(A_->ncol, 1, A_->ncol, CHOLMOD_REAL, &common__);
        cholmod_dense* Y = cholmod_allocate_dense(A_->nrow, 1, A_->nrow, CHOLMOD_REAL, &common__);
        memcpy(X->x, &vec[0], sizeof(double) * A_->ncol);
        double alpha[2] = {1, 1};
        double beta [2] = {0, 0};
        cholmod_sdmult(A_, 0, alpha, beta, X, Y, &common__);
        KLIB::VectorVLd result(A_->nrow);
        memcpy(&result[0], Y->x, sizeof(double) * A_->nrow);
        cholmod_free_dense(&X, &common__);
        cholmod_free_dense(&Y, &common__);
        return result;
    }
    CholmodMatrix submatrix(const std::vector<int>& rowset, const std::vector<int>& colset) const {
        CholmodMatrix result;
        int rsize = rowset.empty() ? -1 : static_cast<int>(rowset.size());
        int csize = colset.empty() ? -1 : static_cast<int>(colset.size());
        int *rset = rowset.empty() ? 0 : const_cast<int*>(&rowset[0]);
        int *cset = colset.empty() ? 0 : const_cast<int*>(&colset[0]);
        result.A_ = cholmod_submatrix(A_, rset, rsize, cset, csize, 1, 1, &common__);
        return result;
    }
    CholmodMatrix horzcat(const CholmodMatrix& rhs) const {
        CholmodMatrix result;
        result.A_ = cholmod_horzcat(A_, rhs.A_, 1, &common__);
        return result;
    }
    CholmodMatrix vertcat(const CholmodMatrix& rhs) const {
        CholmodMatrix result;
        result.A_ = cholmod_vertcat(A_, rhs.A_, 1, &common__);
        return result;
    }
    double norm() const { return cholmod_norm_sparse(A_, 1, &common__); }
    // output of compressed column form
    std::vector<int>    getAp() const {
        std::vector<int> Ap(A_->ncol + 1);
        memcpy(&Ap[0], A_->p, sizeof(int) * (A_->ncol + 1));
        return Ap;
    }
    std::vector<int>    getAi() const {
        std::vector<int> Ai(A_->nzmax);
        memcpy(&Ai[0], A_->i, sizeof(int) * A_->nzmax);
        return Ai;
    }
    std::vector<double> getAx() const {
        std::vector<double> Ax(A_->nzmax);
        memcpy(&Ax[0], A_->x, sizeof(double) * A_->nzmax);
        return Ax;
    }
    // information
    size_t nrow() const { return A_->nrow; }
    size_t ncol() const { return A_->ncol; }
};

CholmodMatrix operator*(double s, const CholmodMatrix& M);

}   // namespace KLIB
