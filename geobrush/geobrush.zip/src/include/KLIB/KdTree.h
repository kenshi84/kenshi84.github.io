#pragma once
#include "Vector.h"
#include <vector>
#include <ANN/ANN.h>
#include <iostream>

namespace KLIB {

template <int N>
class KdTree {
public:
    typedef Vector<double, N> vector_type;
private:
    ANNkd_tree* tree_;
    std::vector<vector_type> points_;
    std::vector<double*>     pointers_;
public:
    KdTree(const std::vector<vector_type>& points = std::vector<vector_type>()) 
        : tree_(0)
        , points_(points)
    {
        if (!points_.empty())
            build();
    }
    ~KdTree() {
        if (tree_)
            delete tree_;
    }
    void build() {
        if (tree_)
            delete tree_;
        assert(!points_.empty());
        int nPts = static_cast<int>(points_.size());
        pointers_.resize(nPts, 0);
        for (int i = 0; i < nPts; ++i)
            pointers_[i] = points_[i].ptr();
        tree_ = new ANNkd_tree(&pointers_[0], nPts, N);
    }
    void push_back(const vector_type& point) { points_.push_back(point); }
    void reserve(size_t sz) { points_.reserve(sz); }
    size_t size() const { return points_.size(); }
    struct SearchResult {
        std::vector<int   > indices_;
        std::vector<double> distances_;
        size_t size() const { return indices_.size(); }
    };
    SearchResult search(vector_type& p, int k) const {
        assert(tree_);
        SearchResult sr;
        sr.indices_  .resize(k, -1);
        sr.distances_.resize(k, 0);
        tree_->annkSearch(p.ptr(), k, &sr.indices_[0], &sr.distances_[0]);
        return sr;
    }
    void clear() {
        if (tree_) {
            delete tree_;
            tree_ = 0;
        }
        points_.clear();
        pointers_.clear();
    }
};

typedef KdTree<2> KdTree2d;
typedef KdTree<3> KdTree3d;
typedef KdTree<4> KdTree4d;

}
