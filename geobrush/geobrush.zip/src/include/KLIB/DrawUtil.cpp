#include "StdAfx.h"
#include "GLUtil.h"
#include "DrawUtil.h"

using namespace KLIB;

void DrawUtil::drawDisk(double radius, int numDiv) {
    glBegin(GL_TRIANGLE_FAN);
    double t = 0;
    double dt = 2 * M_PI / numDiv;
    for (int i = 0; i <= numDiv; ++i, t += dt)
        ::glVertex2d(radius * cos(t), radius * sin(t));
    glEnd();
}
void DrawUtil::drawCircle(double radius, int numDiv) {
    glBegin(GL_LINE_LOOP);
    double t = 0;
    double dt = 2 * M_PI / numDiv;
    for (int i = 0; i <= numDiv; ++i, t += dt)
        ::glVertex2d(radius * cos(t), radius * sin(t));
    glEnd();
}
