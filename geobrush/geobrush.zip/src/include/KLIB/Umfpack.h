#pragma once
#include <cassert>
#include <iostream>
#include <vector>
#include <cmath>
#include "umfpack/umfpack.h"

namespace KLIB {

class Umfpack {
private:
    static int copy_symbolic(void** Symbolic_dst, void* Symbolic_src);
    static int copy_numeric (void** Numeric_dst,  void* Numeric_src);
private:
    // member data
    int n_;
    void* symbolic_;
    void* numeric_;
    std::vector<int>    Ap_;
    std::vector<int>    Ai_;
    std::vector<double> Ax_;
    double info_[UMFPACK_INFO];
    bool isVerbose_;
    void free_symbolic() {
        umfpack_di_free_symbolic(&symbolic_);
    }
    void free_numeric() {
        umfpack_di_free_numeric(&numeric_);
    }
public:
    Umfpack(bool isVerbose = false) : n_(0), symbolic_(0), numeric_(0), isVerbose_(isVerbose) {}
    Umfpack(int n, const std::vector<int>& Ap, const std::vector<int>& Ai, const std::vector<double>& Ax, bool isVerbose = false) : symbolic_(0), numeric_(0), isVerbose_(isVerbose)
    {
        factorize(n, Ap, Ai, Ax);
    }
    ~Umfpack() {
        free_symbolic();
        free_numeric();
    }
    // copy ctor & operator=() -- only optional
    Umfpack(const Umfpack& src);
    Umfpack& operator=(const Umfpack& rhs);
    
    void factorize(int n, const std::vector<int>& Ap, const std::vector<int>& Ai, const std::vector<double>& Ax) {
        factorizeSymbolic(n, Ap, Ai);
        factorizeNumeric(Ax);
    }
    void factorizeSymbolic(int n, const std::vector<int>& Ap, const std::vector<int>& Ai) {
        if (Ap.size() != n + 1 || Ap[0] != 0) throw "Illegal argument.";
        n_ = n;
        Ap_ = Ap;
        Ai_ = Ai;
        free_symbolic();
        if (isVerbose_)
            std::cerr << "[Umfpack: symbolic factorization (n=" << n_ << ") ... ";
        umfpack_di_symbolic(n, n, &Ap_[0], &Ai_[0], static_cast<double*>(0), &symbolic_, static_cast<double*>(0), info_);
        if (isVerbose_) {
            std::cerr << (
                info_[UMFPACK_STATUS] == UMFPACK_OK ? "done!" :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_n_nonpositive    ? "error - n_nonpositive"    :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_invalid_matrix   ? "error - invalid_matrix"   :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_argument_missing ? "error - argument_missing" :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_out_of_memory    ? "error - out_of_memory"    :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_internal_error   ? "error - internal_error"   : "unknown status"
                ) << "]" << std::endl;
        }
    }
    void factorizeNumeric(const std::vector<double>& Ax) {
        if (Ax.size() != Ai_.size()) throw "Illegal argument.";
        if (symbolic_ == 0) throw "Symbolic factorization is not yet done.";
        Ax_ = Ax;
        free_numeric();
        if (isVerbose_)
            std::cerr << "[Umfpack: numeric factorization (n=" << n_ << ") ... ";
        umfpack_di_numeric(&Ap_[0], &Ai_[0], &Ax_[0], symbolic_, &numeric_, static_cast<double*>(0), info_);
        if (isVerbose_) {
            std::cerr << (
                info_[UMFPACK_STATUS] == UMFPACK_OK ? "done!" :
                info_[UMFPACK_STATUS] == UMFPACK_WARNING_singular_matrix       ? "warning - singular_matrix"       :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_invalid_Symbolic_object ? "error - invalid_Symbolic_object" :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_argument_missing        ? "error - argument_missing"        :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_different_pattern       ? "error - different_pattern"       :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_out_of_memory           ? "error - out_of_memory"           : "unknown status"
                ) << "]" << std::endl;
        }
    }
    double getDeterminant() {
        double mx, ex;
        assert(numeric_);
        umfpack_di_get_determinant(&mx, &ex, numeric_, info_);
        return mx * std::pow(10, ex);
    }
    void printError() {
        double control[UMFPACK_CONTROL];
        control[UMFPACK_PRL] = 1;
        umfpack_di_report_info(control, info_);
    }
    void printVerbose() {
        double control[UMFPACK_CONTROL];
        control[UMFPACK_PRL] = 2;
        umfpack_di_report_info(control, info_);
    }
    bool solve(const std::vector<double>& b, std::vector<double>& x) {
        assert(b.size() == n_);// return false;
        assert(symbolic_);// return false;
        assert(numeric_);// return false;
        x.resize(n_);
        if (isVerbose_)
            std::cerr << "[Umfpack: solve (n=" << n_ << ") ... ";
        umfpack_di_solve(UMFPACK_A, &Ap_[0], &Ai_[0], &Ax_[0], &x[0], &b[0], numeric_, static_cast<double*>(0), info_);
        if (isVerbose_) {
            std::cerr << (
                info_[UMFPACK_STATUS] == UMFPACK_OK ? "done!" :
                info_[UMFPACK_STATUS] == UMFPACK_WARNING_singular_matrix      ? "warning - singular_matrix"       :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_invalid_Numeric_object ? "error - invalid_Numeric_object" :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_invalid_system         ? "error - invalid_system" :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_argument_missing       ? "error - argument_missing"        :
                info_[UMFPACK_STATUS] == UMFPACK_ERROR_out_of_memory          ? "error - out_of_memory"           : "unknown status"
                ) << "]" << std::endl;
        }
        return true;
    }
    template <typename T, int N>
    bool solve(const std::vector<T>& b, std::vector<T>& x) {
        x.resize(n_);
        for (int i = 0; i < N; ++i) {
            std::vector<double> db(n_, 0), dx(n_, 0);
            for (int j = 0; j < n_; ++j)
                db[j] = b[j][i];
            if (!solve(db, dx))
                return false;
            for (int j = 0; j < n_; ++j)
                x[j][i] = dx[j];
        }
        return true;
    }
    void setVerbose(bool isVerbose) {
        isVerbose_ = isVerbose;
    }
};

}
