#pragma once
#include "Vector.h"
#include "Matrix.h"
#include "Util.h"

namespace KLIB {

struct Trackball {
    enum DragMode {
        DRAGMODE_ROTATE,
        DRAGMODE_PAN,
        DRAGMODE_ZOOM,
        DRAGMODE_NONE
    };
    DragMode dragMode_;
    Vector2i prevpos_;
    int width_;
    int height_;
    Vector3d eyePoint_;
    Vector3d focusPoint_;
    Vector3d upDirection_;
    
    Trackball()
        : width_(0)
        , height_(0)
        , dragMode_(DRAGMODE_NONE)
        , eyePoint_(0, 0, 3)
        , focusPoint_(0, 0, 0)
        , upDirection_(0, 1, 0)
    {}
    Vector3d eyeDirection() const { return focusPoint_ - eyePoint_; }
    void setSize(int width, int height) {
        width_  = width;
        height_ = height;
    }
    void mouseDown(int x, int y, DragMode dragMode = DRAGMODE_ROTATE) {
        prevpos_.set(x, y);
        dragMode_ = dragMode;
    }
    void mouseMove(int x, int y) {
        if (dragMode_ == DRAGMODE_NONE)
            return;
        Vector2i pos(x, y);
        switch (dragMode_) {
        case DRAGMODE_ROTATE:
            {
                double thetaX = (2 * M_PI * (pos.x_ - prevpos_.x_)) / width_;
                double thetaY = (2 * M_PI * (pos.y_ - prevpos_.y_)) / height_;
                // Horizontal rotation
                Matrix3x3d rotH = Util::rotationFromAxisAngle(upDirection_, -thetaX);
                Vector3d eye = eyePoint_ - focusPoint_;
                eye = rotH * eye;
                // Vertical rotation
                Vector3d leftDirection = eye % upDirection_;
                Matrix3x3d rotV = Util::rotationFromAxisAngle(leftDirection, thetaY);
                eye = rotV * eye;
                upDirection_ = rotV * upDirection_;
                eyePoint_ = focusPoint_ + eye;
            }
            break;
        case DRAGMODE_PAN:
            {
                Vector3d eye = eyePoint_ - focusPoint_;
                Vector3d leftDirection = eye % upDirection_;
                double len = eye.length();
                Vector3d transX(leftDirection);
                Vector3d transY(upDirection_);
                transX.normalize();
                transY.normalize();
                transX *= len * (pos.x_ - prevpos_.x_) / width_;
                transY *= len * (pos.y_ - prevpos_.y_) / height_;
                eyePoint_ += transX;
                eyePoint_ += transY;
                focusPoint_ += transX;
                focusPoint_ += transY;
            }
            break;
        case DRAGMODE_ZOOM:
            {
                Vector3d eyeDirection = focusPoint_ - eyePoint_;
                eyeDirection *= (pos.y_ - prevpos_.y_) / static_cast<double>(height_);
                eyePoint_ += eyeDirection;
            }
            break;
        }
        prevpos_ = pos;
    }
    void mouseUp() {
        dragMode_ = DRAGMODE_NONE;
    }
};

}
