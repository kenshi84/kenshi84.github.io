#pragma once
#include "Vector.h"
#include <vector>
#include <algorithm>

namespace KLIB {

template <typename Scalar, int N>
class Polyline {
public:
    typedef Vector<Scalar, N> vector_type;
    typedef typename std::vector<vector_type>::size_type size_type;
private:
    std::vector<vector_type> points_;
    bool isLoop_;
public:
    Polyline() : isLoop_(false) {}
    Polyline(const std::vector<vector_type>& points, bool isLoop) : points_(points), isLoop_(isLoop) {}
    ~Polyline() {}
    void init(const std::vector<vector_type>& points, bool isLoop) {
        points_ = points;
        isLoop_ = isLoop;
    }
    // read-only access to points_
    const std::vector<vector_type>& points() const { return points_; }
    bool isLoop() const { return isLoop_; }
    void setLoop(bool isLoop) { isLoop_ = isLoop; }
    
    Scalar length() const {
        if (points_.empty())
            return 0;
	    Scalar result = 0;
        for (size_t i = 1; i < points_.size(); ++i) result += (points_[i] - points_[i - 1]).length();
        if (isLoop_) result += (points_.front() - points_.back()).length();
	    return result;
    }
    void resample() { resample(size()); }
    void resample(size_t targetNumPoints) {
        assert (2 <= points_.size());
        assert (2 <= targetNumPoints);
        std::vector<vector_type> pointsOld = points_;
        if (isLoop_) {
            pointsOld.push_back(pointsOld.front());
            ++targetNumPoints;
        }
        const size_t N = pointsOld.size();
        points_.clear();
        std::vector<Scalar> src_len_acc(N, 0);
        for (size_t i = 1; i < N; ++i) {
            vector_type dif = pointsOld[i] - pointsOld[i - 1];
            src_len_acc[i] = src_len_acc[i - 1] + dif.length();
        }
        Scalar tgt_len_segment = src_len_acc.back() / (targetNumPoints - 1.);
        int src_i = 0;
        Scalar tgt_len_acc = 0;
        points_.push_back(pointsOld.front());
        while (true) {
            while (tgt_len_acc + tgt_len_segment <= src_len_acc[src_i]) {
                tgt_len_acc += tgt_len_segment;
                double w1 = (tgt_len_acc - src_len_acc[src_i - 1]) / static_cast<double>(src_len_acc[src_i] - src_len_acc[src_i - 1]);
                double w0 = 1 - w1;
                vector_type p0 = pointsOld[src_i - 1];
                vector_type p1 = pointsOld[src_i];
                vector_type p = p0 * w0 + p1 * w1;
                points_.push_back(p);
                if (points_.size() == targetNumPoints - 1) break;
            }
            if (points_.size() == targetNumPoints - 1) break;
            while (src_len_acc[src_i] <= tgt_len_acc + tgt_len_segment) {
                ++src_i;
            }
        }
        if (!isLoop_) points_.push_back(pointsOld.back());
    }
    void reverse() {
	    if (!isLoop_) {
            std::reverse(points_.begin(), points_.end());
	    } else {
            points_.push_back(points_.front());
            std::reverse(points_.begin(), points_.end());
            points_.pop_back();
	    }
    }
    void subdivide(double coef = 0.75) {
        std::vector<vector_type> points_old = points_;
        size_type n = size();
        clear();
        for (size_t i = 0; i < n; ++i) {
            vector_type& p0 = points_old[(i + n - 1) % n];
            vector_type& p1 = points_old[i];
            vector_type& p2 = points_old[(i + n + 1) % n];
            vector_type  q = (1 - coef) * 0.5 * (p0 + p2) + coef * p1;
            vector_type  m = 0.5 * (p1 + p2);
            if ((i == 0 || i == n - 1) && !isLoop_)
                points_.push_back(p1);
            else
                points_.push_back(q);
            if (i < n - 1 || isLoop_)
                points_.push_back(m);
        }
    }
    void smooth(Scalar coef = 0.5) {
        size_type n = size();
        std::vector<Scalar> dot_products(n, 0);
        for (size_t i = 0; i < n; ++i) {
            if (!isLoop_ && (i == 0 || i == n - 1))
                continue;
            vector_type& p0 = points_[(i + n - 1) % n];
            vector_type& p1 = points_[i];
            vector_type& p2 = points_[(i + n + 1) % n];
            vector_type d0 = p1 - p0;
            vector_type d1 = p2 - p1;
            d0.normalize();
            d1.normalize();
            dot_products[i] = d0 | d1;
        }
        std::vector<vector_type> points_old = points_;
        for (size_t i = 0; i < n; ++i) {
            if (!isLoop_ && (i == 0 || i == n - 1))
                continue;
            Scalar dp0 = dot_products[(i + n - 1) % n];
            Scalar dp1 = dot_products[i];
            Scalar dp2 = dot_products[(i + n + 1) % n];
            Scalar dp_tgt = 0.5 * (dp0 + dp2);
            vector_type& p0 = points_old[(i + n - 1) % n];
            vector_type& p1 = points_old[i];
            vector_type& p2 = points_old[(i + n + 1) % n];
            vector_type q = p1 - 0.5 * (p0 + p2);
            Scalar s = coef * (dp_tgt - dp0) / 2;
            q *= s;
            points_[i] += q;
        }
    }
    void smooth_simple(Scalar coef = 0.5) {
        size_type n = size();
        std::vector<vector_type> points_old = points_;
        for (size_t i = 0; i < n; ++i) {
            if (!isLoop_ && (i == 0 || i == n - 1))
                continue;
            vector_type& p0 = points_old[(i + n - 1) % n];
            vector_type& p1 = points_old[i];
            vector_type& p2 = points_old[(i + n + 1) % n];
            points_[i] = (1 - coef) * 0.5 * (p0 + p2) + coef * p1;
        }
    }

    // vector-compatible interfaces (addition/removal of points)
    void clear() { points_.clear(); }
    void push_back(const vector_type& point) { points_.push_back(point); }
    void pop_back() { points_.pop_back(); }
    void resize(size_type newSize, const vector_type& point = vector_type()) { points_.resize(newSize, point); }
    // vector-compatible interfaces (write-access)
    vector_type& operator[](size_type pos) { return points_[pos]; }
    vector_type& at(size_type pos) { return points_.at(pos); }
    vector_type& back() { return points_.back(); }
    vector_type& front() { return points_.front(); }
    // vector-compatible interfaces (const)
    const vector_type& operator[](size_type pos) const { return points_[pos]; }
    const vector_type& at(size_type pos) const { return points_.at(pos); }
    const vector_type& back() const { return points_.back(); }
    const vector_type& front() const { return points_.front(); }
    bool empty() const { return points_.empty(); }
    size_type size() const { return points_.size(); }
};

typedef Polyline<double, 2> Polyline2d;
typedef Polyline<double, 3> Polyline3d;

typedef Polyline<float , 2> Polyline2f;
typedef Polyline<float , 3> Polyline3f;

template <typename Scalar>
bool isClockwise(const Polyline<Scalar, 2>& polyline);

}   // namespace KLIB

