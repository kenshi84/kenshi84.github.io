#pragma once

namespace KLIB {

class DrawUtil {
    DrawUtil();
    ~DrawUtil();
public:
    static void drawDisk(double radius, int numDiv = 24);
    static void drawCircle(double radius, int numDiv = 24);
};

}
