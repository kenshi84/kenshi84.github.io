#pragma once
#include <KLIB/Vector.h>
#include <KLIB/GLSLUtil.h>
#include <KLIB/Clock.h>
#include "State.h"

class StateParamTgt : public State {
    StateParamTgt(void);
    ~StateParamTgt(void) {}
public:
    static StateParamTgt* getInstance() {
        static StateParamTgt p;
        return &p;
    }
    State* next();
    void clear();
    std::string message() const { return "Target Parameterization Mode"; }
    void draw_left();
    void draw_right();
    void mouseLButtonDown(int x, int y, bool flagShift = false, bool flagCtrl = false);
    void mouseLButtonUp(int x, int y);
    void mouseMove(int x, int y, bool flagShift = false, bool flagCtrl = false);
    void keyDown(char ascii);
    void keyDown(SpecialKey key);
    
    KLIB::Vector2i prevpos_;
    enum DragMode {
        DRAGMODE_MOVE,
        DRAGMODE_SCALE,
        DRAGMODE_ROTATE,
        DRAGMODE_NONE,
    } dragMode_;
    
    KLIB::ProgramObject shader_xyz_;            // fragment shader that renders xyz values directly
    
    void initGL();
    
    bool step1_compute_expmap();
    bool step2_deform_gc();         // make gc mesh for deformed position, perform deformation
    bool step3_render_paramed();    // render parameterized src/tgt patch
    KLIB::ClkData clk_;
    
    bool is_dirty_;
    void on_draw();
};
