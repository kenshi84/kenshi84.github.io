#pragma once
#include <string>

struct Config {
    static int    WINDOW_WIDTH;
    static int    WINDOW_HEIGHT;
    static const int PAINT_INOUT_SUBDIV = 3;
    static int    EXPMAP_KNN;
    static int    PARAMSPACE_REZ;
    static int    PARAMSPACE_REZ2;
    static float  FACE_REVERSED_THRESHOLD;
    static int    FACE_REVERSED_GROW_ITER;
    static float  CAGE_2D_EDGE_LENGTH_AVERAGE;
    static float  CAGE_2D_BOUNDARY_SCALING;
    static float  CAGE_LINE_EXTREMUM_SCALING;
    static double CAGE_ORIGINAL_POSITION_WEIGHT;
    static double CAGE_DEFORMED_POSITION_WEIGHT;
    static int    VCYCLE_NUM_SMOOTHING;
    static int    VCYCLE_NUM_CYCLE;
    static int    POST_SMOOTHING_ITER;
    static std::string FONT_FILENAME;
    
    static bool load();
    static bool save();
    static void set_default();
    
    Config() {
        set_default();
        if (!load())
            save();
    }
    ~Config() {}
};
