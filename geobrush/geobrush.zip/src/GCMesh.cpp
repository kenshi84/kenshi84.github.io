#include "StdAfx.h"
#include "GCMesh.h"
#include <KLIB/Matrix.h>
#include <KLIB/Clock.h>

using namespace std;
using namespace KLIB;

void GCMesh::init_original()       // compute face normal and area
{
    ClkSimple clk("GCMesh::init_original");
    
    for (FIter f_it = faces_begin(); f_it != faces_end(); ++f_it) {
        FVIter fv_it = fv_iter(f_it);
        const Vector3f& p0 = data(fv_it).original_position_;    ++fv_it;
        const Vector3f& p1 = data(fv_it).original_position_;    ++fv_it;
        const Vector3f& p2 = data(fv_it).original_position_;    ++fv_it;
        assert(!fv_it);
        Vector3f u = p1 - p0;
        Vector3f v = p2 - p0;
        Vector3f normal0 = u % v;
        float len = normal0.length();
        data(f_it).original_normal_ = normal0 / len;
        data(f_it).area_      = 0.5f * len;
    }
}
void GCMesh::init_deformed()         // compute face normal and scalar
{
    ClkSimple clk("GCMesh::init_deformed");
    
    for (FIter f_it = faces_begin(); f_it != faces_end(); ++f_it) {
        FVIter fv_it = fv_iter(f_it);
        const Vector3f& p00 = data(fv_it).original_position_;    const Vector3f& p10 = data(fv_it).deformed_position_;    ++fv_it;
        const Vector3f& p01 = data(fv_it).original_position_;    const Vector3f& p11 = data(fv_it).deformed_position_;    ++fv_it;
        const Vector3f& p02 = data(fv_it).original_position_;    const Vector3f& p12 = data(fv_it).deformed_position_;    ++fv_it;
        assert(!fv_it);
        Vector3f u0 = p01 - p00;    Vector3f u1 = p11 - p10;
        Vector3f v0 = p02 - p00;    Vector3f v1 = p12 - p10;
        Vector3f normal1 = u1 % v1;
        normal1.normalize();
        data(f_it).deformed_normal_ = normal1;
        data(f_it).scalar_    =
            sqrt(u1.lengthSquared() * v0.lengthSquared() - 2.0f * (u1 | v1) * (u0 | v0) + v1.lengthSquared() * u0.lengthSquared())
            / (sqrt(8.0f) * data(f_it).area_);
    }
}

void GCMesh::compute_coord (GCMesh::Data& gc_data) const {
    gc_data.coord_v_.clear();
    gc_data.coord_n_.clear();
    gc_data.coord_v_.resize(n_vertices(), 0.0f);
    gc_data.coord_n_.resize(n_faces()   , 0.0f);
    
    for (CFIter f_it = faces_begin(); f_it != faces_end(); ++f_it) {
        Vector3d v[3];
        CFVIter fv_it = cfv_iter(f_it);
        for (int i = 0; i < 3; ++i, ++fv_it)
            v[i] = (data(fv_it).original_position_ - gc_data.original_position_).convert<double>();
        const Vector3d n = data(f_it).original_normal_.convert<double>();
        Vector3d p = (v[0] | n) * n;
        Vector3d s, I, II, N[3];
        for (int i0 = 0; i0 < 3; ++i0) {
            int i1 = (i0 + 1) % 3;
            double dot = ((v[i0] - p) % (v[i1] - p)) | n;
            s [i0] = dot < 0.0 ? -1.0 : 1.0;
            I [i0] = GCTriInt(p         , v[i0], v[i1], Vector3d());
            II[i0] = GCTriInt(Vector3d(), v[i1], v[i0], Vector3d());
            N [i0] = v[i1] % v[i0];
            N [i0].normalize();
        }
        float& psi = gc_data.coord_n_[f_it.handle().idx()];
        for (int i = 0; i < 3; ++i)
            psi += s[i] * I[i];
        psi = abs(psi);
        assert(!_isnan(psi));
        assert(_finite(psi));
        Vector3d w = -(double)psi * n;
        for (int i = 0; i < 3; ++i)
            w += II[i] * N[i];
        fv_it = cfv_iter(f_it);
        for (int i0 = 0; i0 < 3; ++i0, ++fv_it) {
            float& phi = gc_data.coord_v_[fv_it.handle().idx()];
            int i1 = (i0 + 1) % 3;
            phi += (N[i1] | w) / (N[i1] | v[i0]);
            assert(!_isnan(phi));
            assert(_finite(phi));
        }
    }
    // check if queried position is exterior to the cage
    float coord_v_sum = 0.0f;
    for (int i = 0; i < n_vertices(); ++i)
        coord_v_sum += gc_data.coord_v_[i];
    if (coord_v_sum < 0.5f) {
        // find the nearest face (naiive, based on Euclid distance)
        FHandle f_through;
        float dist_min = FLT_MAX;
        for (CFIter f_it = faces_begin(); f_it != faces_end(); ++f_it) {
            float dist = 0.0f;
            for (CFVIter fv_it = cfv_iter(f_it); fv_it; ++fv_it)
                dist += (data(fv_it).original_position_ - gc_data.original_position_).length();
            if (dist < dist_min) {
                dist_min = dist;
                f_through = f_it.handle();
            }
        }
        // compute alpha[3] and beta
        Matrix4x4f A;
        CFVIter fv_it = cfv_iter(f_through);
        for (int i = 0; i < 3; ++i, ++fv_it)
            A.setCol(i, Vector4f(data(fv_it).original_position_, 1.0f));
        A.setCol(3, Vector4f(data(f_through).original_normal_, 0.0f));
        Vector4f x;
        A.solve(Vector4f(gc_data.original_position_, 1.0f), x);
        fv_it = cfv_iter(f_through);
        for (int i = 0; i < 3; ++i, ++fv_it)
            gc_data.coord_v_[fv_it.handle().idx()] += x[i];
        gc_data.coord_n_[f_through.idx()] += x[3];
    }
}
float GCMesh::GCTriInt(const Vector3d& p, const Vector3d& v1, const Vector3d& v2, const Vector3d& e)
{
    const double alpha = acos((v2 - v1).normalized() | (p - v1).normalized());
    const double beta  = acos((v1 - p ).normalized() | (v2 -p ).normalized());
    const double lambda = (p - v1).lengthSquared() * sin(alpha) * sin(alpha);
    const double c      = (p - e).lengthSquared();
    const double theta[2] = { M_PI - alpha, M_PI - alpha - beta };
    Vector2f I;
    for (int i = 0; i < 2; ++i) {
        const double S = sin(theta[i]);
        const double C = cos(theta[i]);
        double sign = S < 0 ? -1.0 : 0 < S ? 1.0 : 0.0;
        if (sign == 0.0)
            I[i] = 0.0;
        else
            I[i] = -0.5 * sign * (2.0f * sqrt(c) * atan(sqrt(c) * C / sqrt(lambda + S * S * c))
                + sqrt(lambda) * log(
                    2.0 * sqrt(lambda) * S * S / ((1.0 - C) * (1.0 - C))
                    * (1.0 - 2.0 * c * C / (c * (1.0 + C) + lambda + sqrt(lambda * lambda + lambda * c * S * S)))));
        double denomi0 = sqrt(lambda + S * S * c);
        double denomi1 = (1.0 - C) * (1.0 - C);
        double denomi2 = c * (1.0 + C) + lambda + sqrt(lambda * lambda + lambda * c * S * S);
        assert(denomi0 != 0.0);
        assert(denomi1 != 0.0);
        assert(denomi2 != 0.0);
        assert(!_isnan(I[i]));
        assert(_finite(I[i]));
    }
    double ret = -0.25 / M_PI * abs(I[0] - I[1] - sqrt(c) * beta);
    assert(!_isnan(ret));
    assert(_finite(ret));
    return ret;
}

void GCMesh::compute_deform(GCMesh::Data& gc_data) const {
    assert(gc_data.coord_v_.size() == n_vertices());
    assert(gc_data.coord_n_.size() == n_faces());
    
    gc_data.deformed_position_ = Vector3f();
    for (int i = 0; i < n_vertices(); ++i) {
        VHandle v = vertex_handle(i);
        const VertexData& vdata = data(v);
        gc_data.deformed_position_ += gc_data.coord_v_[i] * vdata.deformed_position_;
    }
    for (int i = 0; i < n_faces(); ++i) {
        FHandle f = face_handle(i);
        const FaceData& fdata = data(f);
        gc_data.deformed_position_ += gc_data.coord_n_[i] * fdata.scalar_ * fdata.deformed_normal_;
    }
}
