#include "StdAfx.h"
#include "StateParamSrc.h"
#include "StateParamTgt.h"
#include "Core.h"
#include <KLIB/GLUtil.h>
#include <KLIB/DrawUtil.h>
#include <KLIB/TriangleUtil.h>
#include <stack>

using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
Drawer& drawer = core.drawer_;
typedef MeshSrc Mesh;
Mesh& mesh = core.meshSrc_;
CageGenMesh& cageGenMesh = core.cageGenMesh_;
GCMesh& gcmesh = core.gcmesh_;

}

State* StateParamSrc::next() {
    if (mesh.paramedPatch_.faces_.empty())
        return 0;
    //step4_make_gcmesh();
    gcmesh.init_original();
    mesh.compute_gc_coord();       // compute GC coordinates for each paramed vtx
    mesh.render_paramedPatch_mask();
    return StateParamTgt::getInstance();
}
void StateParamSrc::clear() {
    mesh.paramedPatch_.clear();
    mesh.expmap_info_.clear();
    for (Mesh::VIter v = mesh.vertices_begin(); v != mesh.vertices_end(); ++v) {
        Mesh::VertexData& vdata = mesh.data(v);
        vdata.select_value_ = FLT_MAX;
        vdata.paramed_ = false;
        vdata.expmap_data_.clear();
        vdata.expmap_normal_ = Vector3f();
    }
    for (Mesh::FIter f = mesh.faces_begin(); f != mesh.faces_end(); ++f) {
        Mesh::FaceData& fdata = mesh.data(f);
        fdata.paramed_ = false;
        fdata.reversed_ = false;
    }
    for (Mesh::EIter e = mesh.edges_begin(); e != mesh.edges_end(); ++e) {
        Mesh::EdgeData& edata = mesh.data(e);
        edata.paramed_ = false;
    }
    cageGenMesh.clear();
    gcmesh.clear();
}

void StateParamSrc::draw_left() {
    glPushAttrib(GL_LINE_BIT | GL_ENABLE_BIT | GL_POINT_BIT | GL_HINT_BIT);
    
    glDisable(GL_LIGHTING);
    if (drawer.flags_[4]) { // draw expmap normals
        glLineWidth(1);
        glBegin(GL_LINES);
        for (size_t i = 0; i < mesh.paramedPatch_.vertices_.size(); ++i) {
            Mesh::VHandle& v = mesh.paramedPatch_.vertices_[i];
            Vector3f p = mesh.point(v);
            Vector3f n = mesh.data(v).expmap_normal_;
            glColor3d(0.2, 0.1, 0.4);
            glVertex3fv(p.ptr());
            glColor3d(0.4, 0.2, 0.8);
            glVertex3fv((p + 0.025f * n).ptr());
        }
        glEnd();
    }
    
    glDisable(GL_DEPTH_TEST);
    // matrix reset for 2D draw
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0.0, drawer.width_ / 2, 0.0, drawer.height_);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    if (dragMode_ == DRAGMODE_DRAW) {
        // draw screenBuf_
        glEnable(GL_BLEND);
        screenBuf_.texture_.enable();
        screenBuf_.texture_.bind();
        glBegin(GL_QUADS);
        glTexCoord2d(0, 0);    glVertex2d(0, 0);
        glTexCoord2d(1, 0);    glVertex2d(drawer.width_ / 2, 0);
        glTexCoord2d(1, 1);    glVertex2d(drawer.width_ / 2, drawer.height_);
        glTexCoord2d(0, 1);    glVertex2d(0, drawer.height_);
        glEnd();
        screenBuf_.texture_.unbind();
    }
    if (dragMode_ != DRAGMODE_ROTATE) {
        glColor4d(Drawer::ColorList::CANVAS_SELECT);
        glEnable(GL_BLEND);
        glPushMatrix();
        glTranslated(mousePos_.x_, mousePos_.y_, 0);
        DrawUtil::drawDisk(brushSize_);
        glColor4d(Drawer::ColorList::BRUSH_EDGE);
        glLineWidth(2);
        DrawUtil::drawCircle(brushSize_);
        glPopMatrix();
    }
    // matrix restore from 2D draw
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    
    if (mesh.expmap_info_.seed_vhandle_.is_valid() && drawer.flags_[0]) {
        glPointSize(20);
        glEnable(GL_POINT_SMOOTH);
        glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
        glBegin(GL_POINTS);
        glColor3d(1, 1, 0);
        glVertex3f(mesh.point(mesh.expmap_info_.seed_vhandle_));
        glEnd();
    }
    glPopAttrib();
}
void StateParamSrc::draw_right() {
    glPushAttrib(GL_ENABLE_BIT);
    
    // matrix rest for 2D draw
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(drawer.width_ / 2, drawer.width_, 0.0, drawer.height_);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    // draw gray transparent quad
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glColor4d(0.5, 0.5, 0.5, 0.5);
    glBegin(GL_QUADS);
    glVertex2d(drawer.width_ / 2, 0);
    glVertex2d(drawer.width_, 0);
    glVertex2d(drawer.width_, drawer.height_);
    glVertex2d(drawer.width_ / 2, drawer.height_);
    glEnd();
    // matrix restore from 2D draw
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    
    glPopAttrib();
}
void StateParamSrc::mouseLButtonDown(int x, int y, bool flagShift, bool flagCtrl) {
    if (drawer.width_ / 2 < x)
        return;
    if (flagShift) {
        dragMode_ = DRAGMODE_ROTATE;
        prevpos_.set(x, y);
        return;
    }
    // select the seed face
    int faceID = 0;
    Vector3f baryCoord;
    drawer.select(x, drawer.height_ - 1 - y, faceID, baryCoord);
    if (faceID == -1) {
        cout << "Selection lasso should start from a surface point.\n";
        return;
    }
    f_seed_ = mesh.face_handle(faceID);
    float baryCoord_max = 0.0f;
    Mesh::FVIter v = mesh.fv_iter(f_seed_);
    for (int i = 0; i < 3; ++i, ++v) {
        if (baryCoord_max < baryCoord[i]) {
            baryCoord_max = baryCoord[i];
            mesh.expmap_info_.seed_vhandle_ = v;
        }
    }
    
    Vector3f right = (drawer.trackballLeft_.eyeDirection() % drawer.trackballLeft_.upDirection_).convert<float>();
    mesh.expmap_info_.seed_horizon_ = right;
    dragMode_ = DRAGMODE_DRAW;
    mouseMove(x, y);
}
void StateParamSrc::mouseLButtonUp(int x, int y) {
    if (dragMode_ == DRAGMODE_DRAW) {
        clk_.resetTick();
        screenBuf_.dump();
        if (step1_calc_patch    () &&
            step2_interp_normal () &&
            step3_compute_expmap() &&
            step4_make_gcmesh   ())
            cout << "succeed!\n";
        else
            cout << "failed.\n";
        clk_.print();
        drawer.dispList_meshSrc_all_faces_.requestUpdate();
        {   // clear screenBuf
            core.framebuffer_.bind();
            core.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, screenBuf_.texture_);
            GLUtil::checkFramebufferStatus();
            
            glPushAttrib(GL_VIEWPORT_BIT | GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT | GL_HINT_BIT | GL_POINT_BIT);
            // viewport and camera setting
            glViewport(0, 0, drawer.width_ / 2, drawer.height_);
            const Vector4d& p = Drawer::ColorList::CANVAS_SELECT;
            glClearColor(p.x_, p.y_, p.z_, 0);
            glClear(GL_COLOR_BUFFER_BIT);
            glPopAttrib();
            core.framebuffer_.detachTexture(GL_COLOR_ATTACHMENT0_EXT, screenBuf_.texture_);
            core.framebuffer_.unbind();
            GLUtil::checkError();
        }
        redrawWindow();
    }
    dragMode_ = DRAGMODE_NONE;
}
void StateParamSrc::mouseMove(int x, int y, bool flagShift, bool flagCtrl) {
    if (dragMode_ == DRAGMODE_NONE) {
        if (drawer.width_ / 2 < x)
            return;
        mousePos_.set(x, drawer.height_ - 1 - y);
    } else if (dragMode_ == DRAGMODE_DRAW) {
        mousePos_.set(x, drawer.height_ - 1 - y);
        // render a point to screenBuf_
        core.framebuffer_.bind();
        core.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, screenBuf_.texture_);
        GLUtil::checkFramebufferStatus();
        
        glPushAttrib(GL_VIEWPORT_BIT | GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT | GL_HINT_BIT | GL_POINT_BIT);
        // viewport and camera setting
        glViewport(0, 0, drawer.width_ / 2, drawer.height_);
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        gluOrtho2D(0, drawer.width_ / 2, 0, drawer.height_);
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        // render brushed point as a disk
        glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);
        glEnable(GL_BLEND);
        glColor4d(Drawer::ColorList::CANVAS_SELECT);
        glPushMatrix();
        glTranslated(x, drawer.height_ - 1 - y, 0);
        DrawUtil::drawDisk(brushSize_);
        glPopMatrix();
        
        // cleanup
        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
        glPopAttrib();
        core.framebuffer_.unbind();
        GLUtil::checkError();
    } else {
        float dx = 2.0f * (x - prevpos_.x_) / (float)drawer.width_;
        Vector3f& seed_horizon = mesh.expmap_info_.seed_horizon_;
        Vector3f& seed_normal  = mesh.expmap_info_.seed_normal_;
        seed_horizon = Util::rotationFromAxisAngle(seed_normal, dx) * seed_horizon;
        if (mesh.paramedPatch_.vertices_.empty())
            return;
        bool result =
            step3_compute_expmap() &&
            step4_make_gcmesh   ();
        drawer.dispList_meshSrc_all_faces_.requestUpdate();
        cout << (result ? "succeed!" : "failed.") << endl;
        prevpos_.set(x, y);
    }
    redrawWindow();
}
void StateParamSrc::mouseWheel(int direction, int x, int y) {
    brushSize_ = max<float>(min<float>(brushSize_ + (direction == 1 ? 10.0f : -10.0f), 300.0f), 10.0f);
    redrawWindow();
}
bool StateParamSrc::step1_calc_patch() {
    ClkStart clkStart(&clk_, 0);
    
    Vector3f eyeDirection = drawer.trackballLeft_.eyeDirection().convert<float>();
    
    // clear MeshSrc::FaceT::{paramed_, paint_in_}
    for (Mesh::FIter f = mesh.faces_begin(); f != mesh.faces_end(); ++f) {
        mesh.data(f).paramed_  = false;
        mesh.data(f).paint_in_ = false;
    }
    // set a special value (FLT_MAX) to MeshSrc::VertexT::select_value_
    for (Mesh::VIter v = mesh.vertices_begin(); v != mesh.vertices_end(); ++v)
        mesh.data(v).select_value_ = FLT_MAX;
    makeOpenGLCurrent();
    glPushAttrib(GL_VIEWPORT_BIT);
    glViewport(0, 0, drawer.width_ / 2, drawer.height_);
    stack<Mesh::FHandle> s;
    s.push(f_seed_);
    while (!s.empty()) {
        Mesh::FHandle f = s.top();
        s.pop();
        if (mesh.data(f).paramed_)
            continue;
        mesh.data(f).paramed_ = true;
        for (Mesh::FFIter ff = mesh.ff_iter(f); ff; ++ff) {
            if (mesh.data(ff).paramed_)
                continue;
            for (Mesh::FVIter v = mesh.fv_iter(ff); v; ++v) {
                float & select_value = mesh.data(v).select_value_;
                if (select_value == FLT_MAX) {
                    Vector3d screenPos = drawer.project_left(mesh.point(v).convert<double>());
                    Vector2d uv(screenPos.x_ / (drawer.width_ / 2), screenPos.y_ / drawer.height_);
                    select_value = screenBuf_.getValue(uv).w_;
                }
                if (select_value > 0.125f) {
                    s.push(ff);
                    break;
                }
            }
        }
    }
    glPopAttrib();
    
    // set MeshSrc::ParamedPatch.{vertices, faces, edges}
    mesh.paramedPatch_.vertices_.clear();
    mesh.paramedPatch_.vertices_.reserve(mesh.n_vertices() / 4);
    mesh.paramedPatch_.faces_.clear();
    mesh.paramedPatch_.faces_.reserve(mesh.n_faces() / 4);
    mesh.paramedPatch_.edges_.clear();
    mesh.paramedPatch_.edges_.reserve(mesh.n_edges() / 4);
    for (Mesh::VIter v = mesh.vertices_begin(); v != mesh.vertices_end(); ++v) {
        mesh.data(v).paramed_ = false;
        mesh.data(v).stitch_vid_ = -1;
    }
    for (Mesh::EIter e = mesh.edges_begin(); e != mesh.edges_end(); ++e)
        mesh.data(e).paramed_ = false;
    for (Mesh::FIter f = mesh.faces_begin(); f != mesh.faces_end(); ++f) {
        if (!mesh.data(f).paramed_)
            continue;
        mesh.paramedPatch_.faces_.push_back(f);
        for (Mesh::FVIter v = mesh.fv_iter(f); v; ++v) {
            if (mesh.data(v).paramed_)
                continue;
            mesh.data(v).paramed_ = true;
            mesh.paramedPatch_.vertices_.push_back(v);
        }
        for (Mesh::FEIter e = mesh.fe_iter(f); e; ++e) {
            if (mesh.data(e).paramed_)
                continue;
            mesh.data(e).paramed_ = true;
            mesh.paramedPatch_.edges_.push_back(e);
        }
    }
    
    {   // set MeshSrc::ParamedPatch.vertices_boundary
        mesh.paramedPatch_.vertices_boundary_.clear();
        Mesh::VHandle v_start;
        for (size_t i = 0; i < mesh.paramedPatch_.vertices_.size(); ++i) {
            Mesh::VHandle v = mesh.paramedPatch_.vertices_[i];
            for (Mesh::VVIter w = mesh.vv_iter(v); w; ++w)
                if (!mesh.data(w).paramed_) {
                    v_start = v;
                    break;
                }
            if (v_start.is_valid())
                break;
        }
        Mesh::VHandle v_prev, v_next = v_start;
        while (true) {
            mesh.paramedPatch_.vertices_boundary_.push_back(v_next);
            Mesh::VHandle v_next_new;
            for (Mesh::VOHIter h = mesh.voh_iter(v_next); h; ++h) {
                Mesh::FHandle f = mesh.face_handle(h);
                if (!f.is_valid() || !mesh.data(f).paramed_)
                    continue;
                Mesh::HHandle h_opposite = mesh.opposite_halfedge_handle(h);
                Mesh::FHandle f_opposite = mesh.face_handle(h_opposite);
                if (f_opposite.is_valid() && mesh.data(f_opposite).paramed_)
                    continue;
                v_next_new = mesh.to_vertex_handle(h);
                break;
            }
            assert(v_next_new.is_valid());
            v_prev = v_next;
            v_next = v_next_new;
            if (v_next == v_start)
                break;
        }
    }
    
    return !mesh.paramedPatch_.faces_.empty();
}
bool StateParamSrc::step2_interp_normal() {
    ClkStart clkStart(&clk_, 1);
    
    vector<Mesh::VHandle>& vertices_boundary = mesh.paramedPatch_.vertices_boundary_;
    vector<Mesh::VHandle>  vertices_interior;
    for (size_t i = 0; i < mesh.paramedPatch_.vertices_.size(); ++i) {
        Mesh::VHandle& v = mesh.paramedPatch_.vertices_[i];
        bool is_interior = true;
        for (Mesh::VVIter vv = mesh.vv_iter(v); vv; ++vv) {
            is_interior = is_interior && mesh.data(vv).paramed_;
            if (!is_interior)
                break;
        }
        if (is_interior)
            vertices_interior.push_back(v);
    }
    int nb = static_cast<int>(vertices_boundary.size());
    int ni = static_cast<int>(vertices_interior.size());
    for (int i = 0; i < nb; ++i) {      // initialize DEM normal as the surface normal
        Mesh::VHandle v = vertices_boundary[i];
        mesh.data(v).expmap_normal_ = mesh.normal(v);
    }
    for (int m = 0; m < 10; ++m) {       // iterative smoothing of boundary normals
        vector<Vector3f> boundary_normal_old(nb);
        for (int i = 0; i < nb; ++i)
            boundary_normal_old[i] = mesh.data(vertices_boundary[i]).expmap_normal_;
        for (int i = 0; i < nb; ++i) {
            int i_next = (i + 1) % nb;
            int i_prev = (i + nb - 1) % nb;
            Vector3f& normal = mesh.data(vertices_boundary[i]).expmap_normal_;
            normal = 0.5f * boundary_normal_old[i] + 0.25f * (boundary_normal_old[i_next] + boundary_normal_old[i_prev]);
            normal.normalize();
        }
    }
    for (int i = 0; i < ni; ++i) {
        Mesh::VHandle& v = vertices_interior[i];
        Vector3f& p = mesh.point(v);
        Vector3f normal;
        float weightTotal = 0;
        for (int j = 0; j < nb; ++j) {
            Mesh::VHandle& w = vertices_boundary[j];
            Vector3f& q = mesh.point(w);
            float len = (p - q).length();
            float weight = 1.0f / ((p - q).length() + 0.001f);
            normal += weight * mesh.data(w).expmap_normal_;
            weightTotal += weight;
        }
        normal /= weightTotal;
        mesh.data(v).expmap_normal_ = normal;
    }
    // smoothing
    for (int m = 0; m < 2; ++m) {
        vector<Vector3f> normal_temp(ni);
        for (int i = 0; i < ni; ++i) {
            Mesh::VHandle& v = vertices_interior[i];
            normal_temp[i] += mesh.data(v).expmap_normal_;
            set<int>& neighbor = mesh.data(v).expmap_neighbor_;
            for (set<int>::iterator iw = neighbor.begin(); iw != neighbor.end(); ++iw) {
                Mesh::VHandle w = mesh.vertex_handle(*iw);
                if (mesh.data(w).paramed_)
                    normal_temp[i] += mesh.data(w).expmap_normal_;
            }
            normal_temp[i].normalize();
        }
        for (int i = 0; i < ni; ++i)
            mesh.data(vertices_interior[i]).expmap_normal_ = normal_temp[i];
    }
    return true;
}
bool StateParamSrc::step3_compute_expmap() {
    ClkStart clkStart(&clk_, 2);
    mesh.compute_expmap();
    return true;
}
bool StateParamSrc::step4_make_gcmesh() {
    ClkStart clkStart(&clk_, 3);
    bool result = cageGenMesh.cageGen_original();
    cout << (result ? "succeed!" : "failed.") << endl;
    return result;
}
void StateParamSrc::keyDown(char ascii) {
    switch (ascii) {
    case 'z':
    case 'Z':
        CageGenMesh::dbg_use_laplacian_optimization_ = !CageGenMesh::dbg_use_laplacian_optimization_;
        showMessage(CageGenMesh::dbg_use_laplacian_optimization_ ? "Laplacian optimization enabled" : "Laplacian optimization disabled");
        step4_make_gcmesh();
        redrawWindow();
        break;
    case 'x':
    case 'X':
        CageGenMesh::dbg_show_ = !CageGenMesh::dbg_show_;
        redrawWindow();
        break;
    }
}
void StateParamSrc::keyDown(SpecialKey key) {
    switch (key) {
        case KEY_UP:
        case KEY_DOWN:
            brushSize_ = max<float>(min<float>(brushSize_ +  (key == KEY_UP ? 10.0f : -10.0f), 300.0f), 10.0f);
            redrawWindow();
            break;
    }
}
StateParamSrc::StateParamSrc(void)
: dragMode_(DRAGMODE_NONE)
, brushSize_(30.0f)
, clk_("ParamSrc")
{
    clk_.addEntry("calc_patch");
    clk_.addEntry("interp_normal");
    clk_.addEntry("compute_expmap");
    clk_.addEntry("make_gcmesh");
}
