#include "stdafx.h"
#include "VCycle.h"
#include "Core.h"
#include "Config.h"
#include <sstream>

using namespace std;
using namespace KLIB;

namespace {

Core& core = Core::getInstance();

}

void VCycle::bind_output(const TextureObject& texture) {
    glPushAttrib(GL_VIEWPORT_BIT);
    glViewport(0, 0, texture.width(), texture.height());
    
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    glTranslatef(-1.0f, -1.0f, 0.0f);
    glScalef(2.0f / texture.width(), 2.0f / texture.height(), 1.0f);
    
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    
    framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, texture);
    glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
}

void VCycle::unbind_output(const TextureObject& texture) {
    glPopAttrib();

    glMatrixMode(GL_PROJECTION);
    glPopMatrix();

    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();

    framebuffer_.detachTexture(GL_COLOR_ATTACHMENT0_EXT, texture);
}

void VCycle::init() {
    makeOpenGLCurrent();
    
    framebuffer_.init();
    
    // smoothing for f
    shader_smooth_f_.init();
    shader_smooth_f_.attach(ShaderObject("shaders/vcycle_smooth_f.frag"  , ShaderObject::FRAGMENT_SHADER));
    shader_smooth_f_.link();
    shader_smooth_f_.enable();
    shader_smooth_f_.setUniform1i("u_texture_f" , 0);
    shader_smooth_f_.setUniform1i("u_texture_gu", 1);
    shader_smooth_f_.setUniform1i("u_texture_gv", 2);
    shader_smooth_f_.disable();
    
    // smoothing for gu
    shader_smooth_gu_.init();
    shader_smooth_gu_.attach(ShaderObject("shaders/vcycle_smooth_gu.frag"  , ShaderObject::FRAGMENT_SHADER));
    shader_smooth_gu_.link();
    shader_smooth_gu_.enable();
    shader_smooth_gu_.setUniform1i("u_texture_f" , 0);
    shader_smooth_gu_.setUniform1i("u_texture_gu", 1);
    shader_smooth_gu_.disable();
    
    // smoothing for gv
    shader_smooth_gv_.init();
    shader_smooth_gv_.attach(ShaderObject("shaders/vcycle_smooth_gv.frag"  , ShaderObject::FRAGMENT_SHADER));
    shader_smooth_gv_.link();
    shader_smooth_gv_.enable();
    shader_smooth_gv_.setUniform1i("u_texture_f" , 0);
    shader_smooth_gv_.setUniform1i("u_texture_gv", 1);
    shader_smooth_gv_.disable();
    
    // restriction
    shader_restrict_.init();
    shader_restrict_.attach(ShaderObject("shaders/vcycle_restrict.frag", ShaderObject::FRAGMENT_SHADER));
    shader_restrict_.link();
    shader_restrict_.enable();
    shader_restrict_.setUniform1i("u_texture" , 0);
    shader_restrict_.disable();
    
    // prolongation
    shader_prolong_.init();
    shader_prolong_.attach(ShaderObject("shaders/vcycle_prolong.frag", ShaderObject::FRAGMENT_SHADER));
    shader_prolong_.link();
    shader_prolong_.enable();
    shader_prolong_.setUniform1i("u_texture_H" , 0);      // H stands for "higher-res"
    shader_prolong_.setUniform1i("u_texture_L" , 1);      // L stands for "lower-res"
    shader_prolong_.disable();
    
    // allocate cpu/gpu memory
    levels_.reserve(32);
    for (int rez = Config::PARAMSPACE_REZ; ; ) {
        levels_.push_back(Level());
        Level& level = levels_.back();
        level.rez_ = rez;
        // allocate cpu/gpu memory
        for (int i = 0; i < 2; ++i) {
            level.f_ [i].texture_.init(GL_TEXTURE_RECTANGLE_ARB, GL_CLAMP_TO_EDGE, GL_NEAREST, GL_REPLACE);
            level.gu_[i].texture_.init(GL_TEXTURE_RECTANGLE_ARB, GL_CLAMP_TO_EDGE, GL_NEAREST, GL_REPLACE);
            level.gv_[i].texture_.init(GL_TEXTURE_RECTANGLE_ARB, GL_CLAMP_TO_EDGE, GL_NEAREST, GL_REPLACE);
            vector<Vector4f> initial_value(rez * rez, Vector4f(1.0f, 2.0f, 3.0f, 4.0f));    // for debugging only, completely arbitrary...
            level.f_ [i].texture_.allocate(GL_RGBA32F_ARB, rez, rez, GL_RGBA, GL_FLOAT, &initial_value[0]);
            level.gu_[i].texture_.allocate(GL_RGBA32F_ARB, rez - 1, rez, GL_RGBA, GL_FLOAT, &initial_value[0]);
            level.gv_[i].texture_.allocate(GL_RGBA32F_ARB, rez, rez - 1, GL_RGBA, GL_FLOAT, &initial_value[0]);
        }
        if (rez < 3)
            break;
        //rez = 1 + (rez - 1) / 2;
        rez /= 2;           // assuming PARAMSPACE_REZ is power of 2
    }
}

void VCycle::smooth(int levelID) {
    ClkStart clk(&clk_smooth_);
    
    Level& level = levels_[levelID];
    float rez = static_cast<float>(level.rez_);
    
    // smoothing for f
    bind_output(level.f_out().texture_);
    glActiveTextureARB(GL_TEXTURE2);        level.gv_in().texture_.bind();      // set input textures
    glActiveTextureARB(GL_TEXTURE1);        level.gu_in().texture_.bind();
    glActiveTextureARB(GL_TEXTURE0);        level.f_in().texture_.bind();
    shader_smooth_f_.enable();
    shader_smooth_f_.setUniform1f("u_rez", rez);
    
    clk.setCurrentIndex(1);
    glBegin(GL_QUADS);        // render a quad
    glVertex2f(0  , 0  );
    glVertex2f(rez, 0  );
    glVertex2f(rez, rez);
    glVertex2f(0  , rez);
    glEnd();
    clk.setCurrentIndex(0);
    
    shader_smooth_f_.disable();        // cleanng...
    glActiveTextureARB(GL_TEXTURE2);        level.gv_in().texture_.unbind();
    glActiveTextureARB(GL_TEXTURE1);        level.gu_in().texture_.unbind();
    glActiveTextureARB(GL_TEXTURE0);        level.f_in().texture_.unbind();
    unbind_output(level.f_out().texture_);
    
    // smoothing for gu
    bind_output(level.gu_out().texture_);
    glActiveTextureARB(GL_TEXTURE1);        level.gu_in().texture_.bind();      // set input textures
    glActiveTextureARB(GL_TEXTURE0);        level.f_in().texture_.bind();
    shader_smooth_gu_.enable();
    shader_smooth_gu_.setUniform1f("u_rez", rez);
    
    clk.setCurrentIndex(1);
    glBegin(GL_QUADS);        // render a quad
    glVertex2f(0      , 0  );
    glVertex2f(rez - 1, 0  );
    glVertex2f(rez - 1, rez);
    glVertex2f(0      , rez);
    glEnd();
    clk.setCurrentIndex(0);
    
    shader_smooth_gu_.disable();        // cleanng...
    glActiveTextureARB(GL_TEXTURE1);        level.gu_in().texture_.unbind();
    glActiveTextureARB(GL_TEXTURE0);        level.f_in().texture_.unbind();
    unbind_output(level.gu_out().texture_);
    
    // smoothing for gv
    bind_output(level.gv_out().texture_);
    glActiveTextureARB(GL_TEXTURE1);        level.gv_in().texture_.bind();      // set input textures
    glActiveTextureARB(GL_TEXTURE0);        level.f_in().texture_.bind();
    shader_smooth_gv_.enable();
    shader_smooth_gv_.setUniform1f("u_rez", rez);
    
    clk.setCurrentIndex(1);
    glBegin(GL_QUADS);        // render a quad
    glVertex2f(0  , 0      );
    glVertex2f(rez, 0      );
    glVertex2f(rez, rez - 1);
    glVertex2f(0  , rez - 1);
    glEnd();
    clk.setCurrentIndex(0);
    
    shader_smooth_gv_.disable();        // cleanng...
    glActiveTextureARB(GL_TEXTURE1);        level.gv_in().texture_.unbind();
    glActiveTextureARB(GL_TEXTURE0);        level.f_in().texture_.unbind();
    unbind_output(level.gv_out().texture_);
    
    level.swap_inout();  // swap input/output buffers
    
    GLUtil::checkError("VCycle::smooth");
}
void VCycle::restrict(int levelID) {
    ClkStart clk(&clk_restrict_);
    
    Level& level_u = levels_[levelID];             // "*_u" stands for "up", "*_d" stands for "down"
    Level& level_d = levels_[levelID + 1];
    float u_rez = static_cast<float>(level_u.rez_);
    float d_rez = static_cast<float>(level_d.rez_);     //u_rez / 2.0f;
    
    // common setup
    glActiveTextureARB(GL_TEXTURE0);
    shader_restrict_.enable();
    shader_restrict_.setUniform1i("u_isGradient", 0);
    
    // restriction for f
    bind_output(level_d.f_out().texture_);
    level_u.f_in().texture_.bind();      // set input textures
    clk.setCurrentIndex(1);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f , 0.0f ); glVertex2f(0.0f , 0.0f );
    glTexCoord2f(u_rez, 0.0f ); glVertex2f(d_rez, 0.0f );
    glTexCoord2f(u_rez, u_rez); glVertex2f(d_rez, d_rez);
    glTexCoord2f(0.0f , u_rez); glVertex2f(0.0f , d_rez);
    glEnd();
    clk.setCurrentIndex(0);
    unbind_output(level_d.f_out().texture_);
    
    shader_restrict_.setUniform1i("u_isGradient", 1);
    
    // restriction for gu
    bind_output(level_d.gu_out().texture_);
    level_u.gu_in().texture_.bind();      // set input textures
    clk.setCurrentIndex(1);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f        , 0.0f ); glVertex2f(0.0f        , 0.0f );
    glTexCoord2f(u_rez - 1.0f, 0.0f ); glVertex2f(d_rez - 1.0f, 0.0f );
    glTexCoord2f(u_rez - 1.0f, u_rez); glVertex2f(d_rez - 1.0f, d_rez);
    glTexCoord2f(0.0f        , u_rez); glVertex2f(0.0f        , d_rez);
    glEnd();
    clk.setCurrentIndex(0);
    unbind_output(level_d.gu_out().texture_);
    
    // restriction for gv
    bind_output(level_d.gv_out().texture_);
    level_u.gv_in().texture_.bind();      // set input textures
    clk.setCurrentIndex(1);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f , 0.0f        ); glVertex2f(0.0f , 0.0f        );
    glTexCoord2f(u_rez, 0.0f        ); glVertex2f(d_rez, 0.0f        );
    glTexCoord2f(u_rez, u_rez - 1.0f); glVertex2f(d_rez, d_rez - 1.0f);
    glTexCoord2f(0.0f , u_rez - 1.0f); glVertex2f(0.0f , d_rez - 1.0f);
    glEnd();
    clk.setCurrentIndex(0);
    unbind_output(level_d.gv_out().texture_);
    
    shader_restrict_.disable();
    
    level_d.swap_inout();
    
    GLUtil::checkError("VCycle::restrict");
}
void VCycle::prolong(int levelID) {
    ClkStart clk(&clk_prolong_);
    
    Level& level_u = levels_[levelID - 1];             // "*_u" stands for "up", "*_d" stands for "down"
    Level& level_d = levels_[levelID];
    float u_rez = static_cast<float>(level_u.rez_);
    float d_rez = static_cast<float>(level_d.rez_);     //u_rez / 2.0f;
    
    shader_prolong_.enable();
    shader_prolong_.setUniform1i("u_isGradient", 0);
    
    // prolongation for f
    bind_output(level_u.f_out().texture_);
    glActiveTextureARB(GL_TEXTURE1);    level_d.f_in ().texture_.bind();
    glActiveTextureARB(GL_TEXTURE0);    level_u.f_in ().texture_.bind();
    clk.setCurrentIndex(1);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f , 0.0f );   glVertex2f(0.0f , 0.0f );
    glTexCoord2f(d_rez, 0.0f );   glVertex2f(u_rez, 0.0f );
    glTexCoord2f(d_rez, d_rez);   glVertex2f(u_rez, u_rez);
    glTexCoord2f(0.0f , d_rez);   glVertex2f(0.0f , u_rez);
    glEnd();
    clk.setCurrentIndex(0);
    unbind_output(level_u.f_out().texture_);
    
    shader_prolong_.setUniform1i("u_isGradient", 1);
    
    // prolongation for gu
    bind_output(level_u.gu_out().texture_);
    glActiveTextureARB(GL_TEXTURE1);    level_d.gu_in ().texture_.bind();
    glActiveTextureARB(GL_TEXTURE0);    level_u.gu_in ().texture_.bind();
    clk.setCurrentIndex(1);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f        , 0.0f );   glVertex2f(0.0f        , 0.0f );
    glTexCoord2f(d_rez - 0.5f, 0.0f );   glVertex2f(u_rez - 1.0f, 0.0f );
    glTexCoord2f(d_rez - 0.5f, d_rez);   glVertex2f(u_rez - 1.0f, u_rez);
    glTexCoord2f(0.0f        , d_rez);   glVertex2f(0.0f        , u_rez);
    glEnd();
    clk.setCurrentIndex(0);
    unbind_output(level_u.gu_out().texture_);
    
    // prolongation for gv
    bind_output(level_u.gv_out().texture_);
    glActiveTextureARB(GL_TEXTURE1);    level_d.gv_in ().texture_.bind();
    glActiveTextureARB(GL_TEXTURE0);    level_u.gv_in ().texture_.bind();
    clk.setCurrentIndex(1);
    glBegin(GL_QUADS);
    glTexCoord2f(0.0f , 0.0f        );   glVertex2f(0.0f , 0.0f        );
    glTexCoord2f(d_rez, 0.0f        );   glVertex2f(u_rez, 0.0f        );
    glTexCoord2f(d_rez, d_rez - 0.5f);   glVertex2f(u_rez, u_rez - 1.0f);
    glTexCoord2f(0.0f , d_rez - 0.5f);   glVertex2f(0.0f , u_rez - 1.0f);
    glEnd();
    clk.setCurrentIndex(0);
    unbind_output(level_u.gv_out().texture_);
    
    shader_prolong_.disable();
    glActiveTextureARB(GL_TEXTURE1);    level_d.gv_in ().texture_.unbind();
    glActiveTextureARB(GL_TEXTURE0);    level_u.gv_in ().texture_.unbind();
    
    level_u.swap_inout();
    
    GLUtil::checkError("VCycle::prolong");
}

void VCycle::update()
{
    clk_smooth_  .resetTick();
    clk_restrict_.resetTick();
    clk_prolong_ .resetTick();
    
    bool is_bound = framebuffer_.is_bound();
    if (!is_bound)
        framebuffer_.bind();
    vcycle(0);
    if (!is_bound)
        framebuffer_.unbind();
    //cout << "VCycle::update--------------------------------\n";
    //clk_smooth_  .print();
    //clk_restrict_.print();
    //clk_prolong_ .print();
    GLUtil::checkError("VCycle::update");
}
void VCycle::vcycle(int levelID) {
    if (levelID == levels_.size() - 1) {
        for (int i = 0; i < Config::VCYCLE_NUM_SMOOTHING; ++i)
            smooth(levelID);
        return;
    }
    restrict(levelID);
    for (int cycle = 0; cycle < Config::VCYCLE_NUM_CYCLE; ++cycle)
        vcycle(levelID + 1);
    prolong(levelID + 1);
    for (int i = 0; i < Config::VCYCLE_NUM_SMOOTHING; ++i)
        smooth(levelID);
    GLUtil::checkError("VCycle::vcycle");
}

VCycle::VCycle(void)
{
    clk_smooth_  .setClkName("smooth");
    clk_smooth_  .addEntry  ("misc");
    clk_smooth_  .addEntry  ("rendering");
    clk_restrict_.setClkName("restrict");
    clk_restrict_.addEntry  ("misc");
    clk_restrict_.addEntry  ("rendering");
    clk_prolong_ .setClkName("prolong");
    clk_prolong_ .addEntry  ("misc");
    clk_prolong_ .addEntry  ("rendering");
}

VCycle::~VCycle(void) {
}
