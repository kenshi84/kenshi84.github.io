#pragma once
#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/Mesh/Traits.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>
#include <KLIB/Matrix.h>
#include <KLIB/KdTree.h>
#include "Config.h"
#include "ExpMapData.h"
#include <string>

// destination mesh
struct MeshTgtTraits : public OpenMesh::DefaultTraits {
    typedef KLIB::Vector3f Point;
    typedef KLIB::Vector3f Normal;
    VertexTraits {
    public:
        bool paramed_;          // true if included in the parameterized patch
        ExpMapData   expmap_data_;
        
        float paint_value_;
        
        int stitch_vid_;
        
        KLIB::Vector3f result_normal_;        // because of StitchMesh's smoothing, normals of one-ring interior vertices are modified
        
        VertexT()        // ctor
            : paramed_(false)
            , paint_value_(0.0f)
            , stitch_vid_(-1)
        {}
    };
    FaceTraits {
    public:
        bool paramed_;      // true if included in the parameterized patch
        float paint_value_[(Config::PAINT_INOUT_SUBDIV - 1) * (Config::PAINT_INOUT_SUBDIV - 2) / 2];
        bool  paint_out_;
        // ctor
        FaceT()
            : paramed_  (false)     // completely outside paint region (used only for meshTgt)
            , paint_out_(true)
        {
            for (int i = 0; i < (Config::PAINT_INOUT_SUBDIV - 1) * (Config::PAINT_INOUT_SUBDIV - 2) / 2; ++i)
                paint_value_[i] = 0.0f;
        }
    };
    EdgeTraits {
    public:
        bool paramed_;
        float paint_value_[Config::PAINT_INOUT_SUBDIV - 1];
        EdgeT()
            : paramed_(false)
        {
            for (int i = 0; i < Config::PAINT_INOUT_SUBDIV - 1; ++i)
                paint_value_[i] = 0.0f;
        }
    };
};

struct MeshTgt : public OpenMesh::TriMesh_ArrayKernelT<MeshTgtTraits> {
    struct ExpMapInfo {
        KLIB::Vector3f seed_horizon_;
        KLIB::Vector3f seed_normal_;
        FHandle        seed_fhandle_;
        KLIB::Vector3f seed_baryCoord_;
        VHandle        seed_vhandle_;
        float uv_scale_;
        ExpMapInfo();
        void clear() {      // preserves horizon & scale values
            seed_normal_ = KLIB::Vector3f();
            seed_fhandle_ = FHandle();
            seed_baryCoord_ = KLIB::Vector3f();
            seed_vhandle_ = VHandle();
        }
    } expmap_info_;
    
    struct ParamedPatch {
        std::vector<VHandle> vertices_;
        std::vector<FHandle> faces_;
        std::vector<EHandle> edges_;
        KLIB::KdTree2d uv_kdTree_;
        std::vector<VHandle> vertices_boundary_;        // a loop of boundary vertices
        void clear() { *this = ParamedPatch(); }
    } paramedPatch_;
    
    MeshTgt() {}
    
    bool save(const std::string& fname) const;
    bool load(const std::string& fname);
    
    void compute_expmap();
    void fitUnitBox();
private:
    KLIB::Vector2f   compute_expmap_sub_localUV(const VHandle& p, const VHandle& q) const;
    KLIB::Matrix2x2f compute_expmap_sub_rot2D  (const VHandle& p) const;
};
