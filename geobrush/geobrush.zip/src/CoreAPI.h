#include "specialkey.h"

namespace CoreAPI {

void startApp();
void initGL();
void deinitGL();
void draw();
void resize(int width, int height);
void mouseLButtonDown(int x, int y, bool flagShift = false, bool flagCtrl = false);
void mouseRButtonDown(int x, int y, bool flagShift = false, bool flagCtrl = false);
void mouseMButtonDown(int x, int y, bool flagShift = false, bool flagCtrl = false);
void mouseLButtonUp(int x, int y);
void mouseRButtonUp(int x, int y);
void mouseMButtonUp(int x, int y);
void mouseMove(int x, int y, bool flagShift = false, bool flagCtrl = false);
void mouseWheel(int direction, int x, int y);
void keyDown(unsigned char ascii);
void keyDown(SpecialKey key);
}
