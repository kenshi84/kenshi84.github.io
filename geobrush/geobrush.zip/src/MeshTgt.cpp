#include "stdafx.h"
#include "MeshTgt.h"
#include "Core.h"
#include "system_dependent.h"
#include <KLIB/Util.h>
#include <KLIB/Clock.h>
#include <queue>
using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
}

bool MeshTgt::save(const string& fname) const {
    std::cout << "Save file: " << fname << std::endl;
    
    if (!OpenMesh::IO::write_mesh(*this, fname)) {
        std::cerr << "Failed to save file!" << std::endl;
        return false;
    }
    return true;
}
bool MeshTgt::load(const string& fname) {
    ClkSimple clk("MeshTgt::load");
    cout << "Load file: " << fname << endl;
    
    MeshTgt meshTgt_temp;
    if (!OpenMesh::IO::read_mesh(meshTgt_temp, fname)) {
        cerr << "Failed to load file!" << endl;
        return false;
    }
    *this = meshTgt_temp;
    
    fitUnitBox();
    request_face_normals();
    request_vertex_normals();
    update_normals();
    
    cout << "vertices: " << n_vertices() << ", faces: " << n_faces() << endl;
    return true;
}

Vector2f   MeshTgt::compute_expmap_sub_localUV(const VHandle& p, const VHandle& q) const {
    const Vector3f& p_normal = normal(p);
    Vector3f p_horizon;
    if (expmap_info_.seed_vhandle_ == p)
        p_horizon = expmap_info_.seed_horizon_;
    else {
        p_horizon = point(cvv_iter(p)) - point(p);
        p_horizon -= p_normal * (p_normal | p_horizon);
        p_horizon.normalize();
    }
    Vector3f p_vertical = p_normal % p_horizon;
    Vector3f pq = point(q) - point(p);
    //float pq_len = pq.length();
    pq -= p_normal * (p_normal | pq);
    //pq.normalize();
    //pq *= pq_len;
    Vector2f uv(pq | p_horizon, pq | p_vertical);
    uv *= expmap_info_.uv_scale_;
    return uv;
}
Matrix2x2f MeshTgt::compute_expmap_sub_rot2D  (const VHandle& p) const {
    if (expmap_info_.seed_vhandle_ == p)
        return Matrix2x2f::identity();
    
    const Vector3f& s_normal  = expmap_info_.seed_normal_;
    const Vector3f& s_horizon = expmap_info_.seed_horizon_;
    const Vector3f& p_normal  = normal(p);
    Vector3f        p_horizon = point(cvv_iter(p)) - point(p);
    p_horizon -= p_normal * (p_normal | p_horizon);
    p_horizon.normalize();
    
    // first rotation
    float angle1 = Util::calcAngle(s_normal, p_normal);
    if (angle1 != 0.0f) {
        Vector3f axis1 = p_normal % s_normal;
        Matrix3x3f rot1 = Util::rotationFromAxisAngle(axis1, angle1);
        p_horizon = rot1 * p_horizon;
    }
    
    // second rotation
    float angle2 = Util::calcAngle(s_horizon, p_horizon);
    if (((s_horizon % p_horizon) | s_normal) < 0)     // negative rotation
        angle2 *= -1.0f;
    float cosine = cos(angle2), sine = sin(angle2);
    return Matrix2x2f(cosine, -sine, sine, cosine);
}
void MeshTgt::compute_expmap() {
    ClkData clk("MeshTgt::compute_expmap");
    clk.addEntry("expmap_core");
    clk.addEntry("kdtree");
    {   ClkStart clkStart(&clk, 0);
    // clear expmap_vdata.{visited, distance, weightTotal, uv}
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        data(v).expmap_data_.visited_ = false;
        data(v).expmap_data_.distance_ = FLT_MAX;
        data(v).expmap_data_.weightTotal_ = 0.0f;
        data(v).expmap_data_.uv_ = Vector2f();
    }
    
    {   // determine expmap_info_.seed_vhandle_
        FVIter v = fv_iter(expmap_info_.seed_fhandle_);
        float baryCoordMax = 0;
        for (int i = 0; i < 3; ++i, ++v) {
            if (baryCoordMax < expmap_info_.seed_baryCoord_[i]) {
                baryCoordMax = expmap_info_.seed_baryCoord_[i];
                expmap_info_.seed_vhandle_ = v;
            }
        }
    }
    
    // normal and horizon vector
    expmap_info_.seed_normal_ = normal(expmap_info_.seed_vhandle_);
    expmap_info_.seed_horizon_ -= expmap_info_.seed_normal_ * (expmap_info_.seed_normal_ | expmap_info_.seed_horizon_);
    if (expmap_info_.seed_horizon_.length() == 0.0f) {
        expmap_info_.seed_horizon_.set_random(0.0f, 1.0f);
        expmap_info_.seed_horizon_ -= expmap_info_.seed_normal_ * (expmap_info_.seed_normal_ | expmap_info_.seed_horizon_);
    }
    expmap_info_.seed_horizon_.normalize();
    
    Vector2f uv_offset;     {   // determine uv offset vector
        FVIter v = fv_iter(expmap_info_.seed_fhandle_);
        Vector3f origin_position;
        for (int i = 0; i < 3; ++i, ++v)
            origin_position += expmap_info_.seed_baryCoord_[i] * point(v);
        // compute uv offset
        Vector3f f_normal = normal(expmap_info_.seed_fhandle_);
        Vector3f f_horizon = expmap_info_.seed_horizon_ - (f_normal | expmap_info_.seed_horizon_) * f_normal;
        f_horizon.normalize();
        Vector3f f_vertical = f_normal % f_horizon;
        Vector3f xyz_offset = point(expmap_info_.seed_vhandle_) - origin_position;
        uv_offset.set(f_horizon | xyz_offset, f_vertical | xyz_offset);
        uv_offset *= expmap_info_.uv_scale_;
    }
    
    // init queue
    data(expmap_info_.seed_vhandle_).expmap_data_.distance_    = 0.0f;
    data(expmap_info_.seed_vhandle_).expmap_data_.weightTotal_ = 1.0f;
    data(expmap_info_.seed_vhandle_).expmap_data_.uv_          = Vector2f(0.5f) + uv_offset;
    typedef pair<float, VHandle> QueElem;
    priority_queue<QueElem> queue;
    queue.push(QueElem(-0.0f, expmap_info_.seed_vhandle_));
    
    // greedy patch growing process
    while (!queue.empty()) {
        VHandle p = queue.top().second;
        queue.pop();
        ExpMapData& p_data = data(p).expmap_data_;
        if (p_data.visited_)
            continue;
        p_data.visited_ = true;
        p_data.uv_ /= p_data.weightTotal_;
        Vector4f mask = core.paramSpace_.buf_src_.getValue(p_data.uv_);
        if (mask.w_ < 0.5)      // out of the source paramed patch mask
            continue;
        
        Matrix2x2f rot = compute_expmap_sub_rot2D(p);
        
        for (VVIter q = vv_iter(p); q; ++q) {
            ExpMapData& q_data = data(q).expmap_data_;
            if (q_data.visited_)
                continue;
            
            // distance computation
            float len = (point(p) - point(q)).length();
            float distance = p_data.distance_ + len;
            
            // update distance
            if (distance < q_data.distance_)
                q_data.distance_ = distance;
            
            // compute uv
            float weight = 1.0f / len;
            q_data.uv_ += weight * (p_data.uv_ + rot * compute_expmap_sub_localUV(p, q));
            q_data.weightTotal_ += weight;
            
            queue.push(QueElem(-distance, q));
        }
    }
    
    // set VertexT::paramed_, FaceT::{paramed_, paint_out_}, EdgeT::paramed_, paramedPatch_.{vertices_, faces_, edges_}
    paramedPatch_.faces_.clear();
    paramedPatch_.faces_.reserve(n_faces() / 4);
    paramedPatch_.vertices_.clear();
    paramedPatch_.vertices_.reserve(n_vertices() / 4);
    paramedPatch_.edges_.clear();
    paramedPatch_.edges_.reserve(n_edges() / 4);
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        data(v).paramed_ = false;
        data(v).stitch_vid_ = -1;
    }
    for (EIter e = edges_begin(); e != edges_end(); ++e)
        data(e).paramed_ = false;
    for (FIter f = faces_begin(); f != faces_end(); ++f) {
        FaceData& fdata = data(f);
        fdata.paramed_ = true;
        fdata.paint_out_ = false;
        for (FVIter v = fv_iter(f); v; ++v) {
            if (!data(v).expmap_data_.visited_) {
                fdata.paramed_ = false;
                break;
            }
        }
        if (!fdata.paramed_)
            continue;
        paramedPatch_.faces_.push_back(f);
        for (FVIter v = fv_iter(f); v; ++v) {
            if (data(v).paramed_)
                continue;
            data(v).paramed_ = true;
            paramedPatch_.vertices_.push_back(v);
        }
        for (FEIter e = fe_iter(f); e; ++e) {
            if (data(e).paramed_)
                continue;
            data(e).paramed_ = true;
            paramedPatch_.edges_.push_back(e);
        }
    }
    {   // set ParamedPatch.vertices_boundary
        paramedPatch_.vertices_boundary_.clear();
        VHandle v_start;
        for (size_t i = 0; i < paramedPatch_.vertices_.size(); ++i) {
            VHandle v = paramedPatch_.vertices_[i];
            for (VVIter w = vv_iter(v); w; ++w)
                if (!data(w).paramed_) {
                    v_start = v;
                    break;
                }
            if (v_start.is_valid())
                break;
        }
        VHandle v_prev, v_next = v_start;
        while (true) {
            paramedPatch_.vertices_boundary_.push_back(v_next);
            VHandle v_next_new;
            for (VOHIter h = voh_iter(v_next); h; ++h) {
                if (!data(face_handle(h)).paramed_)
                    continue;
                if (data(face_handle(opposite_halfedge_handle(h))).paramed_)
                    continue;
                v_next_new = to_vertex_handle(h);
                break;
            }
            assert(v_next_new.is_valid());
            v_prev = v_next;
            v_next = v_next_new;
            if (v_next == v_start)
                break;
        }
    }
    cout <<
        paramedPatch_.faces_   .size() << " faces, "    <<
        paramedPatch_.vertices_.size() << " vertices, " <<
        paramedPatch_.edges_   .size() << " edges\n";
    clkStart.setCurrentIndex(1);
    {   // build KdTree
        KdTree2d& kdTree = paramedPatch_.uv_kdTree_;
        kdTree.clear();
        for (size_t i = 0; i < paramedPatch_.vertices_.size(); ++i)
            kdTree.push_back(data(paramedPatch_.vertices_[i]).expmap_data_.uv_.convert<double>());
        kdTree.build();
    }
    }   clk.print();
}

void MeshTgt::fitUnitBox() {
    Vector3f bbmax(-FLT_MAX), bbmin(FLT_MAX), center;
    for (VIter v_it = vertices_begin(); v_it != vertices_end(); ++v_it) {
        Vector3f& p = point(v_it);
        bbmax = bbmax.pairwiseMax(p);
        bbmin = bbmin.pairwiseMin(p);
        center += p;
    }
    center /= (float)n_vertices();
    bbmax -= bbmin;
    float scale = 1.0f / bbmax.elemMax();
    for (VIter v_it = vertices_begin(); v_it != vertices_end(); ++v_it) {
        Vector3f& p = point(v_it);
        p -= center;
        p *= scale;
    }
}
MeshTgt::ExpMapInfo::ExpMapInfo()
: seed_horizon_(0.f, 1.f, 0.f)
, uv_scale_(2.5f)
{}
