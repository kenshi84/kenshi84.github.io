#include "StdAfx.h"
#include "Core.h"
#include "StatePaint.h"
#include "StateParamTgt.h"
#include "StateParamSrc.h"
#include <KLIB/TriangleUtil.h>
#include <KLIB/DrawUtil.h>
#include <stack>
using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
Drawer& drawer = core.drawer_;
MeshSrc& meshSrc = core.meshSrc_;
MeshTgt& meshTgt = core.meshTgt_;
StitchMesh& stitchMesh = core.stitchMesh_;
bool dbg_without_derivatives_    = false;
bool dbg_without_roi_correction_ = false;
bool dbg_test_membrane_          = false;
bool dbg_output_solution_        = false;
}

State* StatePaint::next() {
    drawer.dispList_meshSrc_all_faces_.requestUpdate();
    return StateParamTgt::getInstance();
}

string StatePaint::message() const {
    stringstream ss;
    ss << "Painting Mode";
    return ss.str();
}
void StatePaint::clear() {
    {   // clear off the paint buffer
        core.framebuffer_.bind();
        core.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, core.paramSpace_.buf_paint_.texture_);
        GLUtil::checkFramebufferStatus();
        
        glPushAttrib(GL_VIEWPORT_BIT | GL_COLOR_BUFFER_BIT);
        // viewport and camera setting
        glViewport(0, 0, Config::PARAMSPACE_REZ, Config::PARAMSPACE_REZ);
        Vector3f color = Drawer::ColorList::PAINT_NEGATIVE;
        glClearColor(color.x_, color.y_, color.z_, 0);
        glClear(GL_COLOR_BUFFER_BIT);
        glPopAttrib();
        core.framebuffer_.unbind();
        GLUtil::checkError();
        
        core.paramSpace_.buf_paint_.dump();
    }
    
    stitchMesh.clear();
    paintBoundaries_.clear();

    for (size_t i = 0; i < meshSrc.paramedPatch_.vertices_.size(); ++i) {
        MeshSrc::VertexData& vdata = meshSrc.data(meshSrc.paramedPatch_.vertices_[i]);
        vdata.paint_value_ = 0.0f;
        vdata.stitch_vid_ = -1;
    }
    for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
        MeshSrc::FaceData& fdata = meshSrc.data(meshSrc.paramedPatch_.faces_[i]);
        fdata.paint_in_ = false;
    }
    for (size_t i = 0; i < meshSrc.paramedPatch_.edges_.size(); ++i) {
        MeshSrc::EdgeData& edata = meshSrc.data(meshSrc.paramedPatch_.edges_[i]);
        edata.paintBoundary_crossed_ = false;
        edata.paintBoundary_visited_ = false;
        edata.paintBoundary_uv_  = Vector2f();
        edata.paintBoundary_xyz_ = Vector3f();
    }
    for (size_t i = 0; i < meshTgt.paramedPatch_.vertices_.size(); ++i) {
        MeshTgt::VertexData& vdata = meshTgt.data(meshTgt.paramedPatch_.vertices_[i]);
        vdata.paint_value_ = 0.0f;
        vdata.stitch_vid_ = -1;
    }
    for (size_t i = 0; i < meshTgt.paramedPatch_.faces_.size(); ++i) {
        MeshTgt::FaceData& fdata = meshTgt.data(meshTgt.paramedPatch_.faces_[i]);
        fdata.paint_out_ = false;
    }
    
    is_dirty_ = false;
}

void StatePaint::draw_left() {
    if (drawer.flags_[4]) {
        glPushAttrib(GL_LINE_BIT);
        glLineWidth(5);
        glColor3d(0, 1, 1);
        for (size_t i = 0; i < paintBoundaries_.size(); ++i) {
            glBegin(GL_LINE_LOOP);
            for (size_t j = 0; j < paintBoundaries_[i].size(); ++j)
                glVertex3f(paintBoundaries_[i].xyz_[j]);
            glEnd();
        }
        glPopAttrib();
    }
}

void StatePaint::draw_right() {
}

void StatePaint::initGL() {
    vcycle_.init();
    
    float spacing = 1.0f / static_cast<float>(Config::PARAMSPACE_REZ);
    shader_vcycle_input_.init();
    shader_vcycle_input_.attach(ShaderObject("shaders/vcycle_input.frag", ShaderObject::FRAGMENT_SHADER));
    shader_vcycle_input_.link();
    shader_vcycle_input_.enable();
    shader_vcycle_input_.setUniform1i("u_texture_src", 0);
    shader_vcycle_input_.setUniform1i("u_texture_tgt", 1);
    shader_vcycle_input_.setUniform1f("u_spacing", spacing);
    shader_vcycle_input_.disable();
    
    paint_temp_.init(GL_TEXTURE_2D, GL_CLAMP_TO_EDGE);
    vector<Vector3f> paint_temp_buf(Config::PARAMSPACE_REZ2, Drawer::ColorList::PAINT_NEGATIVE);
    paint_temp_.allocate(GL_RGB8, Config::PARAMSPACE_REZ, Config::PARAMSPACE_REZ, GL_RGB, GL_FLOAT, paint_temp_buf[0].ptr());
    
    clear();
}

void StatePaint::mouseLButtonDown(int x, int y, bool flagShift, bool flagCtrl) {
    dragMode_ = flagShift ? DRAGMODE_ERASE : DRAGMODE_PAINT;
    mouseMove(x, y);
}
void StatePaint::mouseLButtonUp(int x, int y) {
    dragMode_ = DRAGMODE_NONE;
}
void StatePaint::mouseMove(int x, int y, bool flagShift, bool flagCtrl) {
    Vector2f uv; {    // determine painted position
        int faceID;
        Vector3f baryCoord;
        core.drawer_.select(x, drawer.height_ - 1 - y, faceID, baryCoord);
        if (faceID < 0)
            return;
        if (faceID < meshSrc.n_faces()) {
            MeshSrc::FHandle f = meshSrc.face_handle(faceID);
            if (!meshSrc.data(f).paramed_)
                return;
            MeshSrc::FVIter v = meshSrc.fv_iter(f);
            for (int i = 0; i < 3; ++i, ++v)
                uv += baryCoord[i] * meshSrc.data(v).expmap_data_.uv_;
        } else {
            faceID -= meshSrc.n_faces();
            MeshTgt::FHandle f = meshTgt.face_handle(faceID);
            if (!meshTgt.data(f).paramed_)
                return;
            MeshTgt::FVIter v = meshTgt.fv_iter(f);
            for (int i = 0; i < 3; ++i, ++v)
                uv += baryCoord[i] * meshTgt.data(v).expmap_data_.uv_;
        }
    }
    draw_brush_is_dirty_ = true;
    draw_brush_uv_ = uv;
    if (dragMode_ != DRAGMODE_NONE) {
        step1_render_paint(uv);
        is_dirty_ = true;
    }
    
    redrawWindow();
}
void StatePaint::mouseWheel(int direction, int x, int y) {
    brushSize_ = max<float>(min<float>(brushSize_ + (direction == 1 ? 0.02f : -0.02f), 0.5f), 0.02f);
    mouseMove(x, y);
    redrawWindow();
}
void StatePaint::keyDown(char ascii) {
    switch (ascii) {
        case 8: // backspace
            core.gotoParamSrc();
            break;
        case 10:
        case 13:    // ENTER key
            core.bake_edit();
            break;
        case 'z':
        case 'Z':
            dbg_without_derivatives_ = !dbg_without_derivatives_;
            showMessage(dbg_without_derivatives_ ? "Without derivatives." : "With derivatives.");
            is_dirty_ = true;
            redrawWindow();
            break;
        case 'x':
        case 'X':
            dbg_without_roi_correction_ = !dbg_without_roi_correction_;
            showMessage(dbg_without_roi_correction_ ? "Without ROI correction." : "With ROI correction.");
            is_dirty_ = true;
            redrawWindow();
            break;
        case 'c':
        case 'C':
            dbg_test_membrane_ = !dbg_test_membrane_;
            showMessage(dbg_test_membrane_ ? "Membrane testing mode." : "Normal mode.");
            is_dirty_ = true;
            redrawWindow();
            break;
        case 'v':
        case 'V':
            dbg_output_solution_ = !dbg_output_solution_;
            showMessage(dbg_output_solution_ ? "Solution output enabled." : "Solution output disabled.");
            is_dirty_ = true;
            redrawWindow();
            break;
    }
}
void StatePaint::keyDown(SpecialKey key) {
    switch (key) {
    case KEY_UP:
    case KEY_DOWN:
        brushSize_ = max<float>(min<float>(brushSize_ + (key == KEY_UP ? 0.02f : -0.02f), 0.5f), 0.02f);
        draw_brush_is_dirty_ = true;
        redrawWindow();
        break;
    }
}
bool StatePaint::step1_render_paint(const Vector2f& uv) {
    ClkStart clkStart(&clk_, 0);
    core.framebuffer_.bind();
    core.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, core.paramSpace_.buf_paint_.texture_);
    GLUtil::checkFramebufferStatus();
    
    glPushAttrib(GL_VIEWPORT_BIT | GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT | GL_HINT_BIT);
    // viewport and camera setting
    glViewport(0, 0, Config::PARAMSPACE_REZ, Config::PARAMSPACE_REZ);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, 1, 0, 1);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    // point rendering options
    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);
    if (dragMode_ == DRAGMODE_PAINT)
        glColor3f(Drawer::ColorList::PAINT_POSITIVE);
    else
        glColor3f(Drawer::ColorList::PAINT_NEGATIVE);
    glPushMatrix();
    glTranslated(uv.x_, uv.y_, 0);
    DrawUtil::drawDisk(brushSize_);
    glPopMatrix();
    
    // cleanup
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glPopAttrib();
    core.framebuffer_.unbind();
    GLUtil::checkError();
    
    core.paramSpace_.buf_paint_.dump();
    return true;
}

bool StatePaint::step2_modify_paint() {
    ClkStart clkStart(&clk_, 1);
    // meshSrc.VertexT.paint_value
    for (size_t i = 0; i < meshSrc.paramedPatch_.vertices_.size(); ++i) {
        MeshSrc::VertexData& vdata = meshSrc.data(meshSrc.paramedPatch_.vertices_[i]);
        vdata.paint_value_ = core.paramSpace_.buf_paint_.getValue(vdata.expmap_data_.uv_).x_ - 0.5f;
    }
    for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i)
        meshSrc.data(meshSrc.paramedPatch_.faces_[i]).reversed_needRender_ = false;
    bool has_reversed_needRender = false;
    for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
        MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
        MeshSrc::FaceData& fdata = meshSrc.data(f);
        if (!fdata.reversed_)
            continue;
        bool has_positive = false;
        bool has_negative = false;
        for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v) {
            float paint_value = meshSrc.data(v).paint_value_;
            has_positive = has_positive || paint_value >  0.0f;
            has_negative = has_negative || paint_value <= 0.0f;
            if (has_positive && has_negative)
                break;
        }
        if (has_positive && has_negative) {
            has_reversed_needRender = true;
            stack<MeshSrc::FHandle> stack;
            stack.push(f);
            while (!stack.empty()) {
                MeshSrc::FHandle f1 = stack.top();
                stack.pop();
                if (meshSrc.data(f1).reversed_needRender_)
                    continue;
                meshSrc.data(f1).reversed_needRender_ = true;
                for (MeshSrc::FFIter f2 = meshSrc.ff_iter(f1); f2; ++f2)
                    if (meshSrc.data(f2).reversed_)
                        stack.push(f2);
            }
        }
    }
    if (has_reversed_needRender) {              // render the modified part
        core.framebuffer_.bind();
        core.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, core.paramSpace_.buf_paint_.texture_);
        GLUtil::checkFramebufferStatus();
        
        glPushAttrib(GL_VIEWPORT_BIT | GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT | GL_LINE_BIT);
        // viewport and camera setting
        glViewport(0, 0, Config::PARAMSPACE_REZ, Config::PARAMSPACE_REZ);
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        gluOrtho2D(0, 1, 0, 1);
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        // point rendering options
        glDisable(GL_LIGHTING);
        glDisable(GL_DEPTH_TEST);
        if (dragMode_ == DRAGMODE_PAINT)
            glColor3f(Drawer::ColorList::PAINT_POSITIVE);
        else
            glColor3f(Drawer::ColorList::PAINT_NEGATIVE);
        glBegin(GL_TRIANGLES);
        for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
            MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
            if (!meshSrc.data(f).reversed_needRender_)
                continue;
            for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v)
                glVertex2f(meshSrc.data(v).expmap_data_.uv_);
        }
        glEnd();
        glLineWidth(10);
        for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
            MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
            if (!meshSrc.data(f).reversed_needRender_)
                continue;
            glBegin(GL_LINE_LOOP);
            for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v)
                glVertex2f(meshSrc.data(v).expmap_data_.uv_);
            glEnd();
        }
        
        // cleanup
        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
        glPopAttrib();
        core.framebuffer_.unbind();
        GLUtil::checkError();
        
        core.paramSpace_.buf_paint_.dump();
    }
    return true;
}
bool StatePaint::step3_extract_paintBoundary() {
    ClkStart clkStart(&clk_, 2);
    // meshSrc.VertexT.paint_value
    for (size_t i = 0; i < meshSrc.paramedPatch_.vertices_.size(); ++i) {
        MeshSrc::VertexData& vdata = meshSrc.data(meshSrc.paramedPatch_.vertices_[i]);
        vdata.paint_value_ = core.paramSpace_.buf_paint_.getValue(vdata.expmap_data_.uv_).x_ - 0.5f;
    }
    // force the paint_value at the boundary to be -1
    for (size_t i = 0; i < meshSrc.paramedPatch_.vertices_boundary_.size(); ++i) {
        MeshSrc::VertexData& vdata = meshSrc.data(meshSrc.paramedPatch_.vertices_boundary_[i]);
        vdata.paint_value_ = -1.0f;
    }
    // meshSrc.EdgeT.paint_value
    for (size_t i = 0; i < meshSrc.paramedPatch_.edges_.size(); ++i) {
        MeshSrc::EHandle e = meshSrc.paramedPatch_.edges_[i];
        MeshSrc::EdgeData& edata = meshSrc.data(e);
        Vector2f uv0 = meshSrc.data(meshSrc.to_vertex_handle(meshSrc.halfedge_handle(e, 0))).expmap_data_.uv_;
        Vector2f uv1 = meshSrc.data(meshSrc.to_vertex_handle(meshSrc.halfedge_handle(e, 1))).expmap_data_.uv_;
        for (int s = 1; s <= Config::PAINT_INOUT_SUBDIV - 1; ++s) {
            float ws = static_cast<float>(s) / static_cast<float>(Config::PAINT_INOUT_SUBDIV);
            Vector2f uv = ws * uv0 + (1 - ws) * uv1;
            edata.paint_value_[s - 1] = core.paramSpace_.buf_paint_.getValue(uv).x_ - 0.5f;
        }
    }
    // meshSrc.FaceT.paint_value
    for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
        MeshSrc::FHandle f = meshSrc.paramedPatch_.faces_[i];
        MeshSrc::FaceData& fdata = meshSrc.data(f);
        MeshSrc::FVIter v = meshSrc.fv_iter(f);
        Vector2f uv0 = meshSrc.data(v).expmap_data_.uv_;    ++v;
        Vector2f uv1 = meshSrc.data(v).expmap_data_.uv_;    ++v;
        Vector2f uv2 = meshSrc.data(v).expmap_data_.uv_;    ++v;
        int index = 0;
        for (int s = 1; s <= Config::PAINT_INOUT_SUBDIV - 1; ++s) {
            float ws = static_cast<float>(s) / static_cast<float>(Config::PAINT_INOUT_SUBDIV);
            for (int t = 1; t <= Config::PAINT_INOUT_SUBDIV - 1 - s; ++t, ++index) {
                float wt = static_cast<float>(t) / static_cast<float>(Config::PAINT_INOUT_SUBDIV);
                Vector2f uv = ws * uv0 + wt * uv1 + (1.0f - ws - wt) * uv2;
                fdata.paint_value_[index] = core.paramSpace_.buf_paint_.getValue(uv).x_ - 0.5f;
            }
        }
    }
    // meshSrc.FaceT.paint_in
    for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
        MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
        MeshSrc::FaceData& fdata = meshSrc.data(f);
        bool& paint_in = fdata.paint_in_;
        paint_in = true;
        int k = 0;
        for (MeshSrc::FHIter h = meshSrc.fh_iter(f); h; ++h, ++k) {
            MeshSrc::VHandle v = meshSrc.to_vertex_handle(h);
            paint_in = paint_in && meshSrc.data(v).paint_value_ > 0.0f;
            if (!paint_in)
                break;
            MeshSrc::EHandle e = meshSrc.edge_handle(h);
            for (int j = 0; j < Config::PAINT_INOUT_SUBDIV - 1; ++j) {
                paint_in = paint_in && meshSrc.data(e).paint_value_[j] > 0.0f;
                if (!paint_in)
                    break;
            }
            if (!paint_in)
                break;
        }
        if (!paint_in)
            continue;
        for (int j = 0; j < (Config::PAINT_INOUT_SUBDIV - 1) * (Config::PAINT_INOUT_SUBDIV - 2) / 2; ++j) {
            paint_in = paint_in && fdata.paint_value_[j] > 0.0f;
            if (!paint_in)
                break;
        }
    }
    // meshTgt.VertexT.paint_value
    for (size_t i = 0; i < meshTgt.paramedPatch_.vertices_.size(); ++i) {
        MeshTgt::VertexData& vdata = meshTgt.data(meshTgt.paramedPatch_.vertices_[i]);
        vdata.paint_value_ = core.paramSpace_.buf_paint_.getValue(vdata.expmap_data_.uv_).x_ - 0.5f;
    }
    // force the paint_value at the boundary to be -1
    for (size_t i = 0; i < meshTgt.paramedPatch_.vertices_boundary_.size(); ++i) {
        MeshTgt::VertexData& vdata = meshTgt.data(meshTgt.paramedPatch_.vertices_boundary_[i]);
        vdata.paint_value_ = -1.0f;
    }
    // meshTgt.EdgeT.paint_value
    for (size_t i = 0; i < meshTgt.paramedPatch_.edges_.size(); ++i) {
        MeshTgt::EHandle e = meshTgt.paramedPatch_.edges_[i];
        MeshTgt::EdgeData& edata = meshTgt.data(e);
        Vector2f uv0 = meshTgt.data(meshTgt.to_vertex_handle(meshTgt.halfedge_handle(e, 0))).expmap_data_.uv_;
        Vector2f uv1 = meshTgt.data(meshTgt.to_vertex_handle(meshTgt.halfedge_handle(e, 1))).expmap_data_.uv_;
        for (int s = 1; s <= Config::PAINT_INOUT_SUBDIV - 1; ++s) {
            float ws = static_cast<float>(s) / static_cast<float>(Config::PAINT_INOUT_SUBDIV);
            Vector2f uv = ws * uv0 + (1 - ws) * uv1;
            edata.paint_value_[s] = core.paramSpace_.buf_paint_.getValue(uv).x_ - 0.5f;
        }
    }
    // meshTgt.FaceT.paint_value
    for (size_t i = 0; i < meshTgt.paramedPatch_.faces_.size(); ++i) {
        MeshTgt::FHandle f = meshTgt.paramedPatch_.faces_[i];
        MeshTgt::FaceData& fdata = meshTgt.data(f);
        MeshTgt::FVIter v = meshTgt.fv_iter(f);
        Vector2f uv0 = meshTgt.data(v).expmap_data_.uv_;    ++v;
        Vector2f uv1 = meshTgt.data(v).expmap_data_.uv_;    ++v;
        Vector2f uv2 = meshTgt.data(v).expmap_data_.uv_;    ++v;
        int index = 0;
        for (int s = 1; s <= Config::PAINT_INOUT_SUBDIV - 1; ++s) {
            float ws = static_cast<float>(s) / static_cast<float>(Config::PAINT_INOUT_SUBDIV);
            for (int t = 1; t <= Config::PAINT_INOUT_SUBDIV - 1 - s; ++t, ++index) {
                float wt = static_cast<float>(t) / static_cast<float>(Config::PAINT_INOUT_SUBDIV);
                Vector2f uv = ws * uv0 + wt * uv1 + (1.0f - ws - wt) * uv2;
                fdata.paint_value_[index] = core.paramSpace_.buf_paint_.getValue(uv).x_ - 0.5f;
            }
        }
    }
    // meshTgt.FaceT.paint_out
    for (size_t i = 0; i < meshTgt.paramedPatch_.faces_.size(); ++i) {
        MeshTgt::FHandle& f = meshTgt.paramedPatch_.faces_[i];
        bool& paint_out = meshTgt.data(f).paint_out_;
        paint_out = true;
        for (MeshTgt::FHIter h = meshTgt.fh_iter(f); h; ++h) {
            MeshTgt::VHandle v = meshTgt.to_vertex_handle(h);
            paint_out = paint_out && meshTgt.data(v).paint_value_ <= 0.0f;
            if (!paint_out)
                break;
            MeshTgt::EHandle e = meshTgt.edge_handle(h);
            for (int j = 0; j < Config::PAINT_INOUT_SUBDIV - 1; ++j) {
                paint_out = paint_out && meshTgt.data(e).paint_value_[j] <= 0.0f;
                if (!paint_out)
                    break;
            }
            if (!paint_out)
                break;
        }
        if (!paint_out)
            continue;
        for (int j = 0; j < (Config::PAINT_INOUT_SUBDIV - 1) * (Config::PAINT_INOUT_SUBDIV - 2) / 2; ++j) {
            paint_out = paint_out && meshTgt.data(f).paint_value_[j] <= 0.0f;
            if (!paint_out)
                break;
        }
    }
    // meshSrc.EdgeT.{paintBoundary_crossed, paintBoundary_visited, paintBoundary_uv, paintBoundary_xyz}
    stack<MeshSrc::EHandle> stack;
    for (size_t i = 0; i < meshSrc.paramedPatch_.edges_.size(); ++i) {
        MeshSrc::EHandle& e = meshSrc.paramedPatch_.edges_[i];
        MeshSrc::EdgeData& e_data = meshSrc.data(e);
        e_data.paintBoundary_visited_ = false;
        
        float    endpoint_value[2];
        Vector2f endpoint_uv[2];
        Vector3f endpoint_xyz[2];
        for (int j = 0; j < 2; ++j) {
            MeshSrc::VHandle v = meshSrc.to_vertex_handle(meshSrc.halfedge_handle(e, j));
            MeshSrc::VertexData& v_data = meshSrc.data(v);
            assert(v_data.paramed_);
            endpoint_uv   [j] = v_data.expmap_data_.uv_;
            endpoint_value[j] = v_data.paint_value_;
            endpoint_xyz  [j] = meshSrc.point(v);
        }
        e_data.paintBoundary_crossed_ = endpoint_value[0] * endpoint_value[1] <= 0.0f;
        if (!e_data.paintBoundary_crossed_)
            continue;
        e_data.paintBoundary_uv_  = endpoint_value[1] * endpoint_uv [0] - endpoint_value[0] * endpoint_uv [1];
        e_data.paintBoundary_xyz_ = endpoint_value[1] * endpoint_xyz[0] - endpoint_value[0] * endpoint_xyz[1];
        e_data.paintBoundary_uv_  /= (endpoint_value[1] - endpoint_value[0]);
        e_data.paintBoundary_xyz_ /= (endpoint_value[1] - endpoint_value[0]);
        stack.push(e);
    }
    // trace boundary polygon by marching triangles
    paintBoundaries_.clear();
    while (!stack.empty()) {
        MeshSrc::EHandle e = stack.top();
        stack.pop();
        if (meshSrc.data(e).paintBoundary_visited_)
            continue;
        MeshSrc::HHandle h_start = meshSrc.halfedge_handle(e, 0);
        paintBoundaries_.push_back(PaintBoundary());
        PaintBoundary& boundary = paintBoundaries_.back();
        for (MeshSrc::HHandle h = h_start; ;) {
            MeshSrc::EdgeData& e_data = meshSrc.data(meshSrc.edge_handle(h));
            assert (e_data.paintBoundary_crossed_);
            e_data.paintBoundary_visited_ = true;
            
            // add point
            boundary.uv_ .push_back(e_data.paintBoundary_uv_);
            boundary.xyz_.push_back(e_data.paintBoundary_xyz_);
            
            // next halfedge
            while (true) {
                h = meshSrc.next_halfedge_handle(h);
                if (meshSrc.data(meshSrc.edge_handle(h)).paintBoundary_crossed_)
                    break;
            }
            h = meshSrc.opposite_halfedge_handle(h);
            if (h == h_start)
                break;
        }
        boundary.uv_.setLoop(true);
        boundary.uv_.resample();
        boundary.xyz_.setLoop(true);
        boundary.xyz_.resample();
    }
    return true;
}
bool StatePaint::step4_compute_offset() {
    ClkStart clkStart(&clk_, 3);
    //ClkData clk2("compute_offset");
    //clk2.addEntry("gpu_pre");
    //clk2.addEntry("gpu_solve");
    //clk2.addEntry("cpu_post");
    //ClkStart clk2Start(&clk2);
    
    int rez = Config::PARAMSPACE_REZ;
    float spacing = 1.0f / static_cast<float>(rez);
    
    // bind fbo
    vcycle_.framebuffer_.bind();
    glDrawBuffer(GL_COLOR_ATTACHMENT0_EXT);
    
    // set input constraints for GPU solver ========================================================
    
    // setup (common to f, gu, gv) |
    //-----------------------------+
    glPushAttrib(GL_VIEWPORT_BIT | GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT | GL_LINE_BIT);
    glClearColor(0, 0, 0, 0);
    glDisable(GL_LIGHTING);
    glDisable(GL_BLEND);
    glLineWidth(1);
    // store camera matrix
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    // input texture, shader
    glActiveTextureARB(GL_TEXTURE1);    core.paramSpace_.buf_tgt_.texture_.bind();
    glActiveTextureARB(GL_TEXTURE0);    core.paramSpace_.buf_src_.texture_.bind();
    shader_vcycle_input_.enable();
    shader_vcycle_input_.setUniform1i("u_dbg_test_membrane", dbg_test_membrane_ ? 1 : 0);
    
    // input for f |
    //-------------+
    shader_vcycle_input_.setUniform1i("u_mode", 0);
    vcycle_.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, vcycle_.levels_[0].f_in().texture_);    // set render target
    GLUtil::checkFramebufferStatus();
    
    glViewport(0, 0, rez, rez);    // viewport and camera setting
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, 1, 0, 1);
    glMatrixMode(GL_MODELVIEW);
    
    glClear(GL_COLOR_BUFFER_BIT);    // clear
    
    // render constraints at paintBoundary
    for (vector<PaintBoundary>::iterator it = paintBoundaries_.begin(); it != paintBoundaries_.end(); ++it) {
        glBegin(GL_LINE_LOOP);
        for (size_t i = 0; i < it->size(); ++i) {
            Vector2f& uv = it->uv_[i];
            glTexCoord2f(uv);
            glVertex2f(uv);
        }
        glEnd();
    }
    
    // input for gu |
    //--------------+
    shader_vcycle_input_.setUniform1i("u_mode", 1);
    vcycle_.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, vcycle_.levels_[0].gu_in().texture_);    // set render target
    GLUtil::checkFramebufferStatus();
    
    glViewport(0, 0, rez - 1, rez);    // viewport and camera setting
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, 1 - spacing, 0, 1);
    glMatrixMode(GL_MODELVIEW);
    
    glClear(GL_COLOR_BUFFER_BIT);    // clear
    
    // render constraints at paintBoundary
    for (vector<PaintBoundary>::iterator it = paintBoundaries_.begin(); it != paintBoundaries_.end(); ++it) {
        glBegin(GL_LINE_LOOP);
        for (size_t i = 0; i < it->size(); ++i) {
            Vector2f uv = it->uv_[i];
            size_t next_i = (i + 1) % it->size();
            Vector2f d = it->uv_[next_i] - uv;
            d.normalize();
            if (0.70711 < d.y_)     // going upward
                uv.x_ -= spacing;   // displace target location to one pixel left
            glTexCoord2f(uv);
            glVertex2f(uv);
        }
        glEnd();
    }
    
    // input for gv |
    //--------------+
    shader_vcycle_input_.setUniform1i("u_mode", 2);
    vcycle_.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, vcycle_.levels_[0].gv_in().texture_);    // set render target
    GLUtil::checkFramebufferStatus();
    
    glViewport(0, 0, rez, rez - 1);    // viewport and camera setting
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, 1, 0, 1 - spacing);
    glMatrixMode(GL_MODELVIEW);
    
    glClear(GL_COLOR_BUFFER_BIT);    // clear
    
    // render constraints at paintBoundary
    for (vector<PaintBoundary>::iterator it = paintBoundaries_.begin(); it != paintBoundaries_.end(); ++it) {
        glBegin(GL_LINE_LOOP);
        for (size_t i = 0; i < it->size(); ++i) {
            Vector2f uv = it->uv_[i];
            size_t next_i = (i + 1) % it->size();
            Vector2f d = it->uv_[next_i] - uv;
            d.normalize();
            if (d.x_ < -0.70711)        // going leftward
                uv.y_ -= spacing;       // displace target location to one pixel down
            glTexCoord2f(uv);
            glVertex2f(uv);
        }
        glEnd();
    }
    
    // cleanup (common to f, gu, gv) |
    //-------------------------------+
    shader_vcycle_input_.disable();
    glActiveTextureARB(GL_TEXTURE1);    core.paramSpace_.buf_tgt_.texture_.unbind();
    glActiveTextureARB(GL_TEXTURE0);    core.paramSpace_.buf_src_.texture_.unbind();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glPopAttrib();
    
    //clk2Start.setCurrentIndex(1);
    // launch GPU solver =================================
    vcycle_.shader_smooth_f_.enable();
    vcycle_.shader_smooth_f_.setUniform1i("dbg_without_derivatives", dbg_without_derivatives_ ? 1 : 0);
    vcycle_.shader_smooth_f_.disable();
    vcycle_.update();
    
    vcycle_.framebuffer_.unbind();
    
    // sample membrane for each Src vertex
    TextureBuffer4f& buf_f = vcycle_.levels_[0].f_in();
    TextureBuffer4f& buf_gu = vcycle_.levels_[0].gu_in();
    TextureBuffer4f& buf_gv = vcycle_.levels_[0].gv_in();
    buf_f.dump();
    buf_gu.dump();
    buf_gv.dump();
    
    // text output for CPU validation
    //clk2Start.setCurrentIndex(2);
    if (dbg_output_solution_) {
        int N = Config::PARAMSPACE_REZ;
        ofstream ofs_f("gpu_f.txt");
        for (int j = 0; j < N; ++j) {
            for (int i = 0; i < N; ++i) {
                Vector4f& f = buf_f.cpuData_[N * j + i];
                ofs_f << f.x_ << " ";
                if (f.w_ == 1.0f)
                    ofs_f << f.x_ << endl;
                else
                    ofs_f << 0 << endl;
            }
            ofs_f << endl;
        }
        ofstream ofs_gu("gpu_gu.txt");
        for (int j = 0; j < N; ++j) {
            for (int i = 0; i < N - 1; ++i) {
                Vector4f& gu = buf_gu.cpuData_[(N - 1) * j + i];
                ofs_gu << gu.x_ << " ";
                if (gu.w_ == 1.0f)
                    ofs_gu << gu.x_ << endl;
                else
                    ofs_gu << 0 << endl;
            }
            ofs_gu << endl;
        }
        ofstream ofs_gv("gpu_gv.txt");
        for (int j = 0; j < N - 1; ++j) {
            for (int i = 0; i < N; ++i) {
                Vector4f& gv = buf_gv.cpuData_[N * j + i];
                ofs_gv << gv.x_ << " ";
                if (gv.w_ == 1.0f)
                    ofs_gv << gv.x_ << endl;
                else
                    ofs_gv << 0 << endl;
            }
            ofs_gv << endl;
        }
    }
    
    for (size_t i = 0; i < meshSrc.paramedPatch_.vertices_.size(); ++i) {
        MeshSrc::VertexData& v_data = meshSrc.data(meshSrc.paramedPatch_.vertices_[i]);
        if (v_data.paint_value_ < 0)
            continue;
        Vector4f f = buf_f.getValue(v_data.expmap_data_.uv_, false, true);
        v_data.result_position_ = f.xyz() + (dbg_test_membrane_ ? Vector3f() : v_data.gc_data_.deformed_position_);
    }
    
    // compute normals
    for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
        MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
        MeshSrc::FaceData& f_data = meshSrc.data(f);
        if (!f_data.paint_in_)
            continue;
        Vector3f f_points[3];
        MeshSrc::FVIter v = meshSrc.fv_iter(f);
        for (int i = 0; i < 3; ++i, ++v)
            f_points[i] = meshSrc.data(v).result_position_;
        f_data.result_normal_ = Util::calcNormal(f_points[0], f_points[1], f_points[2]);
    }
    for (size_t i = 0; i < meshSrc.paramedPatch_.vertices_.size(); ++i) {
        MeshSrc::VHandle& v = meshSrc.paramedPatch_.vertices_[i];
        MeshSrc::VertexData& v_data = meshSrc.data(v);
        if (v_data.paint_value_ < 0)
            continue;
        Vector3f normal;
        for (MeshSrc::VFIter f = meshSrc.vf_iter(v); f; ++f)
            normal += meshSrc.data(f).result_normal_;
        normal.normalize();
        v_data.result_normal_ = normal;
    }
    //clk2.print();
    return true;
}
bool StatePaint::step5_stitch() {
    stitchMesh.clear();
    
    ClkStart clkStart(&clk_, 4);
    // clear {meshSrc, meshTgt}.VertexT.stitch_vid
    for (size_t i = 0; i < meshSrc.paramedPatch_.vertices_.size(); ++i)
        meshSrc.data(meshSrc.paramedPatch_.vertices_[i]).stitch_vid_ = -1;
    for (size_t i = 0; i < meshTgt.paramedPatch_.vertices_.size(); ++i)
        meshTgt.data(meshTgt.paramedPatch_.vertices_[i]).stitch_vid_ = -1;
    bool paint_in_exist = false;
    for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
        MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
        paint_in_exist = paint_in_exist || meshSrc.data(f).paint_in_;
        if (paint_in_exist)
            break;
    }
    if (!paint_in_exist)
        return true;
    
    //--------------------------------+
    // prepare input data to Triangle |
    //--------------------------------+
    vector<MeshSrc::VHandle> map_stitch2src;
    vector<MeshTgt::VHandle> map_stitch2tgt;
    vector<double> in_pointlist;
    vector<int   > in_segmentlist;
    vector<double> in_holelist;
    // source
    for (size_t i = 0; i < meshSrc.paramedPatch_.edges_.size(); ++i) {
        MeshSrc::EHandle& e = meshSrc.paramedPatch_.edges_[i];
        MeshSrc::FHandle f;
        MeshSrc::FHandle f0 = meshSrc.face_handle(meshSrc.halfedge_handle(e, 0));
        MeshSrc::FHandle f1 = meshSrc.face_handle(meshSrc.halfedge_handle(e, 1));
        MeshSrc::FaceData& f0data = meshSrc.data(f0);
        MeshSrc::FaceData& f1data = meshSrc.data(f1);
        if (f0data.paint_in_ && !f1data.paint_in_)
            f = f0;
        else if (!f0data.paint_in_ && f1data.paint_in_)
            f = f1;
        if (!f.is_valid())
            continue;
        // check if this face is too slanted
        Vector3f normal = meshSrc.normal(f);
        float dp = 0.0f;
        for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v)
            dp += (meshSrc.data(v).expmap_normal_ | normal);
        dp /= 3.0f;
        if (0.1f < dp) {// not too slanted
            Vector2f hole;
            for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v)
                hole += meshSrc.data(v).expmap_data_.uv_;
            hole /= 3.0f;
            in_holelist.push_back(static_cast<double>(hole.x_));
            in_holelist.push_back(static_cast<double>(hole.y_));
        }
        for (int j = 0; j < 2; ++j) {
            MeshSrc::VHandle v = meshSrc.to_vertex_handle(meshSrc.halfedge_handle(e, j));
            int& stitch_vid = meshSrc.data(v).stitch_vid_;
            if (stitch_vid == -1) {
                stitch_vid = static_cast<int>(in_pointlist.size()) / 2;
                Vector2f& uv = meshSrc.data(v).expmap_data_.uv_;
                in_pointlist.push_back(static_cast<double>(uv.x_));
                in_pointlist.push_back(static_cast<double>(uv.y_));
                map_stitch2src.push_back(v);
            }
            in_segmentlist.push_back(stitch_vid);
        }
    }
    int nv_src = static_cast<int>(in_pointlist.size()) / 2;
    
    // destination
    int cnt = 0;
    for (size_t i = 0; i < meshTgt.paramedPatch_.edges_.size(); ++i) {
        MeshTgt::EHandle& e = meshTgt.paramedPatch_.edges_[i];
        MeshTgt::FHandle f0 = meshTgt.face_handle(meshTgt.halfedge_handle(e, 0));
        MeshTgt::FHandle f1 = meshTgt.face_handle(meshTgt.halfedge_handle(e, 1));
        MeshTgt::FaceData& f0data = meshTgt.data(f0);
        MeshTgt::FaceData& f1data = meshTgt.data(f1);
        bool isBoundary =
            !f0data.paramed_ ? !f1data.paint_out_ :
            !f1data.paramed_ ? !f0data.paint_out_ :
            (f0data.paint_out_ && !f1data.paint_out_ || !f0data.paint_out_ && f1data.paint_out_);
        if (!isBoundary)
            continue;
        for (int j = 0; j < 2; ++j) {
            MeshTgt::VHandle v = meshTgt.to_vertex_handle(meshTgt.halfedge_handle(e, j));
            int& stitch_vid = meshTgt.data(v).stitch_vid_;
            if (stitch_vid == -1) {
                stitch_vid = static_cast<int>(in_pointlist.size()) / 2;
                Vector2f& uv = meshTgt.data(v).expmap_data_.uv_;
                in_pointlist.push_back(static_cast<double>(uv.x_));
                in_pointlist.push_back(static_cast<double>(uv.y_));
                map_stitch2tgt.push_back(v);
            }
            in_segmentlist.push_back(stitch_vid);
        }
    }
    int nv_tgt = static_cast<int>(in_pointlist.size()) / 2 - nv_src;
    //int tgt_in_point = in_pointlist.size() - src_in_point;
    //int tgt_in_segment = in_segmentlist.size() - src_in_segment;
    //cout << "tgt_in_point: " << tgt_in_point << endl;
    //cout << "tgt_in_segment: " << tgt_in_point << endl;
    //assert(in_pointlist.size() == in_segmentlist.size());
    
    //---------------+
    // call Triangle |
    //---------------+
    vector<double> out_pointlist;
    vector<int   > out_trianglelist;
    //TriangleUtil::save_poly(in_pointlist, in_segmentlist, in_holelist, "debug.poly");
    TriangleUtil::ConformingConstrainedDelaunay(out_pointlist, out_trianglelist, in_pointlist, in_segmentlist, in_holelist, "zpq30YQ");
    
    //--------------------------+
    // convert to OpenMesh data |
    //--------------------------+
    for (size_t i = 0; i < out_pointlist.size(); i += 2) {
        int vid = i / 2;
        if (vid < nv_src + nv_tgt) {
            if (vid < nv_src) {
                MeshSrc::VHandle vhandle = map_stitch2src[vid];
                StitchMesh::VHandle stitch_vhandle = stitchMesh.add_vertex(meshSrc.data(vhandle).result_position_);
                stitchMesh.data(stitch_vhandle).vhandle_src_ = vhandle;
                stitchMesh.data(stitch_vhandle).uv_ = meshSrc.data(vhandle).expmap_data_.uv_;
                meshSrc.data(vhandle).stitch_vid_ = vid;
            } else {
                MeshTgt::VHandle vhandle = map_stitch2tgt[vid - nv_src];
                StitchMesh::VHandle stitch_vhandle = stitchMesh.add_vertex(meshTgt.point(vhandle));
                stitchMesh.data(stitch_vhandle).vhandle_tgt_ = vhandle;
                stitchMesh.data(stitch_vhandle).uv_ = meshTgt.data(vhandle).expmap_data_.uv_;
                meshTgt.data(vhandle).stitch_vid_ = vid;
            }
        } else {
            Vector2d uv_d(&out_pointlist[i]);
            Vector2f uv = uv_d.convert<float>();
            Vector3f xyz;
            float paint_value = core.paramSpace_.buf_paint_.getValue(uv).x_;
            Vector4f src_value;
            if (0.5f < paint_value)
                src_value = core.paramSpace_.buf_src_.getValue(uv, false, true);
            if (paint_value <= 0.5f || src_value.w_ < 1.0f)
                xyz = core.paramSpace_.buf_tgt_.getValue(uv, false, true);
            else {
                Vector4f f = vcycle_.levels_[0].f_in().getValue(uv, false, true);
                xyz = f.xyz() + (dbg_test_membrane_ ? Vector3f() : src_value.xyz());
            }
            StitchMesh::VHandle stitch_vhandle = stitchMesh.add_vertex(xyz);
            stitchMesh.data(stitch_vhandle).uv_ = uv;
        }
    }
    vector<StitchMesh::VHandle> face_vhandles(3);
    for (size_t i = 0; i < out_trianglelist.size(); i += 3) {
        for (int j = 0; j < 3; ++j)
            face_vhandles[j] = stitchMesh.vertex_handle(out_trianglelist[i + j]);
        stitchMesh.add_face(face_vhandles);
    }
    // post-process smoothing (including vertices adjacent to MeshSrc & MeshTgt)
    for (int k = 0; k < Config::POST_SMOOTHING_ITER; ++k) {
        StitchMesh stitchMesh2 = stitchMesh;
        StitchMesh::VIter v  = stitchMesh .vertices_begin();
        StitchMesh::VIter v2 = stitchMesh2.vertices_begin();
        for (; v != stitchMesh.vertices_end(); ++v, ++v2) {
            StitchMesh::VertexData& vdata = stitchMesh.data(v);
            Vector3f cog;
            float valance = 0.0f;
            for (StitchMesh::VVIter w2 = stitchMesh2.vv_iter(v2); w2; ++w2) {
                StitchMesh::VertexData& w2data = stitchMesh2.data(w2);
                if (vdata.vhandle_src_.is_valid() && w2data.vhandle_src_.is_valid())
                    continue;
                if (vdata.vhandle_tgt_.is_valid() && w2data.vhandle_tgt_.is_valid())
                    continue;
                cog += stitchMesh2.point(w2);
                ++valance;
            }
            if (vdata.vhandle_src_.is_valid()) {
                MeshSrc::VHandle v_src = vdata.vhandle_src_;
                for (MeshSrc::VVIter w_src = meshSrc.vv_iter(v_src); w_src; ++w_src) {
                    if (meshSrc.data(w_src).paint_value_ < 0)
                        continue;
                    cog += meshSrc.data(w_src).result_position_;
                    ++valance;
                }
            } else if (vdata.vhandle_tgt_.is_valid()) {
                MeshTgt::VHandle v_tgt = vdata.vhandle_tgt_;
                for (MeshTgt::VVIter w_tgt = meshTgt.vv_iter(v_tgt); w_tgt; ++w_tgt) {
                    if (meshTgt.data(w_tgt).paint_value_ > 0)
                        continue;
                    cog += meshTgt.point(w_tgt);
                    ++valance;
                }
            }
            cog /= valance;
            stitchMesh.point(v) = cog;
        }
    }
    // compute normals
    stitchMesh.request_face_normals();
    stitchMesh.request_vertex_normals();
    stitchMesh.update_normals();
    for (StitchMesh::VIter v = stitchMesh.vertices_begin(); v != stitchMesh.vertices_end(); ++v) {
        StitchMesh::VertexData& vdata = stitchMesh.data(v);
        if (vdata.vhandle_src_.is_valid() || vdata.vhandle_tgt_.is_valid()) {
            Vector3f normal;
            for (StitchMesh::VFIter f = stitchMesh.vf_iter(v); f; ++f)
                normal += stitchMesh.normal(f);
            if (vdata.vhandle_src_.is_valid()) {
                for (MeshSrc::VFIter src_f = meshSrc.vf_iter(vdata.vhandle_src_); src_f; ++src_f) {
                    MeshSrc::FaceData& src_fdata = meshSrc.data(src_f);
                    if (!src_fdata.paint_in_)
                        continue;
                    normal += src_fdata.result_normal_;
                }
            } else if (vdata.vhandle_tgt_.is_valid()) {
                for (MeshTgt::VFIter tgt_f = meshTgt.vf_iter(vdata.vhandle_tgt_); tgt_f; ++tgt_f) {
                    if (!meshTgt.data(tgt_f).paint_out_)
                        continue;
                    normal += meshTgt.normal(tgt_f);
                }
            }
            normal.normalize();
            stitchMesh.set_normal(v, normal);
        }
    }
    // modify result_normal of MeshSrc that are two-ring adjacent to StitchMesh
    for (vector<MeshSrc::VHandle>::iterator v = meshSrc.paramedPatch_.vertices_.begin(); v != meshSrc.paramedPatch_.vertices_.end(); ++v)
        meshSrc.data(*v).result_normal_ = Vector3f();
    for (vector<MeshSrc::FHandle>::iterator f = meshSrc.paramedPatch_.faces_.begin(); f != meshSrc.paramedPatch_.faces_.end(); ++f) {
        Vector3f f_points[3];
        Vector3f* f_normals[3] = {0, 0, 0};
        bool isModified = false;
        MeshSrc::FVIter v = meshSrc.fv_iter(*f);
        for (int i = 0; i < 3; ++i, ++v) {
            if (meshSrc.data(v).stitch_vid_ != -1) {
                f_points[i] = stitchMesh.point(stitchMesh.vertex_handle(meshSrc.data(v).stitch_vid_));
                isModified = true;
            } else {
                f_points[i] = meshSrc.data(v).result_position_;
                f_normals[i] = &meshSrc.data(v).result_normal_;
            }
        }
        Vector3f n = isModified ? Util::calcNormal(f_points[0], f_points[1], f_points[2]) : meshSrc.data(*f).result_normal_;
        for (int i = 0; i < 3; ++i)
            if (f_normals[i])
                *f_normals[i] += n;
    }
    for (vector<MeshSrc::VHandle>::iterator v = meshSrc.paramedPatch_.vertices_.begin(); v != meshSrc.paramedPatch_.vertices_.end(); ++v)
        meshSrc.data(*v).result_normal_.normalize();
    // modify result_normal of MeshTgt that are two-ring adjacent to StitchMesh
    for (vector<MeshTgt::VHandle>::iterator v = meshTgt.paramedPatch_.vertices_.begin(); v != meshTgt.paramedPatch_.vertices_.end(); ++v)
        meshTgt.data(*v).result_normal_ = Vector3f();
    for (vector<MeshTgt::FHandle>::iterator f = meshTgt.paramedPatch_.faces_.begin(); f != meshTgt.paramedPatch_.faces_.end(); ++f) {
        Vector3f f_points[3];
        Vector3f* f_normals[3] = {0, 0, 0};
        bool isModified = false;
        MeshTgt::FVIter v = meshTgt.fv_iter(*f);
        for (int i = 0; i < 3; ++i, ++v) {
            if (meshTgt.data(v).stitch_vid_ != -1) {
                f_points[i] = stitchMesh.point(stitchMesh.vertex_handle(meshTgt.data(v).stitch_vid_));
                isModified = true;
            } else {
                f_points[i] = meshTgt.point(v);
                f_normals[i] = &meshTgt.data(v).result_normal_;
            }
        }
        Vector3f n = isModified ? Util::calcNormal(f_points[0], f_points[1], f_points[2]) : meshTgt.normal(*f);
        for (int i = 0; i < 3; ++i)
            if (f_normals[i])
                *f_normals[i] += n;
    }
    for (vector<MeshTgt::VHandle>::iterator v = meshTgt.paramedPatch_.vertices_.begin(); v != meshTgt.paramedPatch_.vertices_.end(); ++v)
        meshTgt.data(*v).result_normal_.normalize();
    
    return true;
}

void StatePaint::draw_brush() {
    copy_paint_temp();
    
    // paint current brush to paint_temp
    core.framebuffer_.bind();
    core.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, paint_temp_);
    GLUtil::checkFramebufferStatus();
    
    glPushAttrib(GL_VIEWPORT_BIT | GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT | GL_LINE_BIT | GL_HINT_BIT );
    // viewport and camera setting
    glViewport(0, 0, Config::PARAMSPACE_REZ, Config::PARAMSPACE_REZ);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, 1, 0, 1);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    // point rendering options
    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);
    glPushMatrix();
    glTranslated(draw_brush_uv_.x_, draw_brush_uv_.y_, 0);
    glEnable(GL_BLEND);
    glEnable(GL_LINE_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);
    glLineWidth(static_cast<float>(Config::PARAMSPACE_REZ) * 0.01f);
    glColor4d(Drawer::ColorList::BRUSH_EDGE);
    DrawUtil::drawCircle(brushSize_, 32);
    glPopMatrix();
    
    // cleanup
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glPopAttrib();
    core.framebuffer_.unbind();
    GLUtil::checkError();
}
void StatePaint::copy_paint_temp() {
    // copy Core::ParamSpace::buf_paint_.texture_ to paint_temp_
    core.paramSpace_.buf_paint_.texture_.copy_gpu2gpu(paint_temp_);
}
void StatePaint::on_draw() {
    if (draw_brush_is_dirty_) {
        draw_brush();
        draw_brush_is_dirty_ = false;
    }
    if (!is_dirty_)
        return;
    clk_.resetTick();
    bool result =
        (dbg_without_roi_correction_ || step2_modify_paint()) &&
        step3_extract_paintBoundary() &&
        step4_compute_offset() &&
        step5_stitch();
    drawer.dispList_Fx_.requestUpdate();
    drawer.dispList_Fy_.requestUpdate();
    drawer.dispList_Fz_.requestUpdate();
    cout << (result ? "succeed!" : "failed.") << endl;
    clk_.print();
    is_dirty_ = false;
}
StatePaint::StatePaint(void)
: dragMode_(DRAGMODE_NONE)
, brushSize_(0.1f)
, clk_("Paint")
, draw_brush_is_dirty_(false)
, is_dirty_(false)
{
    clk_.addEntry("render_paint");
    clk_.addEntry("modify_paint");
    clk_.addEntry("extract_paintBoundary");
    clk_.addEntry("compute_offset");
    clk_.addEntry("stitch");
}

