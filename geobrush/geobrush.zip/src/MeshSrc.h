#pragma once
#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/Mesh/Traits.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>
#include <KLIB/Matrix.h>
#include <KLIB/KdTree.h>
#include "ExpMapData.h"
#include "Config.h"
#include "GCMesh.h"
#include <set>
#include <string>

// source mesh
struct MeshSrcTraits : public OpenMesh::DefaultTraits {
    typedef KLIB::Vector3f Point;
    typedef KLIB::Vector3f Normal;
    VertexTraits {
    public:
        float select_value_;           // used for patch selection in StateParamSrc
        
        bool paramed_;          // true if included in the parameterized patch
        ExpMapData     expmap_data_;
        KLIB::Vector3f expmap_normal_;                  // approximate smoothed normal
        std::set<int>  expmap_neighbor_;      // nearest neighbors (don't use mesh connectivities)
        //int            expmap_knn_[Config::EXPMAP_KNN];      // k-nearest neighbor (don't use mesh connectivities)
        
        GCMesh::Data gc_data_;
        
        float paint_value_;
        
        KLIB::Vector3f gc_normal_;
        
        KLIB::Vector3f result_position_;        // after GC defm and membrane offset
        KLIB::Vector3f result_normal_;
        
        int stitch_vid_;
        
        VertexT()        // ctor
            : select_value_(FLT_MAX)
            , paramed_(false)
            , paint_value_(0.0f)
            , stitch_vid_(-1)
        {}
    };
    FaceTraits {
    public:
        bool paramed_;      // true if included in the parameterized patch (abbreviation of `parameterized')
        bool reversed_;
        bool reversed_needRender_;
        float paint_value_[(Config::PAINT_INOUT_SUBDIV - 1) * (Config::PAINT_INOUT_SUBDIV - 2) / 2];
        bool  paint_in_;     // true if this is entirely inside P
        KLIB::Vector3f gc_normal_;
        KLIB::Vector3f result_normal_;
        
        // ctor
        FaceT()
            : paramed_ (false)     // completely inside  paint region (used only for meshSrc)
            , reversed_(false)
            , reversed_needRender_(false)
            , paint_in_(false)     // completely outside paint region (used only for meshTgt)
        {
            for (int i = 0; i < (Config::PAINT_INOUT_SUBDIV - 1) * (Config::PAINT_INOUT_SUBDIV - 2) / 2; ++i)
                paint_value_[i] = 0.0f;
        }
    };
    EdgeTraits {
    public:
        bool paramed_;
        float paint_value_[Config::PAINT_INOUT_SUBDIV - 1];
        bool           paintBoundary_crossed_;
        bool           paintBoundary_visited_;   // a flag needed for extracting boundary loops
        KLIB::Vector2f paintBoundary_uv_;
        KLIB::Vector3f paintBoundary_xyz_;
        EdgeT()
            : paramed_(false)
            , paintBoundary_crossed_(false)
            , paintBoundary_visited_(false)
        {
            for (int i = 0; i < Config::PAINT_INOUT_SUBDIV - 1; ++i)
                paint_value_[i] = 0.0f;
        }
    };
};

struct MeshSrc : public OpenMesh::TriMesh_ArrayKernelT<MeshSrcTraits> {
    struct ExpMapInfo {
        KLIB::Vector3f seed_horizon_;
        KLIB::Vector3f seed_normal_;
        VHandle        seed_vhandle_;
        float uv_scale_;
        ExpMapInfo();
        void clear() { *this = ExpMapInfo(); }
    } expmap_info_;
    
    struct ParamedPatch {               // parameterized patch
        std::vector<VHandle> vertices_;
        std::vector<FHandle> faces_;
        std::vector<EHandle> edges_;
        KLIB::KdTree2d uv_kdTree_;
        std::vector<VHandle> vertices_boundary_;        // a loop of boundary vertices
        void clear() { *this = ParamedPatch(); }
    } paramedPatch_;
    
    MeshSrc();
    
    bool load(const std::string& fname);
    
    void compute_neighbor();
    
    void compute_expmap();
    
    void fitUnitBox();
    
    void compute_gc_coord();
    void compute_gc_deform();
    
    void render_paramedPatch_mask();    // render a mask covered by paramedPatch (used by MeshTgt::compute_expmap)
    
    void compute_result_normal();
private:
    KLIB::Vector2f   compute_expmap_sub_localUV(const VHandle& p, const VHandle& q) const;
    KLIB::Matrix2x2f compute_expmap_sub_rot2D  (const VHandle& p) const;
};

