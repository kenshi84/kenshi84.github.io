#include "stdafx.h"
#include "Config.h"
#include <tinyxml.h>
using namespace std;

int    Config::WINDOW_WIDTH;
int    Config::WINDOW_HEIGHT;
int    Config::EXPMAP_KNN;
int    Config::PARAMSPACE_REZ;
int    Config::PARAMSPACE_REZ2;
float  Config::FACE_REVERSED_THRESHOLD;
int    Config::FACE_REVERSED_GROW_ITER;
float  Config::CAGE_2D_EDGE_LENGTH_AVERAGE;
float  Config::CAGE_2D_BOUNDARY_SCALING;
float  Config::CAGE_LINE_EXTREMUM_SCALING;
double Config::CAGE_ORIGINAL_POSITION_WEIGHT;
double Config::CAGE_DEFORMED_POSITION_WEIGHT;
int    Config::VCYCLE_NUM_SMOOTHING;
int    Config::VCYCLE_NUM_CYCLE;
int    Config::POST_SMOOTHING_ITER;
string Config::FONT_FILENAME;

void Config::set_default() {
    WINDOW_WIDTH  = 1600;
    WINDOW_HEIGHT = 800;
    EXPMAP_KNN = 6;
    PARAMSPACE_REZ = 256;
    PARAMSPACE_REZ2 = Config::PARAMSPACE_REZ * Config::PARAMSPACE_REZ;
    FACE_REVERSED_THRESHOLD = 0.2f;
    FACE_REVERSED_GROW_ITER = 3;
    CAGE_2D_EDGE_LENGTH_AVERAGE = 0.3f;
    CAGE_2D_BOUNDARY_SCALING = 1.2f;
    CAGE_LINE_EXTREMUM_SCALING = 1.5f;
    CAGE_ORIGINAL_POSITION_WEIGHT = 1.0;
    CAGE_DEFORMED_POSITION_WEIGHT = 1.0;
    VCYCLE_NUM_SMOOTHING = 5;
    VCYCLE_NUM_CYCLE = 1;        // 1 --> V-cycle, 2 --> W-cycle
    POST_SMOOTHING_ITER = 2;
    FONT_FILENAME = "Bell_Gothic_Black_BT.ttf";
}
bool Config::load() {
    TiXmlDocument doc;
    if (!doc.LoadFile("config.xml"))
        return false;
    TiXmlElement* elem = doc.FirstChildElement("config");
    if (!elem)
        return false;
    
    int flag = 1;
    flag *= elem->QueryIntAttribute("window_width" , &WINDOW_WIDTH ) == TIXML_SUCCESS;
    flag *= elem->QueryIntAttribute("window_height", &WINDOW_HEIGHT) == TIXML_SUCCESS;
    flag *= elem->QueryIntAttribute("expmap_knn", &EXPMAP_KNN) == TIXML_SUCCESS;
    flag *= elem->QueryIntAttribute("paramspace_rez", &PARAMSPACE_REZ) == TIXML_SUCCESS;
    flag *= elem->QueryFloatAttribute("face_reversed_threshold", &FACE_REVERSED_THRESHOLD) == TIXML_SUCCESS;
    flag *= elem->QueryIntAttribute("face_reversed_grow_iter", &FACE_REVERSED_GROW_ITER) == TIXML_SUCCESS;
    flag *= elem->QueryFloatAttribute("cage_2d_edge_length_average", &CAGE_2D_EDGE_LENGTH_AVERAGE) == TIXML_SUCCESS;
    flag *= elem->QueryFloatAttribute("cage_2d_boundary_scaling", &CAGE_2D_BOUNDARY_SCALING) == TIXML_SUCCESS;
    flag *= elem->QueryFloatAttribute("cage_line_extremum_scaling", &CAGE_LINE_EXTREMUM_SCALING) == TIXML_SUCCESS;
    flag *= elem->QueryIntAttribute("vcycle_num_smoothing", &VCYCLE_NUM_SMOOTHING) == TIXML_SUCCESS;
    flag *= elem->QueryIntAttribute("vcycle_num_cycle", &VCYCLE_NUM_CYCLE) == TIXML_SUCCESS;
    flag *= elem->QueryIntAttribute("post_smoothing_iter", &POST_SMOOTHING_ITER) == TIXML_SUCCESS;
    
    {
        const char* c = elem->Attribute("font_filename");
        if (c)
            FONT_FILENAME = c;
        else
            flag = 0;
    }
    
    PARAMSPACE_REZ2 = Config::PARAMSPACE_REZ * Config::PARAMSPACE_REZ;
    
    return flag != 0;
}
bool Config::save() {
    TiXmlDocument doc;
    TiXmlElement* elem = new TiXmlElement("config");
    doc.LinkEndChild(elem);
    
    elem->SetAttribute("window_width" , WINDOW_WIDTH );
    elem->SetAttribute("window_height", WINDOW_HEIGHT);
    elem->SetAttribute("expmap_knn", EXPMAP_KNN);
    elem->SetAttribute("paramspace_rez", PARAMSPACE_REZ);
    elem->SetDoubleAttribute("face_reversed_threshold", FACE_REVERSED_THRESHOLD);
    elem->SetAttribute("face_reversed_grow_iter", FACE_REVERSED_GROW_ITER);
    elem->SetDoubleAttribute("cage_2d_edge_length_average", CAGE_2D_EDGE_LENGTH_AVERAGE);
    elem->SetDoubleAttribute("cage_2d_boundary_scaling", CAGE_2D_BOUNDARY_SCALING);
    elem->SetDoubleAttribute("cage_line_extremum_scaling", CAGE_LINE_EXTREMUM_SCALING);
    elem->SetAttribute("vcycle_num_smoothing", VCYCLE_NUM_SMOOTHING);
    elem->SetAttribute("vcycle_num_cycle", VCYCLE_NUM_CYCLE);
    elem->SetAttribute("post_smoothing_iter", POST_SMOOTHING_ITER);
    elem->SetAttribute("font_filename", FONT_FILENAME);
    
    doc.SaveFile("config.xml");
    
    return true;
}
