#include "stdafx.h"
#include "MeshSrc.h"
#include "Core.h"
#include "system_dependent.h"
#include <KLIB/Clock.h>
#include <KLIB/Util.h>
#include <KLIB/KdTree.h>
#include <queue>
#include <utility>
#include <cstdlib>

using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
GCMesh& gcmesh = core.gcmesh_;
}

bool MeshSrc::load(const string& fname) {
    ClkSimple clk("MeshSrc::load");
    cout << "Load file: " << fname << endl;
    
    MeshSrc meshSrc_temp;
    if (!OpenMesh::IO::read_mesh(meshSrc_temp, fname)) {
        cerr << "Failed to load file!" << endl;
        return false;
    }
    *this = meshSrc_temp;
    
    fitUnitBox();
    request_face_normals();
    request_vertex_normals();
    update_normals();
    
    cout << "vertices: " << n_vertices() << ", faces: " << n_faces() << endl;
    compute_neighbor();
    return true;
}

void MeshSrc::compute_neighbor() {
    ClkSimple clk("MeshSrc::compute_neighbor");
    
    // build kd-tree
    KdTree<3> kdTree;
    kdTree.reserve(n_vertices());
    for (VIter v = vertices_begin(); v != vertices_end(); ++v)
        kdTree.push_back(point(v).convert<double>());
    kdTree.build();
    
    // set neighbor
    for (VIter v = vertices_begin(); v != vertices_end(); ++v)
        data(v).expmap_neighbor_.clear();
    for (VIter v = vertices_begin(); v != vertices_end(); ++v) {
        Vector3d p = point(v).convert<double>();
        KdTree<3>::SearchResult sr = kdTree.search(p, Config::EXPMAP_KNN + 1);       // nnIdx[0] is always equal to v.idx
        for (int i = 0; i < Config::EXPMAP_KNN; ++i) {
            VHandle w = vertex_handle(sr.indices_[i + 1]);
            data(v).expmap_neighbor_.insert(w.idx());
            data(w).expmap_neighbor_.insert(v.handle().idx());      // mutual connection
        }
    }
    annClose();
}

KLIB::Vector2f   MeshSrc::compute_expmap_sub_localUV(const VHandle& p, const VHandle& q) const {
    const Vector3f& p_normal  = data(p).expmap_normal_;
    Vector3f p_horizon;
    if (expmap_info_.seed_vhandle_ == p)
        p_horizon = expmap_info_.seed_horizon_;
    else {
        p_horizon = point(vertex_handle(*data(p).expmap_neighbor_.begin())) - point(p);
        p_horizon -= p_normal * (p_normal | p_horizon);
        p_horizon.normalize();
    }
    Vector3f p_vertical = p_normal % p_horizon;
    Vector3f pq = point(q) - point(p);
    //float pq_len = pq.length();
    pq -= p_normal * (p_normal | pq);
    //pq.normalize();
    //pq *= pq_len;
    return Vector2f(pq | p_horizon, pq | p_vertical);
}
KLIB::Matrix2x2f MeshSrc::compute_expmap_sub_rot2D  (const VHandle& p) const {
    if (expmap_info_.seed_vhandle_ == p)
        return Matrix2x2f::identity();
    
    const Vector3f& s_normal  = expmap_info_.seed_normal_;
    const Vector3f& s_horizon = expmap_info_.seed_horizon_;
    const Vector3f& p_normal  = data(p).expmap_normal_;
    Vector3f        p_horizon = point(vertex_handle(*data(p).expmap_neighbor_.begin())) - point(p);
    p_horizon -= p_normal * (p_normal | p_horizon);
    p_horizon.normalize();
    
    // first rotation
    float angle1 = Util::calcAngle(s_normal, p_normal);
    if (angle1 != 0.0f) {
        Vector3f axis1 = p_normal % s_normal;
        Matrix3x3f rot1 = Util::rotationFromAxisAngle(axis1, angle1);
        p_horizon = rot1 * p_horizon;
    }
    Vector3f hoge3 = p_horizon;
    
    // second rotation
    float angle2 = Util::calcAngle(s_horizon, p_horizon);
    if (((s_horizon % p_horizon) | s_normal) < 0)     // negative rotation
        angle2 *= -1.0f;
    float cosine = cos(angle2), sine = sin(angle2);
    return Matrix2x2f(cosine, -sine, sine, cosine);
}

void MeshSrc::compute_expmap() {
    ClkData clk("MeshSrc::compute_expmap");
    clk.addEntry("expmap_core");
    clk.addEntry("others");
    {   ClkStart clkStart(&clk, 0);
    // clear expmap_vdata.{visited, distance, weightTotal, uv}
    for (size_t i = 0; i < paramedPatch_.vertices_.size(); ++i)
        data(paramedPatch_.vertices_[i]).expmap_data_ = ExpMapData();
    
    VertexData& s_data = data(expmap_info_.seed_vhandle_);
    // normal and horizon vector
    expmap_info_.seed_normal_ = s_data.expmap_normal_;
    expmap_info_.seed_horizon_ -= expmap_info_.seed_normal_ * (expmap_info_.seed_normal_ | expmap_info_.seed_horizon_);
    if (expmap_info_.seed_horizon_.length() == 0.0f) {
        expmap_info_.seed_horizon_.set_random(0.0f, 1.0f);
        expmap_info_.seed_horizon_ -= expmap_info_.seed_normal_ * (expmap_info_.seed_normal_ | expmap_info_.seed_horizon_);
    }
    expmap_info_.seed_horizon_.normalize();
    
    // init queue
    s_data.expmap_data_.distance_    = 0.0f;
    s_data.expmap_data_.weightTotal_ = 1.0f;
    
    typedef pair<float, VHandle> ElemType;
    
    priority_queue<ElemType> candidates;
    candidates.push(ElemType(-0.0f, expmap_info_.seed_vhandle_));
    
    // greedy patch growing process
    while (!candidates.empty()) {
        VHandle p = candidates.top().second;
        candidates.pop();
        VertexData& p_data = data(p);
        
        if (p_data.expmap_data_.visited_)
            continue;
        p_data.expmap_data_.visited_ = true;
        
        p_data.expmap_data_.uv_ /= p_data.expmap_data_.weightTotal_;
        
        Matrix2x2f rot = compute_expmap_sub_rot2D(p);
        
        set<int>::iterator n_begin = p_data.expmap_neighbor_.begin();
        set<int>::iterator n_end   = p_data.expmap_neighbor_.end  ();
        for (set<int>::iterator n = n_begin; n != n_end; ++n) {
            VHandle q = vertex_handle(*n);
            VertexData& q_data = data(q);
            
            if (q_data.expmap_data_.visited_)
                continue;
            
            if (!q_data.paramed_)      // out of the canvas patch
                continue;
            
            // distance computation
            float len = (point(p) - point(q)).length();
            float distance = p_data.expmap_data_.distance_ + len;
            
            // update distance
            if (distance < q_data.expmap_data_.distance_)
                q_data.expmap_data_.distance_ = distance;
            
            // compute uv
            float weight = 1.0f / len;
            q_data.expmap_data_.uv_ += weight * (p_data.expmap_data_.uv_ + rot * compute_expmap_sub_localUV(p, q));
            q_data.expmap_data_.weightTotal_ += weight;
            
            candidates.push(ElemType(-distance, q));
        }
    }
    
    clkStart.setCurrentIndex(1);
    {   // rescale and offset uv so that the entire paramed patch fits within unit box (keep the seed's uv as 0!)
        float coord_max = 0.0f;
        for (size_t i = 0; i < paramedPatch_.vertices_.size(); ++i) {
            Vector2f& uv = data(paramedPatch_.vertices_[i]).expmap_data_.uv_;
            coord_max = max<float>(max<float>(abs(uv.x_), abs(uv.y_)), coord_max);
        }
        expmap_info_.uv_scale_ = 0.5f * 0.9f / coord_max;
        for (size_t i = 0; i < paramedPatch_.vertices_.size(); ++i) {
            Vector2f& uv = data(paramedPatch_.vertices_[i]).expmap_data_.uv_;
            uv *= expmap_info_.uv_scale_;
            uv += Vector2f(0.5f);
        }
    }
    
    {   // mark FaceT.reversed_
        for (size_t i = 0; i < paramedPatch_.faces_.size(); ++i) {
            FHandle& f = paramedPatch_.faces_[i];
            Vector3f original_normal = normal(f);
            Vector3f expmap_normal;
            for (FVIter v = fv_iter(f); v; ++v)
                expmap_normal += data(v).expmap_normal_;
            expmap_normal.normalize();
            data(f).reversed_ = (original_normal | expmap_normal) < Config::FACE_REVERSED_THRESHOLD;
        }
    }
    {   // grow reversed faces
        for (int k = 0; k < Config::FACE_REVERSED_GROW_ITER; ++k) {
            vector<FHandle> growth;
            growth.reserve(paramedPatch_.faces_.size());
            for (size_t i = 0; i < paramedPatch_.faces_.size(); ++i) {
                FHandle& f = paramedPatch_.faces_[i];
                if (!data(f).reversed_)
                    continue;
                for (FFIter ff = ff_iter(f); ff; ++ff)
                    if (!data(ff).reversed_)
                        growth.push_back(ff);
            }
            for (size_t i = 0; i < growth.size(); ++i) {
                FHandle& f = growth[i];
                data(f).reversed_ = true;
            }
        }
    }
    cout <<
        paramedPatch_.faces_   .size() << " faces, "    <<
        paramedPatch_.vertices_.size() << " vertices, " <<
        paramedPatch_.edges_   .size() << " edges\n";
    
    {   // build KdTree
        KdTree2d& kdTree = paramedPatch_.uv_kdTree_;
        kdTree.clear();
        for (size_t i = 0; i < paramedPatch_.vertices_.size(); ++i)
            kdTree.push_back(data(paramedPatch_.vertices_[i]).expmap_data_.uv_.convert<double>());
        kdTree.build();
    }
    }   clk.print(false);
}

void MeshSrc::fitUnitBox() {
    Vector3f bbmax(-FLT_MAX), bbmin(FLT_MAX), center;
    for (VIter v_it = vertices_begin(); v_it != vertices_end(); ++v_it) {
        Vector3f& p = point(v_it);
        bbmax = bbmax.pairwiseMax(p);
        bbmin = bbmin.pairwiseMin(p);
        center += p;
    }
    center /= (float)n_vertices();
    bbmax -= bbmin;
    float scale = 1.0f / bbmax.elemMax();
    for (VIter v_it = vertices_begin(); v_it != vertices_end(); ++v_it) {
        Vector3f& p = point(v_it);
        p -= center;
        p *= scale;
    }
}

void MeshSrc::render_paramedPatch_mask() {
    ClkSimple clk("MeshSrc::render_paramedPatch_mask");
    
    core.framebuffer_.bind();
    core.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, core.paramSpace_.buf_src_.texture_);
    GLUtil::checkFramebufferStatus();
    
    glPushAttrib(GL_VIEWPORT_BIT | GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT | GL_HINT_BIT);
    // viewport and camera setting
    glViewport(0, 0, Config::PARAMSPACE_REZ, Config::PARAMSPACE_REZ);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, 1, 0, 1);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    // rendering options
    glDisable(GL_LIGHTING);
    glDisable(GL_DEPTH_TEST);
    glClearColor(0, 0, 0, 0);
    glClear(GL_COLOR_BUFFER_BIT);
    glColor4d(1, 1, 1, 1);
    glBegin(GL_TRIANGLES);
    for (size_t i = 0; i < paramedPatch_.faces_.size(); ++i) {
        FHandle f = paramedPatch_.faces_[i];
        for (FVIter v = fv_iter(f); v; ++ v)
            glVertex2fv(data(v).expmap_data_.uv_.ptr());
    }
    glEnd();
    
    // cleanup
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glPopAttrib();
    core.framebuffer_.unbind();
    core.paramSpace_.buf_src_.dump();
    GLUtil::checkError();
}
void MeshSrc::compute_gc_coord() {
    ClkSimple clk("MeshSrc::compute_gc_coord");
    
    for (size_t i = 0; i < paramedPatch_.vertices_.size(); ++i) {
        VHandle& v = paramedPatch_.vertices_[i];
        GCMesh::Data& gc_data = data(v).gc_data_;
        gc_data.original_position_ = point(v);
        gcmesh.compute_coord(gc_data);
    }
}
void MeshSrc::compute_gc_deform() {
    ClkSimple clk("MeshSrc::compute_gc_deform");
    
    for (size_t i = 0; i < paramedPatch_.vertices_.size(); ++i) {
        VHandle& v = paramedPatch_.vertices_[i];
        gcmesh.compute_deform(data(v).gc_data_);
    }
    // compute normal
    for (size_t i = 0; i < paramedPatch_.faces_.size(); ++i) {
        FHandle& f = paramedPatch_.faces_[i];
        Vector3f face_points[3];
        FVIter v = fv_iter(f);
        for (int j = 0; j < 3; ++j, ++v)
            face_points[j] = data(v).gc_data_.deformed_position_;
        data(f).gc_normal_ = Util::calcNormal(face_points[0], face_points[1], face_points[2]);
    }
    for (size_t i = 0; i < paramedPatch_.vertices_.size(); ++i) {
        VHandle& v = paramedPatch_.vertices_[i];
        Vector3f n;
        for (VFIter f = vf_iter(v); f; ++f)
            if (data(f).paramed_)
                n += data(f).gc_normal_;
        n.normalize();
        data(v).gc_normal_ = n;
    }
}
MeshSrc::ExpMapInfo::ExpMapInfo()
: seed_horizon_(0.f, 1.f, 0.f)
, uv_scale_(0.0f)
{}
MeshSrc::MeshSrc() {}
