#pragma once
#include <KLIB/GLSLUtil.h>
#include <KLIB/GLUtil.h>
#include <KLIB/Trackball.h>
#define FTGL_LIBRARY_STATIC
#include <FTGL/ftgl.h>

class Drawer {
public:
    struct ColorList {
        static const KLIB::Vector3d SRC_FACE_DEFAULT;
        static const KLIB::Vector3d SRC_FACE_PARAMED;
        static const KLIB::Vector3d DST_FACE_DEFAULT;
        static const KLIB::Vector3d DST_FACE_PARAMED;
        static const KLIB::Vector3d STITCH_FACE;
        static const KLIB::Vector3d EDGE_DEFAULT;
        static const KLIB::Vector3d CAGE;
        static const KLIB::Vector4d CANVAS_SELECT;
        static const KLIB::Vector3f PAINT_POSITIVE;
        static const KLIB::Vector3f PAINT_NEGATIVE;
        static const KLIB::Vector4d BRUSH_EDGE;
    };
    bool flags_[9];
    struct PersParam {
        double fovy_;
        double zNear_;
        double zFar_;
        PersParam()
            : fovy_(30)
            , zNear_(0.01)
            , zFar_(10000)
        {}
    } persParam_;
    
    // camera position parameter
    KLIB::Trackball trackballLeft_, trackballRight_;
    int width_;
    int height_;
    
	FTGLPolygonFont* font_;
    
    Drawer(void);
    ~Drawer(void);
    
    void init();
    void resize(int width, int height);
    
    KLIB::TextureObject checkerboard_texture_;
    
    void draw      ();
    void draw_left ();
    void draw_right();
    
    KLIB::ProgramObject phong_shader_;
    
    // selection
    KLIB::FramebufferObject  select_framebuffer_;
    KLIB::RenderbufferObject select_renderbuffer_[3];  // { face id (RGB), barycentric coord (RGB), depth }
    KLIB::ProgramObject      select_shader_;
    void select_draw      ();
    void select_draw_left ();
    void select_draw_right();
    void select(int x, int y, int& faceID, KLIB::Vector3f& baryCoord);      // xy is GL's manner: left-bottom is (0,0)
    
    // projection utilities
    KLIB::Vector3d project_left (const KLIB::Vector3d& worldPos) const;
    KLIB::Vector3d project_right(const KLIB::Vector3d& worldPos) const;
    
    KLIB::DisplayList dispList_meshSrc_all_faces_;
    KLIB::DisplayList dispList_meshSrc_all_edges_;
    KLIB::DisplayList dispList_meshTgt_unparamed_faces_;
    KLIB::DisplayList dispList_meshTgt_unparamed_edges_;
    KLIB::DisplayList select_dispList_left_;
    KLIB::DisplayList select_dispList_right_;
    
    // code to produce figures in the paper
    KLIB::DisplayList dispList_Fx_;
    KLIB::DisplayList dispList_Fy_;
    KLIB::DisplayList dispList_Fz_;
    int paper_drawMode_;    // 0: default render mode, others: render specific paper figures
    // +--------+-----------------+
    // | number | visualized data |
    // +--------+-----------------+
    // |   1    | Esrc(Psrc)      |
    // |   2    | Etgt(Ptgt)      |
    // |   3    |     Q           |
    // |   4    | Esrc(Rin)       |
    // |   5    | Etgt(Rout)      |
    // |   6    |     Fx          |
    // |   7    |     Fy          |
    // |   8    |     Fz          |
    // |   9    | S,��Rin,��Rout  |
    // +--------+-----------------+
    void paper_draw();
};
