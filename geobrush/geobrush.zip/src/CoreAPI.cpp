#include "StdAfx.h"
#include "CoreAPI.h"
#include "Core.h"

namespace {
Core& core = Core::getInstance();
}

namespace CoreAPI {

void startApp() { Core::getInstance(); }
void initGL() { core.initGL(); }
void deinitGL() { core.deinitGL(); }
void draw() { core.drawer_.draw(); }
void resize(int width, int height)
{
    core.drawer_.resize(width, height);
}
void mouseLButtonDown(int x, int y, bool flagShift, bool flagCtrl) { core.handler_.mouseLButtonDown(x, y, flagShift, flagCtrl); }
void mouseRButtonDown(int x, int y, bool flagShift, bool flagCtrl) { core.handler_.mouseRButtonDown(x, y, flagShift, flagCtrl); }
void mouseMButtonDown(int x, int y, bool flagShift, bool flagCtrl) { core.handler_.mouseMButtonDown(x, y, flagShift, flagCtrl); }
void mouseLButtonUp(int x, int y) { core.handler_.mouseLButtonUp(x, y); }
void mouseRButtonUp(int x, int y) { core.handler_.mouseRButtonUp(x, y); }
void mouseMButtonUp(int x, int y) { core.handler_.mouseMButtonUp(x, y); }
void mouseMove(int x, int y, bool flagShift, bool flagCtrl) { core.handler_.mouseMove(x, y, flagShift, flagCtrl); }
void mouseWheel(int direction, int x, int y) { core.handler_.mouseWheel(direction, x, y); }
void keyDown(unsigned char ascii) { core.handler_.keyDown(ascii); }
void keyDown(SpecialKey key) { core.handler_.keyDown(key); }
}
