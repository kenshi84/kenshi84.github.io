#include "StdAfx.h"
#include "Core.h"
#include "StatePaint.h"
#include "StateParamSrc.h"
#include "StateParamTgt.h"
#include <iostream>
#include <vector>
using namespace std;
using namespace KLIB;

namespace {
    Core& core = Core::getInstance();
    MeshSrc& meshSrc = core.meshSrc_;
    MeshTgt& meshTgt = core.meshTgt_;
    StitchMesh& stitchMesh = core.stitchMesh_;
    GCMesh& gcmesh = core.gcmesh_;
    CageGenMesh& cageGenMesh = core.cageGenMesh_;

    // local functions-----------------------------
    void drawAxis() {
        glPushAttrib(GL_ENABLE_BIT);
        glDisable(GL_LIGHTING);
        glBegin(GL_LINES);
        glColor3d(1, 0, 0); glVertex3d(0, 0, 0); glVertex3d(1, 0, 0);
        glColor3d(0, 1, 0); glVertex3d(0, 0, 0); glVertex3d(0, 1, 0);
        glColor3d(0, 0, 1); glVertex3d(0, 0, 0); glVertex3d(0, 0, 1);
        glEnd();
        glPopAttrib();
    }

    template <typename Mesh>
    void draw_mesh_unparamed_faces(typename Mesh& mesh) {
        glBegin(GL_TRIANGLES);
        for (typename MeshSrc::FIter f = mesh.faces_begin(); f != mesh.faces_end(); ++f) {
            typename Mesh::FaceData& fdata = mesh.data(f);
            if (fdata.paramed_)
                continue;
            for (typename Mesh::FVIter v = mesh.fv_iter(f); v; ++v) {
                glNormal3f(mesh.normal(v));
                glVertex3f(mesh.point (v));
            }
        }
        glEnd();
    }
    template <typename Mesh>
    void draw_mesh_unparamed_edges(typename Mesh& mesh) {
        glBegin(GL_LINES);
        for (typename Mesh::EIter e = mesh.edges_begin(); e != mesh.edges_end(); ++e) {
            bool paramed[2] = {false, false};
            Vector3f point[2];
            for (int i = 0; i < 2; ++i) {
                typename Mesh::HHandle h = mesh.halfedge_handle(e, i);
                typename Mesh::FHandle f = mesh.face_handle(h);
                paramed[i] = f.is_valid() && mesh.data(f).paramed_;
                point[i] = mesh.point(mesh.to_vertex_handle(h));
            }
            if (paramed[0] && paramed[1])
                continue;
            for (int i = 0; i < 2; ++i)
                glVertex3f(point[i]);
        }
        glEnd();
    }
    template <typename Mesh>
    void draw_mesh_all_edges(typename Mesh& mesh) {
        glBegin(GL_LINES);
        for (typename Mesh::EIter e = mesh.edges_begin(); e != mesh.edges_end(); ++e) {
            for (int i = 0; i < 2; ++i)
                glVertex3f(mesh.point(mesh.to_vertex_handle(mesh.halfedge_handle(e, i))));
        }
        glEnd();
    }

}

const Vector3d Drawer::ColorList::SRC_FACE_DEFAULT(0.9, 0.8, 0.6);
const Vector3d Drawer::ColorList::SRC_FACE_PARAMED(0.9, 0.8, 0.6);//(1.0, 0.9, 0.7);
const Vector3d Drawer::ColorList::DST_FACE_DEFAULT(0.6, 0.9, 0.8);
const Vector3d Drawer::ColorList::DST_FACE_PARAMED(0.6, 0.9, 0.8);//(0.7, 1.0, 0.9);
const Vector3d Drawer::ColorList::STITCH_FACE(0.9, 0.2, 0.7);
const Vector3d Drawer::ColorList::EDGE_DEFAULT(0.25, 0.25, 0.25);
const Vector3d Drawer::ColorList::CAGE(0.25, 1.0, 0.0);
const Vector4d Drawer::ColorList::CANVAS_SELECT(0.25, 0.5, 0.75, 0.5);
const Vector3f Drawer::ColorList::PAINT_POSITIVE(1.0f, 0.75f, 0.0f);
const Vector3f Drawer::ColorList::PAINT_NEGATIVE(0.0f, 0.25f, 0.5f);
const Vector4d Drawer::ColorList::BRUSH_EDGE(0.0, 0.0, 0.0, 0.5);

void Drawer::init() {
    phong_shader_.init();
    phong_shader_.attach(ShaderObject("shaders/phong.vert", ShaderObject::VERTEX_SHADER  ));
    phong_shader_.attach(ShaderObject("shaders/phong.frag", ShaderObject::FRAGMENT_SHADER));
    phong_shader_.link();
    phong_shader_.enable();
    phong_shader_.storeAttribLocation("a_textured");
    phong_shader_.setUniform1i("u_texture", 0);
    phong_shader_.disable();

    select_shader_.init();
    {
        ShaderObject vert, frag;
        vert.setSource(
            "void main() {\
            gl_FrontColor = gl_Color;\
            gl_FrontSecondaryColor = gl_SecondaryColor;\
            gl_Position = ftransform();\
            }"
            , ShaderObject::VERTEX_SHADER);
        frag.setSource(
            "void main() {\
            gl_FragData[0] = gl_Color;\
            gl_FragData[1] = gl_SecondaryColor;\
            }"
            , ShaderObject::FRAGMENT_SHADER);
        select_shader_.attach(vert);
        select_shader_.attach(frag);
    }
    select_shader_.link();

    {
        int n = 8;          // number of cells
        int m = 8;          // number of pixels per cell
        int w = n * m;
        vector<Vector3uc> pixels(w * w, Vector3uc(0xFF));
        for (int i = 0; i < n; ++i) {
            for (int j = 0; j < n; ++j) {
                Vector3uc color_u = (i == n / 2 && j == n / 2) ? Vector3uc(0, 255, 255) : Vector3uc(255, 0, 0);
                Vector3uc color_v = (i == n / 2 && j == n / 2) ? Vector3uc(0, 255, 255) : Vector3uc(0, 0, 255);
                for (int k = 1; k < m; ++k) {
                    pixels[w * (m * i) + (m * j + k)] = color_u;
                    pixels[w * (m * j + k) + (m * i)] = color_v;
                }
                pixels[w * (m * i) + (m * j)] = Vector3uc(128, 0, 128);
            }
            //for (int j = 0; j < n; ++j)
            //    pixels[n * i + j] = i % 2 == j % 2 ? Vector3uc(255) : Vector3uc((256 * j) / n, (256 * i) / n, 0);
        }
        checkerboard_texture_.init(GL_TEXTURE_2D);
        checkerboard_texture_.allocate(GL_RGB, w, w, GL_RGB, GL_UNSIGNED_BYTE, pixels[0].ptr());
        checkerboard_texture_.setParamFilter(GL_NEAREST);
    }

    {   // GL state initialization
        glClearColor(1.f, 1.f, 1.f, 1.f);
        glEnable( GL_DEPTH_TEST );
        glCullFace( GL_BACK ) ;
        glEnable( GL_CULL_FACE ) ;
        // for showing edges
        glPolygonOffset(1.f, 1.f);
    }

    // offscreen buffer for selection
    select_framebuffer_.init();
    GLUtil::checkError("Drawer::init");

    // display list generation
    dispList_meshSrc_all_faces_.init();
    dispList_meshSrc_all_edges_.init();
    dispList_meshTgt_unparamed_faces_.init();
    dispList_meshTgt_unparamed_edges_.init();
    select_dispList_left_ .init();
    select_dispList_right_.init();
}
void Drawer::resize(int width, int height) {
    width_  = width;
    height_ = height;
    trackballLeft_ .setSize(width, height);
    trackballRight_.setSize(width, height);
    glMatrixMode( GL_PROJECTION );
    glLoadIdentity();
    gluPerspective(persParam_.fovy_, 0.5 * width_ / static_cast<double>(height_), persParam_.zNear_, persParam_.zFar_);
    glMatrixMode( GL_MODELVIEW ) ;

    static const GLenum format[3] = { GL_RGB8, GL_RGB8, GL_DEPTH_COMPONENT };
    static const GLenum attach[3] = { GL_COLOR_ATTACHMENT0_EXT, GL_COLOR_ATTACHMENT1_EXT, GL_DEPTH_ATTACHMENT_EXT };
    select_framebuffer_.bind();
    for (int i = 0; i < 3; ++i) {
        select_renderbuffer_[i].init();
        select_renderbuffer_[i].allocate(format[i], width, height);
        select_framebuffer_.attachRenderbuffer(attach[i], select_renderbuffer_[i]);
    }
    glDrawBuffers(2, attach);
    GLUtil::checkFramebufferStatus("Drawer::resize");
    select_framebuffer_.unbind();
    select_draw();

    {
        TextureObject& texture = StateParamSrc::getInstance()->screenBuf_.texture_;
        texture.init(GL_TEXTURE_2D);
        Vector4f p = ColorList::CANVAS_SELECT.convert<float>();
        p.w_ = 0.0f;
        vector<Vector4f> pixels(width_ * height_ / 2, p);
        texture.allocate(GL_RGBA, width_ / 2, height_, GL_RGBA, GL_FLOAT, pixels[0].ptr());
    }
    GLUtil::checkError("Drawer::resize");
}

void Drawer::draw() {
    if (core.state_ == StateParamTgt::getInstance())
        StateParamTgt::getInstance()->on_draw();
    if (core.state_ == StatePaint::getInstance())
        StatePaint::getInstance()->on_draw();

    glViewport(0, 0, width_, height_);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

    if (paper_drawMode_) {
        glPushAttrib(GL_ENABLE_BIT | GL_LINE_BIT);
        glMatrixMode( GL_PROJECTION );
        glPushMatrix();
        glLoadIdentity();
        gluPerspective(persParam_.fovy_, width_ / static_cast<double>(height_), persParam_.zNear_, persParam_.zFar_);
        glMatrixMode( GL_MODELVIEW );
        paper_draw();
        glMatrixMode( GL_PROJECTION );
        glPopMatrix();
        glMatrixMode( GL_MODELVIEW );
        glPopAttrib();
        return;
    }

    // left
    glViewport(0, 0, width_ / 2, height_);
    glPushMatrix();
    glLoadIdentity();
    gluLookAt(
        trackballLeft_.eyePoint_[0],
        trackballLeft_.eyePoint_[1],
        trackballLeft_.eyePoint_[2],
        trackballLeft_.focusPoint_[0],
        trackballLeft_.focusPoint_[1],
        trackballLeft_.focusPoint_[2],
        trackballLeft_.upDirection_[0],
        trackballLeft_.upDirection_[1],
        trackballLeft_.upDirection_[2]);
    draw_left();
    glPopMatrix();

    // right
    glPushMatrix();
    glViewport(width_ / 2, 0, width_ / 2, height_);
    glLoadIdentity();
    gluLookAt(
        trackballRight_.eyePoint_[0],
        trackballRight_.eyePoint_[1],
        trackballRight_.eyePoint_[2],
        trackballRight_.focusPoint_[0],
        trackballRight_.focusPoint_[1],
        trackballRight_.focusPoint_[2],
        trackballRight_.upDirection_[0],
        trackballRight_.upDirection_[1],
        trackballRight_.upDirection_[2]);
    draw_right();
    glPopMatrix();

    if (font_) {    // render message
        glPushAttrib( GL_VIEWPORT_BIT | GL_ENABLE_BIT );
        glViewport(0, 0, width_, height_);
        glMatrixMode(GL_PROJECTION);
        glPushMatrix();
        glLoadIdentity();
        gluOrtho2D(0, width_, 0, height_);
        glMatrixMode(GL_MODELVIEW);
        glPushMatrix();
        glLoadIdentity();
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        // State message
        glPushMatrix();
        glTranslatef(20, 20, 0);
        glColor4d(1, 0, 0, 0.5);
        font_->FaceSize(48);
        font_->Render(core.state_->message().c_str());
        glPopMatrix();
        // Source / Target on top
        glColor4d(0.25, 0.125, 1, 0.5);
        glTranslatef(width_ / 4 - 30, height_ - 50, 0);
        font_->FaceSize(36);
        font_->Render("Source");
        glTranslatef(width_ / 2, 0, 0);
        font_->Render("Target");

        glMatrixMode(GL_PROJECTION);
        glPopMatrix();
        glMatrixMode(GL_MODELVIEW);
        glPopMatrix();
        glPopAttrib();
    }

    GLUtil::checkError("Drawer::draw");
}
void Drawer::draw_left() {
    glPushAttrib(GL_ENABLE_BIT | GL_LINE_BIT | GL_COLOR_BUFFER_BIT);
    if (flags_[8]) // axis
        drawAxis();
    if (flags_[0]) {    // draw faces
        phong_shader_.enable();
        phong_shader_.setAttrib1f("a_textured", 0.0f);
        TextureObject* texture = 0;
        if (core.state_ == StatePaint::getInstance()) {
            texture = &StatePaint::getInstance()->paint_temp_;
        } else {
            texture = &checkerboard_texture_;
        }
        texture->bind();
        glColor3d(ColorList::SRC_FACE_DEFAULT);
        glEnable(GL_POLYGON_OFFSET_FILL);
        // [DL] meshSrc faces
        {   DisplayList& dl = dispList_meshSrc_all_faces_;
        if (dl.needUpdate()) {
            dl.newList();
            draw_mesh_unparamed_faces<MeshSrc>(meshSrc);
            // meshSrc paramed patch
            phong_shader_.setAttrib1f("a_textured", flags_[2] ? 1.0f : 0.0f);
            glColor3d(ColorList::SRC_FACE_PARAMED);
            glBegin(GL_TRIANGLES);
            for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
                MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
                for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v) {
                    glTexCoord2f(meshSrc.data(v).expmap_data_.uv_);
                    glNormal3f(meshSrc.normal(v));
                    glVertex3f(meshSrc.point (v));
                }
            }
            glEnd();
            dl.endList();
        } else
            dl.callList();
        }
        texture->unbind();
        phong_shader_.disable();
        glDisable(GL_POLYGON_OFFSET_FILL);
        glColor3d(ColorList::EDGE_DEFAULT);
        glLineWidth(1);
        glBegin(GL_LINES);
        for (size_t i = 0; i < meshSrc.paramedPatch_.edges_.size(); ++i) {
            MeshSrc::EHandle& e = meshSrc.paramedPatch_.edges_[i];
            bool flag = false;
            Vector3f points[2];
            for (int j = 0; j < 2; ++j) {
                MeshSrc::HHandle h = meshSrc.halfedge_handle(e, j);
                points[j] = meshSrc.point(meshSrc.to_vertex_handle(h));
                MeshSrc::FHandle f = meshSrc.face_handle(h);
                if (/*f.is_valid() &&*/ !meshSrc.data(f).paramed_)
                    flag = true;
            }
            if (flag) {
                glVertex3f(points[0]);
                glVertex3f(points[1]);
            }
        }
        glEnd();
    }
    if (flags_[1]) {  // draw edges
        glColor3d(ColorList::EDGE_DEFAULT);
        glLineWidth(1);
        {   DisplayList& dl = dispList_meshSrc_all_edges_;
        if (dl.needUpdate()) {
            dl.newList();
            draw_mesh_all_edges<MeshSrc>(meshSrc);
            dl.endList();
        } else
            dl.callList();
        }
    }
    if (flags_[3]) { // draw GCMesh
        glLineWidth(5);
        //glColor3d(ColorList::CAGE);
        int nb = static_cast<int>(cageGenMesh.boundary_.size());
        if (CageGenMesh::dbg_show_) {
            glColor3d(0, 1, 0.75);
            glBegin(GL_LINES);
            for (CageGenMesh::EIter e = cageGenMesh.edges_begin(); e != cageGenMesh.edges_end(); ++e) {
                CageGenMesh::VHandle v[2];
                for (int i = 0; i < 2; ++i) {
                    CageGenMesh::HHandle h = cageGenMesh.halfedge_handle(e, i);
                    v[i] = cageGenMesh.to_vertex_handle(h);
                }
                if (v[0].idx() < nb && v[1].idx() < nb)
                    continue;
                glVertex3f(cageGenMesh.data(v[0]).original_xyz_);
                glVertex3f(cageGenMesh.data(v[1]).original_xyz_);
            }
            glEnd();
            glColor3d(1, 0, 0);
            glBegin(GL_LINE_LOOP);
            for (int i = 0; i < nb; ++i) {
                CageGenMesh::VHandle v = cageGenMesh.vertex_handle(i);
                glVertex3f(cageGenMesh.data(v).original_xyz_);
            }
            glEnd();
        } else {
            for (int i = 0; i < nb; ++i) {
                for (int j = 0; j < 2; ++j) {
                    GCMesh::FHandle f = gcmesh.face_handle(2 * i + j);
                    GCMesh::FVIter v = gcmesh.fv_iter(f);
                    glColor3d(1, 0, 0);
                    glBegin(GL_LINE_STRIP);
                    glVertex3f(gcmesh.data(v).original_position_);  ++v;
                    glVertex3f(gcmesh.data(v).original_position_);  ++v;
                    glVertex3f(gcmesh.data(v).original_position_);
                    glEnd();
                    glColor3d(0.5, 0, 0);
                    glBegin(GL_LINES);
                    glVertex3f(gcmesh.data(v).original_position_);  ++v;
                    glVertex3f(gcmesh.data(v).original_position_);
                    glEnd();
                }
            }
            for (int i = nb; i < gcmesh.n_faces() / 2; ++i) {
                for (int j = 0; j < 2; ++j) {
                    if (j == 0)
                        glColor3d(0, 1, 0);
                    else
                        glColor3d(0, 0, 1);
                    GCMesh::FHandle f = gcmesh.face_handle(2 * i + j);
                    glBegin(GL_LINE_LOOP);
                    for (GCMesh::FVIter v = gcmesh.fv_iter(f); v; ++v)
                        glVertex3f(gcmesh.data(v).original_position_);
                    glEnd();
                }
            }
        }
    }
    if (flags_[6]) {
        // draw source paramed patch
        phong_shader_.enable();
        phong_shader_.setAttrib1f("a_textured", 0.0f);
        glDisable(GL_CULL_FACE);
        glEnable(GL_POLYGON_OFFSET_FILL);
        glColor3d(ColorList::SRC_FACE_PARAMED);
        glBegin(GL_TRIANGLES);
        for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
            MeshSrc::FHandle f = meshSrc.paramedPatch_.faces_[i];
            for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v) {
                glNormal3f(meshSrc.normal(v));
                glVertex3f(meshSrc.point(v));
            }
        }
        glEnd();
        phong_shader_.disable();
        glDisable(GL_POLYGON_OFFSET_FILL);
        if (flags_[1]) {  // draw edges
            glColor3d(ColorList::EDGE_DEFAULT);
            glLineWidth(1);
            for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
                MeshSrc::FHandle f = meshSrc.paramedPatch_.faces_[i];
                glBegin(GL_LINE_STRIP);
                for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v)
                    glVertex3f(meshSrc.point(v));
                glEnd();
            }
        }
    }
    core.state_->draw_left();
    glPopAttrib();
}
void Drawer::draw_right() {
    glPushAttrib(GL_ENABLE_BIT | GL_LINE_BIT | GL_COLOR_BUFFER_BIT);
    if (flags_[8]) // axis
        drawAxis();
    if (flags_[0]) {    // draw faces
        glEnable(GL_POLYGON_OFFSET_FILL);
        phong_shader_.enable();
        phong_shader_.setAttrib1f("a_textured", 0.0f);
        glColor3d(ColorList::DST_FACE_DEFAULT);
        // [DL] meshTgt's unparamed part
        {   DisplayList& dl = dispList_meshTgt_unparamed_faces_;
        if (dl.needUpdate()) {
            dl.newList();
            draw_mesh_unparamed_faces<MeshTgt>(meshTgt);
            dl.endList();
        } else
            dl.callList();
        }
        // meshTgt paramed patch
        TextureObject* texture = 0;
        if (core.state_ == StatePaint::getInstance()) {
            texture = &StatePaint::getInstance()->paint_temp_;
        } else {
            texture = &checkerboard_texture_;
        }
        texture->bind();
        phong_shader_.setAttrib1f("a_textured", flags_[2] ? 1.0f : 0.0f);
        glColor3d(ColorList::DST_FACE_PARAMED);
        glBegin(GL_TRIANGLES);
        for (size_t i = 0; i < meshTgt.paramedPatch_.faces_.size(); ++i) {
            MeshTgt::FHandle& f = meshTgt.paramedPatch_.faces_[i];
            MeshTgt::FaceData& fdata = meshTgt.data(f);
            if (!stitchMesh.vertices_empty() && !fdata.paint_out_)
                continue;
            for (MeshTgt::FVIter v = meshTgt.fv_iter(f); v; ++v) {
                MeshTgt::VertexData& vdata = meshTgt.data(v);
                glTexCoord2f(vdata.expmap_data_.uv_);
                Vector3f n, p;
                if (vdata.stitch_vid_ != -1) {
                    StitchMesh::VHandle w = stitchMesh.vertex_handle(vdata.stitch_vid_);
                    n = stitchMesh.normal(w);
                    p = stitchMesh.point(w);
                } else {
                    n = stitchMesh.vertices_empty() ? meshTgt.normal(v) : meshTgt.data(v).result_normal_;
                    p = meshTgt.point(v);
                }
                glNormal3f(n);
                glVertex3f(p);
            }
        }
        glEnd();
        if (!stitchMesh.vertices_empty()) {
            // cloned meshSrc
            glColor3d(flags_[4] ? ColorList::SRC_FACE_PARAMED : ColorList::DST_FACE_PARAMED);
            glBegin(GL_TRIANGLES);
            for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
                MeshSrc::FHandle f = meshSrc.paramedPatch_.faces_[i];
                if (!meshSrc.data(f).paint_in_)
                    continue;
                for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v) {
                    MeshSrc::VertexData& vdata = meshSrc.data(v);
                    glTexCoord2f(vdata.expmap_data_.uv_);
                    if (!flags_[5]) {
                        glNormal3f(vdata.gc_normal_);
                        glVertex3f(vdata.gc_data_.deformed_position_);
                    } else {
                        Vector3f n, p;
                        if (vdata.stitch_vid_ != -1) {
                            StitchMesh::VHandle w = stitchMesh.vertex_handle(vdata.stitch_vid_);
                            n = stitchMesh.normal(w);
                            p = stitchMesh.point(w);
                        } else {
                            n = vdata.result_normal_;
                            p = vdata.result_position_;
                        }
                        glNormal3f(n);
                        glVertex3f(p);
                    }
                }
            }
            glEnd();
            // stitchMesh
            if (flags_[7]) {
                glColor3d(flags_[4] ? ColorList::STITCH_FACE : ColorList::DST_FACE_PARAMED);
                glBegin(GL_TRIANGLES);
                for (StitchMesh::FIter f = stitchMesh.faces_begin(); f != stitchMesh.faces_end(); ++f) {
                    for (StitchMesh::FVIter v = stitchMesh.fv_iter(f); v; ++v) {
                        glTexCoord2f(stitchMesh.data(v).uv_);
                        glNormal3f(stitchMesh.normal(v));
                        glVertex3f(stitchMesh.point(v));
                    }
                }
                glEnd();
            }
        }
        texture->unbind();
        phong_shader_.disable();
        glDisable(GL_POLYGON_OFFSET_FILL);
    }
    if (flags_[1]) {  // draw edges
        glColor3d(ColorList::EDGE_DEFAULT);
        glLineWidth(1);
        // [DL] meshTgt's unparamed part
        {   DisplayList& dl = dispList_meshTgt_unparamed_edges_;
        if (dl.needUpdate()) {
            dl.newList();
            draw_mesh_unparamed_edges<MeshTgt>(meshTgt);
            dl.endList();
        } else
            dl.callList();
        }
        // meshTgt paramed patch
        for (size_t i = 0; i < meshTgt.paramedPatch_.faces_.size(); ++i) {
            MeshTgt::FHandle& f = meshTgt.paramedPatch_.faces_[i];
            MeshTgt::FaceData& fdata = meshTgt.data(f);
            if (!stitchMesh.vertices_empty() && !fdata.paint_out_)
                continue;
            glBegin(GL_LINE_LOOP);
            for (MeshTgt::FVIter v = meshTgt.fv_iter(f); v; ++v) {
                MeshTgt::VertexData& vdata = meshTgt.data(v);
                Vector3f p;
                if (vdata.stitch_vid_ != -1) {
                    StitchMesh::VHandle w = stitchMesh.vertex_handle(vdata.stitch_vid_);
                    p = stitchMesh.point(w);
                } else
                    p = meshTgt.point(v);
                glVertex3f(p);
            }
            glEnd();
        }
        if (!stitchMesh.vertices_empty()) {
            // meshSrc patch
            for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
                MeshSrc::FHandle f = meshSrc.paramedPatch_.faces_[i];
                if (!meshSrc.data(f).paint_in_)
                    continue;
                glBegin(GL_LINE_LOOP);
                for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v) {
                    MeshSrc::VertexData& vdata = meshSrc.data(v);
                    Vector3f p;
                    if (!flags_[5])
                        p = vdata.gc_data_.deformed_position_;
                    else if (vdata.stitch_vid_ != -1) {
                        StitchMesh::VHandle w = stitchMesh.vertex_handle(vdata.stitch_vid_);
                        p = stitchMesh.point(w);
                    } else
                        p = vdata.result_position_;
                    glVertex3f(p);
                }
                glEnd();
            }
            // stitchMesh
            if (flags_[7]) {
                for (StitchMesh::FIter f = stitchMesh.faces_begin(); f != stitchMesh.faces_end(); ++f) {
                    glBegin(GL_LINE_LOOP);
                    for (StitchMesh::FVIter v = stitchMesh.fv_iter(f); v; ++v)
                        glVertex3f(stitchMesh.point(v));
                    glEnd();
                }
            }
        }
    }
    if (flags_[0] || flags_[1]) {
        glColor3d(ColorList::EDGE_DEFAULT);
        glPushAttrib(GL_LINE_BIT);
        glLineWidth(3);
        glBegin(GL_LINES);
        for (size_t i = 0; i < meshTgt.paramedPatch_.edges_.size(); ++i) {
            MeshTgt::EHandle& e = meshTgt.paramedPatch_.edges_[i];
            bool flag = false;
            Vector3f points[2];
            for (int j = 0; j < 2; ++j) {
                MeshTgt::HHandle h = meshTgt.halfedge_handle(e, j);
                points[j] = meshTgt.point(meshTgt.to_vertex_handle(h));
                if (!meshTgt.data(meshTgt.face_handle(h)).paramed_)
                    flag = true;
            }
            if (flag) {
                glVertex3f(points[0]);
                glVertex3f(points[1]);
            }
        }
        glEnd();
        glPopAttrib();
    }
    if (flags_[3]) { // draw GCMesh
        glLineWidth(5);
        //glColor3d(ColorList::CAGE);
        int nb = static_cast<int>(cageGenMesh.boundary_.size());
        glColor3d(1, 0, 0);
        for (int i = 0; i < nb; ++i) {
            for (int j = 0; j < 2; ++j) {
                GCMesh::FHandle f = gcmesh.face_handle(2 * i + j);
                GCMesh::FVIter v = gcmesh.fv_iter(f);
                glColor3d(1, 0, 0);
                glBegin(GL_LINE_STRIP);
                glVertex3f(gcmesh.data(v).deformed_position_);  ++v;
                glVertex3f(gcmesh.data(v).deformed_position_);  ++v;
                glVertex3f(gcmesh.data(v).deformed_position_);
                glEnd();
                glColor3d(0.5, 0, 0);
                glBegin(GL_LINES);
                glVertex3f(gcmesh.data(v).deformed_position_);  ++v;
                glVertex3f(gcmesh.data(v).deformed_position_);
                glEnd();
            }
        }
        for (int i = nb; i < gcmesh.n_faces() / 2; ++i) {
            for (int j = 0; j < 2; ++j) {
                if (j == 0)
                    glColor3d(0, 1, 0);
                else
                    glColor3d(0, 0, 1);
                GCMesh::FHandle f = gcmesh.face_handle(2 * i + j);
                glBegin(GL_LINE_LOOP);
                for (GCMesh::FVIter v = gcmesh.fv_iter(f); v; ++v)
                    glVertex3f(gcmesh.data(v).deformed_position_);
                glEnd();
            }
        }
    }
    if (flags_[6]) {
        // draw GC-deformed source paramed patch
        phong_shader_.enable();
        phong_shader_.setAttrib1f("a_textured", 0.0f);
        glDisable(GL_CULL_FACE);
        glEnable(GL_POLYGON_OFFSET_FILL);
        glColor3d(ColorList::SRC_FACE_PARAMED);
        glBegin(GL_TRIANGLES);
        for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
            MeshSrc::FHandle f = meshSrc.paramedPatch_.faces_[i];
            for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v) {
                MeshSrc::VertexData& vdata = meshSrc.data(v);
                glNormal3f(meshSrc.data(v).gc_normal_);
                glVertex3f(meshSrc.data(v).gc_data_.deformed_position_);
            }
        }
        glEnd();
        phong_shader_.disable();
        glDisable(GL_POLYGON_OFFSET_FILL);
        if (flags_[1]) {  // draw edges
            glColor3d(ColorList::EDGE_DEFAULT);
            glLineWidth(1);
            for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
                MeshSrc::FHandle f = meshSrc.paramedPatch_.faces_[i];
                glBegin(GL_LINE_STRIP);
                for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v)
                    glVertex3f(meshSrc.data(v).gc_data_.deformed_position_);
                glEnd();
            }
        }
    }
    glPopAttrib();
    core.state_->draw_right();
}
void Drawer::paper_draw() {
    // +--------+-----------------+
    // | number | visualized data |
    // +--------+-----------------+
    // |   1    | Esrc(Psrc)      |
    // |   2    | Etgt(Ptgt)      |
    // |   3    |     Q           |
    // |   4    | Esrc(Rin)       |
    // |   5    | Etgt(Rout)      |
    // |   6    |     Fx          |
    // |   7    |     Fy          |
    // |   8    |     Fz          |
    // |   9    | S,��Rin,��Rout  |
    // +--------+-----------------+
    if (paper_drawMode_ == 6 ||
        paper_drawMode_ == 7 ||
        paper_drawMode_ == 8)
    {
        // 3D mode
        glPushMatrix();
        glLoadIdentity();
        gluLookAt(
            trackballLeft_.eyePoint_[0],
            trackballLeft_.eyePoint_[1],
            trackballLeft_.eyePoint_[2],
            trackballLeft_.focusPoint_[0],
            trackballLeft_.focusPoint_[1],
            trackballLeft_.focusPoint_[2],
            trackballLeft_.upDirection_[0],
            trackballLeft_.upDirection_[1],
            trackballLeft_.upDirection_[2]);
        // render offset membrane F (for each of X, Y, Z coordinates)
        const int NDIV = Config::PARAMSPACE_REZ;
        TextureBuffer4f& f = StatePaint::getInstance()->vcycle_.levels_[0].f_in();
        f.dump();
        TextureBuffer3f& buf_paint = core.paramSpace_.buf_paint_;
        buf_paint.dump();
        DisplayList& dispList =
            paper_drawMode_ == 6 ? dispList_Fx_ :
            paper_drawMode_ == 7 ? dispList_Fy_ : dispList_Fz_;
        if (dispList.needUpdate()) {
            // determine max and min value of fx
            float val_max = -FLT_MAX, val_min = FLT_MAX;
            for (int i = 0; i < NDIV; ++i)
                for (int j = 0; j < NDIV; ++j) {
                    Vector2f uv((i + 0.5f) / NDIV, (j + 0.5f) / NDIV);
                    Vector4f xyzw = f.getValue(uv);
                    float val =
                        paper_drawMode_ == 6 ? xyzw.x_ :
                        paper_drawMode_ == 7 ? xyzw.y_ : xyzw.z_;
                    if (val_max < val)
                        val_max = val;
                    if (val < val_min)
                        val_min = val;
                }
                float val_range = val_max - val_min;
                dispList.newList();
                checkerboard_texture_.bind();
                phong_shader_.enable();
                phong_shader_.setAttrib1f("a_textured", 1.0f);
                glBegin(GL_QUADS);
                for (int i = 0; i < NDIV; ++i)
                    for (int j = 0; j < NDIV; ++j)
                        for (int di = 0; di < 2; ++di)
                            for (int dj = 0; dj < 2; ++dj) {
                                Vector2f uv((j + (di == 0 ? dj : (1 - dj))) / (float)NDIV, (i + di) / (float)NDIV);
                                Vector4f xyzw = f.getValue(uv);
                                float val =
                                    paper_drawMode_ == 6 ? xyzw.x_ :
                                    paper_drawMode_ == 7 ? xyzw.y_ : xyzw.z_;
                                val = 0.125f * (val - val_min) / val_range + 0.125f;
                                float mask = buf_paint.getValue(uv).x_ - 0.5f;
                                if (mask < 0.0f)
                                    val = 0.0f;
                                GLUtil::glVertex3f_quadAutoNormal(Vector3f(uv.x_, uv.y_, val), uv);
                            }
                            glEnd();
                            phong_shader_.setAttrib1f("a_textured", 0.0f);
                            phong_shader_.disable();
                            checkerboard_texture_.unbind();
                            dispList.endList();
        } else
            dispList.callList();
        glLineWidth(5);
        glBegin(GL_LINES);
        glColor3d(1, 0, 0);    glVertex3d(0, 0, 0);    glVertex3d(1, 0, 0);
        glColor3d(0, 1, 0);    glVertex3d(0, 0, 0);    glVertex3d(0, 1, 0);
        glColor3d(0, 0, 0);    glVertex3d(0, 0, 0);    glVertex3d(0, 0, 0.5);
        glEnd();
        glPopMatrix();
    } else {    // 2D mode
        glPushMatrix();
        glLoadIdentity();
        gluLookAt(
            0.5, 0.5, 3,    // eye
            0.5, 0.5, 0,    // center
            0, 1, 0);   // up
        glDisable(GL_DEPTH_TEST);
        glDisable(GL_LIGHTING);
        if (paper_drawMode_ == 1 ||
            paper_drawMode_ == 2 ||
            paper_drawMode_ == 4 ||
            paper_drawMode_ == 5 ||
            paper_drawMode_ == 9)
        {
            glEnable(GL_TEXTURE_2D);
            checkerboard_texture_.bind();
            glBegin(GL_QUADS);
            glTexCoord2d(0, 0);  glVertex2d(0, 0);
            glTexCoord2d(1, 0);  glVertex2d(1, 0);
            glTexCoord2d(1, 1);  glVertex2d(1, 1);
            glTexCoord2d(0, 1);  glVertex2d(0, 1);
            glEnd();
            checkerboard_texture_.unbind();
            glDisable(GL_TEXTURE_2D);
        }
        if (paper_drawMode_ == 1) {     // Esrc(Psrc)
            glColor3d(ColorList::SRC_FACE_DEFAULT);
            glBegin(GL_TRIANGLES);
            for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
                MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
                for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v)
                    glVertex2f(meshSrc.data(v).expmap_data_.uv_);
            }
            glEnd();
            glColor3d(0, 0, 0);
            for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
                MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
                glBegin(GL_LINE_LOOP);
                for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v)
                    glVertex2f(meshSrc.data(v).expmap_data_.uv_);
                glEnd();
            }
            if (CageGenMesh::dbg_show_) {
                int nb = static_cast<int>(cageGenMesh.boundary_.size());
                glLineWidth(5);
                glColor3d(0, 1, 0.75);
                glBegin(GL_LINES);
                for (CageGenMesh::EIter e = cageGenMesh.edges_begin(); e != cageGenMesh.edges_end(); ++e) {
                    CageGenMesh::VHandle v[2];
                    for (int i = 0; i < 2; ++i) {
                        CageGenMesh::HHandle h = cageGenMesh.halfedge_handle(e, i);
                        v[i] = cageGenMesh.to_vertex_handle(h);
                    }
                    if (v[0].idx() < nb && v[1].idx() < nb)
                        continue;
                    glVertex2f(cageGenMesh.point(v[0]));
                    glVertex2f(cageGenMesh.point(v[1]));
                }
                glEnd();
                glColor3d(1, 0, 0);
                glBegin(GL_LINE_LOOP);
                for (int i = 0; i < nb; ++i) {
                    CageGenMesh::VHandle v = cageGenMesh.vertex_handle(i);
                    glVertex2f(cageGenMesh.point(v));
                }
                glEnd();
            }
        } else if (paper_drawMode_ == 2) {     // Etgt(Ptgt)
            glColor3d(ColorList::DST_FACE_DEFAULT);
            glBegin(GL_TRIANGLES);
            for (size_t i = 0; i < meshTgt.paramedPatch_.faces_.size(); ++i) {
                MeshTgt::FHandle& f = meshTgt.paramedPatch_.faces_[i];
                for (MeshTgt::FVIter v = meshTgt.fv_iter(f); v; ++v)
                    glVertex2f(meshTgt.data(v).expmap_data_.uv_);
            }
            glEnd();
            glColor3d(0, 0, 0);
            for (size_t i = 0; i < meshTgt.paramedPatch_.faces_.size(); ++i) {
                MeshTgt::FHandle& f = meshTgt.paramedPatch_.faces_[i];
                glBegin(GL_LINE_LOOP);
                for (MeshTgt::FVIter v = meshTgt.fv_iter(f); v; ++v)
                    glVertex2f(meshTgt.data(v).expmap_data_.uv_);
                glEnd();
            }
        } else if (paper_drawMode_ == 3) {     // Q
            glEnable(GL_TEXTURE_2D);
            core.paramSpace_.buf_paint_.texture_.bind();
            glBegin(GL_QUADS);
            glTexCoord2d(0, 0);  glVertex2d(0, 0);
            glTexCoord2d(1, 0);  glVertex2d(1, 0);
            glTexCoord2d(1, 1);  glVertex2d(1, 1);
            glTexCoord2d(0, 1);  glVertex2d(0, 1);
            glEnd();
            core.paramSpace_.buf_paint_.texture_.unbind();
            glDisable(GL_TEXTURE_2D);
        } else if (paper_drawMode_ == 4) {     // Esrc(Rin)
            glColor3d(ColorList::SRC_FACE_DEFAULT);
            glBegin(GL_TRIANGLES);
            for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
                MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
                if (!meshSrc.data(f).paint_in_)
                    continue;
                for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v)
                    glVertex2f(meshSrc.data(v).expmap_data_.uv_);
            }
            glEnd();
            glColor3d(0, 0, 0);
            for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
                MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
                if (!meshSrc.data(f).paint_in_)
                    continue;
                glBegin(GL_LINE_LOOP);
                for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v)
                    glVertex2f(meshSrc.data(v).expmap_data_.uv_);
                glEnd();
            }
        } else if (paper_drawMode_ == 5) {     // Etgt(Rout)
            glColor3d(ColorList::DST_FACE_DEFAULT);
            glBegin(GL_TRIANGLES);
            for (size_t i = 0; i < meshTgt.paramedPatch_.faces_.size(); ++i) {
                MeshTgt::FHandle& f = meshTgt.paramedPatch_.faces_[i];
                if (!meshTgt.data(f).paint_out_)
                    continue;
                for (MeshTgt::FVIter v = meshTgt.fv_iter(f); v; ++v)
                    glVertex2f(meshTgt.data(v).expmap_data_.uv_);
            }
            glEnd();
            glColor3d(0, 0, 0);
            for (size_t i = 0; i < meshTgt.paramedPatch_.faces_.size(); ++i) {
                MeshTgt::FHandle& f = meshTgt.paramedPatch_.faces_[i];
                if (!meshTgt.data(f).paint_out_)
                    continue;
                glBegin(GL_LINE_LOOP);
                for (MeshTgt::FVIter v = meshTgt.fv_iter(f); v; ++v)
                    glVertex2f(meshTgt.data(v).expmap_data_.uv_);
                glEnd();
            }
        } else {     // S,��Rin,��Rout
            glColor3d(ColorList::STITCH_FACE);
            glBegin(GL_TRIANGLES);
            for (StitchMesh::FIter f = stitchMesh.faces_begin(); f != stitchMesh.faces_end(); ++f) {
                for (StitchMesh::FVIter v = stitchMesh.fv_iter(f); v; ++v)
                    glVertex2f(stitchMesh.data(v).uv_);
            }
            glEnd();
            glColor3d(0, 0, 0);
            for (StitchMesh::FIter f = stitchMesh.faces_begin(); f != stitchMesh.faces_end(); ++f) {
                glBegin(GL_LINE_LOOP);
                for (StitchMesh::FVIter v = stitchMesh.fv_iter(f); v; ++v)
                    glVertex2f(stitchMesh.data(v).uv_);
                glEnd();
            }
            // ��Rin and ��Rout
            glLineWidth(3);
            glBegin(GL_LINES);
            for (StitchMesh::EIter e = stitchMesh.edges_begin(); e != stitchMesh.edges_end(); ++e) {
                bool flag = false;
                Vector2f uv[2];
                for (int i = 0; i < 2; ++i) {
                    StitchMesh::HHandle h = stitchMesh.halfedge_handle(e, i);
                    uv[i] = stitchMesh.data(stitchMesh.to_vertex_handle(h)).uv_;
                    StitchMesh::FHandle f = stitchMesh.face_handle(h);
                    if (!f.is_valid()) {
                        flag = true;
                        break;
                    }
                }
                if (flag) {
                    glVertex2f(uv[0]);
                    glVertex2f(uv[1]);
                }
            }
            glEnd();
        }
        // axis
        glLineWidth(5);
        glBegin(GL_LINES);
        glColor3d(1, 0, 0);        glVertex2d(0, 0);        glVertex2d(1, 0);
        glColor3d(0, 1, 0);        glVertex2d(0, 0);        glVertex2d(0, 1);
        glEnd();
        glPopMatrix();
    }
}
void Drawer::select_draw() {
    makeOpenGLCurrent();

    select_framebuffer_.bind();
    select_shader_.enable();
    glViewport(0, 0, width_, height_);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

    // left
    glViewport(0, 0, width_ / 2, height_);
    glPushMatrix();
    glLoadIdentity();
    gluLookAt(
        trackballLeft_.eyePoint_[0],
        trackballLeft_.eyePoint_[1],
        trackballLeft_.eyePoint_[2],
        trackballLeft_.focusPoint_[0],
        trackballLeft_.focusPoint_[1],
        trackballLeft_.focusPoint_[2],
        trackballLeft_.upDirection_[0],
        trackballLeft_.upDirection_[1],
        trackballLeft_.upDirection_[2]);
    if (select_dispList_left_.needUpdate()) {
        select_dispList_left_.newList();
        select_draw_left();
        select_dispList_left_.endList();
    } else {
        select_dispList_left_.callList();
    }
    glPopMatrix();

    // right
    glPushMatrix();
    glViewport(width_ / 2, 0, width_ / 2, height_);
    glLoadIdentity();
    gluLookAt(
        trackballRight_.eyePoint_[0],
        trackballRight_.eyePoint_[1],
        trackballRight_.eyePoint_[2],
        trackballRight_.focusPoint_[0],
        trackballRight_.focusPoint_[1],
        trackballRight_.focusPoint_[2],
        trackballRight_.upDirection_[0],
        trackballRight_.upDirection_[1],
        trackballRight_.upDirection_[2]);
    if (select_dispList_right_.needUpdate()) {
        select_dispList_right_.newList();
        select_draw_right();
        select_dispList_right_.endList();
    } else {
        select_dispList_right_.callList();
    }
    glPopMatrix();

    glFlush();
    select_shader_.disable();
    select_framebuffer_.unbind();
    GLUtil::checkError("Drawer::select_draw");
}
void Drawer::select_draw_left() {
    glBegin(GL_TRIANGLES);
    for (MeshSrc::FIter f = meshSrc.faces_begin(); f != meshSrc.faces_end(); ++f) {
        unsigned int id = f.handle().idx();        // face id
        assert (id < 0x1000000);
        Vector3uc pixel;
        pixel[0] = (id >> 16) & 0xFF;
        pixel[1] = (id >> 8 ) & 0xFF;
        pixel[2] = id & 0xFF;
        glColor3ubv(pixel.ptr());
        MeshSrc::FVIter v = meshSrc.fv_iter(f);
        for (int i = 0; v; ++v, ++i) {
            glSecondaryColor3f(i == 0 ? 1.0f : 0.0f, i == 1 ? 1.0f : 0.0f, 0.0f);            // fragment's baryCoord
            glVertex3fv(meshSrc.point (v).ptr());
        }
    }
    glEnd();
}
void Drawer::select_draw_right() {
    glBegin(GL_TRIANGLES);
    for (MeshTgt::FIter f = meshTgt.faces_begin(); f != meshTgt.faces_end(); ++f) {
        unsigned int id = meshSrc.n_faces() + f.handle().idx();            // face id
        assert (id < 0x1000000);
        Vector3uc pixel;
        pixel[0] = (id >> 16) & 0xFF;
        pixel[1] = (id >> 8 ) & 0xFF;
        pixel[2] = id & 0xFF;
        glColor3ubv(pixel.ptr());
        MeshTgt::FVIter v = meshTgt.fv_iter(f);
        for (int i = 0; v; ++v, ++i) {
            glSecondaryColor3f(i == 0 ? 1.0f : 0.0f, i == 1 ? 1.0f : 0.0f, 0.0f);            // fragment's baryCoord
            glVertex3fv(meshTgt.point (v).ptr());
        }
    }
    glEnd();
}

void Drawer::select(int x, int y, int& faceID, Vector3f& baryCoord)
{
    makeOpenGLCurrent();
    Vector3uc pixel_id;
    select_framebuffer_.bind();
    glReadBuffer(GL_COLOR_ATTACHMENT0_EXT);
    glReadPixels(x, y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, &pixel_id[0]);
    glReadBuffer(GL_COLOR_ATTACHMENT1_EXT);
    glReadPixels(x, y, 1, 1, GL_RGB, GL_FLOAT        , &baryCoord[0]);
    select_framebuffer_.unbind();
    faceID = (pixel_id.x_ << 16) | (pixel_id.y_ << 8) | pixel_id.z_;
    baryCoord[2] = 1.f - baryCoord[0] - baryCoord[1];
    if (faceID == 0xFFFFFF) {   // no intersections
        faceID = -1;
        return;
    }
    GLUtil::checkError("Drawer::select");
    GLUtil::checkFramebufferStatus("Drawer::select");
}

Vector3d Drawer::project_left (const Vector3d& worldPos ) const {
    makeOpenGLCurrent();
    glPushAttrib(GL_VIEWPORT_BIT);
    glViewport(0, 0, width_ / 2, height_);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluPerspective(persParam_.fovy_, 0.5 * width_ / static_cast<double>(height_), persParam_.zNear_, persParam_.zFar_);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    gluLookAt(
        trackballLeft_.eyePoint_[0],
        trackballLeft_.eyePoint_[1],
        trackballLeft_.eyePoint_[2],
        trackballLeft_.focusPoint_[0],
        trackballLeft_.focusPoint_[1],
        trackballLeft_.focusPoint_[2],
        trackballLeft_.upDirection_[0],
        trackballLeft_.upDirection_[1],
        trackballLeft_.upDirection_[2]);
    Vector3d screenPos = GLUtil::project(worldPos);
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glPopAttrib();
    return screenPos;
}
Vector3d Drawer::project_right(const Vector3d& worldPos ) const {
    makeOpenGLCurrent();
    glPushAttrib(GL_VIEWPORT_BIT);
    glViewport(width_ / 2, 0, width_ / 2, height_);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluPerspective(persParam_.fovy_, 0.5 * width_ / static_cast<double>(height_), persParam_.zNear_, persParam_.zFar_);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    gluLookAt(
        trackballRight_.eyePoint_[0],
        trackballRight_.eyePoint_[1],
        trackballRight_.eyePoint_[2],
        trackballRight_.focusPoint_[0],
        trackballRight_.focusPoint_[1],
        trackballRight_.focusPoint_[2],
        trackballRight_.upDirection_[0],
        trackballRight_.upDirection_[1],
        trackballRight_.upDirection_[2]);
    Vector3d screenPos = GLUtil::project(worldPos);
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glPopAttrib();
    return screenPos;
}

Drawer::Drawer()
: font_(0)
, paper_drawMode_(0)
{
    font_ = new FTGLPolygonFont(Config::FONT_FILENAME.c_str());
    if (font_->Error()) {
        cout << "Failed to read font: " << Config::FONT_FILENAME << endl;
        delete font_;
        font_ = 0;
    }
    for (int i = 0; i < 9; ++i)
        flags_[i] = true;
    flags_[1] = false;
    flags_[3] = false;
    flags_[4] = false;
    flags_[6] = false;
    flags_[8] = false;
}
Drawer::~Drawer() {
    if (font_)
        delete(font_);
}
