#include "StdAfx.h"
#include "StateParamTgt.h"
#include "StatePaint.h"
#include "Core.h"
using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
Drawer& drawer = core.drawer_;
MeshSrc& meshSrc = core.meshSrc_;
MeshTgt& meshTgt = core.meshTgt_;
StitchMesh& stitchMesh = core.stitchMesh_;
GCMesh& gcmesh = core.gcmesh_;
CageGenMesh& cageGenMesh = core.cageGenMesh_;
int dbg_cage_vid_ = 0;
bool dbg_show_frame_ = false;
bool dbg_show_goal_  = false;
}

State* StateParamTgt::next() {
    if (meshTgt.paramedPatch_.faces_.empty())
        return 0;
    step3_render_paramed();
    StatePaint::getInstance()->copy_paint_temp();
    drawer.dispList_meshSrc_all_faces_.requestUpdate();
    return StatePaint::getInstance();
}

void StateParamTgt::clear() {
    meshTgt.paramedPatch_.clear();
    meshTgt.expmap_info_.clear();
    for (MeshTgt::VIter v = meshTgt.vertices_begin(); v != meshTgt.vertices_end(); ++v) {
        MeshTgt::VertexData& vdata = meshTgt.data(v);
        vdata.paramed_ = false;
        vdata.expmap_data_.clear();
    }
    for (MeshTgt::FIter f = meshTgt.faces_begin(); f != meshTgt.faces_end(); ++f) {
        MeshTgt::FaceData& fdata = meshTgt.data(f);
        fdata.paramed_ = false;
    }
    for (size_t i = 0; i < meshSrc.paramedPatch_.vertices_.size(); ++i)
        meshSrc.data(meshSrc.paramedPatch_.vertices_[i]).gc_data_.deformed_position_ = Vector3f();
    for (GCMesh::VIter v = gcmesh.vertices_begin(); v != gcmesh.vertices_end(); ++v)
        gcmesh.data(v).deformed_position_ = Vector3f();
    for (GCMesh::FIter f = gcmesh.faces_begin(); f != gcmesh.faces_end(); ++f)
        gcmesh.data(f).deformed_normal_ = Vector3f();
    drawer.dispList_meshTgt_unparamed_faces_.requestUpdate();
    drawer.dispList_meshTgt_unparamed_edges_.requestUpdate();
}

void StateParamTgt::draw_left() {
    glPushAttrib(GL_ENABLE_BIT | GL_LINE_BIT | GL_POINT_BIT | GL_HINT_BIT);
    
    CageGenMesh::VHandle v = cageGenMesh.vertex_handle(dbg_cage_vid_);
    CageGenMesh::VertexData vdata = cageGenMesh.data(v);
    if (dbg_show_frame_) {
        Vector3f axis0, axis1;
        axis0 = vdata.original_normal_;
        axis1 = vdata.original_ugrad_;
        Vector3f  axis2 = axis0 % axis1;
        Vector3f& p = gcmesh.data(gcmesh.vertex_handle(2 * dbg_cage_vid_)).original_position_;
        glLineWidth(5);
        glBegin(GL_LINES);
        glColor3d(1, 1, 0);
        glVertex3f(p);
        glVertex3f(p + 0.1f * axis0);
        glColor3d(0, 1, 1);
        glVertex3f(p);
        glVertex3f(p + 0.1f * axis1);
        glColor3d(1, 0, 1);
        glVertex3f(p);
        glVertex3f(p + 0.1f * axis2);
        glEnd();
    }
    if (dbg_show_goal_) {
        glBegin(GL_LINES);
        glColor3d(0.5, 0.5, 0.5);
        glVertex3f(vdata.original_xyz_ - 1000.0f * vdata.original_normal_);
        glVertex3f(vdata.original_xyz_ + 1000.0f * vdata.original_normal_);
        glEnd();
        glPointSize(15);
        glEnable(GL_BLEND);
        glEnable(GL_POINT_SMOOTH);
        glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
        glBegin(GL_POINTS);
        glColor3d(0, 0, 0);
        glVertex3f(vdata.original_xyz_);
        glColor3d(0, 1, 0);
        glVertex3f(vdata.original_xyz_ + vdata.line_coef_[0] * vdata.original_normal_);
        glColor3d(0, 0, 1);
        glVertex3f(vdata.original_xyz_ + vdata.line_coef_[1] * vdata.original_normal_);
        glEnd();
    }
    
    // matrix rest for 2D draw
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0.0, drawer.width_ / 2, 0.0, drawer.height_);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    // draw gray transparent quad
    glDisable(GL_DEPTH_TEST);
    glDisable(GL_LIGHTING);
    glEnable(GL_BLEND);
    glColor4d(0.5, 0.5, 0.5, 0.5);
    glBegin(GL_QUADS);
    glVertex2d(0, 0);
    glVertex2d(drawer.width_ / 2, 0);
    glVertex2d(drawer.width_ / 2, drawer.height_);
    glVertex2d(0, drawer.height_);
    glEnd();
    // matrix restore from 2D draw
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    
    glPopAttrib();
}
void StateParamTgt::draw_right() {
    glPushAttrib(GL_ENABLE_BIT | GL_LINE_BIT | GL_POINT_BIT | GL_HINT_BIT);
    
    CageGenMesh::VHandle v = cageGenMesh.vertex_handle(dbg_cage_vid_);
    CageGenMesh::VertexData vdata = cageGenMesh.data(v);
    if (dbg_show_frame_) {
        Vector3f axis0 = vdata.deformed_normal_;
        Vector3f axis1 = vdata.deformed_ugrad_;
        Vector3f axis2 = axis0 % axis1;
        Vector3f& p = gcmesh.data(gcmesh.vertex_handle(2 * dbg_cage_vid_)).deformed_position_;
        glLineWidth(5);
        glBegin(GL_LINES);
        glColor3d(1, 1, 0);
        glVertex3f(p);
        glVertex3f(p + 0.1f * axis0);
        glColor3d(0, 1, 1);
        glVertex3f(p);
        glVertex3f(p + 0.1f * axis1);
        glColor3d(1, 0, 1);
        glVertex3f(p);
        glVertex3f(p + 0.1f * axis2);
        glEnd();
    }
    if (dbg_show_goal_) {
        glPointSize(15);
        glEnable(GL_BLEND);
        glEnable(GL_POINT_SMOOTH);
        glHint(GL_POINT_SMOOTH_HINT, GL_NICEST);
        glBegin(GL_POINTS);
        glColor3d(0, 0, 0);
        glVertex3f(vdata.deformed_xyz_);
        glEnd();
    }
    
    glPopAttrib();
}

void StateParamTgt::initGL() {
    shader_xyz_.init(); {
        ShaderObject frag;
        frag.setSource("void main() { gl_FragColor = gl_TexCoord[0]; }", ShaderObject::FRAGMENT_SHADER);
        shader_xyz_.attach(frag);
        shader_xyz_.link();
    }
}
void StateParamTgt::mouseLButtonDown(int x, int y, bool flagShift, bool flagCtrl) {
    if (x < drawer.width_ / 2)
        return;
    prevpos_.set(x, y);
    dragMode_ = flagShift ? DRAGMODE_ROTATE : flagCtrl ? DRAGMODE_SCALE : DRAGMODE_MOVE;
    if (dragMode_ == DRAGMODE_MOVE) {
        Vector3f right = (drawer.trackballRight_.eyeDirection() % drawer.trackballRight_.upDirection_).convert<float>();
        meshTgt.expmap_info_.seed_horizon_ = right;
    }
    mouseMove(x, y);
}
void StateParamTgt::mouseLButtonUp(int x, int y) {
    dragMode_ = DRAGMODE_NONE;
}
void StateParamTgt::mouseMove(int x, int y, bool flagShift, bool flagCtrl) {
    if (dragMode_ == DRAGMODE_NONE || x < drawer.width_ / 2)
        return;
    float dx = 2.0f * (x - prevpos_.x_) / (float)drawer.width_;
    if (dragMode_ == DRAGMODE_MOVE) {
        int faceID = 0;
        Vector3f baryCoord;
        drawer.select(x, drawer.height_ - 1 - y, faceID, baryCoord);
        if (faceID < 0)
            return;
        assert(core.meshSrc_.n_faces() <= faceID);
        faceID -= core.meshSrc_.n_faces();
        meshTgt.expmap_info_.seed_fhandle_   = meshTgt.face_handle(faceID);
        meshTgt.expmap_info_.seed_baryCoord_ = baryCoord;
    } else if (dragMode_ == DRAGMODE_ROTATE) {
        Vector3f& seed_horizon = meshTgt.expmap_info_.seed_horizon_;
        Vector3f& seed_normal  = meshTgt.expmap_info_.seed_normal_;
        seed_horizon = Util::rotationFromAxisAngle(seed_normal, dx) * seed_horizon;
    } else {
        meshTgt.expmap_info_.uv_scale_ *= (1.0f - dx);
    }
    is_dirty_ = true;
    prevpos_.set(x, y);
    drawer.dispList_meshTgt_unparamed_faces_.requestUpdate();
    drawer.dispList_meshTgt_unparamed_edges_.requestUpdate();
    redrawWindow();
}
bool StateParamTgt::step1_compute_expmap() {
    ClkStart clkStart(&clk_, 0);
    meshTgt.compute_expmap();
    return true;
}
bool StateParamTgt::step2_deform_gc() {
    ClkStart clkStart(&clk_, 1);
    bool result = cageGenMesh.cageGen_deformed();
    gcmesh.init_deformed();
    meshSrc.compute_gc_deform();
    cout << (result ? "succeed!" : "failed.") << endl;
    return result;
}
bool StateParamTgt::step3_render_paramed() {
    ClkSimple clk("StateParamTgt::step3_render_paramed");
    core.framebuffer_.bind();
    core.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, core.paramSpace_.buf_src_.texture_);
    GLUtil::checkFramebufferStatus();
    
    // viewport and camera setting
    glPushAttrib(GL_VIEWPORT_BIT | GL_ENABLE_BIT | GL_COLOR_BUFFER_BIT);
    glViewport(0, 0, Config::PARAMSPACE_REZ, Config::PARAMSPACE_REZ);
    glDisable(GL_LIGHTING);
    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
    gluOrtho2D(0, 1, 0, 1);
    glMatrixMode(GL_MODELVIEW);
    glPushMatrix();
    glLoadIdentity();
    glClearColor(0, 0, 0, 0);
    shader_xyz_.enable();
    // render src (after GC deformation)
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glBegin(GL_TRIANGLES);
    for (size_t i = 0; i < meshSrc.paramedPatch_.faces_.size(); ++i) {
        MeshSrc::FHandle& f = meshSrc.paramedPatch_.faces_[i];
        for (MeshSrc::FVIter v = meshSrc.fv_iter(f); v; ++v) {
            Vector3f& xyz = meshSrc.data(v).gc_data_.deformed_position_;
            Vector2f& uv  = meshSrc.data(v).expmap_data_.uv_;
            glTexCoord4f(Vector4f(xyz, 1.0f));
            glVertex2f  (uv);
        }
    }
    glEnd();
    
    // render tgt
    core.framebuffer_.attachTexture(GL_COLOR_ATTACHMENT0_EXT, core.paramSpace_.buf_tgt_.texture_);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glBegin(GL_TRIANGLES);
    for (size_t i = 0; i < meshTgt.paramedPatch_.faces_.size(); ++i) {
        MeshTgt::FHandle& f = meshTgt.paramedPatch_.faces_[i];
        for (MeshTgt::FVIter v = meshTgt.fv_iter(f); v; ++v) {
            Vector3f& xyz = meshTgt.point(v);
            Vector2f& uv  = meshTgt.data(v).expmap_data_.uv_;
            glTexCoord3f(xyz);
            glVertex2f  (uv);
        }
    }
    glEnd();
    shader_xyz_.disable();
    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);
    glPopMatrix();
    glPopAttrib();
    core.framebuffer_.unbind();
    
    // dump
    core.paramSpace_.buf_src_.dump();
    core.paramSpace_.buf_tgt_.dump();
    GLUtil::checkError();
    return true;
}
void StateParamTgt::keyDown(char ascii) {
    switch (ascii) {
        case 8: // backspace
            core.gotoParamSrc();
            break;
        case 10:
        case 13:    // ENTER key
            core.bake_edit();
            break;
        case 'z':
        case 'Z':
            dbg_cage_vid_ = (dbg_cage_vid_ + 1) % cageGenMesh.n_vertices();
            break;
        case 'x':
        case 'X':
            dbg_cage_vid_ = (dbg_cage_vid_ + cageGenMesh.n_vertices() - 1) % cageGenMesh.n_vertices();
            break;
        case 'c':
        case 'C':
            dbg_show_frame_ = !dbg_show_frame_;
            break;
        case 'v':
        case 'V':
            dbg_show_goal_ = !dbg_show_goal_;
            break;
    }
}
void StateParamTgt::keyDown(SpecialKey key) {
}

void StateParamTgt::on_draw() {
    if (!is_dirty_)
        return;
    clk_.resetTick();
    StatePaint* statePaint = StatePaint::getInstance();
    bool result =
        step1_compute_expmap() &&
        step2_deform_gc() &&
        (statePaint->paintBoundaries_.empty() ||
        step3_render_paramed() &&
        statePaint->step3_extract_paintBoundary() &&
        statePaint->step4_compute_offset() &&
        statePaint->step5_stitch());
    cout << (result ? "succeed!" : "failed.") << endl;
    clk_.print();
    is_dirty_ = false;
}
StateParamTgt::StateParamTgt(void)
: dragMode_(DRAGMODE_NONE)
, clk_("ParamTgt")
, is_dirty_(false)
{
    clk_.addEntry("compute_expmap");
    clk_.addEntry("deform_gc");
}
