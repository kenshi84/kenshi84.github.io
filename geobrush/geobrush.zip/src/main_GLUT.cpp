#include "stdafx.h"

//---- to enable using MFC's file dialog ----+
#define WINVER 0x0502                     // |
#include <afxdlgs.h>                      // |
//-------------------------------------------+

#include <sstream>
#include "CoreAPI.h"
#include "Config.h"
//#include <gl/glut.h>
#include <openglut/openglut.h>
#include "system_dependent.h"
using namespace std;

int glut_windowID_ = 0;

// system_dependent functions begin--------------------------------------
void redrawWindow() {
    glutPostRedisplay();
}
void makeOpenGLCurrent() {
    int hoge = glutGetWindow();
    glutSetWindow(glut_windowID_);
}
string showFileDialog(bool open_mode, const vector<string>& file_extensions, const char* dialog_title) {
    ostringstream oss;
    if (!file_extensions.empty()) {
        oss << "All supported files (";
        size_t sz = file_extensions.size();
        for (size_t i = 0; i < sz; ++i) {
            oss << "*." << file_extensions[i];
            if (i < sz - 1)
                oss << ", ";
        }
        oss << ")|";
        for (size_t i = 0; i < sz; ++i) {
            oss << "*." << file_extensions[i];
            if (i < sz - 1)
                oss << ";";
        }
        oss << "|";
        for (size_t i = 0; i < sz; ++i)
            oss << file_extensions[i] << " files (*." << file_extensions[i] << ")|*." << file_extensions[i] << "|";
    }
    oss << "All files (*.*)|*.*||";
	DWORD flags_open = OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR;
	DWORD flags_save = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT | OFN_NOCHANGEDIR;
    CFileDialog dialog(open_mode, 0, 0, open_mode ? flags_open : flags_save, oss.str().c_str(), NULL);
    if (dialog_title)
        dialog.GetOFN().lpstrTitle = dialog_title;
	if (dialog.DoModal() != IDOK)
		return "";
	return string(dialog.GetPathName());
}
bool confirmMessage(const char* message) {
    return ::MessageBox(0, message, "GeoBrush", MB_OKCANCEL) == IDOK;
}
void showMessage(const char* message) {
    ::MessageBox(0, message, "GeoBrush", MB_OK);
}
// system_dependent functions end--------------------------------------

void glut_display() {
    CoreAPI::draw();
    glutSwapBuffers();
}

void glut_mouse(int button, int state, int x, int y) {
    bool flagShift = glutGetModifiers() == GLUT_ACTIVE_SHIFT;
    bool flagCtrl  = glutGetModifiers() == GLUT_ACTIVE_CTRL;

    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_DOWN)
            CoreAPI::mouseLButtonDown(x, y, flagShift, flagCtrl);
        else
            CoreAPI::mouseLButtonUp(flagShift, flagCtrl);
    } else if (button == GLUT_RIGHT_BUTTON) {
        if (state == GLUT_DOWN)
            CoreAPI::mouseRButtonDown(x, y, flagShift, flagCtrl);
        else
            CoreAPI::mouseRButtonUp(flagShift, flagCtrl);
    } else {
        if (state == GLUT_DOWN)
            CoreAPI::mouseMButtonDown(x, y, flagShift, flagCtrl);
        else
            CoreAPI::mouseMButtonUp(flagShift, flagCtrl);
    }
}
void glut_motion(int x, int y) {
    bool flagShift = glutGetModifiers() == GLUT_ACTIVE_SHIFT;
    bool flagCtrl  = glutGetModifiers() == GLUT_ACTIVE_CTRL;
    CoreAPI::mouseMove(x, y, flagShift, flagCtrl);
}

void glut_keyboard (unsigned char key, int x, int y) { CoreAPI::keyDown(key); }
void glut_special (int key, int x, int y) {
    CoreAPI::keyDown(
          key == GLUT_KEY_F1 ? KEY_F1
        : key == GLUT_KEY_F2 ? KEY_F2
        : key == GLUT_KEY_F3 ? KEY_F3
        : key == GLUT_KEY_F4 ? KEY_F4
        : key == GLUT_KEY_F5 ? KEY_F5
        : key == GLUT_KEY_F6 ? KEY_F6
        : key == GLUT_KEY_F7 ? KEY_F7
        : key == GLUT_KEY_F8 ? KEY_F8
        : key == GLUT_KEY_F9 ? KEY_F9
        : key == GLUT_KEY_F10 ? KEY_F10
        : key == GLUT_KEY_F11 ? KEY_F11
        : key == GLUT_KEY_F12 ? KEY_F12
        : key == GLUT_KEY_LEFT  ? KEY_LEFT 
        : key == GLUT_KEY_UP    ? KEY_UP   
        : key == GLUT_KEY_RIGHT ? KEY_RIGHT
        : key == GLUT_KEY_DOWN  ? KEY_DOWN 
        : key == GLUT_KEY_PAGE_UP   ? KEY_PGUP
        : key == GLUT_KEY_PAGE_DOWN ? KEY_PGDN
        : key == GLUT_KEY_HOME ? KEY_HOME
        : key == GLUT_KEY_END  ? KEY_END
        : KEY_INSERT);
}
void glut_mouseWheel(int wheel, int direction, int x, int y) { CoreAPI::mouseWheel(direction, x, y); }

int main(int argc, char* argv[]) {
    CoreAPI::startApp();
    // to enable using MFC's file dialog
	InitCommonControls();
	AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0);
    
    glutInit (&argc, argv);
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH);
    glutInitWindowPosition(5, 5);
    glutInitWindowSize(Config::WINDOW_WIDTH, Config::WINDOW_HEIGHT);
    glut_windowID_ = glutCreateWindow("GeoBrush");
    
    glutDisplayFunc(glut_display);
    glutReshapeFunc(CoreAPI::resize);
    glutKeyboardFunc(glut_keyboard);
    glutSpecialFunc(glut_special);
    glutMouseFunc(glut_mouse);
    glutMotionFunc(glut_motion);
    glutMouseWheelFunc(glut_mouseWheel);
    glutPassiveMotionFunc(glut_motion);
    
    CoreAPI::initGL();
    
    glutMainLoop();
    
    return 0;
}
