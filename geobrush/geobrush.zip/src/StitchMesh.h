#pragma once
#include <OpenMesh/Core/Mesh/Traits.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>
#include <KLIB/Vector.h>
#include "MeshSrc.h"
#include "MeshTgt.h"

struct StitchMeshTraits : public OpenMesh::DefaultTraits {
    typedef KLIB::Vector3f Point;
    typedef KLIB::Vector3f Normal;
    VertexTraits {
    public:
        MeshSrc::VHandle vhandle_src_;
        MeshTgt::VHandle vhandle_tgt_;
        KLIB::Vector2f uv_;
    };
};

struct StitchMesh : public OpenMesh::TriMesh_ArrayKernelT<StitchMeshTraits> {
    void compute_normal();
};
