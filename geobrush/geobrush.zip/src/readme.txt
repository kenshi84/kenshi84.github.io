GeoBrush usage (2010/09/30)

<Camera control>
You can do it by dragging with the right mouse button. Dragging with nothing/SHIFT/CTRL pressed down causes rotation/zoom/pan.
In the following, all input is made through the left mouse button.

<Step 1: Source parameterization mode>
Drag over the model to specify the canvas patch for the source mesh. The point where you start dragging is the "origin" of the cloning; this corresponds precisely to another "origin" point on the target, which you will specify later. Once you release the mouse button, the painted region gets parameterized. You can increase/decrease the brush radius by scrolling the mouse wheel up/down or pressing UP/DOWN keys. You can rotate the parameterization afterward by SHIFT + dragging toward right/left.
Make sure that the painted area is disc topology in the screen space (i.e., no interior holes are allowed). Also you will probably not get desired results if the paint boundary crosses the model's silhouette, so you should avoid that (in fact, the paint wraps around the back faces across the silhouette). Note that the "up" direction of the parameterization is aligned to the screen-space "up" direction.
When you are done with the parameterization, hit SPACE to proceed to the next step.
(For debugging only)
* You can enable/disable the Laplacian mesh optimization for the source cage by hitting 'Z'.
* You can show/hide the base 2D mesh from which the GC cage mesh is derived by hitting 'X' (only when GC cage is visualized).

<Step 2: Target parameterization mode>
You can specify the center of the canvas by clicking over the model. Again, the "up" direction of the parameterization is aligned to the screen-space "up" direction, and you can rotate it by SHIFT + dragging. You can also change its scaling (i.e., enlarge/shrink the canvas) by CTRL + dragging toward right/left.
When you are done with the parameterization, hit SPACE to proceed to the next step.

<Step 3: Painting mode>
You can paint the ROI by dragging over either the source or the target canvas patches. SHIFT + dragging does a negative painting (i.e., erasing). You can increase/decrease the brush radius by scrolling the mouse wheel up/down or pressing UP/DOWN keys.
When you are done with the painting, hit ENTER to bake the edit into the target mesh going back to Step 2. You can also go back to Step 2 while retaining the current ROI by hitting SPACE.
(For debugging only)
* You can enable/disable derivative constraints for the offset membrane by hitting 'Z'.
* You can enable/disable automatic ROI correction by hitting 'X'.
* You can switch to membrane testing mode by hitting 'C'.
* You can enable/disable outputting membrane solution and constraints (x-coordinate only) by hitting 'V'. (These .txt files are compatible with gnuplot data format. The solution and constraints are in the first and second columns, respectively.)

<Common>
* In Steps 2 and 3, you can go back to Step 1 immediately by hitting BACKSPACE.

* At any time, you can load source/target meshes and start over from Step 1 by hitting 'L'.

* After you bake the edit in Step 3, hit 'S' to save the target mesh.

* You can exit from the system by hitting ESC.

* '1' ~ '9' keys toggle various display switches.
1: Faces
2: Edges
3: Texture (DEM/paint)
4: GC cages
5: different colors for the cloned source patch and the stitch mesh, ROI boundary in 3D
6: cloned source patch without the offset membrane
7: source canvas patch (original, GC-deformed)
8: show/hide stitch mesh
9: world XYZ axes

* You can see various debugging information (parameterization, ROI, offset membrane, etc.) by hitting TAB few times. Offset membranes are rendered in 3D, whose camera control is shared by that for the left screen.
