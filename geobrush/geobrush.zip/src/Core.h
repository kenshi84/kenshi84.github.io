#pragma once
#include <GL/glew.h>
#include "EventHandler.h"
#include "Drawer.h"
#include "MeshSrc.h"
#include "MeshTgt.h"
#include "GCMesh.h"
#include "CageGenMesh.h"
#include "StitchMesh.h"
#include "State.h"
#include "Config.h"
#include "system_dependent.h"
#include <KLIB/Polyline.h>

class Core {
public:
    static Core& getInstance() {
        static Core p;
        return p;
    }
    Config config_;
    EventHandler handler_;
    Drawer       drawer_;
    State*       state_;
    
    Core(void);
    ~Core(void);
    void initGL();
    void deinitGL() {}
    
    MeshSrc meshSrc_;
    MeshTgt meshTgt_;
    GCMesh gcmesh_;
    CageGenMesh cageGenMesh_;
    StitchMesh stitchMesh_;
    
    void loadMesh();
    
    void gotoParamSrc();
    void bake_edit();
    
    KLIB::FramebufferObject framebuffer_;
    struct ParamSpace {
        KLIB::TextureBuffer4f buf_src_;         // w-channel contains a mask flag
        KLIB::TextureBuffer3f buf_tgt_;
        KLIB::TextureBuffer3f buf_paint_;       // painted region
        void init();
    } paramSpace_;
};
