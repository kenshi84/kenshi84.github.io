#pragma once
#include "specialkey.h"
#include <string>

class State {
protected:
    State() {}
    ~State() {}
public:
    virtual State* next() { return 0; } // returns a pointer to the next state if it's ready, 0 otherwise
    virtual void clear() {}             // clear everything edited within the state
    virtual std::string message() const { return ""; }
    
    virtual void draw_left () {}
    virtual void draw_right() {}
    virtual void mouseLButtonDown(int x, int y, bool flagShift = false, bool flagCtrl = false) {}
    virtual void mouseLButtonUp(int x, int y) {}
    virtual void mouseMove(int x, int y, bool flagShift = false, bool flagCtrl = false) {}
    virtual void mouseWheel(int direction, int x, int y) {}
    virtual void keyDown(char ascii) {}
    virtual void keyDown(SpecialKey key) {}
};
