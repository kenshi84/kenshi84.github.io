#pragma once
#include <vector>
#include <KLIB/Vector.h>
#include <KLIB/GLSLUtil.h>
#include <KLIB/Clock.h>

class VCycle {
public:
    struct Level {
        int rez_;           // resolution
        bool inout_flag_;
        KLIB::TextureBuffer4f f_ [2];            // actual value
        KLIB::TextureBuffer4f gu_[2];           // u-direction gradient
        KLIB::TextureBuffer4f gv_[2];           // v-direction gradient
        KLIB::TextureBuffer4f& f_in  () { return inout_flag_ ? f_ [1] : f_ [0]; }
        KLIB::TextureBuffer4f& gu_in () { return inout_flag_ ? gu_[1] : gu_[0]; }
        KLIB::TextureBuffer4f& gv_in () { return inout_flag_ ? gv_[1] : gv_[0]; }
        KLIB::TextureBuffer4f& f_out () { return inout_flag_ ? f_ [0] : f_ [1]; }
        KLIB::TextureBuffer4f& gu_out() { return inout_flag_ ? gu_[0] : gu_[1]; }
        KLIB::TextureBuffer4f& gv_out() { return inout_flag_ ? gv_[0] : gv_[1]; }
        void  swap_inout() { inout_flag_ = !inout_flag_; }
        
        // ctor
        Level()
            : rez_(0)
            , inout_flag_(false)
        {}
    };
    
    std::vector<Level> levels_;
    
    KLIB::ProgramObject shader_smooth_f_;
    KLIB::ProgramObject shader_smooth_gu_;
    KLIB::ProgramObject shader_smooth_gv_;
    KLIB::ProgramObject shader_restrict_;
    KLIB::ProgramObject shader_prolong_;
    
    KLIB::FramebufferObject framebuffer_;
    
    KLIB::ClkData clk_smooth_;
    KLIB::ClkData clk_restrict_;
    KLIB::ClkData clk_prolong_;
    
    VCycle(void);
    ~VCycle(void);
    
    void init();        // initialize framebuffer, load shaders, allocate texture memory
    
    void update();
    void vcycle(int levelID);
    
    void smooth  (int levelID);
    void restrict(int levelID);
    void prolong (int levelID);
    
    void bind_output  (const KLIB::TextureObject& texture);
    void unbind_output(const KLIB::TextureObject& texture);
};
