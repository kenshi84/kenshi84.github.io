#pragma once
#include <KLIB/Vector.h>

struct ExpMapData {  // per-vertex data for computing ExpMap
    bool  visited_;
    float distance_;
    float weightTotal_;
    KLIB::Vector2f uv_;
    ExpMapData ()
        : visited_    (false)
        , distance_   (FLT_MAX)
        , weightTotal_(0.0f)
    {}
    void clear() { *this = ExpMapData(); }
};

