#pragma once
#include "State.h"
#include <KLIB/Polyline.h>
#include <KLIB/Clock.h>
#include <KLIB/GLUtil.h>
#include "MeshSrc.h"

class StateParamSrc : public State {
    StateParamSrc(void);
    ~StateParamSrc(void) {}
public:
    static StateParamSrc* getInstance() {
        static StateParamSrc p;
        return &p;
    }
    
    State* next();
    void clear();
    std::string message() const { return "Source Parameterization Mode"; }
    void draw_left();
    void draw_right();
    void mouseLButtonDown(int x, int y, bool flagShift = false, bool flagCtrl = false);
    void mouseLButtonUp(int x, int y);
    void mouseMove(int x, int y, bool flagShift = false, bool flagCtrl = false);
    void mouseWheel(int direction, int x, int y);
    void keyDown(char ascii);
    void keyDown(SpecialKey key);
    
    KLIB::Vector2i prevpos_;
    enum DragMode {
        DRAGMODE_DRAW,
        DRAGMODE_ROTATE,
        DRAGMODE_NONE,
    } dragMode_;
    float brushSize_;
    KLIB::Vector2i mousePos_;
    KLIB::TextureBuffer4f screenBuf_;
    MeshSrc::FHandle f_seed_;
    
    KLIB::ClkData clk_;
    bool step1_calc_patch();
    bool step2_interp_normal();
    bool step3_compute_expmap();
    bool step4_make_gcmesh();
};
