#pragma once
#include <KLIB/Vector.h>
#include <KLIB/Matrix.h>
#include <KLIB/Polyline.h>
#include <KLIB/KdTree.h>
#include <OpenMesh/Core/IO/MeshIO.hh>
#include <OpenMesh/Core/Mesh/Traits.hh>
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>

struct CageGenMeshTraits : public OpenMesh::DefaultTraits {
    typedef KLIB::Vector2f Point;       // uv
    VertexTraits {
    public:
        KLIB::Vector3f original_normal_;                // normal used for DEM
        KLIB::Vector3f original_ugrad_;                 // u-gradient direction (with normal, forms a 3x3 rotation matrix)
        KLIB::Vector3f original_xyz_;
        KLIB::Vector3f deformed_normal_;
        KLIB::Vector3f deformed_ugrad_;
        KLIB::Vector3f deformed_xyz_;
        
        // a line used to determine goal positions for original geometry: f(t) = original_xyz_ + t * original_normal_
        float line_coef_[2];                // [0]: maximum (top face), [1]: minimum (bottom face)
        
        VertexT() {
            line_coef_[0] = -FLT_MAX;
            line_coef_[1] =  FLT_MAX;
        }
    };
};
struct CageGenMesh : public OpenMesh::TriMesh_ArrayKernelT<CageGenMeshTraits> {
    KLIB::Polyline2f boundary_;
    
    KLIB::KdTree2d uv_kdTree_;
    
    CageGenMesh() {}
    
    bool cageGen_original();
    bool original_step1_compute_boundary();
    bool original_step2_triangulate();
    bool original_step3_set_configuration();        // set original_normal, original_ugrad, original_xyz
    bool original_step4_project_line();
    bool original_step5_optimize_position();
    
    bool cageGen_deformed();
    bool deformed_step1_set_configuration();        // set deformed_normal, deformed_ugrad, deformed_xyz
    bool deformed_step2_optimize_position();
    static bool dbg_use_laplacian_optimization_;
    static bool dbg_show_;
};
