#pragma once
#include "specialkey.h"
#include <KLIB/Trackball.h>

class EventHandler {
public:
    EventHandler(void);
    ~EventHandler(void);
    
    KLIB::Trackball* trackball_;
    
    void mouseLButtonDown(int x, int y, bool flagShift = false, bool flagCtrl = false);
    void mouseRButtonDown(int x, int y, bool flagShift = false, bool flagCtrl = false);
    void mouseMButtonDown(int x, int y, bool flagShift = false, bool flagCtrl = false);
    void mouseLButtonUp(int x, int y);
    void mouseRButtonUp(int x, int y);
    void mouseMButtonUp(int x, int y);
    void mouseMove(int x, int y, bool flagShift = false, bool flagCtrl = false);
    void mouseWheel(int direction, int x, int y);
    void keyDown(char ascii);
    void keyDown(SpecialKey key);
};
