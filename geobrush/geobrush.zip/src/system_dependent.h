#pragma once
#include <vector>
#include <string>

void redrawWindow();
void makeOpenGLCurrent();
std::string showFileDialog(bool open_mode, const std::vector<std::string>& file_extensions = std::vector<std::string>(), const char* dialog_title = 0);
bool confirmMessage(const char* message);
void showMessage(const char* message);
