#include "StdAfx.h"
#include "EventHandler.h"
#include "Core.h"
#include <iostream>
#include <KLIB/Clock.h>
using namespace std;
using namespace KLIB;

namespace {
Core& core = Core::getInstance();
Drawer& drawer = core.drawer_;
MeshTgt& meshTgt = core.meshTgt_;
}

void EventHandler::mouseLButtonDown(int x, int y, bool flagShift, bool flagCtrl) {
    core.state_->mouseLButtonDown(x, y, flagShift, flagCtrl);
}
void EventHandler::mouseLButtonUp(int x, int y) {
    core.state_->mouseLButtonUp(x, y);
}
void EventHandler::mouseRButtonDown(int x, int y, bool flagShift, bool flagCtrl) {
    trackball_ = x < core.drawer_.width_ / 2 ? &core.drawer_.trackballLeft_ : &core.drawer_.trackballRight_;
    trackball_->mouseDown(x, y,
        flagShift ? Trackball::DRAGMODE_ZOOM :
        flagCtrl  ? Trackball::DRAGMODE_PAN  : Trackball::DRAGMODE_ROTATE);
}
void EventHandler::mouseRButtonUp(int x, int y) {
    trackball_ ->mouseUp();
    trackball_ = 0;
    core.drawer_.select_draw();
}
void EventHandler::mouseMButtonDown(int x, int y, bool flagShift, bool flagCtrl) {}
void EventHandler::mouseMButtonUp(int x, int y) {}
void EventHandler::mouseMove(int x, int y, bool flagShift, bool flagCtrl) {
    if (trackball_) {   // camera control
        trackball_->mouseMove(x, y);
        redrawWindow();
        return;
    }
    core.state_->mouseMove(x, y, flagShift, flagCtrl);
}
void EventHandler::mouseWheel(int direction, int x, int y) {
    core.state_->mouseWheel(direction, x, y);
}
void EventHandler::keyDown(char ascii) {
    switch (ascii) {
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
            drawer.flags_[ascii - '1'] = !drawer.flags_[ascii - '1'];
            drawer.dispList_meshSrc_all_faces_.requestUpdate();
            redrawWindow();
            break;
        case 'l':
        case 'L':
            core.loadMesh();
            break;
        case 's':
        case 'S':
            {
                vector<string> file_extensions;
                file_extensions.push_back("obj");
                file_extensions.push_back("off");
                file_extensions.push_back("ply");
                file_extensions.push_back("stl");
                file_extensions.push_back("om");
                string fname = showFileDialog(false, file_extensions, "Save edited mesh");
                if (fname.empty())
                    return;
                meshTgt.save(fname);
            }
            break;
        case ' ':
            {
                State* next_state = core.state_->next();
                if (next_state) {
                    core.state_ = next_state;
                    redrawWindow();
                }
            }
            break;
        case 9:     // tab key
            drawer.paper_drawMode_ = (drawer.paper_drawMode_ + 1) % 10;
            cout << "paper_drawMode: " << drawer.paper_drawMode_ << endl;
            redrawWindow();
            break;
        case 27:    // ESC key
            if (confirmMessage("Exit the system?"))
                exit(0);
            break;
        default:
            core.state_->keyDown(ascii);
    }
}
void EventHandler::keyDown(SpecialKey key) {
    core.state_->keyDown(key);
}
EventHandler::EventHandler(void)
: trackball_(0)
{
}
EventHandler::~EventHandler(void) {}
