#pragma once
#include <KLIB/Polyline.h>
#include <KLIB/GLSLUtil.h>
#include <KLIB/Clock.h>
#include "VCycle.h"
#include "State.h"

class StatePaint : public State {
    StatePaint(void);
    ~StatePaint(void) {}
public:
    static StatePaint* getInstance() {
        static StatePaint p;
        return &p;
    }
    State* next();
    void clear();
    std::string message() const;
    void draw_left();
    void draw_right();
    void mouseLButtonDown(int x, int y, bool flagShift = false, bool flagCtrl = false);
    void mouseLButtonUp(int x, int y);
    void mouseMove(int x, int y, bool flagShift = false, bool flagCtrl = false);
    void mouseWheel(int direction, int x, int y);
    void keyDown(char ascii);
    void keyDown(SpecialKey key);
    
    enum DragMode {
        DRAGMODE_PAINT,
        DRAGMODE_ERASE,
        DRAGMODE_NONE,
    } dragMode_;
    
    float brushSize_;
    
    VCycle vcycle_;
    KLIB::ProgramObject shader_vcycle_input_;
    
    struct PaintBoundary {
        KLIB::Polyline2f uv_;
        KLIB::Polyline3f xyz_;          // only needed for visualization purposes
        void clear() { *this = PaintBoundary(); }
        size_t size() const { return uv_.size(); }
        bool empty() const { return uv_.empty(); }
    };
    std::vector<PaintBoundary> paintBoundaries_;
    
    void initGL();
    
    KLIB::TextureObject paint_temp_;        // temporary texture to show brush size
    void copy_paint_temp();
    
    bool step1_render_paint(const KLIB::Vector2f& uv);
    bool step2_modify_paint();
    bool step3_extract_paintBoundary();
    bool step4_compute_offset();
    bool step5_stitch();              // stitch the gap by performing Delaunay triangulation in uv space
    KLIB::ClkData clk_;
    
    void draw_brush();
    KLIB::Vector2f draw_brush_uv_;
    bool draw_brush_is_dirty_;
    
    bool is_dirty_;
    void on_draw();
};
