#include <vector>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include "stb_image.c"

const int N = 3;    // neighborhood size
const int R = 3;    // synthesis levels
const double HM_WEIGHT = 1000;     // weight of histogram matching

struct Color {
    double m_red, m_green, m_blue;
    Color() : m_red(0), m_green(0), m_blue(0) {}
    Color& operator+=(const Color& rhs) {
        m_red   += rhs.m_red;
        m_green += rhs.m_green;
        m_blue  += rhs.m_blue;
        return *this;
    }
    Color& operator*=(double rhs) {
        m_red   *= rhs;
        m_green *= rhs;
        m_blue  *= rhs;
        return *this;
    }
    double distance(const Color& color) const {
        double d_red   = m_red   - color.m_red  ;
        double d_green = m_green - color.m_green;
        double d_blue  = m_blue  - color.m_blue ;
        return d_red * d_red + d_green * d_green + d_blue * d_blue;
    }
};

struct Pixel {
    Color m_color;
};

struct Image {
    std::vector<Pixel> m_pixel;
    int m_width, m_height;
    Image () : m_width(0), m_height(0) {}
    void resize(int width, int height) {
        m_pixel.resize(width * height);
        m_width  = width;
        m_height = height;
    }
    Pixel& pixel(int i, int j) {
        return m_pixel[i + m_width * j];
    }
    const Pixel& pixel(int i, int j) const {
        return m_pixel[i + m_width * j];
    }
};

struct NearestNeighborInfo {
    int m_index;
    double m_distance;
    NearestNeighborInfo() : m_index(-1), m_distance(10000000.0) {}
};

struct Voxel {
    Color m_color;
    NearestNeighborInfo m_nnInfo_x;
    NearestNeighborInfo m_nnInfo_y;
    NearestNeighborInfo m_nnInfo_z;
};

struct Volume {
    std::vector<Voxel> m_voxel;
    int m_dim;      // always same dimensions for 3 axes
    Volume() : m_dim(0) {}
    void resize(int dim) {
        m_voxel.resize(dim * dim * dim);
        m_dim = dim;
    }
    Voxel& voxel(int ix, int iy, int iz) {
        return m_voxel[ix + m_dim * (iy + m_dim * iz)];
    }
    const Voxel& voxel(int ix, int iy, int iz) const {
        return m_voxel[ix + m_dim * (iy + m_dim * iz)];
    }
};

struct Neighbor {
    Color m_color[(2 * N + 1) * (2 * N + 1)];
    Color& color(int du, int dv) {
        return m_color[N + du + (2 * N + 1) * (N + dv)];
    }
    const Color& color(int du, int dv) const {
        return m_color[N + du + (2 * N + 1) * (N + dv)];
    }
    double distance(const Neighbor& neighbor) const {
        double result = 0;
        for (int i = 0; i < (2 * N + 1) * (2 * N + 1); ++i)
            result += m_color[i].distance(neighbor.m_color[i]);
        return result;
    }
};

int mod(int index, int modulo) {
    while (index < 0)
        index += modulo;
    return index % modulo;
}

Neighbor get_neighbor(const Image& img, int i, int j) {
    Neighbor neighbor;
    for (int du = -N; du <= N; ++du)
    for (int dv = -N; dv <= N; ++dv)
    {
        neighbor.color(du, dv) = img.pixel(i + du, j + dv).m_color;
    }
    return neighbor;
}

Neighbor get_neighbor_x(const Volume& vol, int ix, int iy, int iz) {
    Neighbor neighbor;
    for (int du = -N; du <= N; ++du)
    for (int dv = -N; dv <= N; ++dv)
    {
        int iy2 = mod(iy + du, vol.m_dim);
        int iz2 = mod(iz + dv, vol.m_dim);
        neighbor.color(du, dv) = vol.voxel(ix, iy2, iz2).m_color;
    }
    return neighbor;
}
Neighbor get_neighbor_y(const Volume& vol, int ix, int iy, int iz) {
    Neighbor neighbor;
    for (int du = -N; du <= N; ++du)
    for (int dv = -N; dv <= N; ++dv)
    {
        int iz2 = mod(iz + du, vol.m_dim);
        int ix2 = mod(ix + dv, vol.m_dim);
        neighbor.color(du, dv) = vol.voxel(ix2, iy, iz2).m_color;
    }
    return neighbor;
}
Neighbor get_neighbor_z(const Volume& vol, int ix, int iy, int iz) {
    Neighbor neighbor;
    for (int du = -N; du <= N; ++du)
    for (int dv = -N; dv <= N; ++dv)
    {
        int ix2 = mod(ix + du, vol.m_dim);
        int iy2 = mod(iy + dv, vol.m_dim);
        neighbor.color(du, dv) = vol.voxel(ix2, iy2, iz).m_color;
    }
    return neighbor;
}

std::vector<Neighbor> collect_neighbors_sample(const Image& img_sample) {
    std::vector<Neighbor> neighbors_sample;
    for (int j = N; j < img_sample.m_height - N; ++j)
    for (int i = N; i < img_sample.m_width  - N; ++i)
    {
        neighbors_sample.push_back(get_neighbor(img_sample, i, j));
    }
    return neighbors_sample;
}

void init(
    Volume& vol_synth,
    const Image& img_sample_x,
    const Image& img_sample_y,
    const Image& img_sample_z
) {
    for (int iz = 0; iz < vol_synth.m_dim; ++iz)
    for (int iy = 0; iy < vol_synth.m_dim; ++iy)
    for (int ix = 0; ix < vol_synth.m_dim; ++ix)
    {
        int axis = rand() % 3;
        vol_synth.voxel(ix, iy, iz).m_color =
            axis == 0 ? img_sample_x.pixel(rand() % img_sample_x.m_width, rand() % img_sample_x.m_height).m_color :
            axis == 1 ? img_sample_y.pixel(rand() % img_sample_y.m_width, rand() % img_sample_y.m_height).m_color :
                        img_sample_z.pixel(rand() % img_sample_z.m_width, rand() % img_sample_z.m_height).m_color;
    }
}

void search(
    Volume& vol_synth,
    const std::vector<Neighbor>& neighbors_sample_x,
    const std::vector<Neighbor>& neighbors_sample_y,
    const std::vector<Neighbor>& neighbors_sample_z
) {
    int cnt = 0;
    int cnt_max = vol_synth.m_voxel.size();
    clock_t clk = std::clock();
#pragma omp parallel for
    for (int iz = 0; iz < vol_synth.m_dim; ++iz)
    for (int iy = 0; iy < vol_synth.m_dim; ++iy)
    for (int ix = 0; ix < vol_synth.m_dim; ++ix)
    {
        Voxel& voxel = vol_synth.voxel(ix, iy, iz);
        Neighbor neighbor_synth_x = get_neighbor_x(vol_synth, ix, iy, iz);
        Neighbor neighbor_synth_y = get_neighbor_y(vol_synth, ix, iy, iz);
        Neighbor neighbor_synth_z = get_neighbor_z(vol_synth, ix, iy, iz);
        voxel.m_nnInfo_x = NearestNeighborInfo();
        voxel.m_nnInfo_y = NearestNeighborInfo();
        voxel.m_nnInfo_z = NearestNeighborInfo();
        // along x-axis
        for (int k = 0; k < neighbors_sample_x.size(); ++k) {
            double d = neighbor_synth_x.distance(neighbors_sample_x[k]);
            if (d < voxel.m_nnInfo_x.m_distance) {
                voxel.m_nnInfo_x.m_index    = k;
                voxel.m_nnInfo_x.m_distance = d;
            }
        }
        // along y-axis
        for (int k = 0; k < neighbors_sample_y.size(); ++k) {
            double d = neighbor_synth_y.distance(neighbors_sample_y[k]);
            if (d < voxel.m_nnInfo_y.m_distance) {
                voxel.m_nnInfo_y.m_index    = k;
                voxel.m_nnInfo_y.m_distance = d;
            }
        }
        // along z-axis
        for (int k = 0; k < neighbors_sample_z.size(); ++k) {
            double d = neighbor_synth_z.distance(neighbors_sample_z[k]);
            if (d < voxel.m_nnInfo_z.m_distance) {
                voxel.m_nnInfo_z.m_index    = k;
                voxel.m_nnInfo_z.m_distance = d;
            }
        }
        std::cout << "searching...";
        ++cnt;
        if (cnt < cnt_max) {
            int percent = 100 * cnt / cnt_max;
            std::cout << percent << "%\r";
        }
    }
    std::cout << "done!(" << ((std::clock() - clk) / CLOCKS_PER_SEC) << "sec)\n";
}

struct Histogram {
    static const int NUM_BIN = 16;
    int m_bin[NUM_BIN];
    int m_total;
    Histogram() {
        for (int i = 0; i < NUM_BIN; ++i)
            m_bin[i] = 0;
        m_total = 0;
    }
    void add_count(double value) {
        ++m_bin[get_bin_index(value)];
        ++m_total;
    }
    double get_count_normalized(double value) const {
        if (m_total == 0)
            return 0;
        return m_bin[get_bin_index(value)] / static_cast<double>(m_total);
    }
private:
    int get_bin_index(double value) const {
        value = std::max<double>(0, std::min<double>(1, value));
        if (value == 1)
            return NUM_BIN - 1;
        return static_cast<int>(value * NUM_BIN) % NUM_BIN;
    }
};

void calc_histogram(const Image& img, Histogram& hist_red, Histogram& hist_green, Histogram& hist_blue) {
    for (int j = 0; j < img.m_height; ++j)
    for (int i = 0; i < img.m_width ; ++i)
    {
        const Color& color = img.pixel(i, j).m_color;
        hist_red  .add_count(color.m_red  );
        hist_green.add_count(color.m_green);
        hist_blue .add_count(color.m_blue );
    }
}

void optimize(
    Volume& vol_synth,
    const std::vector<Neighbor>& neighbors_sample_x,
    const std::vector<Neighbor>& neighbors_sample_y,
    const std::vector<Neighbor>& neighbors_sample_z,
    const Histogram& hist_sample_red  ,
    const Histogram& hist_sample_green,
    const Histogram& hist_sample_blue 
) {
    int cnt = 0;
    int cnt_max = vol_synth.m_voxel.size();
    clock_t clk = std::clock();
    Histogram hist_synth_red  ;
    Histogram hist_synth_green;
    Histogram hist_synth_blue ;
#pragma omp parallel for
    for (int iz = 0; iz < vol_synth.m_dim; ++iz)
    for (int iy = 0; iy < vol_synth.m_dim; ++iy)
    for (int ix = 0; ix < vol_synth.m_dim; ++ix)
    {
        Voxel& voxel = vol_synth.voxel(ix, iy, iz);
        voxel.m_color = Color();
        double sum_weight = 0;
        
        // along x-axis
        for (int dy = -N; dy <= N; ++dy)
        for (int dz = -N; dz <= N; ++dz)
        {
            int iy2 = mod(iy + dy, vol_synth.m_dim);
            int iz2 = mod(iz + dz, vol_synth.m_dim);
            const Voxel& voxel_neighbor = vol_synth.voxel(ix, iy2, iz2);
            const Neighbor& neighbor = neighbors_sample_x[voxel_neighbor.m_nnInfo_x.m_index];
            Color color = neighbor.color(-dy, -dz);
            double weight = std::pow(voxel_neighbor.m_nnInfo_x.m_distance, -1.2);
            
            // histogram matching
            double hist_factor = 0;
            hist_factor += std::max<double>(0, hist_synth_red  .get_count_normalized(color.m_red  ) - hist_sample_red  .get_count_normalized(color.m_red  ));
            hist_factor += std::max<double>(0, hist_synth_green.get_count_normalized(color.m_green) - hist_sample_green.get_count_normalized(color.m_green));
            hist_factor += std::max<double>(0, hist_synth_blue .get_count_normalized(color.m_blue ) - hist_sample_blue .get_count_normalized(color.m_blue ));
            weight /= 1 + HM_WEIGHT * hist_factor;
            
            color *= weight;
            voxel.m_color += color;
            sum_weight += weight;
        }
        // along y-axis
        for (int dz = -N; dz <= N; ++dz)
        for (int dx = -N; dx <= N; ++dx)
        {
            int iz2 = mod(iz + dz, vol_synth.m_dim);
            int ix2 = mod(ix + dx, vol_synth.m_dim);
            const Voxel& voxel_neighbor = vol_synth.voxel(ix2, iy, iz2);
            const Neighbor& neighbor = neighbors_sample_y[voxel_neighbor.m_nnInfo_y.m_index];
            Color color = neighbor.color(-dz, -dx);
            double weight = std::pow(voxel_neighbor.m_nnInfo_y.m_distance, -1.2);
            
            // histogram matching
            double hist_factor = 0;
            hist_factor += std::max<double>(0, hist_synth_red  .get_count_normalized(color.m_red  ) - hist_sample_red  .get_count_normalized(color.m_red  ));
            hist_factor += std::max<double>(0, hist_synth_green.get_count_normalized(color.m_green) - hist_sample_green.get_count_normalized(color.m_green));
            hist_factor += std::max<double>(0, hist_synth_blue .get_count_normalized(color.m_blue ) - hist_sample_blue .get_count_normalized(color.m_blue ));
            weight /= 1 + HM_WEIGHT * hist_factor;
            
            color *= weight;
            voxel.m_color += color;
            sum_weight += weight;
        }
        // along z-axis
        for (int dx = -N; dx <= N; ++dx)
        for (int dy = -N; dy <= N; ++dy)
        {
            int ix2 = mod(ix + dx, vol_synth.m_dim);
            int iy2 = mod(iy + dy, vol_synth.m_dim);
            const Voxel& voxel_neighbor = vol_synth.voxel(ix2, iy2, iz);
            const Neighbor& neighbor = neighbors_sample_z[voxel_neighbor.m_nnInfo_z.m_index];
            Color color = neighbor.color(-dx, -dy);
            double weight = std::pow(voxel_neighbor.m_nnInfo_z.m_distance, -1.2);
            
            // histogram matching
            double hist_factor = 0;
            hist_factor += std::max<double>(0, hist_synth_red  .get_count_normalized(color.m_red  ) - hist_sample_red  .get_count_normalized(color.m_red  ));
            hist_factor += std::max<double>(0, hist_synth_green.get_count_normalized(color.m_green) - hist_sample_green.get_count_normalized(color.m_green));
            hist_factor += std::max<double>(0, hist_synth_blue .get_count_normalized(color.m_blue ) - hist_sample_blue .get_count_normalized(color.m_blue ));
            weight /= 1 + HM_WEIGHT * hist_factor;
            
            color *= weight;
            voxel.m_color += color;
            sum_weight += weight;
        }
        voxel.m_color *= 1 / sum_weight;
        hist_synth_red  .add_count(voxel.m_color.m_red  );
        hist_synth_green.add_count(voxel.m_color.m_green);
        hist_synth_blue .add_count(voxel.m_color.m_blue );
        std::cout << "optimizing...";
        ++cnt;
        if (cnt < cnt_max) {
            int percent = 100 * cnt / cnt_max;
            std::cout << percent << "%\r";
        }
    }
    std::cout << "done!(" << ((std::clock() - clk) / CLOCKS_PER_SEC) << "sec)\n";
}
int load_image(Image& img, const char* filename) {
    int width, height, comp;
    unsigned char *data = stbi_load(filename, &width, &height, &comp, 3);
    if (!data)
        return 1;
    img.resize(width, height);
    for (int j = 0; j < height; ++j)
    for (int i = 0; i < width ; ++i)
    {
        Color& color = img.pixel(i, j).m_color;
        color.m_red   = data[3 * (i + width * j)    ] / 255.;
        color.m_green = data[3 * (i + width * j) + 1] / 255.;
        color.m_blue  = data[3 * (i + width * j) + 2] / 255.;
    }
    stbi_image_free(data);
    return 0;
}

struct VolumeHeader {
	char magic[4];
	int version;
	char texName[256];
	bool wrap;
	int volSize;
	int numChannels;
	int bytesPerChannel;
    // http://johanneskopf.de/publications/solid/textures/file_format.txt
};

int save_volume(const Volume& vol, const char* filename) {
    char buf[4096];
    VolumeHeader* header = reinterpret_cast<VolumeHeader *>(buf);
    sprintf(header->magic, "VOLU");
    header->version = 4;
    sprintf(header->texName, filename);
    header->wrap = true;
    header->volSize = vol.m_dim;
    header->numChannels = 3;
    header->bytesPerChannel = 1;
    std::vector<unsigned char> data(vol.m_voxel.size() * 3, 0);
    for (int i = 0; i < vol.m_voxel.size(); ++i) {
        const Color& color = vol.m_voxel[i].m_color;
        data[3 * i    ] = static_cast<unsigned char>(color.m_red   * 255);
        data[3 * i + 1] = static_cast<unsigned char>(color.m_green * 255);
        data[3 * i + 2] = static_cast<unsigned char>(color.m_blue  * 255);
    }
    FILE* fout = fopen(filename, "wb");
    fwrite(buf, 4096, 1, fout);
    fwrite(&data[0], 1, data.size(), fout);
    fclose(fout);
    return 0;
}

void downsample(Image& img_low, const Image& img_high) {
    img_low.resize((img_high.m_width + 1) / 2, (img_high.m_height + 1) / 2);
    for (int j = 0; j < img_low.m_height; ++j)
    for (int i = 0; i < img_low.m_width ; ++i)
    {
        Color& color = img_low.pixel(i, j).m_color;
        color = Color();
        color += img_high.pixel(2 * i    , 2 * j    ).m_color;
        color += img_high.pixel(2 * i + 1, 2 * j    ).m_color;
        color += img_high.pixel(2 * i    , 2 * j + 1).m_color;
        color += img_high.pixel(2 * i + 1, 2 * j + 1).m_color;
        color *= 0.25;
    }
}
void downsample(Volume& vol_low, const Volume& vol_high) {
    vol_low.resize((vol_high.m_dim + 1) / 2);
    for (int iz = 0; iz < vol_low.m_dim; ++iz)
    for (int iy = 0; iy < vol_low.m_dim; ++iy)
    for (int ix = 0; ix < vol_low.m_dim; ++ix)
    {
        Color& color = vol_low.voxel(ix, iy, iz).m_color;
        color = Color();
        color += vol_high.voxel(2 * ix    , 2 * iy    , 2 * iz    ).m_color;
        color += vol_high.voxel(2 * ix + 1, 2 * iy    , 2 * iz    ).m_color;
        color += vol_high.voxel(2 * ix    , 2 * iy + 1, 2 * iz    ).m_color;
        color += vol_high.voxel(2 * ix + 1, 2 * iy + 1, 2 * iz    ).m_color;
        color += vol_high.voxel(2 * ix    , 2 * iy    , 2 * iz + 1).m_color;
        color += vol_high.voxel(2 * ix + 1, 2 * iy    , 2 * iz + 1).m_color;
        color += vol_high.voxel(2 * ix    , 2 * iy + 1, 2 * iz + 1).m_color;
        color += vol_high.voxel(2 * ix + 1, 2 * iy + 1, 2 * iz + 1).m_color;
        color *= 0.125;
    }
}
void upsample(const Volume& vol_low, Volume& vol_high) {
    for (int iz = 0; iz < vol_high.m_dim; ++iz)
    for (int iy = 0; iy < vol_high.m_dim; ++iy)
    for (int ix = 0; ix < vol_high.m_dim; ++ix)
    {
        vol_high.voxel(ix, iy, iz).m_color = vol_low.voxel(ix / 2, iy / 2, iz / 2).m_color;
    }
}

int main(int argc, char** argv) {
    if (argc != 6 + R) {
        std::cout << "usage:\n" << argv[0] << " input_x.png input_y.png input_z.png output_dim output.vol";
        for (int i = 0; i < R; ++i)
            std::cout << " num_iter_" << i;
        std::cout << std::endl;
        return 1;
    }
    int num_iter[R];
    for (int i = 0; i < R; ++i)
        num_iter[i] = atoi(argv[6 + i]);
    bool is_num_iter_set = num_iter[0] != 0;
    
    // build sample image pyramid
    Image img_sample_x[R];
    Image img_sample_y[R];
    Image img_sample_z[R];
    if (load_image(img_sample_x[R - 1], argv[1])) {
        std::cout << "failed to load " << argv[1] << std::endl;
        return 1;
    }
    if (load_image(img_sample_y[R - 1], argv[2])) {
        std::cout << "failed to load " << argv[2] << std::endl;
        return 1;
    }
    if (load_image(img_sample_z[R - 1], argv[3])) {
        std::cout << "failed to load " << argv[3] << std::endl;
        return 1;
    }
    for (int i = R - 1; i > 0; --i) {
        downsample(img_sample_x[i - 1], img_sample_x[i]);
        downsample(img_sample_y[i - 1], img_sample_y[i]);
        downsample(img_sample_z[i - 1], img_sample_z[i]);
    }
    
    // calculate sample image histogram
    Histogram hist_sample_red  [R];
    Histogram hist_sample_green[R];
    Histogram hist_sample_blue [R];
    for (int i = 0; i < R; ++i) {
        calc_histogram(img_sample_x[i], hist_sample_red[i], hist_sample_green[i], hist_sample_blue[i]);
        calc_histogram(img_sample_y[i], hist_sample_red[i], hist_sample_green[i], hist_sample_blue[i]);
        calc_histogram(img_sample_z[i], hist_sample_red[i], hist_sample_green[i], hist_sample_blue[i]);
    }
    
    // collect sample neighbors
    std::vector<Neighbor> neighbors_sample_x[R];
    std::vector<Neighbor> neighbors_sample_y[R];
    std::vector<Neighbor> neighbors_sample_z[R];
    for (int i = 0; i < R; ++i) {
        neighbors_sample_x[i] = collect_neighbors_sample(img_sample_x[i]);
        neighbors_sample_y[i] = collect_neighbors_sample(img_sample_y[i]);
        neighbors_sample_z[i] = collect_neighbors_sample(img_sample_z[i]);
    }
    
    // build synth volume pyramid
    Volume vol_synth[R];
    vol_synth[R - 1].resize(std::atoi(argv[4]));
    srand(time(0));
    for (int i = R - 1; i > 0; --i)
        downsample(vol_synth[i - 1], vol_synth[i]);
    init(vol_synth[0], img_sample_x[0], img_sample_y[0], img_sample_z[0]);
    
    clock_t clk = std::clock();
    for (int level = 0; level < R; ) {
        save_volume(vol_synth[level], argv[5]);
        if (!is_num_iter_set) {
            std::cout << "number of iterations to perform: ";
            std::cin >> num_iter[level];
            num_iter[level] = std::max<int>(1, num_iter[level]);
        }
        for (int i = 0; i < num_iter[level]; ++i) {
            search(
                vol_synth[level],
                neighbors_sample_x[level],
                neighbors_sample_y[level],
                neighbors_sample_z[level]);
            optimize(
                vol_synth[level],
                neighbors_sample_x[level],
                neighbors_sample_y[level],
                neighbors_sample_z[level],
                hist_sample_red  [level],
                hist_sample_green[level],
                hist_sample_blue [level]);
            save_volume(vol_synth[level], argv[5]);
        }
        if (is_num_iter_set && level < R - 1) {
            std::cout << "upsample!\n";
        } else {
            if (level == R - 1)
                continue;
            std::cout << "upsample? (y/n): ";
            char c;
            std::cin >> c;
            if (c != 'y')
                continue;
        }
        if (level < R - 1)
            upsample(vol_synth[level], vol_synth[level + 1]);
        ++level;
    }
    std::cout << "done!(" << ((std::clock() - clk) / (CLOCKS_PER_SEC * 60)) << "min)\n";
    return 0;
}
