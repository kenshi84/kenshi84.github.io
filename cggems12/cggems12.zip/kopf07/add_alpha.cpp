// ad-hoc code to add alpha value to RGB volume by simple thresholding
#include <iostream>
#include <vector>

struct VolumeHeader {
    char magic[4];
    int version;
    char texName[256];
    bool wrap;
    int volSize;
    int numChannels;
    int bytesPerChannel;
};
struct Volume {
    VolumeHeader m_header;
    std::vector<unsigned char> m_data;
};

int read_volume(Volume& vol, const char* filename) {
    FILE* fin = fopen(filename, "rb");
    if (!fin) {
        printf("cannot open %s\n", filename);
        return 1;
    }
    
    char buf[4096];
    fread(buf, 4096, 1, fin);
    vol.m_header = *reinterpret_cast<VolumeHeader *>(buf);
    if (!strcmp(vol.m_header.magic, "VOLU")) {
        printf("wrong magic\n");
        return 1;
    }
    if (vol.m_header.bytesPerChannel != 1) {
        printf("only 1 byte per channel is supported\n");
        return 1;
    }

    vol.m_data.resize(vol.m_header.volSize * vol.m_header.volSize * vol.m_header.volSize * vol.m_header.numChannels);
    fread(&vol.m_data[0], 1, vol.m_data.size(), fin);
    fclose(fin);
    return 0;
}

int write_volume(const Volume& vol, const char* filename) {
    FILE* fout = fopen(filename, "wb");
    if (!fout) {
        printf("cannot open %s\n", filename);
        return 1;
    }
    
    char buf[4096];
    *reinterpret_cast<VolumeHeader *>(buf) = vol.m_header;
    fwrite(buf, 4096, 1, fout);
    
    fwrite(&vol.m_data[0], 1, vol.m_data.size(), fout);
    fclose(fout);
    return 0;
}

void main(int argc, char** argv) {
    if (argc != 4) {
        std::cout << "usage :\n" << argv[0] << " input_rgb.vol uint_threshold output_rgba.vol\n";
        return;
    }
    Volume vol_in, vol_out;
    if (read_volume(vol_in, argv[1])) {
        std::cout << "failed to read " << argv[1] << std::endl;
        return;
    }
    if (vol_in.m_header.numChannels != 3) {
        std::cout << argv[1] << " is not in RGB format\n";
        return;
    }
    vol_out = vol_in;
    vol_out.m_header.numChannels = 4;
    unsigned int threshold = atoi(argv[2]);
    vol_out.m_data.resize(4 * vol_out.m_header.volSize * vol_out.m_header.volSize * vol_out.m_header.volSize);
    for (int i = 0; i < vol_in.m_data.size() / 3; ++i) {
        unsigned int sum = 0;
        for (int j = 0; j < 3; ++j) {
            vol_out.m_data[4 * i + j] = vol_in.m_data[3 * i + j];
            sum += vol_in.m_data[3 * i + j];
        }
        bool test = sum < threshold;
        //bool test = threshold < vol_in.m_data[3 * i + 2];
        if (test) {
            for (int j = 0; j < 3; ++j)
                vol_out.m_data[4 * i + j] /= 2;
        }
        vol_out.m_data[4 * i + 3] = test ? 10 : 255;
    }
    if (write_volume(vol_out, argv[3])) {
        std::cout << "failed to write " << argv[3] << std::endl;
        return;
    }
}
