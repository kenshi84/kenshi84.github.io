#include <vector>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include "stb_image.c"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

const int N = 3;    // neighborhood size
const int R = 3;    // synthesis levels
const double HM_WEIGHT = 100;     // weight of histogram matching

struct Color {
    double m_red, m_green, m_blue;
    Color() : m_red(0), m_green(0), m_blue(0) {}
    Color& operator+=(const Color& rhs) {
        m_red   += rhs.m_red;
        m_green += rhs.m_green;
        m_blue  += rhs.m_blue;
        return *this;
    }
    Color& operator*=(double rhs) {
        m_red   *= rhs;
        m_green *= rhs;
        m_blue  *= rhs;
        return *this;
    }
    double distance(const Color& color) const {
        double d_red   = m_red   - color.m_red  ;
        double d_green = m_green - color.m_green;
        double d_blue  = m_blue  - color.m_blue ;
        return d_red * d_red + d_green * d_green + d_blue * d_blue;
    }
};

struct NearestNeighborInfo {
    int m_index;
    double m_distance;
    NearestNeighborInfo() : m_index(-1), m_distance(10000000.0) {}
};

struct Pixel {
    Color m_color;
    NearestNeighborInfo m_nnInfo;
};

struct Image {
    std::vector<Pixel> m_pixel;
    int m_width, m_height;
    Image () : m_width(0), m_height(0) {}
    void resize(int width, int height) {
        m_pixel.resize(width * height);
        m_width  = width;
        m_height = height;
    }
    Pixel& pixel(int i, int j) {
        return m_pixel[i + m_width * j];
    }
    const Pixel& pixel(int i, int j) const {
        return m_pixel[i + m_width * j];
    }
};

struct Neighbor {
    Color m_color[(2 * N + 1) * (2 * N + 1)];
    Color& color(int dx, int dy) {
        return m_color[N + dx + (2 * N + 1) * (N + dy)];
    }
    const Color& color(int dx, int dy) const {
        return m_color[N + dx + (2 * N + 1) * (N + dy)];
    }
    double distance(const Neighbor& neighbor) const {
        double sum_d = 0;
        for (int i = 0; i < (2 * N + 1) * (2 * N + 1); ++i)
            sum_d += m_color[i].distance(neighbor.m_color[i]);
        return sum_d;
    }
};

int mod(int index, int modulo) {
    while (index < 0)
        index += modulo;
    return index % modulo;
}

Neighbor get_neighbor(const Image& img, int i, int j) {
    Neighbor neighbor;
    for (int dy = -N; dy <= N; ++dy)
    for (int dx = -N; dx <= N; ++dx)
    {
        int i2 = mod(i + dx, img.m_width);
        int j2 = mod(j + dy, img.m_height);
        neighbor.color(dx, dy) = img.pixel(i2, j2).m_color;
    }
    return neighbor;
}

std::vector<Neighbor> collect_neighbors_sample(const Image& img_sample) {
    std::vector<Neighbor> neighbors_sample;
    for (int j = N; j < img_sample.m_height - N; ++j)
    for (int i = N; i < img_sample.m_width  - N; ++i)
    {
        neighbors_sample.push_back(get_neighbor(img_sample, i, j));
    }
    return neighbors_sample;
}

void init(Image& img_synth, const Image& img_sample) {
    for (int j = 0; j < img_synth.m_height; ++j)
    for (int i = 0; i < img_synth.m_width ; ++i)
    {
        img_synth.pixel(i, j).m_color = img_sample.pixel(
            rand() % img_sample.m_width,
            rand() % img_sample.m_height).m_color;
    }
}

void search(Image& img_synth, const std::vector<Neighbor>& neighbors_sample) {
    int cnt = 0;
    int cnt_max = img_synth.m_pixel.size();
    clock_t clk = std::clock();
#pragma omp parallel for
    for (int j = 0; j < img_synth.m_height; ++j)
    for (int i = 0; i < img_synth.m_width ; ++i)
    {
        Pixel& p = img_synth.pixel(i, j);
        Neighbor neighbor_synth = get_neighbor(img_synth, i, j);
        p.m_nnInfo = NearestNeighborInfo();
        for (int k = 0; k < neighbors_sample.size(); ++k) {
            double d = neighbor_synth.distance(neighbors_sample[k]);
            if (d < p.m_nnInfo.m_distance) {
                p.m_nnInfo.m_index    = k;
                p.m_nnInfo.m_distance = d;
            }
        }
        std::cout << "searching...";
        ++cnt;
        if (cnt < cnt_max) {
            int percent = 100 * cnt / cnt_max;
            std::cout << percent << "%\r";
        }
    }
    std::cout << "done!(" << ((std::clock() - clk) / CLOCKS_PER_SEC) << "sec)\n";
}

struct Histogram {
    static const int NUM_BIN = 16;
    int m_bin[NUM_BIN];
    int m_total;
    Histogram() {
        for (int i = 0; i < NUM_BIN; ++i)
            m_bin[i] = 0;
        m_total = 0;
    }
    void add_count(double value) {
        ++m_bin[get_bin_index(value)];
        ++m_total;
    }
    double get_count_normalized(double value) const {
        if (m_total == 0)
            return 0;
        return m_bin[get_bin_index(value)] / static_cast<double>(m_total);
    }
private:
    int get_bin_index(double value) const {
        value = std::max<double>(0, std::min<double>(1, value));
        if (value == 1)
            return NUM_BIN - 1;
        return static_cast<int>(value * NUM_BIN);
    }
};

void calc_histogram(const Image& img, Histogram& hist_red, Histogram& hist_green, Histogram& hist_blue) {
    for (int j = 0; j < img.m_height; ++j)
    for (int i = 0; i < img.m_width ; ++i)
    {
        const Color& color = img.pixel(i, j).m_color;
        hist_red  .add_count(color.m_red  );
        hist_green.add_count(color.m_green);
        hist_blue .add_count(color.m_blue );
    }
}

void optimize(
    Image& img_synth,
    const std::vector<Neighbor>& neighbors_sample,
    const Histogram& hist_sample_red,
    const Histogram& hist_sample_green,
    const Histogram& hist_sample_blue
) {
    int cnt = 0;
    int cnt_max = img_synth.m_pixel.size();
    clock_t clk = std::clock();
    Histogram hist_synth_red  ;
    Histogram hist_synth_green;
    Histogram hist_synth_blue ;
#pragma omp parallel for
    for (int j = 0; j < img_synth.m_height; ++j)
    for (int i = 0; i < img_synth.m_width ; ++i)
    {
        Pixel& p = img_synth.pixel(i, j);
        p.m_color = Color();
        double sum_weight = 0;
        for (int dy = -N; dy <= N; ++dy)
        for (int dx = -N; dx <= N; ++dx)
        {
            int i2 = mod(i + dx, img_synth.m_width);
            int j2 = mod(j + dy, img_synth.m_height);
            const Pixel& p2 = img_synth.pixel(i2, j2);
            const Neighbor& neighbor = neighbors_sample[p2.m_nnInfo.m_index];
            Color color = neighbor.color(-dx, -dy);
            double weight = std::pow(p2.m_nnInfo.m_distance, -1.2);
            
            // histogram matching
            double hist_factor = 0;
            hist_factor += std::max<double>(0, hist_synth_red  .get_count_normalized(color.m_red  ) - hist_sample_red  .get_count_normalized(color.m_red  ));
            hist_factor += std::max<double>(0, hist_synth_green.get_count_normalized(color.m_green) - hist_sample_green.get_count_normalized(color.m_green));
            hist_factor += std::max<double>(0, hist_synth_blue .get_count_normalized(color.m_blue ) - hist_sample_blue .get_count_normalized(color.m_blue ));
            weight /= 1 + HM_WEIGHT * hist_factor;
            
            color *= weight;
            p.m_color += color;
            sum_weight += weight;
        }
        p.m_color *= 1 / sum_weight;
        hist_synth_red  .add_count(p.m_color.m_red  );
        hist_synth_green.add_count(p.m_color.m_green);
        hist_synth_blue .add_count(p.m_color.m_blue );
        std::cout << "optimizing...";
        ++cnt;
        if (cnt < cnt_max) {
            int percent = 100 * cnt / cnt_max;
            std::cout << percent << "%\r";
        }
    }
    std::cout << "done!(" << ((std::clock() - clk) / CLOCKS_PER_SEC) << "sec)\n";
}
int load_image(Image& img, const char* filename) {
    int width, height, comp;
    unsigned char *data = stbi_load(filename, &width, &height, &comp, 3);
    if (!data)
        return 1;
    img.resize(width, height);
    for (int j = 0; j < height; ++j)
    for (int i = 0; i < width ; ++i)
    {
        Color& color = img.pixel(i, j).m_color;
        color.m_red   = data[3 * (i + width * j)    ] / 255.;
        color.m_green = data[3 * (i + width * j) + 1] / 255.;
        color.m_blue  = data[3 * (i + width * j) + 2] / 255.;
    }
    stbi_image_free(data);
    return 0;
}
int save_image(const Image& img, const char* filename) {
    std::vector<unsigned char> data(img.m_width * img.m_height * 3, 0);
    for (int j = 0; j < img.m_height; ++j)
    for (int i = 0; i < img.m_width ; ++i)
    {
        const Color& color = img.pixel(i, j).m_color;
        data[3 * (i + img.m_width * j)    ] = static_cast<unsigned char>(color.m_red   * 255);
        data[3 * (i + img.m_width * j) + 1] = static_cast<unsigned char>(color.m_green * 255);
        data[3 * (i + img.m_width * j) + 2] = static_cast<unsigned char>(color.m_blue  * 255);
    }
    stbi_write_png(filename, img.m_width, img.m_height, 3, &data[0], 3 * img.m_width);
    return 0;
}

void downsample(Image& img_low, const Image& img_high) {
    img_low.resize((img_high.m_width + 1) / 2, (img_high.m_height + 1) / 2);
    for (int j = 0; j < img_low.m_height; ++j)
    for (int i = 0; i < img_low.m_width ; ++i)
    {
        Color& color = img_low.pixel(i, j).m_color;
        color = Color();
        color += img_high.pixel(2 * i    , 2 * j    ).m_color;
        color += img_high.pixel(2 * i + 1, 2 * j    ).m_color;
        color += img_high.pixel(2 * i    , 2 * j + 1).m_color;
        color += img_high.pixel(2 * i + 1, 2 * j + 1).m_color;
        color *= 0.25;
    }
}
void upsample(const Image& img_low, Image& img_high) {
    for (int j = 0; j < img_high.m_height; ++j)
    for (int i = 0; i < img_high.m_width ; ++i)
    {
        img_high.pixel(i, j).m_color = img_low.pixel(i / 2, j / 2).m_color;
    }
}

int main(int argc, char** argv) {
    if (argc != 5 + R) {
        std::cout << "usage:\n" << argv[0] << " input.png output_width output_height output.png";
        for (int i = 0; i < R; ++i)
            std::cout << " num_iter_" << i;
        std::cout << std::endl;
        return 1;
    }
    int num_iter[R];
    for (int i = 0; i < R; ++i)
        num_iter[i] = atoi(argv[5 + i]);
    bool is_num_iter_set = num_iter[0] != 0;
    
    // build sample image pyramid
    Image img_sample[R];
    if (load_image(img_sample[R - 1], argv[1])) {
        std::cout << "failed to load " << argv[1] << std::endl;
        return 1;
    }
    for (int i = R - 1; i > 0; --i)
        downsample(img_sample[i - 1], img_sample[i]);
    
    // calculate sample image histogram
    Histogram hist_sample_red  [R];
    Histogram hist_sample_green[R];
    Histogram hist_sample_blue [R];
    for (int i = 0; i < R; ++i)
        calc_histogram(img_sample[i], hist_sample_red[i], hist_sample_green[i], hist_sample_blue[i]);
    
    // collect sample neighbors
    std::vector<Neighbor> neighbors_sample[R];
    for (int i = 0; i < R; ++i)
        neighbors_sample[i] = collect_neighbors_sample(img_sample[i]);
    
    // build synth image pyramid
    Image img_synth[R];
    img_synth[R - 1].resize(atoi(argv[2]), atoi(argv[3]));
    for (int i = R - 1; i > 0; --i)
        downsample(img_synth[i - 1], img_synth[i]);
    srand(time(0));
    init(img_synth[0], img_sample[0]);
    
    clock_t clk = std::clock();
    for (int level = 0; level < R; ) {
        save_image(img_synth[level], argv[4]);
        if (!is_num_iter_set) {
            std::cout << "number of iterations to perform: ";
            std::cin >> num_iter[level];
            num_iter[level] = std::max<int>(1, num_iter[level]);
        }
        for (int i = 0; i < num_iter[level]; ++i) {
            search(img_synth[level], neighbors_sample[level]);
            optimize(img_synth[level], neighbors_sample[level], hist_sample_red[level], hist_sample_green[level], hist_sample_blue[level]);
            save_image(img_synth[level], argv[4]);
        }
        if (is_num_iter_set && level < R - 1) {
            std::cout << "upsample!\n";
        } else {
            if (level == R - 1)
                continue;
            std::cout << "upsample? (y/n): ";
            char c;
            std::cin >> c;
            if (c != 'y')
                continue;
        }
        if (level < R - 1)
            upsample(img_synth[level], img_synth[level + 1]);
        ++level;
    }
    std::cout << "done!(" << ((std::clock() - clk) / (CLOCKS_PER_SEC * 60)) << "min)\n";
    return 0;
}
