#include <vector>
#include <iostream>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include "stb_image.c"
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "stb_image_write.h"

const int N = 3;    // neighborhood size

struct Color {
    double m_red, m_green, m_blue;
    Color() : m_red(0), m_green(0), m_blue(0) {}
    Color& operator+=(const Color& rhs) {
        m_red   += rhs.m_red;
        m_green += rhs.m_green;
        m_blue  += rhs.m_blue;
        return *this;
    }
    Color& operator*=(double rhs) {
        m_red   *= rhs;
        m_green *= rhs;
        m_blue  *= rhs;
        return *this;
    }
    double distance(const Color& color) const {
        double d_red   = m_red   - color.m_red  ;
        double d_green = m_green - color.m_green;
        double d_blue  = m_blue  - color.m_blue ;
        return d_red * d_red + d_green * d_green + d_blue * d_blue;
    }
};

struct NearestNeighborInfo {
    int m_index;
    double m_distance;
    NearestNeighborInfo() : m_index(-1), m_distance(10000000.0) {}
};

struct Pixel {
    Color m_color;
    NearestNeighborInfo m_nnInfo;
};

struct Image {
    std::vector<Pixel> m_pixel;
    int m_width, m_height;
    Image () : m_width(0), m_height(0) {}
    void resize(int width, int height) {
        m_pixel.resize(width * height);
        m_width  = width;
        m_height = height;
    }
    Pixel& pixel(int i, int j) {
        return m_pixel[i + m_width * j];
    }
    const Pixel& pixel(int i, int j) const {
        return m_pixel[i + m_width * j];
    }
};

struct Neighbor {
    Color m_color[(2 * N + 1) * (2 * N + 1)];
    Color& color(int dx, int dy) {
        return m_color[N + dx + (2 * N + 1) * (N + dy)];
    }
    const Color& color(int dx, int dy) const {
        return m_color[N + dx + (2 * N + 1) * (N + dy)];
    }
    double distance(const Neighbor& neighbor) const {
        double result = 0;
        for (int i = 0; i < (2 * N + 1) * (2 * N + 1); ++i)
            result += m_color[i].distance(neighbor.m_color[i]);
        return result;
    }
};

int mod(int index, int modulo) {
    while (index < 0)
        index += modulo;
    return index % modulo;
}

Neighbor get_neighbor(const Image& img, int i, int j) {
    Neighbor neighbor;
    for (int dy = -N; dy <= N; ++dy)
    for (int dx = -N; dx <= N; ++dx)
    {
        int i2 = mod(i + dx, img.m_width );
        int j2 = mod(j + dy, img.m_height);
        neighbor.color(dx, dy) = img.pixel(i2, j2).m_color;
    }
    return neighbor;
}

std::vector<Neighbor> collect_neighbors_sample(const Image& img_sample) {
    std::vector<Neighbor> neighbors_sample;
    for (int j = N; j < img_sample.m_height - N; ++j)
    for (int i = N; i < img_sample.m_width  - N; ++i)
    {
        neighbors_sample.push_back(get_neighbor(img_sample, i, j));
    }
    return neighbors_sample;
}

void init(Image& img_synth, const Image& img_sample) {
    for (int j = 0; j < img_synth.m_height; ++j)
    for (int i = 0; i < img_synth.m_width ; ++i)
    {
        img_synth.pixel(i, j).m_color = img_sample.pixel(
            rand() % img_sample.m_width,
            rand() % img_sample.m_height).m_color;
    }
}

void search(Image& img_synth, const std::vector<Neighbor>& neighbors_sample) {
    int cnt = 0;
    int cnt_max = img_synth.m_pixel.size();
    clock_t clk = std::clock();
#pragma omp parallel for
    for (int j = 0; j < img_synth.m_height; ++j)
    for (int i = 0; i < img_synth.m_width ; ++i)
    {
        Pixel& p = img_synth.pixel(i, j);
        Neighbor neighbor_synth = get_neighbor(img_synth, i, j);
        p.m_nnInfo = NearestNeighborInfo();
        for (int k = 0; k < neighbors_sample.size(); ++k) {
            double d = neighbor_synth.distance(neighbors_sample[k]);
            if (d < p.m_nnInfo.m_distance) {
                p.m_nnInfo.m_index    = k;
                p.m_nnInfo.m_distance = d;
            }
        }
        std::cout << "searching...";
        ++cnt;
        if (cnt < cnt_max) {
            int percent = 100 * cnt / cnt_max;
            std::cout << percent << "%\r";
        }
    }
    std::cout << "done!(" << ((std::clock() - clk) / CLOCKS_PER_SEC) << "sec)\n";
}

void optimize(Image& img_synth, const std::vector<Neighbor>& neighbors_sample) {
    int cnt = 0;
    int cnt_max = img_synth.m_pixel.size();
    clock_t clk = std::clock();
#pragma omp parallel for
    for (int j = 0; j < img_synth.m_height; ++j)
    for (int i = 0; i < img_synth.m_width ; ++i)
    {
        Pixel& p = img_synth.pixel(i, j);
        p.m_color = Color();
        double sum_weight = 0;
        for (int dy = -N; dy <= N; ++dy)
        for (int dx = -N; dx <= N; ++dx)
        {
            int i2 = mod(i + dx, img_synth.m_width);
            int j2 = mod(j + dy, img_synth.m_height);
            const Pixel& p2 = img_synth.pixel(i2, j2);
            const Neighbor& neighbor = neighbors_sample[p2.m_nnInfo.m_index];
            Color color = neighbor.color(-dx, -dy);
            double weight = std::pow(p2.m_nnInfo.m_distance, -1.2);
            color *= weight;
            p.m_color += color;
            sum_weight += weight;
        }
        p.m_color *= 1 / sum_weight;
        std::cout << "optimizing...";
        ++cnt;
        if (cnt < cnt_max) {
            int percent = 100 * cnt / cnt_max;
            std::cout << percent << "%\r";
        }
    }
    std::cout << "done!(" << ((std::clock() - clk) / CLOCKS_PER_SEC) << "sec)\n";
}
int load_image(Image& img, const char* filename) {
    int width, height, comp;
    unsigned char *data = stbi_load(filename, &width, &height, &comp, 3);
    if (!data)
        return 1;
    img.resize(width, height);
    for (int j = 0; j < height; ++j)
    for (int i = 0; i < width ; ++i)
    {
        Color& color = img.pixel(i, j).m_color;
        color.m_red   = data[3 * (i + width * j)    ] / 255.;
        color.m_green = data[3 * (i + width * j) + 1] / 255.;
        color.m_blue  = data[3 * (i + width * j) + 2] / 255.;
    }
    stbi_image_free(data);
    return 0;
}
int save_image(const Image& img, const char* filename) {
    std::vector<unsigned char> data(img.m_width * img.m_height * 3, 0);
    for (int j = 0; j < img.m_height; ++j)
    for (int i = 0; i < img.m_width ; ++i)
    {
        const Color& color = img.pixel(i, j).m_color;
        data[3 * (i + img.m_width * j)    ] = static_cast<unsigned char>(color.m_red   * 255);
        data[3 * (i + img.m_width * j) + 1] = static_cast<unsigned char>(color.m_green * 255);
        data[3 * (i + img.m_width * j) + 2] = static_cast<unsigned char>(color.m_blue  * 255);
    }
    stbi_write_png(filename, img.m_width, img.m_height, 3, &data[0], 3 * img.m_width);
    return 0;
}

int main(int argc, char** argv) {
    if (argc != 5) {
        std::cout << "usage:\n" << argv[0] << " input.png output_width output_height output.png\n";
        return 1;
    }
    
    Image img_sample;
    if (load_image(img_sample, argv[1])) {
        std::cout << "failed to load " << argv[1] << std::endl;
        return 1;
    }
    
    std::vector<Neighbor> neighbors_sample = collect_neighbors_sample(img_sample);
    
    Image img_synth;
    img_synth.resize(std::atoi(argv[2]), std::atoi(argv[3]));
    srand(time(0));
    init(img_synth, img_sample);
    
    while (true) {
        save_image(img_synth, argv[4]);
        std::cout << "number of iterations to perform: ";
        int num_iter;
        std::cin >> num_iter;
        num_iter = std::max<int>(1, num_iter);
        for (int i = 0; i < num_iter; ++i) {
            search(img_synth, neighbors_sample);
            optimize(img_synth, neighbors_sample);
            save_image(img_synth, argv[4]);
        }
    }
    return 0;
}
