This library extra implements "Bounded Biharmonic Weights". By default it
depends on libiglmosek and therefor also mosek. To compile issue:

    make

To compile without the mosek dependency issue:

    make IGL_NO_MOSEK=1
