// MainFrm.h : interface of the CMainFrame class
//
#include "DlgBarColorPalette.h"
#include "DlgBarToolPalette.h"

#pragma once

class CMainFrame : public CFrameWnd
{
	
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
public:
	DlgBarColorPalette m_wndDlgBarColorPalette;
	DlgBarToolPalette  m_wndDlgBarToolPalette;
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;

// Operations
public:

// Overrides
public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);

// Implementation
public:
	virtual ~CMainFrame();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

// Generated message map functions
protected:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	DECLARE_MESSAGE_MAP()
public:
public:
	afx_msg void OnViewColorpalette();
public:
	afx_msg void OnUpdateViewColorpalette(CCmdUI *pCmdUI);
public:
	afx_msg void OnViewToolpalette();
public:
	afx_msg void OnUpdateViewToolpalette(CCmdUI *pCmdUI);
};

