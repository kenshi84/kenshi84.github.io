#include "StdAfx.h"
#include <gl/glew.h>
#include "KCore.h"
#include "KTetraCube.h"
#include "VolumeHeader.h"
#include "KWaveletNoise.h"
#include "KPerlinNoise.h"
#include "StatePen.h"
#include "StateGeometry.h"
#include <KLIB/KMarchingTetra.h>
#include <KLIB/KUtil.h>
//#include <gl/glext.h>
#include <OpenCV/highgui.h>
using namespace std;

//PFNGLTEXIMAGE3DPROC glTexImage3D;

KCore::KCore(void)
: m_tetraCube(KTetraCube(1))
, m_polyHandleRef(0.05)
{
	m_cb_format = RegisterClipboardFormat("volume data format");
	srand((UINT)time(NULL));
	m_volSize = 64;
	m_volData.resize(m_volSize * m_volSize * m_volSize * 3, 0);
	m_ogl.m_clearColor[0] = m_ogl.m_clearColor[1] = m_ogl.m_clearColor[2] = 1;
	m_polyHandleRef.subdivide();
	m_polyHandleRef.calcSmoothNormals();
	m_polyHandleX = m_polyHandleRef;
	m_polyHandleY = m_polyHandleRef;
	m_polyHandleZ = m_polyHandleRef;
	mp_state = StatePen::getInstance();
}

void KCore::init() {
	m_ogl.makeOpenGLCurrent();
	glewInit();
	m_viewDir = VIEWDIR_Z;
	m_slice = m_volSize - 1;
	m_prevX = m_prevY = m_prevZ = m_volSize - 1;
	m_volDataUndo.resize(m_volData.size());
	memcpy(&m_volDataUndo[0], &m_volData[0], m_volData.size());
	m_colorCurrentFg = RGB(0, 0, 0);
	m_colorCurrentBg = RGB(255, 255, 255);
	m_colorPalette[0 ] = RGB(  0,   0,   0);	m_colorPalette[1 ] = RGB(255, 255, 255);
	m_colorPalette[2 ] = RGB(128, 128, 128);	m_colorPalette[3 ] = RGB(192, 192, 192);
	m_colorPalette[4 ] = RGB(128,   0,  0 );	m_colorPalette[5 ] = RGB(255,   0,   0);
	m_colorPalette[6 ] = RGB(128, 128,   0);	m_colorPalette[7 ] = RGB(255, 255,   0);
	m_colorPalette[8 ] = RGB(  0, 128,   0);	m_colorPalette[9 ] = RGB(  0, 255,   0);
	m_colorPalette[10] = RGB(  0, 128, 128);	m_colorPalette[11] = RGB(  0, 255, 255);
	m_colorPalette[12] = RGB(  0,   0, 128);	m_colorPalette[13] = RGB(  0,   0, 255);
	m_colorPalette[14] = RGB(128,   0, 128);	m_colorPalette[15] = RGB(255,   0, 255);
	
	mp_state = StatePen::getInstance();
	mp_state->init();
	updateTexture();
	updatePolyCut();
	updateHandlePos();
	resetEyePosition();
}

void KCore::resetEyePosition() {
	//m_ogl.m_eyePoint.set(0.5, 0.5, 5);
	//m_ogl.m_focusPoint.set(0.5, 0.5, 0.5);
	//m_ogl.m_upDirection.set(0, 1, 0);
	//m_ogl.updateEyePosition();
}

void KCore::updateHandlePos() {
	double off = (m_slice + 1.) / m_volSize;
	for (int i = 0; i < (int)m_polyHandleRef.m_vertices.size(); ++i) {
		m_polyHandleX.m_vertices[i].m_pos.x = m_polyHandleRef.m_vertices[i].m_pos.x + off;
		m_polyHandleY.m_vertices[i].m_pos.y = m_polyHandleRef.m_vertices[i].m_pos.y + off;
		m_polyHandleZ.m_vertices[i].m_pos.z = m_polyHandleRef.m_vertices[i].m_pos.z + off;
	}
}

void KCore::updateTexture() {
	m_ogl.makeOpenGLCurrent();
	//if (glTexImage3D == 0) glTexImage3D = (PFNGLTEXIMAGE3DPROC)wglGetProcAddress("glTexImage3D");
	glDeleteTextures(1, &m_texName);
	glGenTextures(1, &m_texName);
	glBindTexture(GL_TEXTURE_3D, m_texName);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
	glTexImage3D(GL_TEXTURE_3D, 0, GL_RGB, m_volSize, m_volSize, m_volSize, 0, GL_RGB, GL_UNSIGNED_BYTE, &m_volData[0]);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
}

void KCore::updatePolyCut() {
	static double delta = 0.001;
	vector<double> vtxValue(m_tetraCube.m_vertices.size(), 0);
	for (int i = 0; i < (int)m_tetraCube.m_vertices.size(); ++i) {
		const KVector3d& pos = m_tetraCube.m_vertices[i].m_pos;
		vtxValue[i] =
			  m_viewDir == VIEWDIR_X ? pos.x
			  : m_viewDir == VIEWDIR_Y ? pos.y
			  : pos.z;
	}
	double threshold = (m_slice + 1.) / m_volSize;
	m_polyCut = KMarchingTetra::calcMarchingTetra(m_tetraCube, vtxValue, threshold);
	for (int i = 0; i < (int)m_polyCut.m_vertices.size(); ++i) {
		KVector3d& pos = m_polyCut.m_vertices[i].m_pos;
		if (pos.x == 0) pos.x = delta; else pos.x -= delta;
		if (pos.y == 0) pos.y = delta; else pos.y -= delta;
		if (pos.z == 0) pos.z = delta; else pos.z -= delta;
	}
}
bool KCore::loadVolData(const std::string& fname) {
	FILE * fin = fopen(fname.c_str(), "rb");
	if (!fin) {
		CString str;
		str.Format("Failed to load solid texture file %s", fname.c_str());
		AfxMessageBox(str);
		return false;
	}
	char buf[4096];
	fread(buf, 4096, 1, fin);
	
	VolumeHeader* header = (VolumeHeader *)buf;
	if ((header->magic[0] != 'V') ||
		(header->magic[1] != 'O') ||
		(header->magic[2] != 'L') ||
		(header->magic[3] != 'U') ||
		(header->bytesPerChannel != 1) ||
		(header->version != 4))
	{
		AfxMessageBox("Bad header!");
		return false;
	}
	if (!is2pow(header->volSize)) {
		AfxMessageBox("Texture size must be power of 2.");
		return false;
	}
	if (header->numChannels != 3) {
		AfxMessageBox("Only RGB format supported.");
		return false;
	}
	m_volSize = header->volSize;
	int volBytes = m_volSize * m_volSize * m_volSize * 3;
	m_volData.resize(volBytes);
	fread(&m_volData[0], 1, volBytes, fin);
	fclose(fin);
	return true;
}
bool KCore::is2pow(int n) {
	if (n < 1) return false;
	bool flag = false;
	for (int t = 1; t <= n; t <<= 1) {
		if (t & n) {
			if (flag) return false;
			flag = true;
		}
	}
	return true;
}
void KCore::addNoise() {
	int pow2 = 0;
	for (int i = 1; i < m_volSize; i <<= 1, ++pow2) {
		if ((i & m_volSize) != 0) break;
	}
	vector<double> noise = KWaveletNoise::getNoise3D(pow2);	//KPerlinNoise::getNoise3D(pow2);
	int w = 32;
	for (int i = 0; i < (int)noise.size(); ++i) {
		int d = (int)(w * (noise[i] - 0.5));
		int r = m_volData[3 * i    ] + d;
		int g = m_volData[3 * i + 1] + d;
		int b = m_volData[3 * i + 2] + d;
		m_volData[3 * i    ] = max(min(r, 255), 0);
		m_volData[3 * i + 1] = max(min(g, 255), 0);
		m_volData[3 * i + 2] = max(min(b, 255), 0);
	}
}

void KCore::shiftColor() {
	int pow2 = 0;
	for (int i = 1; i < m_volSize; i <<= 1, ++pow2) {
		if ((i & m_volSize) != 0) break;
	}
	vector<GLubyte> volDataTmp(m_volData.size());
	vector<double> noiseY = KWaveletNoise::getNoise3D(pow2);
	double wY = 2;	// 0 < wY < 2
	for (int iz = 0; iz < m_volSize; ++iz) {
		for (int iy = 0; iy < m_volSize; ++iy) {
			for (int ix = 0; ix < m_volSize; ++ix) {
				int index  = xyz2index(ix, iy, iz);
				int indexm = xyz2index(ix, max(iy - 1, 0)            , iz);
				int indexp = xyz2index(ix, min(iy + 1, m_volSize - 1), iz);
				double t = (noiseY[xyz2index(ix, iy, iz) / 3] - 0.5) * wY + 1;
				if (t < 1) {
					volDataTmp[index    ] = (GLubyte)(t * m_volData[index    ] + (1 - t) * m_volData[indexm    ]);
					volDataTmp[index + 1] = (GLubyte)(t * m_volData[index + 1] + (1 - t) * m_volData[indexm + 1]);
					volDataTmp[index + 2] = (GLubyte)(t * m_volData[index + 2] + (1 - t) * m_volData[indexm + 2]);
				} else {
					volDataTmp[index    ] = (GLubyte)((t - 1) * m_volData[indexp    ] + (2 - t) * m_volData[index    ]);
					volDataTmp[index + 1] = (GLubyte)((t - 1) * m_volData[indexp + 1] + (2 - t) * m_volData[index + 1]);
					volDataTmp[index + 2] = (GLubyte)((t - 1) * m_volData[indexp + 2] + (2 - t) * m_volData[index + 2]);
				}
			}
		}
	}
	vector<double> noiseX = KWaveletNoise::getNoise3D(pow2);
	double wX = 0.5;	// 0 < wX < 2
	for (int iz = 0; iz < m_volSize; ++iz) {
		for (int iy = 0; iy < m_volSize; ++iy) {
			for (int ix = 0; ix < m_volSize; ++ix) {
				int index = xyz2index(ix, iy, iz);
				int indexm = xyz2index(max(ix - 1, 0)            , iy, iz);
				int indexp = xyz2index(min(ix + 1, m_volSize - 1), iy, iz);
				double t = (noiseX[xyz2index(ix, iy, iz) / 3] - 0.5) * wX + 1;
				// carrot=80	tree 20
				if (t < 1) {
					m_volData[index    ] = (GLubyte)(t * volDataTmp[index    ] + (1 - t) * volDataTmp[indexm    ]);
					m_volData[index + 1] = (GLubyte)(t * volDataTmp[index + 1] + (1 - t) * volDataTmp[indexm + 1]);
					m_volData[index + 2] = (GLubyte)(t * volDataTmp[index + 2] + (1 - t) * volDataTmp[indexm + 2]);
				} else {
					m_volData[index    ] = (GLubyte)((t - 1) * volDataTmp[indexp    ] + (2 - t) * volDataTmp[index    ]);
					m_volData[index + 1] = (GLubyte)((t - 1) * volDataTmp[indexp + 1] + (2 - t) * volDataTmp[index + 1]);
					m_volData[index + 2] = (GLubyte)((t - 1) * volDataTmp[indexp + 2] + (2 - t) * volDataTmp[index + 2]);
				}
			}
		}
	}
}

void KCore::blur() {
	static double gauss[4] = {1 / 81., 2 / 81., 4 / 81., 8 / 81. };
	int& N = m_volSize;
	for (int iz = 0; iz < m_volSize; ++iz) {
		for (int iy = 0; iy < m_volSize; ++iy) {
			for (int ix = 0; ix < m_volSize; ++ix) {
				int index = (ix + N * iy + N * N * iz) * 3;
				double totalWeight = 0;
				double r = 0;
				double g = 0;
				double b = 0;
				for (int dz = -1; dz <= 1; ++dz) {
					if (iz + dz < 0 || N <= iz + dz) continue;
					for (int dy = -1; dy <= 1; ++dy) {
						if (iy + dy < 0 || N <= iy + dy) continue;
						for (int dx = -1; dx <= 1; ++dx) {
							if (ix + dx < 0 || N <= ix + dx) continue;
							double weight = gauss[abs(dz) + abs(dy) + abs(dx)];
							int indexd = index + (dx + N * dy + N * N * dz) * 3;
							r += weight * m_volDataUndo[indexd    ];
							g += weight * m_volDataUndo[indexd + 1];
							b += weight * m_volDataUndo[indexd + 2];
							totalWeight += weight;
						}
					}
				}
				m_volData[index    ] = (GLubyte)(r / totalWeight);
				m_volData[index + 1] = (GLubyte)(g / totalWeight);
				m_volData[index + 2] = (GLubyte)(b / totalWeight);
			}
		}
	}
}

void KCore::flipX() {
	int& N = m_volSize;
	for (int iz = 0; iz < m_volSize; ++iz) {
		for (int iy = 0; iy < m_volSize; ++iy) {
			for (int ix = 0; ix < m_volSize; ++ix) {
				int index  = (ix + N * iy + N * N * iz) * 3;
				int index2 = (N - 1 - ix + N * iy + N * N * iz) * 3;
				m_volData[index    ] = m_volDataUndo[index2    ];
				m_volData[index + 1] = m_volDataUndo[index2 + 1];
				m_volData[index + 2] = m_volDataUndo[index2 + 2];
			}
		}
	}
}
void KCore::flipY() {
	int& N = m_volSize;
	for (int iz = 0; iz < m_volSize; ++iz) {
		for (int iy = 0; iy < m_volSize; ++iy) {
			for (int ix = 0; ix < m_volSize; ++ix) {
				int index  = (ix + N * iy + N * N * iz) * 3;
				int index2 = (ix + N * (N - 1 - iy) + N * N * iz) * 3;
				m_volData[index    ] = m_volDataUndo[index2    ];
				m_volData[index + 1] = m_volDataUndo[index2 + 1];
				m_volData[index + 2] = m_volDataUndo[index2 + 2];
			}
		}
	}
}
void KCore::flipZ() {
	int& N = m_volSize;
	for (int iz = 0; iz < m_volSize; ++iz) {
		for (int iy = 0; iy < m_volSize; ++iy) {
			for (int ix = 0; ix < m_volSize; ++ix) {
				int index  = (ix + N * iy + N * N * iz) * 3;
				int index2 = (ix + N * iy + N * N * (N - 1 - iz)) * 3;
				m_volData[index    ] = m_volDataUndo[index2    ];
				m_volData[index + 1] = m_volDataUndo[index2 + 1];
				m_volData[index + 2] = m_volDataUndo[index2 + 2];
			}
		}
	}
}
void KCore::replaceXY() {
	int& N = m_volSize;
	for (int iz = 0; iz < m_volSize; ++iz) {
		for (int iy = 0; iy < m_volSize; ++iy) {
			for (int ix = 0; ix < m_volSize; ++ix) {
				int index  = (ix + N * iy + N * N * iz) * 3;
				int index2 = (iy + N * ix + N * N * iz) * 3;
				m_volData[index    ] = m_volDataUndo[index2    ];
				m_volData[index + 1] = m_volDataUndo[index2 + 1];
				m_volData[index + 2] = m_volDataUndo[index2 + 2];
			}
		}
	}
}
void KCore::replaceYZ() {
	int& N = m_volSize;
	for (int iz = 0; iz < m_volSize; ++iz) {
		for (int iy = 0; iy < m_volSize; ++iy) {
			for (int ix = 0; ix < m_volSize; ++ix) {
				int index  = (ix + N * iy + N * N * iz) * 3;
				int index2 = (ix + N * iz + N * N * iy) * 3;
				m_volData[index    ] = m_volDataUndo[index2    ];
				m_volData[index + 1] = m_volDataUndo[index2 + 1];
				m_volData[index + 2] = m_volDataUndo[index2 + 2];
			}
		}
	}
}
void KCore::replaceZX() {
	int& N = m_volSize;
	for (int iz = 0; iz < m_volSize; ++iz) {
		for (int iy = 0; iy < m_volSize; ++iy) {
			for (int ix = 0; ix < m_volSize; ++ix) {
				int index  = (ix + N * iy + N * N * iz) * 3;
				int index2 = (iz + N * iy + N * N * ix) * 3;
				m_volData[index    ] = m_volDataUndo[index2    ];
				m_volData[index + 1] = m_volDataUndo[index2 + 1];
				m_volData[index + 2] = m_volDataUndo[index2 + 2];
			}
		}
	}
}


bool KCore::sweepImageFrom1Dir(const string& fname) {
	IplImage *img;
	if ((img = cvLoadImage(fname.c_str(), CV_LOAD_IMAGE_COLOR)) == 0) {
		CString msg;
		msg.Format("Failed to load %s.", fname.c_str());
		AfxMessageBox(msg);
		return false;
	}
	int& N = m_volSize;
	if (img->width != N || img->height != N) {
		CString msg;
		msg.Format("The image size should be %d x %d.", N, N);
		AfxMessageBox(msg);
		return false;
	}
	for (int iy = 0; iy < N; ++iy) {
		for (int ix = 0; ix < N; ++ix) {
			int index = 3 * (ix + N * iy);
			int index2 = 3 * (ix + N * (N - 1 - iy));
			m_volData[index]     = img->imageData[index2 + 2];
			m_volData[index + 1] = img->imageData[index2 + 1];
			m_volData[index + 2] = img->imageData[index2];
		}
	}
	cvReleaseImage(&img);
	for (int iz = 1; iz < N; ++iz) {
		memcpy(&m_volData[3 * N * N * iz], &m_volData[0], 3 * N * N);
	}
	return true;
}

bool KCore::sweepImageFrom2Dir(const string& fname) {
	IplImage *img;
	if ((img = cvLoadImage(fname.c_str(), CV_LOAD_IMAGE_COLOR)) == 0) {
		CString msg;
		msg.Format("Failed to load %s.", fname.c_str());
		AfxMessageBox(msg);
		return false;
	}
	int& N = m_volSize;
	if (img->width != N || img->height != N) {
		CString msg;
		msg.Format("The image size should be %d x %d.", N, N);
		AfxMessageBox(msg);
		return false;
	}
	for (int iz = 0; iz < N; ++iz) {
		for (int iy = 0; iy < N; ++iy) {
			for (int ix = 0; ix < N; ++ix) {
				int index3D  = 3 * (ix + N * iy + N * N * iz);
				int index2Dz = 3 * (ix + N * (N - 1 -iy));
				int index2Dx = 3 * (N - 1 - iz + N * (N - 1 - iy));
				m_volData[index3D    ] = ((uchar)img->imageData[index2Dx + 2] + (uchar)img->imageData[index2Dz + 2]) / 2;
				m_volData[index3D + 1] = ((uchar)img->imageData[index2Dx + 1] + (uchar)img->imageData[index2Dz + 1]) / 2;
				m_volData[index3D + 2] = ((uchar)img->imageData[index2Dx    ] + (uchar)img->imageData[index2Dz    ]) / 2;
			}
		}
	}
	cvReleaseImage(&img);
	return true;
}

bool KCore::sweepImageFrom3Dir(const string& fname) {
	IplImage *img;
	if ((img = cvLoadImage(fname.c_str(), CV_LOAD_IMAGE_COLOR)) == 0) {
		CString msg;
		msg.Format("Failed to load %s.", fname.c_str());
		AfxMessageBox(msg);
		return false;
	}
	int& N = m_volSize;
	if (img->width != N || img->height != N) {
		CString msg;
		msg.Format("The image size should be %d x %d.", N, N);
		AfxMessageBox(msg);
		return false;
	}
	for (int iz = 0; iz < N; ++iz) {
		for (int iy = 0; iy < N; ++iy) {
			for (int ix = 0; ix < N; ++ix) {
				int index3D  = 3 * (ix + N * iy + N * N * iz);
				int index2Dx = 3 * (iy + N * (N - 1 - iz));
				int index2Dy = 3 * (iz + N * (N - 1 - ix));
				int index2Dz = 3 * (ix + N * (N - 1 - iy));
				m_volData[index3D    ] = (img->imageData[index2Dx + 2] + img->imageData[index2Dy + 2]+ img->imageData[index2Dz + 2]) / 3;
				m_volData[index3D + 1] = (img->imageData[index2Dx + 1] + img->imageData[index2Dy + 1]+ img->imageData[index2Dz + 1]) / 3;
				m_volData[index3D + 2] = (img->imageData[index2Dx    ] + img->imageData[index2Dy    ]+ img->imageData[index2Dz    ]) / 3;
			}
		}
	}
	cvReleaseImage(&img);
	return true;
}

bool KCore::loadSkin(const string& fname) {
	IplImage *img;
	if ((img = cvLoadImage(fname.c_str(), CV_LOAD_IMAGE_COLOR)) == 0) {
		CString msg;
		msg.Format("Failed to load %s.", fname.c_str());
		AfxMessageBox(msg);
		return false;
	}
	int& N = m_volSize;
	if (img->width != N || img->height != N) {
		CString msg;
		msg.Format("The image size should be %d x %d.", N, N);
		AfxMessageBox(msg);
		return false;
	}
	for (int iy = 0; iy < N; ++iy) {
		for (int ix = 0; ix < N; ++ix) {
			int index3D = 3 * (iy + N * N * ix);
			int index2D = 3 * (ix + N * (N - 1 - iy));
			m_volData[index3D]     = img->imageData[index2D + 2];
			m_volData[index3D + 1] = img->imageData[index2D + 1];
			m_volData[index3D + 2] = img->imageData[index2D];
		}
	}
	cvReleaseImage(&img);
	return true;
}

void KCore::changeContrast(double bound) {
	for (int iz = 0; iz < m_volSize; ++iz) {
		for (int iy = 0; iy < m_volSize; ++iy) {
			for (int ix = 0; ix < m_volSize; ++ix) {
				int index  = xyz2index(ix, iy, iz);
				GLubyte& r = m_volData[index];
				GLubyte& g = m_volData[index + 1];
				GLubyte& b = m_volData[index + 2];
				double dr = r / 255.;
				double dg = g / 255.;
				double db = b / 255.;
				dr = max(min((dr - bound) / (1. - 2 * bound), 1), 0);
				dg = max(min((dg - bound) / (1. - 2 * bound), 1), 0);
				db = max(min((db - bound) / (1. - 2 * bound), 1), 0);
				r = (GLubyte)(dr * 255);
				g = (GLubyte)(dg * 255);
				b = (GLubyte)(db * 255);
			}
		}
	}
}

void KCore::changeIntensity(double scale) {
	for (int iz = 0; iz < m_volSize; ++iz) {
		for (int iy = 0; iy < m_volSize; ++iy) {
			for (int ix = 0; ix < m_volSize; ++ix) {
				int index  = xyz2index(ix, iy, iz);
				GLubyte& r = m_volData[index];
				GLubyte& g = m_volData[index + 1];
				GLubyte& b = m_volData[index + 2];
				double dr = r / 255.;
				double dg = g / 255.;
				double db = b / 255.;
				dr = max(min(dr * scale, 1), 0);
				dg = max(min(dg * scale, 1), 0);
				db = max(min(db * scale, 1), 0);
				r = (GLubyte)(dr * 255);
				g = (GLubyte)(dg * 255);
				b = (GLubyte)(db * 255);
			}
		}
	}
}

void KCore::storeUndo() {
	memcpy(&m_volDataUndo[0], &m_volData[0], m_volData.size());
	mp_view->GetDocument()->SetModifiedFlag(TRUE);
}
