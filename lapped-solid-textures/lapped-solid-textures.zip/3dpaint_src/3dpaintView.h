// 3dpaintView.h : interface of the CMy3dpaintView class
//


#pragma once


class CMy3dpaintView : public CView
{
protected: // create from serialization only
	CMy3dpaintView();
	DECLARE_DYNCREATE(CMy3dpaintView)

// Attributes
public:
	CMy3dpaintDoc* GetDocument() const;

// Operations
public:

// Overrides
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:

// Implementation
public:
	virtual ~CMy3dpaintView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
public:
	afx_msg void OnDestroy();
public:
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
public:
	afx_msg void OnSize(UINT nType, int cx, int cy);
public:
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
public:
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
public:
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
public:
	afx_msg void OnRButtonUp(UINT nFlags, CPoint point);
public:
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
public:
	afx_msg void OnMButtonUp(UINT nFlags, CPoint point);
public:
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
public:
	afx_msg void OnDropFiles(HDROP hDropInfo);
public:
	afx_msg BOOL OnMouseWheel(UINT nFlags, short zDelta, CPoint pt);
public:
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
public:
	afx_msg void OnEditUndo();
public:
	afx_msg void OnProcessNoise();
public:
	afx_msg void OnContrastIncrease();
public:
	afx_msg void OnContrastDecrease();
public:
	afx_msg void OnIntensityIncrease();
public:
	afx_msg void OnIntensityDecrease();
public:
	afx_msg void OnSweepFrom1direction();
public:
	afx_msg void OnSweepFrom2direction();
public:
	afx_msg void OnSweepFrom3direction();
public:
	afx_msg void On2dimageLoadskin();
public:
	afx_msg void OnProcessBlur();
public:
	afx_msg void OnFlipX();
public:
	afx_msg void OnFlipY();
public:
	afx_msg void OnFlipZ();
public:
	afx_msg void OnReplaceXy();
public:
	afx_msg void OnReplaceYz();
public:
	afx_msg void OnReplaceZx();
public:
	afx_msg void OnEditCopy();
public:
	afx_msg void OnUpdateEditPaste(CCmdUI *pCmdUI);
public:
	afx_msg void OnEditPaste();
public:
	afx_msg void OnUpdateEditCopy(CCmdUI *pCmdUI);
public:
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
public:
	afx_msg void OnFileLoadgeometry();
public:
	afx_msg void OnEditCut();
public:
	afx_msg void OnUpdateEditCut(CCmdUI *pCmdUI);
};

#ifndef _DEBUG  // debug version in 3dpaintView.cpp
inline CMy3dpaintDoc* CMy3dpaintView::GetDocument() const
   { return reinterpret_cast<CMy3dpaintDoc*>(m_pDocument); }
#endif

