// DlgBarToolPalette.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "3dpaint.h"
#include "DlgBarToolPalette.h"
#include "StatePen.h"
#include "StateEraser.h"
#include "StateSpuit.h"
#include "StateSelect.h"
#include "StateGeometry.h"
#include "StateBlur.h"
#include "KCore.h"

// DlgBarToolPalette �_�C�A���O

IMPLEMENT_DYNAMIC(DlgBarToolPalette, CDialogBar)

DlgBarToolPalette::DlgBarToolPalette()
	: CDialogBar()
	, m_xvRadioTool(0)
{
	m_bmpPen     .LoadBitmapA(IDB_BMP_PEN);
	m_bmpEraser  .LoadBitmapA(IDB_BMP_ERASER);
	m_bmpSpuit   .LoadBitmapA(IDB_BMP_SPUIT);
	m_bmpSelect  .LoadBitmapA(IDB_BMP_SELECT);
	m_bmpGeometry.LoadBitmapA(IDB_BMP_GEOMETRY);
	m_bmpBlur    .LoadBitmapA(IDB_BMP_BLUR);
}

DlgBarToolPalette::~DlgBarToolPalette()
{
}

void DlgBarToolPalette::DoDataExchange(CDataExchange* pDX)
{
	CDialogBar::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RADIO0, m_xvRadioTool);
}

void DlgBarToolPalette::initBitmap() {
	((CButton *)GetDlgItem(IDC_RADIO0))->SetBitmap(m_bmpPen);
	((CButton *)GetDlgItem(IDC_RADIO1))->SetBitmap(m_bmpEraser);
	((CButton *)GetDlgItem(IDC_RADIO2))->SetBitmap(m_bmpSpuit);
	((CButton *)GetDlgItem(IDC_RADIO3))->SetBitmap(m_bmpSelect);
	((CButton *)GetDlgItem(IDC_RADIO4))->SetBitmap(m_bmpGeometry);
	((CButton *)GetDlgItem(IDC_RADIO5))->SetBitmap(m_bmpBlur);
}

void DlgBarToolPalette::updateData() {
	KCore& core = *KCore::getInstance();
	m_xvRadioTool =
		core.mp_state == StatePen     ::getInstance() ? 0 :
		core.mp_state == StateEraser  ::getInstance() ? 1 :
		core.mp_state == StateSpuit   ::getInstance() ? 2 :
		core.mp_state == StateSelect  ::getInstance() ? 3 :
		core.mp_state == StateGeometry::getInstance() ? 4 : 5;
	UpdateData(FALSE);
}

BEGIN_MESSAGE_MAP(DlgBarToolPalette, CDialogBar)
	ON_BN_CLICKED(IDC_RADIO0, &DlgBarToolPalette::OnBnClickedRadio0)
	ON_BN_CLICKED(IDC_RADIO1, &DlgBarToolPalette::OnBnClickedRadio1)
	ON_BN_CLICKED(IDC_RADIO2, &DlgBarToolPalette::OnBnClickedRadio2)
	ON_BN_CLICKED(IDC_RADIO3, &DlgBarToolPalette::OnBnClickedRadio3)
	ON_BN_CLICKED(IDC_RADIO4, &DlgBarToolPalette::OnBnClickedRadio4)
	ON_BN_CLICKED(IDC_RADIO5, &DlgBarToolPalette::OnBnClickedRadio5)
END_MESSAGE_MAP()


// DlgBarToolPalette ���b�Z�[�W �n���h��

void DlgBarToolPalette::OnBnClickedRadio0() {
	KCore& core = *KCore::getInstance();
	core.mp_state->quit();
	core.mp_state = StatePen::getInstance();
	core.m_ogl.RedrawWindow();
}

void DlgBarToolPalette::OnBnClickedRadio1() {
	KCore& core = *KCore::getInstance();
	core.mp_state->quit();
	core.mp_state = StateEraser::getInstance();
	core.mp_state->init();
	core.m_ogl.RedrawWindow();
}

void DlgBarToolPalette::OnBnClickedRadio2() {
	KCore& core = *KCore::getInstance();
	core.mp_state->quit();
	core.mp_state = StateSpuit::getInstance();
	core.mp_state->init();
	core.m_ogl.RedrawWindow();
}

void DlgBarToolPalette::OnBnClickedRadio3() {
	KCore& core = *KCore::getInstance();
	core.mp_state->quit();
	core.mp_state = StateSelect::getInstance();
	core.mp_state->init();
	core.m_ogl.RedrawWindow();
}


void DlgBarToolPalette::OnBnClickedRadio4() {
	KCore& core = *KCore::getInstance();
	core.mp_state->quit();
	core.mp_state = StateGeometry::getInstance();
	core.mp_state->init();
	core.m_ogl.RedrawWindow();
}

void DlgBarToolPalette::OnBnClickedRadio5() {
	KCore& core = *KCore::getInstance();
	core.mp_state->quit();
	core.mp_state = StateBlur::getInstance();
	core.mp_state->init();
	core.m_ogl.RedrawWindow();
}
