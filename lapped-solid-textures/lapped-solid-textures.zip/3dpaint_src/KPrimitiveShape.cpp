#include "StdAfx.h"
#include "KPrimitiveShape.h"

void KBox::init(double x0, double y0, double z0, double x1, double y1, double z1) {
	m_vertices.reserve(8);
	for (int i = 0; i < 8; ++i) {
		bool bx = (i & 1) != 0;
		bool by = (i & 2) != 0;
		bool bz = (i & 4) != 0;
		m_vertices.push_back(KVector3d(bx ? x1 : x0, by ? y1 : y0, bz ? z1 : z0));
	}
	// x: 1, 5, 6, 9,
	// y: 0, 4, 8, 11,
	// z: 2, 3, 7, 10,
	m_polygons.reserve(12);
	
	m_polygons.push_back(KPolygon(0, 1, 4));	// y
	m_polygons.push_back(KPolygon(0, 4, 2));	// x
	m_polygons.push_back(KPolygon(0, 2, 1));	// z
	m_polygons.push_back(KPolygon(3, 1, 2));	// z
	m_polygons.push_back(KPolygon(5, 4, 1));	// y
	m_polygons.push_back(KPolygon(6, 2, 4));	// x
	m_polygons.push_back(KPolygon(3, 5, 1));	// x
	m_polygons.push_back(KPolygon(5, 6, 4));	// z
	m_polygons.push_back(KPolygon(6, 3, 2));	// y
	m_polygons.push_back(KPolygon(7, 5, 3));	// x
	m_polygons.push_back(KPolygon(7, 6, 5));	// z
	m_polygons.push_back(KPolygon(7, 3, 6));	// y
}

