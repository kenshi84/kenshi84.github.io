#pragma once
#include "Resource.h"

// DlgBarColorPalette �_�C�A���O

class DlgBarColorPalette : public CDialogBar
{
	DECLARE_DYNAMIC(DlgBarColorPalette)

public:
	DlgBarColorPalette();   // �W���R���X�g���N�^
	virtual ~DlgBarColorPalette();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_DLG_COLOR };

public:

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
public:
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnStnClickedLblColorFg();
	afx_msg void OnStnClickedLblColorBg();
	afx_msg void OnStnClickedLblColor0 ();
	afx_msg void OnStnClickedLblColor1 ();
	afx_msg void OnStnClickedLblColor2 ();
	afx_msg void OnStnClickedLblColor3 ();
	afx_msg void OnStnClickedLblColor4 ();
	afx_msg void OnStnClickedLblColor5 ();
	afx_msg void OnStnClickedLblColor6 ();
	afx_msg void OnStnClickedLblColor7 ();
	afx_msg void OnStnClickedLblColor8 ();
	afx_msg void OnStnClickedLblColor9 ();
	afx_msg void OnStnClickedLblColor10();
	afx_msg void OnStnClickedLblColor11();
	afx_msg void OnStnClickedLblColor12();
	afx_msg void OnStnClickedLblColor13();
	afx_msg void OnStnClickedLblColor14();
	afx_msg void OnStnClickedLblColor15();
	afx_msg void OnStnDblclickLblColor0 ();
	afx_msg void OnStnDblclickLblColor1 ();
	afx_msg void OnStnDblclickLblColor2 ();
	afx_msg void OnStnDblclickLblColor3 ();
	afx_msg void OnStnDblclickLblColor4 ();
	afx_msg void OnStnDblclickLblColor5 ();
	afx_msg void OnStnDblclickLblColor6 ();
	afx_msg void OnStnDblclickLblColor7 ();
	afx_msg void OnStnDblclickLblColor8 ();
	afx_msg void OnStnDblclickLblColor9 ();
	afx_msg void OnStnDblclickLblColor10();
	afx_msg void OnStnDblclickLblColor11();
	afx_msg void OnStnDblclickLblColor12();
	afx_msg void OnStnDblclickLblColor13();
	afx_msg void OnStnDblclickLblColor14();
	afx_msg void OnStnDblclickLblColor15();
};
