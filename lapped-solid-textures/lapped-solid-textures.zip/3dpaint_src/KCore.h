#pragma once

#include <gl/glew.h>
#include "Drawer.h"
#include "EventHandler.h"
#include "State.h"
#include <KLIB/KOGL.h>
#include <KLIB/KGeometry.h>
#include <KLIB/KIcosahedron.h>
#include <vector>
#include <string>

// tools: brush, spoit, color select, region select, 3d poly, load img, noise

class KCore {
public:
	KOGL m_ogl;
	Drawer m_drawer;
	EventHandler m_eventHandler;
	CView* mp_view;
	
	// volume data (volSize should be 2^m)
	std::vector<GLubyte> m_volData;
	int m_volSize;
	
	GLuint m_texName;
	
	// cube geometry and its cut result
	KTetraModel m_tetraCube;
	KPolygonModel m_polyCut;
	
	// slice parameter
	enum {
		VIEWDIR_X,
		VIEWDIR_Y,
		VIEWDIR_Z
	} m_viewDir;
	int m_slice;
	// handle balls
	KIcosahedron m_polyHandleRef;
	KPolygonModel m_polyHandleX, m_polyHandleY, m_polyHandleZ;
	
	int m_prevX, m_prevY, m_prevZ;
	
	// color
	COLORREF m_colorCurrentFg, m_colorCurrentBg;
	COLORREF m_colorPalette[16];
	
	// tool
	State* mp_state;
	
	// 3D geometry
	KPolygonModel m_polyGeometry;
	KVector3d m_geometryPos;
	
	// undo support (only once)
	std::vector<GLubyte> m_volDataUndo;
	void storeUndo();
	
	// .vol data format (stored in clipboard)
	UINT m_cb_format;
	
	static KCore* getInstance() {
		static KCore p;
		return &p;
	}
	
	void init();
	void updateTexture();
	void resetEyePosition();
	void updateHandlePos();
	void updatePolyCut();
	bool loadVolData(const std::string& fname);
	void addNoise();
	void shiftColor();
	void blur();
	void flipX();
	void flipY();
	void flipZ();
	void replaceXY();
	void replaceYZ();
	void replaceZX();
	void changeContrast(double bound = 0.1);
	void changeIntensity(double scale = 1.1);
	bool sweepImageFrom1Dir(const std::string& fname);
	bool sweepImageFrom2Dir(const std::string& fname);
	bool sweepImageFrom3Dir(const std::string& fname);
	bool loadSkin(const std::string& fname);
	static bool is2pow(int n);
	static GLubyte getR(COLORREF col) { return (GLubyte)(col & 0xFF); }
	static GLubyte getG(COLORREF col) { return (GLubyte)((col & 0xFF00) >> 8); }
	static GLubyte getB(COLORREF col) { return (GLubyte)((col & 0xFF0000) >> 16); }
	static COLORREF getRGB(GLubyte r, GLubyte g, GLubyte b) { return r | (g << 8) | (b << 16); }
	int xyz2index(int ix, int iy, int iz) { return 3 * (ix + m_volSize * iy + m_volSize * m_volSize * iz); }
	
protected:
	KCore(void);
	~KCore(void) {}
};
