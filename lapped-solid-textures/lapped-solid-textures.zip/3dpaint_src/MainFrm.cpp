// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "3dpaint.h"

#include "MainFrm.h"
#include "KCore.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
	ON_COMMAND(ID_VIEW_COLORPALETTE, &CMainFrame::OnViewColorpalette)
	ON_UPDATE_COMMAND_UI(ID_VIEW_COLORPALETTE, &CMainFrame::OnUpdateViewColorpalette)
	ON_COMMAND(ID_VIEW_TOOLPALETTE, &CMainFrame::OnViewToolpalette)
	ON_UPDATE_COMMAND_UI(ID_VIEW_TOOLPALETTE, &CMainFrame::OnUpdateViewToolpalette)
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};


// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);
	
	if (!m_wndDlgBarColorPalette.Create(this, IDD_DLG_COLOR, WS_VISIBLE | CBRS_BOTTOM, IDD_DLG_COLOR))
	{
		TRACE0("Failed to create color dialog bar\n");
		return -1;      // fail to create
	}
	m_wndDlgBarColorPalette.EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndDlgBarColorPalette);

	if (!m_wndDlgBarToolPalette.Create(this, IDD_DLG_TOOL, WS_VISIBLE | CBRS_LEFT, IDD_DLG_TOOL))
	{
		TRACE0("Failed to create tool dialog bar\n");
		return -1;      // fail to create
	}
	m_wndDlgBarToolPalette.EnableDocking(CBRS_ALIGN_ANY);
	m_wndDlgBarToolPalette.initBitmap();
	m_wndDlgBarToolPalette.updateData();
	DockControlBar(&m_wndDlgBarToolPalette);
	
	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}


// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame message handlers


void CMainFrame::OnViewColorpalette() {
	ShowControlBar(&m_wndDlgBarColorPalette, !m_wndDlgBarColorPalette.IsWindowVisible(), FALSE);
}

void CMainFrame::OnUpdateViewColorpalette(CCmdUI *pCmdUI) {
	pCmdUI->SetCheck(m_wndDlgBarColorPalette.IsWindowVisible());
}

void CMainFrame::OnViewToolpalette() {
	ShowControlBar(&m_wndDlgBarToolPalette, !m_wndDlgBarToolPalette.IsWindowVisible(), FALSE);
}

void CMainFrame::OnUpdateViewToolpalette(CCmdUI *pCmdUI) {
	pCmdUI->SetCheck(m_wndDlgBarToolPalette.IsWindowVisible());
}
