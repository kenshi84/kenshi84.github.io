// 3dpaintDoc.h : interface of the CMy3dpaintDoc class
//


#pragma once


class CMy3dpaintDoc : public CDocument
{
protected: // create from serialization only
	CMy3dpaintDoc();
	DECLARE_DYNCREATE(CMy3dpaintDoc)

// Attributes
public:

// Operations
public:

// Overrides
public:
	virtual BOOL OnNewDocument();

// Implementation
public:
	virtual ~CMy3dpaintDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
public:
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
};


