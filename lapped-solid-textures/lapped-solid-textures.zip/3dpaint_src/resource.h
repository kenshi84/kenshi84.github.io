//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by 3dpaint.rc
//
#define IDD_ABOUTBOX                    100
#define IDD_DLG_COLOR                   103
#define IDD_DLG_TOOL                    104
#define IDR_MAINFRAME                   128
#define IDR_My3dpaintTYPE               129
#define IDB_BMP_SPUIT                   130
#define IDB_BMP_ERASER                  131
#define IDB_BMP_PEN                     132
#define IDB_BMP_SELECT                  133
#define IDB_BMP_GEOMETRY                134
#define IDB_BMP_BLUR                    135
#define IDC_LBL_COLOR_BG                1002
#define IDC_LBL_COLOR_FG2               1003
#define IDC_LBL_COLOR_FG                1003
#define IDC_RADIO0                      1003
#define IDC_LBL_COLOR0                  1004
#define IDC_RADIO1                      1004
#define IDC_LBL_COLOR1                  1005
#define IDC_RADIO2                      1005
#define IDC_LBL_COLOR2                  1006
#define IDC_RADIO3                      1006
#define IDC_LBL_COLOR3                  1007
#define IDC_LBL_COLOR4                  1008
#define IDC_RADIO4                      1008
#define IDC_LBL_COLOR5                  1009
#define IDC_RADIO5                      1009
#define IDC_LBL_COLOR6                  1010
#define IDC_LBL_COLOR7                  1011
#define IDC_LBL_COLOR8                  1012
#define IDC_LBL_COLOR9                  1013
#define IDC_LBL_COLOR10                 1014
#define IDC_LBL_COLOR11                 1015
#define IDC_LBL_COLOR12                 1016
#define IDC_LBL_COLOR13                 1017
#define IDC_LBL_COLOR14                 1018
#define IDC_LBL_COLOR15                 1019
#define ID_VIEW_COLORPALETTE            32771
#define ID_VIEW_TOOLPALETTE             32772
#define ID_FILE_SWEEPIMAGE              32773
#define ID_PROCESS_NOISE                32774
#define ID_PROCESS_FLIP                 32775
#define ID_FLIP_X                       32776
#define ID_FLIP_Y                       32777
#define ID_FLIP_Z                       32778
#define ID_PROCESS_REPLACE              32779
#define ID_REPLACE_X                    32780
#define ID_REPLACE_Y                    32781
#define ID_REPLACE_Z                    32782
#define ID_PROCESS_BLUR                 32783
#define ID_PROCESS_INTENSITY            32784
#define ID_INTENSITY_INCREASE           32785
#define ID_INTENSITY_DECREASE           32786
#define ID_PROCESS_CONTRAST             32787
#define ID_CONTRAST_INCREASE            32788
#define ID_CONTRAST_DECREASE            32789
#define ID_SWEEP_FROM1DIRECTION         32790
#define ID_SWEEP_FROM2DIRECTION         32791
#define ID_SWEEP_FROM3DIRECTION         32792
#define ID_2DIMAGE_LOADSKIN             32793
#define ID_REPLACE_XY                   32794
#define ID_REPLACE_YZ                   32795
#define ID_REPLACE_ZX                   32796
#define ID_Menu                         32797
#define ID_FILE_LOADGEOMETRY            32798

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32800
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
