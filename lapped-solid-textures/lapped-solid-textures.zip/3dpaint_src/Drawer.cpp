#include "StdAfx.h"
#include "Drawer.h"
#include <gl/glew.h>
#include "KCore.h"
#include <KLIB/KDrawer.h>

Drawer::Drawer(void) {
	m_isDrawHandle = true;
	m_isDrawFrame = true;
	m_isDrawEdge = true;
	m_isDrawAxis = true;
}

Drawer::~Drawer(void) {
}

void Drawer::init() {
	KCore& core = *KCore::getInstance();
	core.m_ogl.m_eyePoint  .set( -5, 0.5, 0.5);
	core.m_ogl.m_focusPoint.set(0.5, 0.5, 0.5);
	glEnable(GL_LIGHT0);
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_DIFFUSE);
	static double genfunc[][4] = {
		{ 1.0, 0.0, 0.0, 0.0 },
		{ 0.0, 1.0, 0.0, 0.0 },
		{ 0.0, 0.0, 1.0, 0.0 },
	};
	glTexGeni(GL_S, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGeni(GL_T, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGeni(GL_R, GL_TEXTURE_GEN_MODE, GL_OBJECT_LINEAR);
	glTexGendv(GL_S, GL_OBJECT_PLANE, genfunc[0]);
	glTexGendv(GL_T, GL_OBJECT_PLANE, genfunc[1]);
	glTexGendv(GL_R, GL_OBJECT_PLANE, genfunc[2]);
}
void Drawer::draw() {
	static double colorHandleActive[3] = {1, 1, 0};
	static double colorHandle      [3] = {0.5, 0.5, 0.5};
	static double colorFrame[3] = {0.25, 0.25, 0.25};
	static double colorEdge[3] = {0.25, 0.25, 0.25};
	
	KCore& core = *KCore::getInstance();
	
	glDisable(GL_LIGHTING);
	glEnable(GL_TEXTURE_3D);
	glBindTexture(GL_TEXTURE_3D, core.m_texName);
	glColor3d(1, 1, 1);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)core.m_polyCut.m_polygons.size(); ++i) {
		KPolygon& p = core.m_polyCut.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& pos = core.m_polyCut.m_vertices[p.m_vtx[j]].m_pos;
			glTexCoord3dv(pos.getPtr());
			glVertex3dv(pos.getPtr());
		}
	}
	glEnd();
	glDisable(GL_TEXTURE_3D);
	if (m_isDrawFrame) {
		// draw frame
		glLineWidth(3);
		glColor3dv(colorFrame);
		KDrawer::drawWireBox(0, 0, 0, 1, 1, 1);
	}
	if (m_isDrawAxis) {
		// draw axis
		glLineWidth(5);
		glPushMatrix();
		glScaled(1.1, 1.1, 1.1);
		KDrawer::drawAxis();
		glPopMatrix();
	}
	if (m_isDrawEdge) {
		// draw edges
		glLineWidth(1);
		glColor3dv(colorEdge);
		double threshold = (core.m_slice + 1.) / core.m_volSize;
		if (core.m_viewDir == KCore::VIEWDIR_X)
			KDrawer::drawWireBox(0, 0, 0, threshold, 1, 1);
		else if (core.m_viewDir == KCore::VIEWDIR_Y) 
			KDrawer::drawWireBox(0, 0, 0, 1, threshold, 1);
		else
			KDrawer::drawWireBox(0, 0, 0, 1, 1, threshold);
	}
	glEnable(GL_LIGHTING);
	if (m_isDrawHandle) {
		// draw handles
		glColor3dv(core.m_viewDir == KCore::VIEWDIR_X ? colorHandleActive : colorHandle);
		KDrawer::drawPolygonModel(core.m_polyHandleX);
		glColor3dv(core.m_viewDir == KCore::VIEWDIR_Y ? colorHandleActive : colorHandle);
		KDrawer::drawPolygonModel(core.m_polyHandleY);
		glColor3dv(core.m_viewDir == KCore::VIEWDIR_Z ? colorHandleActive : colorHandle);
		KDrawer::drawPolygonModel(core.m_polyHandleZ);
	}
	glDisable(GL_LIGHTING);
	core.mp_state->draw();
}
void Drawer::postDraw(CDC* pDC) {}
