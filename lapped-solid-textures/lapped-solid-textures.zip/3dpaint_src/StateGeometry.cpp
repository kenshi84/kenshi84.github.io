#include "StdAfx.h"
#include "KCore.h"
#include "StateGeometry.h"
#include <KLIB/KUtil.h>
#include <KLIB/KDrawer.h>
#include "KPrimitiveShape.h"
#include <vector>

using namespace std;

StateGeometry::StateGeometry() {
	m_poly = KBox(-1, -1, -1, 1, 1, 1);
	m_poly.calcSmoothNormals();
	loadGeometry_init();
}

void StateGeometry::OnLButtonDown(UINT nFlags, CPoint& point) {
	m_point_old = point;
	m_isDragging = true;
}

void StateGeometry::OnLButtonUp  (UINT nFlags, CPoint& point) {
	m_isDragging = false;
}

void StateGeometry::OnMouseMove  (UINT nFlags, CPoint& point) {
	if (!m_isDragging) return;
	KCore& core = *KCore::getInstance();
	CRect rect;
	core.mp_view->GetClientRect(&rect);
	int width  = rect.right - rect.left;
	int height = rect.bottom - rect.top;
	if ((nFlags & MK_SHIFT) != 0) {		// rotation
		double thetaX = 2 * M_PI * (point.x - m_point_old.x) / width;
		double thetaY = 2 * M_PI * (point.y - m_point_old.y) / height;
		
		KMatrix4d mat_hrz, mat_vrt;
		
		// Horizontal rotation
		mat_hrz.setRotationFromAxisAngle(core.m_ogl.m_upDirection, -thetaX);
		
		// Vertical rotation
		KVector3d eye(core.m_ogl.m_eyePoint);	// vector from focus to eye
		eye.sub(core.m_ogl.m_focusPoint);
		KVector3d leftDirection;
		leftDirection.cross(eye, core.m_ogl.m_upDirection);
		leftDirection = mat_hrz.transform(leftDirection);
		mat_vrt.setRotationFromAxisAngle(leftDirection, thetaY);
		
		m_rotation.mul(mat_hrz);
		m_rotation.mul(mat_vrt);
	} else if ((nFlags & MK_CONTROL) != 0) {		// scaling
		m_scale *= 1 + (m_point_old.y - point.y) / (double)height;
	} else {		// translation
		KVector3d start, ori;
		core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
		KVector3d pos;
		int polyID;
		if (!KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) return;
		m_translate.set(pos);
	}
	m_point_old = point;
	core.m_ogl.RedrawWindow();
}

void StateGeometry::OnLButtonDblClk(UINT nFlags, CPoint point) {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	fillInside();
	core.updateTexture();
	core.m_ogl.RedrawWindow();
}

void StateGeometry::fillInside() {
	KCore& core = *KCore::getInstance();
	int N = core.m_volSize;
	int ix_max, iy_max, iz_max, ix_min, iy_min, iz_min;
	ix_max = iy_max = iz_max = -INT_MAX;
	ix_min = iy_min = iz_min =  INT_MAX;
	KMatrix4d rotation_inv(m_rotation);
	rotation_inv.invert();
	for (int i = 0; i < (int)m_poly.m_vertices.size(); ++i) {
		KVector3d v = m_poly.m_vertices[i].m_pos;
		v = rotation_inv.transform(v);
		v.scale(m_scale);
		v.add(m_translate);
		v.scale(N);
		int ix = (int)v.x;
		int iy = (int)v.y;
		int iz = (int)v.z;
		ix_max = max(ix, ix_max);
		iy_max = max(iy, iy_max);
		iz_max = max(iz, iz_max);
		ix_min = min(ix, ix_min);
		iy_min = min(iy, iy_min);
		iz_min = min(iz, iz_min);
	}
	int mrg = 2;
	GLubyte r = KCore::getR(core.m_colorCurrentFg);
	GLubyte g = KCore::getG(core.m_colorCurrentFg);
	GLubyte b = KCore::getB(core.m_colorCurrentFg);
	for (int iz = iz_min - mrg; iz < iz_max + mrg; ++iz) {
		for (int iy = iy_min - mrg; iy < iy_max + mrg; ++iy) {
			for (int ix = ix_min - mrg; ix < ix_max + mrg; ++ix) {
				if (ix < 0 || N <= ix || iy < 0 || N <= iy || iz < 0 || N <= iz) continue;
				KVector3d v(ix, iy, iz);
				v.scale(1. / N);
				v.sub(m_translate);
				v.scale(1 / m_scale);
				v = m_rotation.transform(v);
				double value = m_rbf.getValue(v);
				if (value < 1.5) continue;
				value = min(value, 2);
				double t = (value - 1.5) * 2;
				int index = 3 * (ix + N * iy + N * N * iz);
				core.m_volData[index    ] = (GLubyte)(t * r + (1 - t) * core.m_volData[index    ]);
				core.m_volData[index + 1] = (GLubyte)(t * g + (1 - t) * core.m_volData[index + 1]);
				core.m_volData[index + 2] = (GLubyte)(t * b + (1 - t) * core.m_volData[index + 2]);
			}
		}
	}
}

void StateGeometry::loadGeometry(const char* fname) {
	m_poly.loadObjFile(fname);
	m_poly.calcSmoothNormals();
	loadGeometry_init();
}
void StateGeometry::loadGeometry_init() {
	double xMin, yMin, zMin, xMax, yMax, zMax;
	KUtil::getBoundingBox(m_poly, xMin, yMin, zMin, xMax, yMax, zMax);
	double sMax = max(max(xMax - xMin, yMax - yMin), zMax - zMin);
	m_scale = 0.5 / sMax;
	m_rotation.setIdentity();
	m_translate.set(0, 0, 0);
	// RBF construction
	vector<KVector3d> points;
	vector<double   > values;
	{
		int size_vertices = (int)m_poly.m_vertices.size();
		int size_polygons = (int)m_poly.m_polygons.size();
		points.reserve(size_vertices);
		values.reserve(size_vertices);
		vector<bool> checked(size_vertices, false);
		double delta = sMax * 0.05;
		for (int i = 0; i < size_polygons; ++i) {
			KPolygon& p = m_poly.m_polygons[i];
			for (int j = 0; j < 3; ++j) {
				if (checked[p.m_vtx[j]]) continue;
				checked[p.m_vtx[j]] = true;
				KVector3d v = m_poly.m_vertices[p.m_vtx[j]].m_pos;
				points.push_back(v);
				values.push_back(2);
				v.addWeighted(p.m_normal[j], delta);
				points.push_back(v);
				values.push_back(1);
			}
		}
	}
	m_rbf.setPoints(points);
	m_rbf.setValues(values);
}

void StateGeometry::draw() {
	KCore& core = *KCore::getInstance();
	core.m_ogl.makeOpenGLCurrent();
	glEnable(GL_LIGHTING);
	glDisable(GL_TEXTURE_3D);
	GLubyte r = KCore::getR(core.m_colorCurrentFg);
	GLubyte g = KCore::getG(core.m_colorCurrentFg);
	GLubyte b = KCore::getB(core.m_colorCurrentFg);
	glColor3ub(r, g, b);
	glEnable(GL_NORMALIZE);
	glPushMatrix();
	glTranslated(m_translate.x, m_translate.y, m_translate.z);
	glScaled(m_scale, m_scale, m_scale);
	glMultMatrixd(m_rotation.getPtr());
	KDrawer::drawPolygonModel(m_poly);
	glPopMatrix();
	glDisable(GL_NORMALIZE);
	glDisable(GL_LIGHTING);
}

