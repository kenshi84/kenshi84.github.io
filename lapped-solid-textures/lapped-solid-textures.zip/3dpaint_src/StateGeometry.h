#pragma once
#include "State.h"
#include <KLIB/KGeometry.h>
#include <KLIB/KRBF.h>

class StateGeometry : public State {
	StateGeometry(void);
	~StateGeometry(void) {}
public:
	static StateGeometry* getInstance() {
		static StateGeometry p;
		return &p;
	}
	void OnLButtonDown(UINT nFlags, CPoint& point);
	void OnLButtonUp  (UINT nFlags, CPoint& point);
	void OnMouseMove  (UINT nFlags, CPoint& point);
	void OnMouseWheel (UINT nFlags, short zDelta, CPoint& pt) {}
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) {}
	void OnLButtonDblClk(UINT nFlags, CPoint point);
	void init() {}
	void draw();
	void quit() {}
	void loadGeometry(const char* fname);
	void fillInside();
	KPolygonModel m_poly;
	KVector3d m_translate;
	double m_scale;
	KMatrix4d m_rotation;
	bool m_isDragging;
	CPoint m_point_old;
	KThinPlate3DConstant m_rbf;
protected:
	void loadGeometry_init();
};
