#pragma once

class State {
protected:
	State(void) {}
	~State(void) {}
public:
	virtual void OnLButtonDown(UINT nFlags, CPoint& point) = 0;
	virtual void OnLButtonUp  (UINT nFlags, CPoint& point) = 0;
	virtual void OnMouseMove  (UINT nFlags, CPoint& point) = 0;
	virtual void OnMouseWheel (UINT nFlags, short zDelta, CPoint& pt) = 0;
	virtual void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) = 0;
	virtual void OnLButtonDblClk(UINT nFlags, CPoint point) = 0;
	virtual void init() = 0;
	virtual void draw() = 0;
	virtual void quit() = 0;
};
