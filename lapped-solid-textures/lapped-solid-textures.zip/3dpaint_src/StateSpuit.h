#pragma once
#include "State.h"

class StateSpuit : public State {
	StateSpuit(void) {}
	~StateSpuit(void) {}
public:
	static StateSpuit* getInstance() {
		static StateSpuit p;
		return &p;
	}
	void OnLButtonDown(UINT nFlags, CPoint& point);
	void OnLButtonUp  (UINT nFlags, CPoint& point) {}
	void OnMouseMove  (UINT nFlags, CPoint& point);
	void OnMouseWheel (UINT nFlags, short zDelta, CPoint& pt) {}
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) {}
	void OnLButtonDblClk(UINT nFlags, CPoint point) {}
	void init() {}
	void draw();
	void quit() {}
	bool m_isDrawing;
	int m_currentX, m_currentY, m_currentZ;
};
