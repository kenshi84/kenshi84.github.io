#pragma once
#include "Resource.h"

// DlgBarToolPalette �_�C�A���O

class DlgBarToolPalette : public CDialogBar
{
	DECLARE_DYNAMIC(DlgBarToolPalette)

public:
	DlgBarToolPalette();   // �W���R���X�g���N�^
	virtual ~DlgBarToolPalette();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_DLG_TOOL };

	CBitmap m_bmpPen, m_bmpEraser, m_bmpSpuit, m_bmpSelect, m_bmpGeometry, m_bmpBlur;
	void initBitmap();
	void updateData();

	int m_xvRadioTool;
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedRadio0();
	afx_msg void OnBnClickedRadio1();
	afx_msg void OnBnClickedRadio2();
	afx_msg void OnBnClickedRadio3();
	afx_msg void OnBnClickedRadio4();
	afx_msg void OnBnClickedRadio5();
};
