// DlgBarColorPalette.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "3dpaint.h"
#include "DlgBarColorPalette.h"
#include "KCore.h"


// DlgBarColorPalette �_�C�A���O

IMPLEMENT_DYNAMIC(DlgBarColorPalette, CDialogBar)

DlgBarColorPalette::DlgBarColorPalette()
	: CDialogBar()
{

}

DlgBarColorPalette::~DlgBarColorPalette()
{
}

void DlgBarColorPalette::DoDataExchange(CDataExchange* pDX)
{
	CDialogBar::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(DlgBarColorPalette, CDialogBar)
	ON_WM_CTLCOLOR()
	ON_STN_CLICKED(IDC_LBL_COLOR_FG, &DlgBarColorPalette::OnStnClickedLblColorFg)
	ON_STN_CLICKED(IDC_LBL_COLOR_BG, &DlgBarColorPalette::OnStnClickedLblColorBg)
	ON_STN_CLICKED(IDC_LBL_COLOR0 , &DlgBarColorPalette::OnStnClickedLblColor0 )
	ON_STN_CLICKED(IDC_LBL_COLOR1 , &DlgBarColorPalette::OnStnClickedLblColor1 )
	ON_STN_CLICKED(IDC_LBL_COLOR2 , &DlgBarColorPalette::OnStnClickedLblColor2 )
	ON_STN_CLICKED(IDC_LBL_COLOR3 , &DlgBarColorPalette::OnStnClickedLblColor3 )
	ON_STN_CLICKED(IDC_LBL_COLOR4 , &DlgBarColorPalette::OnStnClickedLblColor4 )
	ON_STN_CLICKED(IDC_LBL_COLOR5 , &DlgBarColorPalette::OnStnClickedLblColor5 )
	ON_STN_CLICKED(IDC_LBL_COLOR6 , &DlgBarColorPalette::OnStnClickedLblColor6 )
	ON_STN_CLICKED(IDC_LBL_COLOR7 , &DlgBarColorPalette::OnStnClickedLblColor7 )
	ON_STN_CLICKED(IDC_LBL_COLOR8 , &DlgBarColorPalette::OnStnClickedLblColor8 )
	ON_STN_CLICKED(IDC_LBL_COLOR9 , &DlgBarColorPalette::OnStnClickedLblColor9 )
	ON_STN_CLICKED(IDC_LBL_COLOR10, &DlgBarColorPalette::OnStnClickedLblColor10)
	ON_STN_CLICKED(IDC_LBL_COLOR11, &DlgBarColorPalette::OnStnClickedLblColor11)
	ON_STN_CLICKED(IDC_LBL_COLOR12, &DlgBarColorPalette::OnStnClickedLblColor12)
	ON_STN_CLICKED(IDC_LBL_COLOR13, &DlgBarColorPalette::OnStnClickedLblColor13)
	ON_STN_CLICKED(IDC_LBL_COLOR14, &DlgBarColorPalette::OnStnClickedLblColor14)
	ON_STN_CLICKED(IDC_LBL_COLOR15, &DlgBarColorPalette::OnStnClickedLblColor15)
	ON_STN_DBLCLK(IDC_LBL_COLOR0 , &DlgBarColorPalette::OnStnDblclickLblColor0 )
	ON_STN_DBLCLK(IDC_LBL_COLOR1 , &DlgBarColorPalette::OnStnDblclickLblColor1 )
	ON_STN_DBLCLK(IDC_LBL_COLOR2 , &DlgBarColorPalette::OnStnDblclickLblColor2 )
	ON_STN_DBLCLK(IDC_LBL_COLOR3 , &DlgBarColorPalette::OnStnDblclickLblColor3 )
	ON_STN_DBLCLK(IDC_LBL_COLOR4 , &DlgBarColorPalette::OnStnDblclickLblColor4 )
	ON_STN_DBLCLK(IDC_LBL_COLOR5 , &DlgBarColorPalette::OnStnDblclickLblColor5 )
	ON_STN_DBLCLK(IDC_LBL_COLOR6 , &DlgBarColorPalette::OnStnDblclickLblColor6 )
	ON_STN_DBLCLK(IDC_LBL_COLOR7 , &DlgBarColorPalette::OnStnDblclickLblColor7 )
	ON_STN_DBLCLK(IDC_LBL_COLOR8 , &DlgBarColorPalette::OnStnDblclickLblColor8 )
	ON_STN_DBLCLK(IDC_LBL_COLOR9 , &DlgBarColorPalette::OnStnDblclickLblColor9 )
	ON_STN_DBLCLK(IDC_LBL_COLOR10, &DlgBarColorPalette::OnStnDblclickLblColor10)
	ON_STN_DBLCLK(IDC_LBL_COLOR11, &DlgBarColorPalette::OnStnDblclickLblColor11)
	ON_STN_DBLCLK(IDC_LBL_COLOR12, &DlgBarColorPalette::OnStnDblclickLblColor12)
	ON_STN_DBLCLK(IDC_LBL_COLOR13, &DlgBarColorPalette::OnStnDblclickLblColor13)
	ON_STN_DBLCLK(IDC_LBL_COLOR14, &DlgBarColorPalette::OnStnDblclickLblColor14)
	ON_STN_DBLCLK(IDC_LBL_COLOR15, &DlgBarColorPalette::OnStnDblclickLblColor15)
END_MESSAGE_MAP()


// DlgBarColorPalette ���b�Z�[�W �n���h��

HBRUSH DlgBarColorPalette::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	HBRUSH hbr = CDialogBar::OnCtlColor(pDC, pWnd, nCtlColor);

	// TODO:  ������ DC �̑�����ύX���Ă��������B
	KCore& core = *KCore::getInstance();
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR_FG)->m_hWnd) { pDC->SetBkColor(core.m_colorCurrentFg); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR_BG)->m_hWnd) { pDC->SetBkColor(core.m_colorCurrentBg); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR0 )->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[0 ]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR1 )->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[1 ]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR2 )->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[2 ]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR3 )->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[3 ]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR4 )->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[4 ]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR5 )->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[5 ]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR6 )->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[6 ]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR7 )->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[7 ]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR8 )->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[8 ]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR9 )->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[9 ]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR10)->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[10]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR11)->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[11]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR12)->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[12]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR13)->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[13]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR14)->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[14]); } else
	if (pWnd->m_hWnd == GetDlgItem(IDC_LBL_COLOR15)->m_hWnd) { pDC->SetBkColor(core.m_colorPalette[15]); }

	// TODO:  ����l���g�p�������Ȃ��ꍇ�͕ʂ̃u���V��Ԃ��܂��B
	return hbr;
}

void DlgBarColorPalette::OnStnClickedLblColorFg() {
	KCore& core = *KCore::getInstance();
	CColorDialog dlg(core.m_colorCurrentFg);
	if (dlg.DoModal() == IDOK) {
		core.m_colorCurrentFg = dlg.GetColor();
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnClickedLblColorBg() {
	KCore& core = *KCore::getInstance();
	CColorDialog dlg(core.m_colorCurrentBg);
	if (dlg.DoModal() == IDOK) {
		core.m_colorCurrentBg = dlg.GetColor();
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnClickedLblColor0() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[0];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor1() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[1];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor2() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[2];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor3() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[3];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor4() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[4];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor5() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[5];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor6() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[6];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor7() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[7];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor8() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[8];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor9() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[9];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor10() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[10];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor11() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[11];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor12() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[12];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor13() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[13];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor14() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[14];
	Invalidate();
}

void DlgBarColorPalette::OnStnClickedLblColor15() {
	KCore& core = *KCore::getInstance();
	COLORREF& col = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	col = core.m_colorPalette[15];
	Invalidate();
}

void DlgBarColorPalette::OnStnDblclickLblColor0(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[0];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor1(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[1];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor2(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[2];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor3(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[3];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor4(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[4];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor5(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[5];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor6(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[6];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor7(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[7];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor8(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[8];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor9(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[9];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor10(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[10];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor11(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[11];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor12(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[12];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor13(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[13];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor14(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[14];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}

void DlgBarColorPalette::OnStnDblclickLblColor15(){
	KCore& core = *KCore::getInstance();
	COLORREF& col1 = core.m_colorPalette[15];
	COLORREF& col2 = (GetKeyState(VK_SHIFT) & 0x8000) == 0 ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	CColorDialog dlg(col1);
	if (dlg.DoModal() == IDOK) {
		col1 = dlg.GetColor();
		col2 = col1;
		Invalidate();
	}
}
