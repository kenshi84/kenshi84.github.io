#pragma once
#include "State.h"
#include <vector>
#include <gl/glew.h>
#include <KLIB/KMath.h>
#include "KCore.h"

class StateSelect : public State {
	StateSelect(void) {}
	~StateSelect(void) {}
public:
	static StateSelect* getInstance() {
		static StateSelect p;
		return &p;
	}
	void OnLButtonDown(UINT nFlags, CPoint& point);
	void OnLButtonUp  (UINT nFlags, CPoint& point);
	void OnMouseMove  (UINT nFlags, CPoint& point);
	void OnMouseWheel (UINT nFlags, short zDelta, CPoint& pt) {}
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	void OnLButtonDblClk(UINT nFlags, CPoint point) {}
	void draw();
	void quit();
//protected:
	void init();
	void pasteBuf();
	int m_step;
	int m_p0_x, m_p0_y, m_p0_z;
	int m_p1_x, m_p1_y, m_p1_z;
	int m_size_x, m_size_y, m_size_z;
	int m_offset_x, m_offset_y, m_offset_z;
	int m_offset_old_x, m_offset_old_y, m_offset_old_z;
	int m_move_orientation;				// 0:X, 1:Y, 2:Z
	KVector3d m_move_from;
	std::vector<GLubyte> m_volDataBuf;
	std::vector<GLubyte> m_volDataBuf_texture;
	GLuint m_texName;
	int m_texSize_x, m_texSize_y, m_texSize_z;
	void updateTexture();
};
