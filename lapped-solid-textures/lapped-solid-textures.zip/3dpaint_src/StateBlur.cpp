#include "StdAfx.h"
#include "StateBlur.h"
#include "KCore.h"
#include <KLIB/KUtil.h>
#include <KLIB/KDrawer.h>

void StateBlur::OnLButtonDown(UINT nFlags, CPoint& point) {
	KCore& core = *KCore::getInstance();
	KVector3d start, ori;
	KVector3d pos;
	int polyID;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	if (!KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) return;
	int N = core.m_volSize;
	core.storeUndo();
	pos.scale(N);
	int ix = (int)pos.x;
	int iy = (int)pos.y;
	int iz = (int)pos.z;
	int index = 3 * (ix + N * iy + N * N * iz);
	int r = 0, g = 0, b = 0;
	int cnt = 0;
	for (int dz = -1; dz <= 1; ++dz) {
		for (int dy = -1; dy <= 1; ++dy) {
			for (int dx = -1; dx <= 1; ++dx) {
				int x = ix + dx;
				int y = iy + dy;
				int z = iz + dz;
				if (x < 0 || N <= x || y < 0 || N <= y || z < 0 || N <= z) continue;
				int index = 3 * (x + N * y + N * N * z);
				r += core.m_volData[index    ];
				g += core.m_volData[index + 1];
				b += core.m_volData[index + 2];
				++cnt;
			}
		}
	}
	core.m_volData[index    ] = (GLubyte)(r / cnt);
	core.m_volData[index + 1] = (GLubyte)(g / cnt);
	core.m_volData[index + 2] = (GLubyte)(b / cnt);
	core.updateTexture();
	core.m_prevX = ix;
	core.m_prevY = iy;
	core.m_prevZ = iz;
	core.m_ogl.RedrawWindow();
}

void StateBlur::OnMouseMove  (UINT nFlags, CPoint& point) {
	KCore& core = *KCore::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (!KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) return;
	int& N = core.m_volSize;
	pos.scale(N);
	int ix = (int)pos.x;
	int iy = (int)pos.y;
	int iz = (int)pos.z;
	int index = 3 * (ix + N * iy + N * N * iz);
	m_currentX = ix;
	m_currentY = iy;
	m_currentZ = iz;
	core.m_ogl.RedrawWindow();
}

void StateBlur::draw() {
	KCore& core = *KCore::getInstance();
	int& N = core.m_volSize;
	double x0 = m_currentX / (double)N;
	double y0 = m_currentY / (double)N;
	double z0 = m_currentZ / (double)N;
	double x1 = (m_currentX + 1) / (double)N;
	double y1 = (m_currentY + 1) / (double)N;
	double z1 = (m_currentZ + 1) / (double)N;
	GLubyte r = KCore::getR(core.m_colorCurrentFg);
	GLubyte g = KCore::getG(core.m_colorCurrentFg);
	GLubyte b = KCore::getB(core.m_colorCurrentFg);
	glColor3ub(r, g, b);
	KDrawer::drawWireBox(x0, y0, z0, x1, y1, z1);
}
