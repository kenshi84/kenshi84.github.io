#include "StdAfx.h"
#include "KTetraCube.h"
using namespace std;

KTetraCube::KTetraCube(double size) {
	m_vertices.clear();
	m_vertices.reserve(8);
	m_vertices.push_back(KVector3d(0, 0, 0));
	m_vertices.push_back(KVector3d(size, 0, 0));
	m_vertices.push_back(KVector3d(0, size, 0));
	m_vertices.push_back(KVector3d(0, 0, size));
	m_vertices.push_back(KVector3d(size, size, 0));
	m_vertices.push_back(KVector3d(0, size, size));
	m_vertices.push_back(KVector3d(size, 0, size));
	m_vertices.push_back(KVector3d(size, size, size));
	m_tetras.clear();
	m_tetras.reserve(5);
	m_tetras.push_back(KTetra(0, 1, 2, 3));
	m_tetras.push_back(KTetra(7, 1, 2, 4));
	m_tetras.push_back(KTetra(7, 2, 3, 5));
	m_tetras.push_back(KTetra(7, 3, 1, 6));
	m_tetras.push_back(KTetra(7, 3, 2, 1));
	calcNeighbor();
}
