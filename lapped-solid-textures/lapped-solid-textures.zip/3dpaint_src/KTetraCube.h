#pragma once

#include <KLIB/KGeometry.h>

class KTetraCube : public KTetraModel {
public:
	KTetraCube(double size = 1);
	~KTetraCube(void) {}
};
