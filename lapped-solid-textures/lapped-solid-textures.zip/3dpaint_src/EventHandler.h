#pragma once

class EventHandler
{
public:
	EventHandler(void) {}
	~EventHandler(void) {}
	void OnLButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnLButtonUp(CView* view, UINT nFlags, CPoint& point);
	void OnRButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnRButtonUp(CView* view, UINT nFlags, CPoint& point);
	void OnMButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnMButtonUp(CView* view, UINT nFlags, CPoint& point);
	void OnMouseMove(CView* view, UINT nFlags, CPoint& point);
	void OnDropFiles(CView* view, HDROP hDropInfo);
	void OnMouseWheel(CView* view, UINT nFlags, short zDelta, CPoint& pt);
	void OnKeyDown(CView* view, UINT nChar, UINT nRepCnt, UINT nFlags);
	void OnLButtonDblClk(CView* view, UINT nFlags, CPoint point);
	bool m_isDraggingHandle;
	//bool m_isDrawing;
	bool m_isMovingCamera;
};
