#pragma once
#include <KLIB/KGeometry.h>

class KBox : public KPolygonModel {
public:
	KBox(double x0, double y0, double z0, double x1, double y1, double z1) {
		init(x0, y0, z0, x1, y1, z1);
	}
	KBox(const KVector3d& v0, const KVector3d& v1) {
		init(v0.x, v0.y, v0.z, v1.x, v1.y, v1.z);
	}
	~KBox() {}
	void init(double x0, double y0, double z0, double x1, double y1, double z1);
};
