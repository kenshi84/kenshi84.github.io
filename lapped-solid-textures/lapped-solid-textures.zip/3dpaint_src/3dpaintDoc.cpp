// 3dpaintDoc.cpp : implementation of the CMy3dpaintDoc class
//

#include "stdafx.h"
#include "3dpaint.h"
#include "3dpaintDoc.h"
#include "KCore.h"
#include "VolumeHeader.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMy3dpaintDoc

IMPLEMENT_DYNCREATE(CMy3dpaintDoc, CDocument)

BEGIN_MESSAGE_MAP(CMy3dpaintDoc, CDocument)
END_MESSAGE_MAP()


// CMy3dpaintDoc construction/destruction

CMy3dpaintDoc::CMy3dpaintDoc()
{
	// TODO: add one-time construction code here

}

CMy3dpaintDoc::~CMy3dpaintDoc()
{
}

BOOL CMy3dpaintDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
	KCore& core = *KCore::getInstance();
	core.m_volSize = 64;
	core.m_volData.clear();
	core.m_volData.resize(core.m_volSize * core.m_volSize * core.m_volSize * 3, 255);
	core.init();
	CMainFrame* p = (CMainFrame *)AfxGetMainWnd();
	if (p != NULL) {
		p->m_wndDlgBarColorPalette.Invalidate();
		p->m_wndDlgBarToolPalette.updateData();
	}
	
	return TRUE;
}




// CMy3dpaintDoc diagnostics

#ifdef _DEBUG
void CMy3dpaintDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMy3dpaintDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CMy3dpaintDoc commands

BOOL CMy3dpaintDoc::OnOpenDocument(LPCTSTR lpszPathName)
{
	KCore& core = *KCore::getInstance();
	if (!CDocument::OnOpenDocument(lpszPathName))
		return FALSE;

	// TODO:  �����ɓ���ȍ쐬�R�[�h��ǉ����Ă��������B
	FILE * fin = fopen(lpszPathName, "rb");
	if (!fin) {
		CString str;
		str.Format("Failed to open file %s", lpszPathName);
		AfxMessageBox(str);
		return FALSE;
	}
	char buf[4096];
	fread(buf, 1, 4096, fin);
	
	VolumeHeader* header = (VolumeHeader *)buf;
	if ((header->magic[0] != 'V') ||
		(header->magic[1] != 'O') ||
		(header->magic[2] != 'L') ||
		(header->magic[3] != 'U') ||
		(header->bytesPerChannel != 1) ||
		(header->version != 4))
	{
		AfxMessageBox("Bad header!");
		return FALSE;
	}
	if (!KCore::is2pow(header->volSize)) {
		AfxMessageBox("Texture size must be power of 2.");
		return FALSE;
	}
	if (header->numChannels != 3) {
		AfxMessageBox("Only RGB format supported.");
		return FALSE;
	}
	core.m_volSize = header->volSize;
	int volBytes = core.m_volSize * core.m_volSize * core.m_volSize * 3;
	core.m_volData.resize(volBytes);
	fread(&core.m_volData[0], 1, volBytes, fin);
	fclose(fin);
	core.init();
	core.m_ogl.RedrawWindow();
	CMainFrame* p = (CMainFrame *)AfxGetMainWnd();
	if (p != NULL) {
		p->m_wndDlgBarColorPalette.Invalidate();
		p->m_wndDlgBarToolPalette.updateData();
	}
	return TRUE;
}

BOOL CMy3dpaintDoc::OnSaveDocument(LPCTSTR lpszPathName)
{
	// TODO: �����ɓ���ȃR�[�h��ǉ����邩�A�������͊�{�N���X���Ăяo���Ă��������B
	FILE * fout = fopen(lpszPathName, "wb");
	if (!fout) {
		CString str;
		str.Format("Failed to open file %s", lpszPathName);
		AfxMessageBox(str);
		return FALSE;
	}
	char buf[4096];
	VolumeHeader* header = (VolumeHeader *)buf;
	KCore& core = *KCore::getInstance();
	header->magic[0] = 'V';
	header->magic[1] = 'O';
	header->magic[2] = 'L';
	header->magic[3] = 'U';
	header->bytesPerChannel = 1;
	header->version = 4;
	header->volSize = core.m_volSize;
	header->numChannels = 3;
	sprintf(header->texName, "Created by 3dpaint");
	fwrite(buf, 1, 4096, fout);
	int volBytes = core.m_volSize * core.m_volSize * core.m_volSize * 3;
	fwrite(&core.m_volData[0], 1, volBytes, fout);
	fclose(fout);
	SetModifiedFlag(FALSE);
	
	return TRUE;//CDocument::OnSaveDocument(lpszPathName);
}
