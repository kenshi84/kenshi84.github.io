#include "StdAfx.h"
#include "KWaveletNoise.h"
#include <cfloat>
using namespace std;

vector<double> KWaveletNoise::getNoise3D(int pow2) {
	int n = 1 << pow2;
	vector<double> data(n * n * n, 0);
	
	for (int i = 0; i < pow2; ++i) {
		// random noise on 2^(i + 1) image
		int nn = 1 << (i + 1);
		vector<double> tmp(nn * nn * nn);
		for (int j = 0; j < (int)tmp.size(); ++j) tmp[j] = rand() / (double)RAND_MAX;
		// downsample
		int nn_down = nn / 2;
		vector<double> tmp_down(nn_down * nn_down * nn_down);
		for (int iz = 0; iz < nn; ++iz) {
			for (int iy = 0; iy < nn; ++iy) {
				for (int ix = 0; ix < nn; ++ix) {
					int ix_down = ix / 2;
					int iy_down = iy / 2;
					int iz_down = iz / 2;
					tmp_down[ix_down + nn_down * iy_down + nn_down * nn_down * iz_down] += tmp[ix + nn * iy + nn * nn * iz];
				}
			}
		}
		for (int j = 0; j < (int)tmp_down.size(); ++j) tmp_down[j] /= 8;
		// subtract
		for (int iz = 0; iz < nn; ++iz) {
			for (int iy = 0; iy < nn; ++iy) {
				for (int ix = 0; ix < nn; ++ix) {
					tmp[ix + nn * iy + nn * nn * iz] -= upsample(tmp_down, i, ix, iy, iz, 2);
				}
			}
		}
		
		double weight = 1. / (1 << i);
		for (int iz = 0; iz < n; ++iz) {
			for (int iy = 0; iy < n; ++iy) {
				for (int ix = 0; ix < n; ++ix) {
					data[ix + n * iy + n * n * iz] += weight * upsample(tmp, i + 1, ix, iy, iz, 1 << (pow2 - i - 1));
				}
			}
		}
	}
	// normalize
	double dmax = -DBL_MAX;
	double dmin =  DBL_MAX;
	for (int i = 0; i < (int)data.size(); ++i) {
		dmax = max(data[i], dmax);
		dmin = min(data[i], dmin);
	}
	double dlen = dmax - dmin;
	for (int i = 0; i < (int)data.size(); ++i) {
		data[i] -= dmin;
		data[i] /= dlen;
	}
	return data;
	//for (int i = 0; i < (int)data.size(); ++i) data[i] = rand() / (double)RAND_MAX;
	//const int levelMax = 5;
	//vector<vector<double> > filtered(levelMax);
	//filtered[0] = data;
	//for (int i = 1; i < levelMax; ++i) {
	//	int p = 1 << i;
	//	int nx = sizeX / p;
	//	int ny = sizeY / p;
	//	int nz = sizeZ / p;
	//	int nxx = nx * 2;
	//	int nyy = ny * 2;
	//	int nzz = nz * 2;
	//	filtered[i].resize(nx * ny * nz);
	//	for (int iz = 0; iz < nz; ++iz) {
	//		for (int iy = 0; iy < ny; ++iy) {
	//			for (int ix = 0; ix < nx; ++ix) {
	//				double total = 0;
	//				for (int iz2 = 0; iz2 < 2; ++iz2) {
	//					int izz = min(2 * iz + iz2, nzz - 1);
	//					for (int iy2 = 0; iy2 < 2; ++iy2) {
	//						int iyy = min(2 * iy + iy2, nyy - 1);
	//						for (int ix2 = 0; ix2 < 2; ++ix2) {
	//							int ixx = min(2 * ix + ix2, nxx - 1);
	//							total += filtered[i - 1][ixx + nxx * iyy + nxx * nyy * izz];
	//						}
	//					}
	//				}
	//				filtered[i][ix + nx * iy + nx * ny * iz] = total / 8;
	//			}
	//		}
	//	}
	//}
	//vector<vector<double> > signal(levelMax - 1);
	//for (int i = 0; i < levelMax - 1; ++i) {
	//	int p = 1 << i;
	//	int nx = sizeX / p;
	//	int ny = sizeY / p;
	//	int nz = sizeZ / p;
	//	signal[i].resize(nx * ny * nz);
	//	for (int iz = 0; iz < nz; ++iz) {
	//		for (int iy = 0; iy < ny; ++iy) {
	//			for (int ix = 0; ix < nx; ++ix) {
	//				signal[i][ix + nx * iy + nx * ny * iz] =
	//					filtered[i][ix + nx * iy + nx * ny * iz] -
	//					upsample(filtered[i + 1], nx / 2, ny / 2, nz / 2, ix, iy, iz, 2);
	//			}
	//		}
	//	}
	//}
	//vector<double> noise(sizeX * sizeY * sizeZ, 0);
	//vector<double> amplitude(levelMax - 1);
	//for (int i = 0; i < levelMax - 1; ++i)
	//	amplitude[i] = pow(0.2, levelMax - i - 2);
	//for (int iz = 0; iz < sizeZ; ++iz) {
	//	for (int iy = 0; iy < sizeY; ++iy) {
	//		for (int ix = 0; ix < sizeX; ++ix) {
	//			for (int i = 0; i < levelMax - 1; ++i) {
	//				int p = 1 << i;
	//				int nx = sizeX / p;
	//				int ny = sizeY / p;
	//				int nz = sizeZ / p;
	//				noise[ix + sizeX * iy + sizeX * sizeY * iz] += upsample(signal[i], nx, ny, nz, ix, iy, iz, 1 << i) * amplitude[i];
	//			}
	//		}
	//	}
	//}
	//return noise;
}

double KWaveletNoise::upsample(const vector<double>& data, int pow2, int x, int y, int z, int s) {
	int n = 1 << pow2;
	if (s == 1) return data[x + n * y + n * n * z];
	int ix0 = x / s;
	int iy0 = y / s;
	int iz0 = z / s;
	int ix1 = min(ix0 + 1, n - 1);
	int iy1 = min(iy0 + 1, n - 1);
	int iz1 = min(iz0 + 1, n - 1);
	double v000 = data[ix0 + n * iy0 + n * n * iz0];
	double v100 = data[ix1 + n * iy0 + n * n * iz0];
	double v010 = data[ix0 + n * iy1 + n * n * iz0];
	double v001 = data[ix0 + n * iy0 + n * n * iz1];
	double v110 = data[ix1 + n * iy1 + n * n * iz0];
	double v011 = data[ix0 + n * iy1 + n * n * iz1];
	double v101 = data[ix1 + n * iy0 + n * n * iz1];
	double v111 = data[ix1 + n * iy1 + n * n * iz1];
	double wx = x / (double)s - ix0;
	double wy = y / (double)s - iy0;
	double wz = z / (double)s - iz0;
	double vX00 = interpolate(v000, v100, wx);
	double vX10 = interpolate(v010, v110, wx);
	double vX01 = interpolate(v001, v101, wx);
	double vX11 = interpolate(v011, v111, wx);
	double vXY0 = interpolate(vX00, vX10, wy);
	double vXY1 = interpolate(vX01, vX11, wy);
	double vXYZ = interpolate(vXY0, vXY1, wz);
	return vXYZ;
}
