#pragma once
#include <vector>
#define _USE_MATH_DEFINES
#include <cmath>

class KWaveletNoise
{
public:
	static std::vector<double> getNoise3D(int pow2);

private:
	static double upsample(const std::vector<double>& data, int pow2, int x, int y, int z, int s);
	static double interpolate (double v1, double v2, double t) {
		double cost = 0.5 * (1 - cos(M_PI * t));
		return (1 - cost) * v1 + cost * v2;
	}
	KWaveletNoise(void);
	~KWaveletNoise(void);
};
