// 3dpaint.h : main header file for the 3dpaint application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CMy3dpaintApp:
// See 3dpaint.cpp for the implementation of this class
//

class CMy3dpaintApp : public CWinApp
{
public:
	CMy3dpaintApp();


// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CMy3dpaintApp theApp;