#include "StdAfx.h"
#include "EventHandler.h"
#include "KCore.h"
#include "StatePen.h"
#include "3dpaintDoc.h"
#include "MainFrm.h"
#include <KLIB/KUtil.h>
#include <vector>
#include <string>
#include <algorithm>
#include "StateGeometry.h"
using namespace std;

void EventHandler::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	KCore& core = *KCore::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (core.m_drawer.m_isDrawHandle && KUtil::getIntersection(pos, polyID, core.m_polyHandleX, start, ori)) {
		core.m_viewDir = KCore::VIEWDIR_X;
		m_isDraggingHandle = true;
	} else if (core.m_drawer.m_isDrawHandle && KUtil::getIntersection(pos, polyID, core.m_polyHandleY, start, ori)) {
		core.m_viewDir = KCore::VIEWDIR_Y;
		m_isDraggingHandle = true;
	} else if (core.m_drawer.m_isDrawHandle && KUtil::getIntersection(pos, polyID, core.m_polyHandleZ, start, ori)) {
		core.m_viewDir = KCore::VIEWDIR_Z;
		m_isDraggingHandle = true;
	} else {
		core.mp_state->OnLButtonDown(nFlags, point);
	}
}
void EventHandler::OnLButtonUp(CView* view, UINT nFlags, CPoint& point) {
	m_isDraggingHandle = false;
	KCore::getInstance()->mp_state->OnLButtonUp(nFlags, point);
	//m_isDrawing = false;
}
void EventHandler::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			KCore::getInstance()->m_ogl.ButtonDownForTranslate(point);
		} else {
			KCore::getInstance()->m_ogl.ButtonDownForRotate(point);
		}
	}else {
		KCore::getInstance()->m_ogl.ButtonDownForZoom(point);
	}
	m_isMovingCamera = true;
}
void EventHandler::OnRButtonUp(CView* view, UINT nFlags, CPoint& point) {
	KCore::getInstance()->m_ogl.ButtonUp();
	m_isMovingCamera = false;
}
void EventHandler::OnMButtonDown(CView* view, UINT nFlags, CPoint& point) {
	KCore::getInstance()->m_ogl.ButtonDownForTranslate(point);
	m_isMovingCamera = true;
}
void EventHandler::OnMButtonUp(CView* view, UINT nFlags, CPoint& point) {
	KCore::getInstance()->m_ogl.ButtonUp();
	m_isMovingCamera = false;
}
void EventHandler::OnMouseMove(CView* view, UINT nFlags, CPoint& point) {
	KCore& core = *KCore::getInstance();
	if (m_isMovingCamera) {
		core.m_ogl.MouseMove(point);
		return;
	}
	if (m_isDraggingHandle) {
		KVector3d start, ori;
		core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
		KVector3d x(ori);
		x.normalize();
		KVector3d e(core.m_ogl.m_eyePoint);
		KVector3d d;
		if (core.m_viewDir == KCore::VIEWDIR_X)
			d.set(1, 0, 0);
		else if (core.m_viewDir == KCore::VIEWDIR_Y)
			d.set(0, 1, 0);
		else
			d.set(0, 0, 1);
		double ed = e.dot(d);
		double ex = e.dot(x);
		double xd = x.dot(d);
		double k = (ed - ex * xd) / (1 - xd * xd);
		k = max(1. / core.m_volSize, min(1, k));
		core.m_slice = (int)(k * core.m_volSize) - 1;
		core.updatePolyCut();
		core.updateHandlePos();
		core.m_ogl.RedrawWindow();
	} else {
		core.mp_state->OnMouseMove(nFlags, point);
	}
}
void EventHandler::OnMouseWheel(CView* view, UINT nFlags, short zDelta, CPoint& pt) {
	KCore& core = *KCore::getInstance();
	core.m_slice += zDelta < 0 ? -1 : 1;
	core.m_slice = max(0, min(core.m_volSize - 1, core.m_slice));
	core.updatePolyCut();
	core.updateHandlePos();
	core.m_ogl.RedrawWindow();
}
void EventHandler::OnKeyDown(CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {
	KCore& core = *KCore::getInstance();
	switch (nChar) {
		case 'X':
		case 'Y':
		case 'Z':
			core.m_viewDir =
				nChar == 'X' ? KCore::VIEWDIR_X :
				nChar == 'Y' ? KCore::VIEWDIR_Y : KCore::VIEWDIR_Z;
			core.m_slice =
				nChar == 'X' ? core.m_prevX :
				nChar == 'Y' ? core.m_prevY : core.m_prevZ;
			core.updateHandlePos();
			core.updatePolyCut();
			core.m_ogl.RedrawWindow();
			break;
		case VK_UP:
		case VK_DOWN:
			core.m_slice += nChar == VK_UP ? 1 : -1;
			core.m_slice = max(0, min(core.m_volSize - 1, core.m_slice));
			core.updatePolyCut();
			core.updateHandlePos();
			core.m_ogl.RedrawWindow();
			break;
		case 'H':
			core.m_drawer.m_isDrawHandle = !core.m_drawer.m_isDrawHandle;
			core.m_ogl.RedrawWindow();
			break;
		case 'F':
			core.m_drawer.m_isDrawFrame = !core.m_drawer.m_isDrawFrame;
			core.m_ogl.RedrawWindow();
			break;
		case 'E':
			core.m_drawer.m_isDrawEdge = !core.m_drawer.m_isDrawEdge;
			core.m_ogl.RedrawWindow();
			break;
		case 'A':
			core.m_drawer.m_isDrawAxis = !core.m_drawer.m_isDrawAxis;
			core.m_ogl.RedrawWindow();
			break;
	}
	core.mp_state->OnKeyDown(nChar, nRepCnt, nFlags);
}
void EventHandler::OnDropFiles(CView* view, HDROP hDropInfo) {
	KCore& core = *KCore::getInstance();
	if (DragQueryFile(hDropInfo, -1, NULL, 0) != 1) return;
	int len = DragQueryFile(hDropInfo, 0, NULL, 0);
	vector<char> buf(len + 1, 0);
	DragQueryFile(hDropInfo, 0, &buf[0], len + 1);
	string fname(&buf[0]);
	size_t extPos = fname.rfind('.');
	string ext = fname.substr(extPos, fname.length() - extPos);
	transform(ext.begin(), ext.end(), ext.begin(), tolower);
	if (ext.compare(".vol") == 0) {
		AfxGetApp()->OpenDocumentFile(fname.c_str());
		core.mp_state = StatePen::getInstance();
		core.m_ogl.RedrawWindow();
		return;
	} else if (ext.compare(".obj") == 0) {
		StateGeometry::getInstance()->loadGeometry(fname.c_str());
		core.m_ogl.RedrawWindow();
		return;
	}
	AfxMessageBox("Invalid file type!");
}

void EventHandler::OnLButtonDblClk(CView* view, UINT nFlags, CPoint point) {
	KCore::getInstance()->mp_state->OnLButtonDblClk(nFlags, point);
}
