#include "StdAfx.h"
#include "StateSelect.h"
#include "MainFrm.h"
#include <KLIB/KUtil.h>
#include <KLIB/KDrawer.h>
#include "KPrimitiveShape.h"

void StateSelect::init() {
	m_p0_x = m_p0_y = m_p0_z = m_p1_x = m_p1_y = m_p1_z = m_offset_x = m_offset_y = m_offset_z = 0;
	m_step = 0;
}

void StateSelect::quit() {
	if (m_step == 2) {
		pasteBuf();
	}
	((CMainFrame *)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(0, "");
}

void StateSelect::pasteBuf() {
	KCore& core = *KCore::getInstance();
	int& N = core.m_volSize;
	core.storeUndo();
	for (int iz = 0; iz < m_size_z; ++iz) {
		for (int iy = 0; iy < m_size_y; ++iy) {
			for (int ix = 0; ix < m_size_x; ++ix) {
				int index = 3 * (
					(m_offset_x + ix) +
					(m_offset_y + iy) * N +
					(m_offset_z + iz) * N * N);
				int index2 = 3 * (
					ix +
					iy * m_size_x +
					iz * m_size_x * m_size_y);
				core.m_volData[index    ] = m_volDataBuf[index2    ];
				core.m_volData[index + 1] = m_volDataBuf[index2 + 1];
				core.m_volData[index + 2] = m_volDataBuf[index2 + 2];
			}
		}
	}
	core.updateTexture();
	core.m_ogl.RedrawWindow();
}

void StateSelect::OnLButtonDown(UINT nFlags, CPoint& point) {
	KCore& core = *KCore::getInstance();
	int& N = core.m_volSize;
	if (m_step == 0) {			// first selection corner is specified (do nothing)
		m_step = 1;
	} else if (m_step == 1) {		// both selection corners are specified
		int tmp_x = m_p0_x;
		int tmp_y = m_p0_y;
		int tmp_z = m_p0_z;
		m_p0_x = min(m_p0_x, m_p1_x);
		m_p0_y = min(m_p0_y, m_p1_y);
		m_p0_z = min(m_p0_z, m_p1_z);
		m_p1_x = max(tmp_x, m_p1_x);
		m_p1_y = max(tmp_y, m_p1_y);
		m_p1_z = max(tmp_z, m_p1_z);
		m_size_x = m_p1_x - m_p0_x + 1;
		m_size_y = m_p1_y - m_p0_y + 1;
		m_size_z = m_p1_z - m_p0_z + 1;
		m_offset_x = m_p0_x;
		m_offset_y = m_p0_y;
		m_offset_z = m_p0_z;
		m_volDataBuf.resize(3 * m_size_x * m_size_y * m_size_z);
		GLubyte bg_r = KCore::getR(core.m_colorCurrentBg);
		GLubyte bg_g = KCore::getG(core.m_colorCurrentBg);
		GLubyte bg_b = KCore::getB(core.m_colorCurrentBg);
		core.storeUndo();
		for (int z = 0; z < m_size_z; ++z) {
			for (int y = 0; y < m_size_y; ++y) {
				for (int x = 0; x < m_size_x; ++x) {
					int index = 3 * (x + m_size_x * (y + m_size_y * z));
					int index2 = 3 * (m_p0_x + x + N * (m_p0_y + y + N * (m_p0_z + z)));
					GLubyte& r = core.m_volData[index2    ];
					GLubyte& g = core.m_volData[index2 + 1];
					GLubyte& b = core.m_volData[index2 + 2];
					m_volDataBuf[index    ] = r;
					m_volDataBuf[index + 1] = g;
					m_volDataBuf[index + 2] = b;
					r = bg_r;
					g = bg_g;
					b = bg_b;
				}
			}
		}
		updateTexture();
		core.updateTexture();
		m_step = 2;
		((CMainFrame *)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(0, "");
	} if (m_step == 2) {			// selected region is { moved / pasted }
		double x0 = m_offset_x / (double)N;
		double y0 = m_offset_y / (double)N;
		double z0 = m_offset_z / (double)N;
		double x1 = (m_offset_x + m_size_x) / (double)N;
		double y1 = (m_offset_y + m_size_y) / (double)N;
		double z1 = (m_offset_z + m_size_z) / (double)N;
		KBox box(x0, y0, z0, x1, y1, z1);
		KVector3d start, ori;
		KVector3d pos;
		int polyID;
		core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
		if (!KUtil::getIntersection(pos, polyID, box, start, ori)) {	// pasted --> update texture and go back to the initial
			pasteBuf();
			m_step = 0;
			m_offset_x = m_offset_y = m_offset_z = 0;
			return;
		}
		// decide which direction to move (perpendicular to { x / y / z } axis)
		static const int face_x[4] = { 1, 5, 6, 9  };
		static const int face_y[4] = { 0, 4, 8, 11 };
		static const int face_z[4] = { 2, 3, 7, 10 };
		for (int i = 0; i < 4; ++i) {
			if (polyID == face_x[i]) {
				m_move_orientation = 0;
				break;
			} else if (polyID == face_y[i]) {
				m_move_orientation = 1;
				break;
			} else if (polyID == face_z[i]) {
				m_move_orientation = 2;
				break;
			}
		}
		m_offset_old_x = m_offset_x;
		m_offset_old_y = m_offset_y;
		m_offset_old_z = m_offset_z;
		m_move_from = pos;
		m_step = 3;
	}
}

void StateSelect::OnLButtonUp  (UINT nFlags, CPoint& point) {
	if (m_step == 3) {
		m_step = 2;
	}
}

void StateSelect::OnMouseMove  (UINT nFlags, CPoint& point) {
	KCore& core = *KCore::getInstance();
	int N = core.m_volSize;
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	if (m_step == 3) {	// selected region is being dragged
		double t = 0;
		if (m_move_orientation == 0) {	// moving perpendicular to x-axis
			t = (m_move_from.x - start.x) / ori.x;
		} else if (m_move_orientation == 1) {	// moving perpendicular to y-axis
			t = (m_move_from.y - start.y) / ori.y;
		} else {	// moving perpendicular to z-axis
			t = (m_move_from.z - start.z) / ori.z;
		}
		KVector3d dif(start);
		dif.addWeighted(ori, t);
		dif.sub(m_move_from);
		int dx = (int)(dif.x * N);
		int dy = (int)(dif.y * N);
		int dz = (int)(dif.z * N);
		m_offset_x = max(min(N - m_size_x, m_offset_old_x + dx), 0);
		m_offset_y = max(min(N - m_size_y, m_offset_old_y + dy), 0);
		m_offset_z = max(min(N - m_size_z, m_offset_old_z + dz), 0);
		core.m_ogl.RedrawWindow();
		return;
	}
	KVector3d pos;
	int polyID;
	if (!KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) return;
	pos.scale(N);
	int ix = (int)pos.x;
	int iy = (int)pos.y;
	int iz = (int)pos.z;
	if (m_step == 0) {
		m_p0_x = m_p1_x = ix;
		m_p0_y = m_p1_y = iy;
		m_p0_z = m_p1_z = iz;
	} else if (m_step == 1) {
		m_p1_x = ix;
		m_p1_y = iy;
		m_p1_z = iz;
	}
	if (m_step == 1) {
		int size_x = abs(m_p0_x - m_p1_x) + 1;
		int size_y = abs(m_p0_y - m_p1_y) + 1;
		int size_z = abs(m_p0_z - m_p1_z) + 1;
		char buf[256];
		sprintf(buf, "%d x %d x %d", size_x, size_y, size_z);
		((CMainFrame *)AfxGetMainWnd())->m_wndStatusBar.SetPaneText(0, buf);
	}
	core.m_ogl.RedrawWindow();
}

void StateSelect::draw() {
	KCore& core = *KCore::getInstance();
	int& N = core.m_volSize;
	if (m_step < 2) {
		double x0 = min(m_p0_x, m_p1_x) / (double)N;
		double y0 = min(m_p0_y, m_p1_y) / (double)N;
		double z0 = min(m_p0_z, m_p1_z) / (double)N;
		double x1 = (max(m_p0_x, m_p1_x) + 1) / (double)N - 0.001;
		double y1 = (max(m_p0_y, m_p1_y) + 1) / (double)N - 0.001;
		double z1 = (max(m_p0_z, m_p1_z) + 1) / (double)N - 0.001;
		glEnable(GL_TEXTURE_3D);
		glBindTexture(GL_TEXTURE_3D, core.m_texName);
		glEnable(GL_TEXTURE_GEN_S);
		glEnable(GL_TEXTURE_GEN_T);
		glEnable(GL_TEXTURE_GEN_R);
		KDrawer::drawBox(x0, y0, z0, x1, y1, z1);
		glDisable(GL_TEXTURE_GEN_S);
		glDisable(GL_TEXTURE_GEN_T);
		glDisable(GL_TEXTURE_GEN_R);
		glDisable(GL_TEXTURE_3D);
		GLubyte r = KCore::getR(core.m_colorCurrentFg);
		GLubyte g = KCore::getG(core.m_colorCurrentFg);
		GLubyte b = KCore::getB(core.m_colorCurrentFg);
		glColor3ub(r, g, b);
		KDrawer::drawWireBox(x0, y0, z0, x1, y1, z1);
	} else {
		double x0 = m_offset_x / (double)N;
		double y0 = m_offset_y / (double)N;
		double z0 = m_offset_z / (double)N;
		double x1 = (m_offset_x + m_size_x) / (double)N;
		double y1 = (m_offset_y + m_size_y) / (double)N;
		double z1 = (m_offset_z + m_size_z) / (double)N;
		double s1 = m_size_x / (double)m_texSize_x;
		double t1 = m_size_y / (double)m_texSize_y;
		double r1 = m_size_z / (double)m_texSize_z;
		glEnable(GL_TEXTURE_3D);
		glBindTexture(GL_TEXTURE_3D, m_texName);
		KDrawer::drawBoxTex3D(x0, y0, z0, x1, y1, z1, 0, 0, 0, s1, t1, r1);
		glDisable(GL_TEXTURE_3D);
		GLubyte r = KCore::getR(core.m_colorCurrentFg);
		GLubyte g = KCore::getG(core.m_colorCurrentFg);
		GLubyte b = KCore::getB(core.m_colorCurrentFg);
		glColor3ub(r, g, b);
		KDrawer::drawWireBox(x0, y0, z0, x1, y1, z1);
	}
}

void StateSelect::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) {
	KCore& core = *KCore::getInstance();
	switch(nChar) {
		case VK_ESCAPE:
			init();
			core.m_ogl.RedrawWindow();
			break;
	}
}

void StateSelect::updateTexture() {
	KCore& core = *KCore::getInstance();
	for (m_texSize_x = 1; m_texSize_x <= m_size_x; m_texSize_x <<= 1);
	for (m_texSize_y = 1; m_texSize_y <= m_size_y; m_texSize_y <<= 1);
	for (m_texSize_z = 1; m_texSize_z <= m_size_z; m_texSize_z <<= 1);
	m_volDataBuf_texture.clear();
	m_volDataBuf_texture.resize(3 * m_texSize_x * m_texSize_y * m_texSize_z);
	for (int z = 0; z <= m_size_z; ++z) {
		for (int y = 0; y <= m_size_y; ++y) {
			for (int x = 0; x <= m_size_x; ++x) {
				int index  = 3 * (x + m_texSize_x * (y + m_texSize_y * z));
				int index2 = 3 * (min(x, m_size_x - 1) + m_size_x    * (min(y, m_size_y - 1) + m_size_y    * min(z, m_size_z - 1)));
				m_volDataBuf_texture[index    ] = m_volDataBuf[index2    ];
				m_volDataBuf_texture[index + 1] = m_volDataBuf[index2 + 1];
				m_volDataBuf_texture[index + 2] = m_volDataBuf[index2 + 2];
			}
		}
	}
	core.m_ogl.makeOpenGLCurrent();
	glDeleteTextures(1, &m_texName);
	glGenTextures(1, &m_texName);
	glBindTexture(GL_TEXTURE_3D, m_texName);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
	glTexImage3D(GL_TEXTURE_3D, 0, GL_RGB, m_texSize_x, m_texSize_y, m_texSize_z, 0, GL_RGB, GL_UNSIGNED_BYTE, &m_volDataBuf_texture[0]);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
}

