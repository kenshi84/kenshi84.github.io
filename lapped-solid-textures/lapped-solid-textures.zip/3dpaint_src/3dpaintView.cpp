// 3dpaintView.cpp : implementation of the CMy3dpaintView class
//

#include "stdafx.h"
#include "3dpaint.h"
#include "3dpaintDoc.h"
#include "3dpaintView.h"
#include "StateSelect.h"
#include "StateGeometry.h"
#include "KCore.h"
#include "MainFrm.h"
using namespace std;

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMy3dpaintView

IMPLEMENT_DYNCREATE(CMy3dpaintView, CView)

BEGIN_MESSAGE_MAP(CMy3dpaintView, CView)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_MBUTTONDOWN()
	ON_WM_MBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_DROPFILES()
	ON_WM_MOUSEWHEEL()
	ON_WM_KEYDOWN()
	ON_COMMAND(ID_EDIT_UNDO, &CMy3dpaintView::OnEditUndo)
//	ON_COMMAND(ID_FILE_SWEEPIMAGE, &CMy3dpaintView::OnFileSweepimage)
	ON_COMMAND(ID_PROCESS_NOISE, &CMy3dpaintView::OnProcessNoise)
	ON_COMMAND(ID_CONTRAST_INCREASE, &CMy3dpaintView::OnContrastIncrease)
	ON_COMMAND(ID_CONTRAST_DECREASE, &CMy3dpaintView::OnContrastDecrease)
	ON_COMMAND(ID_INTENSITY_INCREASE, &CMy3dpaintView::OnIntensityIncrease)
	ON_COMMAND(ID_INTENSITY_DECREASE, &CMy3dpaintView::OnIntensityDecrease)
	ON_COMMAND(ID_SWEEP_FROM1DIRECTION, &CMy3dpaintView::OnSweepFrom1direction)
	ON_COMMAND(ID_SWEEP_FROM2DIRECTION, &CMy3dpaintView::OnSweepFrom2direction)
	ON_COMMAND(ID_SWEEP_FROM3DIRECTION, &CMy3dpaintView::OnSweepFrom3direction)
	ON_COMMAND(ID_2DIMAGE_LOADSKIN, &CMy3dpaintView::On2dimageLoadskin)
	ON_COMMAND(ID_PROCESS_BLUR, &CMy3dpaintView::OnProcessBlur)
	ON_COMMAND(ID_FLIP_X, &CMy3dpaintView::OnFlipX)
	ON_COMMAND(ID_FLIP_Y, &CMy3dpaintView::OnFlipY)
	ON_COMMAND(ID_FLIP_Z, &CMy3dpaintView::OnFlipZ)
	ON_COMMAND(ID_REPLACE_XY, &CMy3dpaintView::OnReplaceXy)
	ON_COMMAND(ID_REPLACE_YZ, &CMy3dpaintView::OnReplaceYz)
	ON_COMMAND(ID_REPLACE_ZX, &CMy3dpaintView::OnReplaceZx)
	ON_COMMAND(ID_EDIT_COPY, &CMy3dpaintView::OnEditCopy)
	ON_UPDATE_COMMAND_UI(ID_EDIT_PASTE, &CMy3dpaintView::OnUpdateEditPaste)
	ON_COMMAND(ID_EDIT_PASTE, &CMy3dpaintView::OnEditPaste)
	ON_UPDATE_COMMAND_UI(ID_EDIT_COPY, &CMy3dpaintView::OnUpdateEditCopy)
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_FILE_LOADGEOMETRY, &CMy3dpaintView::OnFileLoadgeometry)
	ON_COMMAND(ID_EDIT_CUT, &CMy3dpaintView::OnEditCut)
	ON_UPDATE_COMMAND_UI(ID_EDIT_CUT, &CMy3dpaintView::OnUpdateEditCut)
END_MESSAGE_MAP()

// CMy3dpaintView construction/destruction

CMy3dpaintView::CMy3dpaintView()
{
	// TODO: add construction code here

}

CMy3dpaintView::~CMy3dpaintView()
{
}

BOOL CMy3dpaintView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs
	cs.dwExStyle |= WS_EX_ACCEPTFILES;

	return CView::PreCreateWindow(cs);
}

// CMy3dpaintView drawing

void CMy3dpaintView::OnDraw(CDC* pDC)
{
	CMy3dpaintDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// TODO: add draw code for native data here
	KCore::getInstance()->m_ogl.OnDraw_Begin();
	KCore::getInstance()->m_drawer.draw();
	KCore::getInstance()->m_ogl.OnDraw_End();
	KCore::getInstance()->m_drawer.postDraw(pDC);
}


// CMy3dpaintView diagnostics

#ifdef _DEBUG
void CMy3dpaintView::AssertValid() const
{
	CView::AssertValid();
}

void CMy3dpaintView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CMy3dpaintDoc* CMy3dpaintView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CMy3dpaintDoc)));
	return (CMy3dpaintDoc*)m_pDocument;
}
#endif //_DEBUG


// CMy3dpaintView message handlers

int CMy3dpaintView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  �����ɓ���ȍ쐬�R�[�h��ǉ����Ă��������B
	KCore::getInstance()->m_ogl.OnCreate(this);
	KCore::getInstance()->init();
	KCore::getInstance()->m_drawer.init();
	KCore::getInstance()->mp_view = this;

	return 0;
}

void CMy3dpaintView::OnDestroy()
{
	CView::OnDestroy();

	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����܂��B
	KCore::getInstance()->m_ogl.OnDestroy();
}

BOOL CMy3dpaintView::OnEraseBkgnd(CDC* pDC)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B

	return TRUE;//CView::OnEraseBkgnd(pDC);
}

void CMy3dpaintView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����܂��B
	KCore::getInstance()->m_ogl.OnSize(cx, cy);
}

void CMy3dpaintView::OnLButtonDown(UINT nFlags, CPoint point)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	KCore::getInstance()->m_eventHandler.OnLButtonDown(this, nFlags, point);

	CView::OnLButtonDown(nFlags, point);
}

void CMy3dpaintView::OnLButtonUp(UINT nFlags, CPoint point)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	KCore::getInstance()->m_eventHandler.OnLButtonUp(this, nFlags, point);

	CView::OnLButtonUp(nFlags, point);
}

void CMy3dpaintView::OnRButtonDown(UINT nFlags, CPoint point)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	KCore::getInstance()->m_eventHandler.OnRButtonDown(this, nFlags, point);

	CView::OnRButtonDown(nFlags, point);
}

void CMy3dpaintView::OnRButtonUp(UINT nFlags, CPoint point)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	KCore::getInstance()->m_eventHandler.OnRButtonUp(this, nFlags, point);

	CView::OnRButtonUp(nFlags, point);
}

void CMy3dpaintView::OnMButtonDown(UINT nFlags, CPoint point)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	KCore::getInstance()->m_eventHandler.OnMButtonDown(this, nFlags, point);

	CView::OnMButtonDown(nFlags, point);
}

void CMy3dpaintView::OnMButtonUp(UINT nFlags, CPoint point)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	KCore::getInstance()->m_eventHandler.OnMButtonUp(this, nFlags, point);

	CView::OnMButtonUp(nFlags, point);
}

void CMy3dpaintView::OnMouseMove(UINT nFlags, CPoint point)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	KCore::getInstance()->m_eventHandler.OnMouseMove(this, nFlags, point);

	CView::OnMouseMove(nFlags, point);
}

void CMy3dpaintView::OnDropFiles(HDROP hDropInfo)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	KCore::getInstance()->m_eventHandler.OnDropFiles(this, hDropInfo);

	CView::OnDropFiles(hDropInfo);
}

BOOL CMy3dpaintView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	KCore::getInstance()->m_eventHandler.OnMouseWheel(this, nFlags, zDelta, pt);

	return CView::OnMouseWheel(nFlags, zDelta, pt);
}

void CMy3dpaintView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags)
{
	// TODO: �����Ƀ��b�Z�[�W �n���h�� �R�[�h��ǉ����邩�A����̏������Ăяo���܂��B
	KCore::getInstance()->m_eventHandler.OnKeyDown(this, nChar, nRepCnt, nFlags);

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CMy3dpaintView::OnEditUndo()
{
	KCore& core = *KCore::getInstance();
	memcpy(&core.m_volData[0], &core.m_volDataUndo[0], core.m_volData.size());
	core.updateTexture();
	core.m_ogl.RedrawWindow();
	GetDocument()->SetModifiedFlag(TRUE);
}


void CMy3dpaintView::OnProcessNoise() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.shiftColor();
	core.addNoise();
	core.updateTexture();
	core.m_ogl.RedrawWindow();
}

void CMy3dpaintView::OnProcessBlur() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.blur();
	core.updateTexture();
	core.m_ogl.RedrawWindow();
}

void CMy3dpaintView::OnContrastIncrease() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.changeContrast(0.1);
	core.updateTexture();
	core.m_ogl.RedrawWindow();
}

void CMy3dpaintView::OnContrastDecrease() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.changeContrast(-0.1);
	core.updateTexture();
	core.m_ogl.RedrawWindow();
}

void CMy3dpaintView::OnIntensityIncrease() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.changeIntensity(1.1);
	core.updateTexture();
	core.m_ogl.RedrawWindow();
}

void CMy3dpaintView::OnIntensityDecrease() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.changeIntensity(0.9);
	core.updateTexture();
	core.m_ogl.RedrawWindow();

}

void CMy3dpaintView::OnSweepFrom1direction() {
	CString         filter("Image Files (*.bmp;*.jpg;*.jpeg;*.png;*.tif;*.ppm)|*.bmp; *.jpg; *.jpeg; *.png; *.tif; *.ppm||");
	CFileDialog     dlg(TRUE, NULL, NULL, 0, filter);
	if (dlg.DoModal() != IDOK) return;
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	if (core.sweepImageFrom1Dir((LPCTSTR)dlg.GetFileName())) {
		core.updateTexture();
		core.m_ogl.RedrawWindow();
	
	}
}

void CMy3dpaintView::OnSweepFrom2direction() {
	CString         filter("Image Files (*.bmp;*.jpg;*.jpeg;*.png;*.tif;*.ppm)|*.bmp; *.jpg; *.jpeg; *.png; *.tif; *.ppm||");
	CFileDialog     dlg(TRUE, NULL, NULL, 0, filter);
	if (dlg.DoModal() != IDOK) return;
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	if (core.sweepImageFrom2Dir((LPCTSTR)dlg.GetFileName())) {
		core.updateTexture();
		core.m_ogl.RedrawWindow();
	
	}
}

void CMy3dpaintView::OnSweepFrom3direction() {
	CString         filter("Image Files (*.bmp;*.jpg;*.jpeg;*.png;*.tif;*.ppm)|*.bmp; *.jpg; *.jpeg; *.png; *.tif; *.ppm||");
	CFileDialog     dlg(TRUE, NULL, NULL, 0, filter);
	if (dlg.DoModal() != IDOK) return;
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	if (core.sweepImageFrom3Dir((LPCTSTR)dlg.GetFileName())) {
		core.updateTexture();
		core.m_ogl.RedrawWindow();
	
	}
}

void CMy3dpaintView::On2dimageLoadskin() {
	CString         filter("Image Files (*.bmp;*.jpg;*.jpeg;*.png;*.tif;*.ppm)|*.bmp; *.jpg; *.jpeg; *.png; *.tif; *.ppm||");
	CFileDialog     dlg(TRUE, NULL, NULL, 0, filter);
	if (dlg.DoModal() != IDOK) return;
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	if (core.loadSkin((LPCTSTR)dlg.GetFileName())) {
		core.updateTexture();
		core.m_ogl.RedrawWindow();
	
	}
}


void CMy3dpaintView::OnFlipX() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.flipX();
	core.updateTexture();
	core.m_ogl.RedrawWindow();

}

void CMy3dpaintView::OnFlipY() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.flipY();
	core.updateTexture();
	core.m_ogl.RedrawWindow();

}

void CMy3dpaintView::OnFlipZ() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.flipZ();
	core.updateTexture();
	core.m_ogl.RedrawWindow();

}

void CMy3dpaintView::OnReplaceXy() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.replaceXY();
	core.updateTexture();
	core.m_ogl.RedrawWindow();

}

void CMy3dpaintView::OnReplaceYz() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.replaceYZ();
	core.updateTexture();
	core.m_ogl.RedrawWindow();

}

void CMy3dpaintView::OnReplaceZx() {
	KCore& core = *KCore::getInstance();
	core.storeUndo();
	core.replaceZX();
	core.updateTexture();
	core.m_ogl.RedrawWindow();

}

void CMy3dpaintView::OnEditCopy() {
	KCore& core = *KCore::getInstance();
	StateSelect& select = *StateSelect::getInstance();
	int length = 0;
	length += sizeof(int) * 3;
	length += sizeof(char) * 3 * select.m_size_x * select.m_size_y * select.m_size_z;
	HGLOBAL hGlobal = GlobalAlloc(GHND, length);
	LPSTR lpStr = (LPSTR)GlobalLock(hGlobal);
	memcpy(lpStr, &select.m_size_x, sizeof(int));
	lpStr += sizeof(int);
	memcpy(lpStr, &select.m_size_y, sizeof(int));
	lpStr += sizeof(int);
	memcpy(lpStr, &select.m_size_z, sizeof(int));
	lpStr += sizeof(int);
	memcpy(lpStr, &select.m_volDataBuf[0], 3 * sizeof(char) * select.m_size_x * select.m_size_y * select.m_size_z);
	GlobalUnlock(hGlobal);
	OpenClipboard();
	EmptyClipboard();
	SetClipboardData(core.m_cb_format, hGlobal);
	CloseClipboard();
}

void CMy3dpaintView::OnUpdateEditCopy(CCmdUI *pCmdUI) {
	pCmdUI->Enable(
		KCore::getInstance()->mp_state == StateSelect::getInstance() &&
		StateSelect::getInstance()->m_step == 2);
}

void CMy3dpaintView::OnEditCut()
{
	KCore& core = *KCore::getInstance();
	StateSelect& select = *StateSelect::getInstance();
	int length = 0;
	length += sizeof(int) * 3;
	length += sizeof(char) * 3 * select.m_size_x * select.m_size_y * select.m_size_z;
	HGLOBAL hGlobal = GlobalAlloc(GHND, length);
	LPSTR lpStr = (LPSTR)GlobalLock(hGlobal);
	memcpy(lpStr, &select.m_size_x, sizeof(int));
	lpStr += sizeof(int);
	memcpy(lpStr, &select.m_size_y, sizeof(int));
	lpStr += sizeof(int);
	memcpy(lpStr, &select.m_size_z, sizeof(int));
	lpStr += sizeof(int);
	memcpy(lpStr, &select.m_volDataBuf[0], 3 * sizeof(char) * select.m_size_x * select.m_size_y * select.m_size_z);
	GlobalUnlock(hGlobal);
	OpenClipboard();
	EmptyClipboard();
	SetClipboardData(core.m_cb_format, hGlobal);
	CloseClipboard();
	select.m_step = 0;
}

void CMy3dpaintView::OnUpdateEditCut(CCmdUI *pCmdUI) {
	pCmdUI->Enable(
		KCore::getInstance()->mp_state == StateSelect::getInstance() &&
		StateSelect::getInstance()->m_step == 2);
}

void CMy3dpaintView::OnEditPaste() {
	KCore& core = *KCore::getInstance();
	StateSelect& select = *StateSelect::getInstance();
	OpenClipboard();
	HGLOBAL hGlobal = (HGLOBAL)GetClipboardData(core.m_cb_format);
	LPSTR lpStr = (LPSTR)GlobalLock(hGlobal);
	int size_x, size_y, size_z;
	memcpy(&size_x, lpStr, sizeof(int));
	lpStr += sizeof(int);
	memcpy(&size_y, lpStr, sizeof(int));
	lpStr += sizeof(int);
	memcpy(&size_z, lpStr, sizeof(int));
	lpStr += sizeof(int);
	if (size_x <= core.m_volSize && size_y <= core.m_volSize && size_z <= core.m_volSize) {
		select.m_size_x = size_x;
		select.m_size_y = size_y;
		select.m_size_z = size_z;
		select.m_volDataBuf.resize(3 * select.m_size_x * select.m_size_y * select.m_size_z);
		memcpy(&select.m_volDataBuf[0], lpStr, 3 * sizeof(char) * select.m_size_x * select.m_size_y * select.m_size_z);
		if (core.mp_state == &select && select.m_step == 2) {
			select.pasteBuf();
		}
		core.mp_state = &select;
		select.m_offset_x = select.m_offset_y = select.m_offset_z = 0;
		select.m_step = 2;
		((CMainFrame *)AfxGetMainWnd())->m_wndDlgBarToolPalette.Invalidate();
		core.m_ogl.RedrawWindow();
	} else {
		MessageBox("Data size in clipboard is too large for this volume!");
	}
	GlobalUnlock(hGlobal);
	CloseClipboard();
}

void CMy3dpaintView::OnUpdateEditPaste(CCmdUI *pCmdUI) {
	pCmdUI->Enable(IsClipboardFormatAvailable(KCore::getInstance()->m_cb_format));
}


void CMy3dpaintView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	KCore::getInstance()->m_eventHandler.OnLButtonDblClk(this, nFlags, point);

	CView::OnLButtonDblClk(nFlags, point);
}

void CMy3dpaintView::OnFileLoadgeometry() {
	CFileDialog dlg(TRUE, ".obj", "*.obj", OFN_FILEMUSTEXIST, "OBJ file (*.obj|*.obj||");
	if (dlg.DoModal() != IDOK) return;
	StateGeometry::getInstance()->loadGeometry(dlg.GetPathName());
}

