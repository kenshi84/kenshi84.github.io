#include "StdAfx.h"
#include "StatePen.h"
#include "KCore.h"
#include <KLIB/KUtil.h>
#include <KLIB/KDrawer.h>

StatePen::StatePen(void) {
}

StatePen::~StatePen(void)
{
}

void StatePen::OnLButtonDown(UINT nFlags, CPoint& point) {
	KCore& core = *KCore::getInstance();
	KVector3d start, ori;
	KVector3d pos;
	int polyID;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	if (!KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) return;
	int N = core.m_volSize;
	core.storeUndo();
	pos.scale(N);
	int ix = (int)pos.x;
	int iy = (int)pos.y;
	int iz = (int)pos.z;
	int index = 3 * (ix + N * iy + N * N * iz);
	bool b = true;
	if ((nFlags & MK_SHIFT) != 0) b = !b;
	COLORREF& col = b ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	GLubyte& volR = core.m_volData[index];
	GLubyte& volG = core.m_volData[index + 1];
	GLubyte& volB = core.m_volData[index + 2];
	volR = KCore::getR(col);
	volG = KCore::getG(col);
	volB = KCore::getB(col);
	core.updateTexture();
	core.m_prevX = ix;
	core.m_prevY = iy;
	core.m_prevZ = iz;
	core.m_ogl.RedrawWindow();
	m_isDrawing = true;
}
void StatePen::OnLButtonUp  (UINT nFlags, CPoint& point) {
	m_isDrawing = false;
}

void StatePen::OnMouseMove  (UINT nFlags, CPoint& point) {
	KCore& core = *KCore::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (!KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) return;
	int& N = core.m_volSize;
	pos.scale(N);
	int ix = (int)pos.x;
	int iy = (int)pos.y;
	int iz = (int)pos.z;
	int index = 3 * (ix + N * iy + N * N * iz);
	m_currentX = ix;
	m_currentY = iy;
	m_currentZ = iz;
	if (!m_isDrawing) {
		core.m_ogl.RedrawWindow();
		return;
	}
	bool b = true;
	if ((nFlags & MK_SHIFT) != 0) b = !b;
	COLORREF& col = b ? core.m_colorCurrentFg : core.m_colorCurrentBg;
	core.m_volData[index]     = KCore::getR(col);
	core.m_volData[index + 1] = KCore::getG(col);
	core.m_volData[index + 2] = KCore::getB(col);
	core.updateTexture();
	core.m_prevX = ix;
	core.m_prevY = iy;
	core.m_prevZ = iz;
	core.m_ogl.RedrawWindow();
}

void StatePen::draw() {
	KCore& core = *KCore::getInstance();
	int& N = core.m_volSize;
	double x0 = m_currentX / (double)N;
	double y0 = m_currentY / (double)N;
	double z0 = m_currentZ / (double)N;
	double x1 = (m_currentX + 1) / (double)N;
	double y1 = (m_currentY + 1) / (double)N;
	double z1 = (m_currentZ + 1) / (double)N;
	GLubyte r = KCore::getR(core.m_colorCurrentFg);
	GLubyte g = KCore::getG(core.m_colorCurrentFg);
	GLubyte b = KCore::getB(core.m_colorCurrentFg);
	glColor3ub(r, g, b);
	KDrawer::drawWireBox(x0, y0, z0, x1, y1, z1);
}
