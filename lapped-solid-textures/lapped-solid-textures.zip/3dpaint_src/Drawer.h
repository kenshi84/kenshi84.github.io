#pragma once

class Drawer
{
public:
	Drawer(void);
	~Drawer(void);
	void init();
	void draw();
	void postDraw(CDC* pDC);
	bool m_isDrawHandle;
	bool m_isDrawFrame;
	bool m_isDrawEdge;
	bool m_isDrawAxis;
};
