#pragma once
#include "State.h"

class StateBlur : public State {
	StateBlur(void) {}
	~StateBlur(void) {}
public:
	static StateBlur* getInstance() {
		static StateBlur p;
		return &p;
	}
	void OnLButtonDown(UINT nFlags, CPoint& point);
	void OnLButtonUp  (UINT nFlags, CPoint& point) {}
	void OnMouseMove  (UINT nFlags, CPoint& point);
	void OnMouseWheel (UINT nFlags, short zDelta, CPoint& pt) {}
	void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) {}
	void OnLButtonDblClk(UINT nFlags, CPoint point) {}
	void init() {}
	void draw();
	void quit() {}
	int m_currentX, m_currentY, m_currentZ;
};
