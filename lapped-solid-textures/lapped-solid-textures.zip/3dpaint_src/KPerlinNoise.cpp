#include "StdAfx.h"
#include "KPerlinNoise.h"
using namespace std;

vector<double> KPerlinNoise::getNoise3D(int pow2) {
	srand((UINT)time(NULL));
	int n = 1 << pow2;
	vector<double> data(n * n * n, 0);
	for (int i = 0; i < pow2; ++i) {
		int nn = 1 << (i + 1);
		vector<double> tmp(nn * nn * nn);
		for (int j = 0; j < (int)tmp.size(); ++j) tmp[j] = rand() / (double)RAND_MAX;
		double weight = 1. / (1 << i);
		for (int iz = 0; iz < n; ++iz) {
			for (int iy = 0; iy < n; ++iy) {
				for (int ix = 0; ix < n; ++ix) {
					data[ix + n * iy + n * n * iz] += weight * upsample(tmp, i + 1, ix, iy, iz, 1 << (pow2 - i - 1));
				}
			}
		}
	}
	double dmax = 0;
	for (int i = 0; i < (int)data.size(); ++i)
		dmax = max(data[i], dmax);
	for (int i = 0; i < (int)data.size(); ++i)
		data[i] /= dmax;
	return data;
}
double KPerlinNoise::upsample(const vector<double>& data, int pow2, int x, int y, int z, int s) {
	int n = 1 << pow2;
	if (s == 1) return data[x + n * y + n * n * z];
	int ix0 = x / s;
	int iy0 = y / s;
	int iz0 = z / s;
	int ix1 = min(ix0 + 1, n - 1);
	int iy1 = min(iy0 + 1, n - 1);
	int iz1 = min(iz0 + 1, n - 1);
	double v000 = data[ix0 + n * iy0 + n * n * iz0];
	double v100 = data[ix1 + n * iy0 + n * n * iz0];
	double v010 = data[ix0 + n * iy1 + n * n * iz0];
	double v001 = data[ix0 + n * iy0 + n * n * iz1];
	double v110 = data[ix1 + n * iy1 + n * n * iz0];
	double v011 = data[ix0 + n * iy1 + n * n * iz1];
	double v101 = data[ix1 + n * iy0 + n * n * iz1];
	double v111 = data[ix1 + n * iy1 + n * n * iz1];
	double wx = x / (double)s - ix0;
	double wy = y / (double)s - iy0;
	double wz = z / (double)s - iz0;
	double vX00 = interpolate(v000, v100, wx);
	double vX10 = interpolate(v010, v110, wx);
	double vX01 = interpolate(v001, v101, wx);
	double vX11 = interpolate(v011, v111, wx);
	double vXY0 = interpolate(vX00, vX10, wy);
	double vXY1 = interpolate(vX01, vX11, wy);
	double vXYZ = interpolate(vXY0, vXY1, wz);
	return vXYZ;
}
