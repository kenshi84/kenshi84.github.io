#include "StdAfx.h"
#include "EventHandler.h"

#include "Core.h"
#include "KLIB/KUtil.h"

#include <iostream>
#include <string>
using namespace std;

EventHandler::EventHandler(void) :
m_isRButtonDown(false),
m_isCutting(false) {
}

void EventHandler::OnDropFiles(CView* view, HDROP hDropInfo) {
	Core::getInstance()->m_state->OnDropFiles(view, hDropInfo);
}

void EventHandler::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core::getInstance()->m_state->OnLButtonDown(view, nFlags, point);
}

void EventHandler::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core::getInstance()->m_state->OnLButtonUp(view, nFlags, point);
}

void EventHandler::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core::getInstance()->m_state->OnRButtonDown(view, nFlags, point);
}

void EventHandler::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core::getInstance()->m_state->OnRButtonUp(view, nFlags, point);
}

void EventHandler::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core::getInstance()->m_state->OnMouseMove(view, nFlags, point);
}

void EventHandler::OnMouseWheel(CView *view, UINT nFlags, short zDelta, CPoint pt) {
	Core::getInstance()->m_state->OnMouseWheel(view, nFlags, zDelta, pt);
}
void EventHandler::OnLButtonDblClk(CView* view, UINT nFlags, CPoint point) {
	Core::getInstance()->m_state->OnLButtonDblClk(view, nFlags, point);
}

void EventHandler::OnKeyDown   (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {
	Core::getInstance()->m_state->OnKeyDown(view, nChar, nRepCnt, nFlags);
}
