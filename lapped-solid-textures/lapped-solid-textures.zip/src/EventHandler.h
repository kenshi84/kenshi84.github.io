#pragma once

class EventHandler
{
public:
	EventHandler(void);
	~EventHandler(void) {}
public:
	bool m_isRButtonDown;
	bool m_isCutting;
	CPoint m_pointOld;
	void OnLButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnLButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnRButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnRButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnMouseMove  (CView* view, UINT nFlags, CPoint& point);
	void OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags);
	void OnDropFiles  (CView* view, HDROP hDropInfo);
	void OnFileOpen(CDocument* doc);
	void OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt);
	void OnLButtonDblClk(CView* view, UINT nFlags, CPoint point);
};
