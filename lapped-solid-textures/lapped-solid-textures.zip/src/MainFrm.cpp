// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "LSTDemo.h"

#include "MainFrm.h"

#include "Core.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	ON_WM_CREATE()
//	ON_UPDATE_COMMAND_UI(ID_APP_EXIT, &CMainFrame::OnUpdateAppExit)
//	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};


// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
}

CMainFrame::~CMainFrame()
{
}


int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar_navigate.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_BOTTOM
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar_navigate.LoadToolBar(IDR_TOOLBAR_NAVIGATE))
	{
		TRACE0("Failed to create navigation toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndToolBar_scale.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar_scale.LoadToolBar(IDR_TOOLBAR_SCALE))
	{
		TRACE0("Failed to create scale toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndToolBar_process.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar_process.LoadToolBar(IDR_TOOLBAR_PROCESS))
	{
		TRACE0("Failed to create process toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndToolBar_result.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar_result.LoadToolBar(IDR_TOOLBAR_RESULT))
	{
		TRACE0("Failed to create result toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndToolBar_manualPaste.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar_manualPaste.LoadToolBar(IDR_TOOLBAR_MANUALPASTE))
	{
		TRACE0("Failed to create ManualPaste toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndToolBar_browse.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar_browse.LoadToolBar(IDR_TOOLBAR_BROWSE))
	{
		TRACE0("Failed to create Browse toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndToolBar_depthPaint.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar_depthPaint.LoadToolBar(IDR_TOOLBAR_DEPTH))
	{
		TRACE0("Failed to create DepthPaint toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndToolBar_peelStroke.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar_peelStroke.LoadToolBar(IDR_TOOLBAR_PEEL))
	{
		TRACE0("Failed to create Peel toolbar\n");
		return -1;      // fail to create
	}
	if (!m_wndToolBar_loadTexture.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar_loadTexture.LoadToolBar(IDR_TOOLBAR_LOADTEXTURE))
	{
		TRACE0("Failed to create LoadTexture toolbar\n");
		return -1;      // fail to create
	}


	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}
	
	ShowControlBar(&m_wndToolBar_scale,       false, true);
	ShowControlBar(&m_wndToolBar_process,     false, true);
	ShowControlBar(&m_wndToolBar_result,      false, true);
	ShowControlBar(&m_wndToolBar_manualPaste, false, true);
	ShowControlBar(&m_wndToolBar_browse     , false, true);
	ShowControlBar(&m_wndToolBar_depthPaint , false, true);
	ShowControlBar(&m_wndToolBar_peelStroke , false, true);
	ShowControlBar(&m_wndToolBar_loadTexture, false, true);
	
	Core::getInstance()->p_mainFrm = this;
	
	// TODO: Delete these three lines if you don't want the toolbar to be dockable
	EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar_navigate   .EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar_scale      .EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar_process    .EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar_result     .EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar_manualPaste.EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar_browse     .EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar_depthPaint .EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar_peelStroke .EnableDocking(CBRS_ALIGN_ANY);
	m_wndToolBar_loadTexture.EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar_navigate);
	DockControlBar(&m_wndToolBar_scale);
	DockControlBar(&m_wndToolBar_process);
	DockControlBar(&m_wndToolBar_result);
	DockControlBar(&m_wndToolBar_manualPaste);
	DockControlBar(&m_wndToolBar_browse);
	DockControlBar(&m_wndToolBar_depthPaint);
	DockControlBar(&m_wndToolBar_peelStroke);
	DockControlBar(&m_wndToolBar_loadTexture);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}


// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG


// CMainFrame message handlers


