#include "StdAfx.h"
#include "Core.h"

#include <KLIB/KMarchingTetra.h>
#include <KLIB/KMarchingTetraSubdiv.h>
#include <KLIB/KUtil.h>
#include <KLIB/KUmfpack.h>
#include <KLIB/KUmfpackSparseMatrix.h>
#include <KLIB/KVolumeRenderer.h>

#include <iostream>
#include <fstream>
#include <algorithm>
#include <set>

#include <ctime>
#include <cstdlib>

#include "StateLoadTetra.h"

using namespace std;

const double Core::GRADIENT_DELTA = 0.005;
const int Core::VOLSIZE = 64;
const int Core::LAYER_MAX = 10;
const char Core::MASKFNAME[] = "mask.vol";
//const bool Core::FLAG_DEBUG = false;

Core::Core(void)
{
	srand( static_cast<unsigned int>( time(NULL) ) );
	loadMask(MASKFNAME);
	m_lst.setMask(VOLSIZE, m_volMask);
	constructTetraCube();
	m_state = StateLoadTetra::getInstance();
	m_state->init();
}

Core::~Core(void) { }

void Core::constructTetraCube() {
	vector<KVertex> vertices;
	vector<KMultiTexTetra> tetras;
	KVector3d v[8] = {
		KVector3d (0, 0, 0),
		KVector3d (1, 0, 0),
		KVector3d (0, 1, 0),
		KVector3d (0, 0, 1),
		KVector3d (1, 1, 0),
		KVector3d (0, 1, 1),
		KVector3d (1, 0, 1),
		KVector3d (1, 1, 1)
	};
	for (int i = 0; i < 8; ++i)
		vertices.push_back(KVertex(v[i]));
	KMultiTexTetra tet000(0, 1, 2, 3);
	KMultiTexTetra tet110(7, 1, 2, 4);
	KMultiTexTetra tet011(7, 2, 3, 5);
	KMultiTexTetra tet101(7, 3, 1, 6);
	KMultiTexTetra tet111(7, 3, 2, 1);
	tet000.m_texCoords.push_back(KTetraTexCoord(v[0], v[1], v[2], v[3]));
	tet110.m_texCoords.push_back(KTetraTexCoord(v[7], v[1], v[2], v[4]));
	tet011.m_texCoords.push_back(KTetraTexCoord(v[7], v[2], v[3], v[5]));
	tet101.m_texCoords.push_back(KTetraTexCoord(v[7], v[3], v[1], v[6]));
	tet111.m_texCoords.push_back(KTetraTexCoord(v[7], v[3], v[2], v[1]));
	tetras.push_back(tet000);
	tetras.push_back(tet110);
	tetras.push_back(tet011);
	tetras.push_back(tet101);
	tetras.push_back(tet111);
	m_tetraCube.m_vertices = vertices;
	m_tetraCube.m_tetras = tetras;
	m_tetraCube.calcNeighbor();
}

void Core::loadTetraOrg(const string& fname) {
	m_tetraOrg.loadFile(fname);
	setFocusCenter();
	m_tetraOrg.calcNeighbor();
}

void Core::loadMask(const string& fname) {
	FILE * fin = fopen(fname.c_str(), "rb");
	if (!fin) {
		CString str;
		str.Format("Failed to load mask file %s", MASKFNAME);
		AfxMessageBox(str);
		exit(1);
	}
	char buf[4096];
	fread(buf, 4096, 1, fin);
	
	VolumeHeader* header = (VolumeHeader *)buf;
	if ((header->magic[0] != 'V') ||
		(header->magic[1] != 'O') ||
		(header->magic[2] != 'L') ||
		(header->magic[3] != 'U') ||
		(header->version != 4) ||
		(header->bytesPerChannel != 1) ||
		(header->numChannels != 1) ||
		(header->volSize != VOLSIZE)) {
		CString str;
		str.Format("Invalid mask file %s", MASKFNAME);
		AfxMessageBox(str);
		exit(0);
	}
	
	int volBytes = VOLSIZE * VOLSIZE * VOLSIZE;
	m_volMask.resize(volBytes);
	fread(&m_volMask[0], volBytes, 1, fin);
	fclose(fin);
}

bool Core::loadVolInputDisp(const string& fname) {
	FILE * fin = fopen(fname.c_str(), "rb");
	if (!fin) {
		CString str;
		str.Format("Failed to load solid texture file %s", fname.c_str());
		AfxMessageBox(str);
		return false;
	}
	char buf[4096];
	fread(buf, 4096, 1, fin);
	
	VolumeHeader* header = (VolumeHeader *)buf;
	if ((header->magic[0] != 'V') ||
		(header->magic[1] != 'O') ||
		(header->magic[2] != 'L') ||
		(header->magic[3] != 'U') ||
		(header->bytesPerChannel != 1) ||
		(header->version != 4))
	{
		AfxMessageBox("Bad header!");
		return false;
	}
	if (header->volSize != VOLSIZE) {
		CString str;
		str.Format("Texture size must be %d", VOLSIZE);
		AfxMessageBox(str);
		return false;
	}
	if (header->numChannels != 1) {
		AfxMessageBox("Single channel only.");
		return false;
	}
	int volBytes = VOLSIZE * VOLSIZE * VOLSIZE;
	m_volInputDisp.resize(volBytes);
	fread(&m_volInputDisp[0], volBytes, 1, fin);
	fclose(fin);
	return true;
}

bool Core::loadVolInput(const string& fname) {
	FILE * fin = fopen(fname.c_str(), "rb");
	if (!fin) {
		CString str;
		str.Format("Failed to load solid texture file %s", fname.c_str());
		AfxMessageBox(str);
		return false;
	}
	char buf[4096];
	fread(buf, 4096, 1, fin);
	
	VolumeHeader* header = (VolumeHeader *)buf;
	if ((header->magic[0] != 'V') ||
		(header->magic[1] != 'O') ||
		(header->magic[2] != 'L') ||
		(header->magic[3] != 'U') ||
		(header->bytesPerChannel != 1) ||
		(header->version != 4))
	{
		AfxMessageBox("Bad header!");
		return false;
	}
	if (header->volSize != VOLSIZE) {
		CString str;
		str.Format("Texture size must be %d", VOLSIZE);
		AfxMessageBox(str);
		return false;
	}
	m_numChannels = header->numChannels;
	if (m_numChannels != 3 && m_numChannels != 4) {
		AfxMessageBox("Only RGB or RGBA formats supported.");
		return false;
	}
	int volBytes = VOLSIZE * VOLSIZE * VOLSIZE * m_numChannels;
	m_volInput.resize(volBytes);
	fread(&m_volInput[0], volBytes, 1, fin);
	fclose(fin);
	return true;
}

bool Core::loadVolManual(const string& fname) {
	FILE * fin = fopen(fname.c_str(), "rb");
	if (!fin) {
		CString str;
		str.Format("Failed to load solid texture file %s", fname.c_str());
		AfxMessageBox(str);
		return false;
	}
	char buf[4096];
	fread(buf, 4096, 1, fin);
	
	VolumeHeader* header = (VolumeHeader *)buf;
	if ((header->magic[0] != 'V') ||
		(header->magic[1] != 'O') ||
		(header->magic[2] != 'L') ||
		(header->magic[3] != 'U') ||
		(header->bytesPerChannel != 1) ||
		(header->version != 4))
	{
		AfxMessageBox("Bad header!");
		return false;
	}
	if (header->volSize != VOLSIZE) {
		CString str;
		str.Format("Texture size must be %d", VOLSIZE);
		AfxMessageBox(str);
		return false;
	}
	int numChannels = header->numChannels;
	if (numChannels != 3 && numChannels != 4) {
		AfxMessageBox("Only RGB or RGBA formats supported.");
		return false;
	}
	int volBytesIn = VOLSIZE * VOLSIZE * VOLSIZE * numChannels;
	vector<GLubyte> volIn(volBytesIn);
	fread(&volIn[0], volBytesIn, 1, fin);
	fclose(fin);
	int volBytes = VOLSIZE * VOLSIZE * VOLSIZE * 4;
	vector<GLubyte>& volTgt = m_volManual.back();
	volTgt.resize(volBytes);
	for (int iz = 0; iz < VOLSIZE; ++iz) {
		int offz = VOLSIZE * VOLSIZE * iz;
		for (int iy = 0; iy < VOLSIZE; ++iy) {
			int offy = VOLSIZE * iy;
			for (int ix = 0; ix < VOLSIZE; ++ix) {
				int index = ix + offy + offz;
				int indexIn = index * numChannels;
				GLubyte r = volIn[indexIn];
				GLubyte g = volIn[indexIn + 1];
				GLubyte b = volIn[indexIn + 2];
				GLubyte a = numChannels == 4 ? volIn[indexIn + 3] : 255;
				a = min(a, m_volMask[index]);
				int indexOut = index * 4;
				volTgt[indexOut]     = r;
				volTgt[indexOut + 1] = g;
				volTgt[indexOut + 2] = b;
				volTgt[indexOut + 3] = a;
			}
		}
	}
	return true;
}

bool Core::loadVolManualDisp(const string& fname) {
	FILE * fin = fopen(fname.c_str(), "rb");
	if (!fin) {
		CString str;
		str.Format("Failed to load solid texture file %s", fname.c_str());
		AfxMessageBox(str);
		return false;
	}
	char buf[4096];
	fread(buf, 4096, 1, fin);
	
	VolumeHeader* header = (VolumeHeader *)buf;
	if ((header->magic[0] != 'V') ||
		(header->magic[1] != 'O') ||
		(header->magic[2] != 'L') ||
		(header->magic[3] != 'U') ||
		(header->bytesPerChannel != 1) ||
		(header->version != 4))
	{
		AfxMessageBox("Bad header!");
		return false;
	}
	if (header->volSize != VOLSIZE) {
		CString str;
		str.Format("Texture size must be %d", VOLSIZE);
		AfxMessageBox(str);
		return false;
	}
	if (header->numChannels != 1) {
		AfxMessageBox("Single channel only.");
		return false;
	}
	int volBytes = VOLSIZE * VOLSIZE * VOLSIZE;
	m_volManualDisp.back().resize(volBytes);
	fread(&m_volManualDisp.back()[0], volBytes, 1, fin);
	fclose(fin);
	return true;
}

void Core::setFocusCenter() {
	double xMax, yMax, zMax;
	double xMin, yMin, zMin;
	xMax = yMax = zMax = -DBL_MAX;
	xMin = yMin = zMin =  DBL_MAX;
	for (int i = 0; i < (int)m_tetraOrg.m_vertices.size(); ++i) {
		KVector3d& pos = m_tetraOrg.m_vertices[i].m_pos;
		xMax = max(xMax, pos.x);
		yMax = max(yMax, pos.y);
		zMax = max(zMax, pos.z);
		xMin = min(xMin, pos.x);
		yMin = min(yMin, pos.y);
		zMin = min(zMin, pos.z);
	}
	double cx = 0.5 * (xMax + xMin);
	double cy = 0.5 * (yMax + yMin);
	double cz = 0.5 * (zMax + zMin);
	double sizeMax = xMax - xMin;
	sizeMax = max(sizeMax, yMax - yMin);
	sizeMax = max(sizeMax, zMax - zMin);
	m_ogl.m_eyePoint.set(cx, cy, cz - 2.5 * sizeMax);
	m_ogl.m_upDirection.set(0, 1, 0);
	m_ogl.m_focusPoint.set(cx, cy, cz);
	m_ogl.updateEyePosition();
}


void Core::initCut() {
	m_tetraCut = m_tetraOrg;
	m_polyCut = m_tetraOrg.toMultiTexPolygonModel();
	m_polyCut.calcSmoothNormals(0.75);
	m_vtxValueCut.clear();
	m_vtxValueCut.resize(m_tetraCut.m_vertices.size(), -DBL_MAX);
	m_polyIDs_oncutplane.clear();
}
void Core::calcCutSubdiv(const std::vector<KVector3d>& cutStroke) {
	KThinPlate2D rbfCut;
	{
		// set vtxValue by projecting cutStroke and tetra vertices onto screen coord
		vector<KVector2d> cutStroke2D;
		for (int i = 0; i < (int)cutStroke.size(); ++i) {
			const KVector3d& pos = cutStroke[i];
			double winx, winy, winz;
			m_ogl.project(pos.x, pos.y, pos.z, winx, winy, winz);
			cutStroke2D.push_back(KVector2d(winx, winy));
		}
		vector<KVector2d> points;
		vector<double   > values;
		for (int i = 1; i < (int)cutStroke2D.size(); ++i) {
			KVector2d& p0 = cutStroke2D[i - 1];
			KVector2d& p1 = cutStroke2D[i];
			KVector2d d(p1);
			d.sub(p0);
			d.normalize();
			d.scale(10);
			KVector2d cp(p0), cm(p0);
			cp.add(-d.y, d.x);
			cm.add(d.y, -d.x);
			points.push_back(cp);
			points.push_back(cm);
			values.push_back( 1);
			values.push_back(-1);
		}
		rbfCut.setPoints(points);
		rbfCut.setValues(values);
	}
	vector<double> vtxValueCut(m_tetraCut.m_vertices.size());
	for (int i = 0; i < (int)m_tetraCut.m_vertices.size(); ++i) {
		KVector3d& pos = m_tetraCut.m_vertices[i].m_pos;
		double winx, winy, winz;
		m_ogl.project(pos.x, pos.y, pos.z, winx, winy, winz);
		double val = rbfCut.getValue(winx, winy);
		vtxValueCut[i] = val;
	}
	m_tetraCut = KMarchingTetraSubdiv::calcMarchingTetraSubdiv(m_tetraCut, vtxValueCut, 0);
	m_tetraCut.calcNeighbor();
	m_polyCut = m_tetraCut.toMultiTexPolygonModel();
	m_polyCut.calcSmoothNormals(0.75);
}
void Core::calcVtxValueCut(const std::vector<KVector3d>& cutStroke) {
	KThinPlate2D rbfCut;
	{
		// set vtxValue by projecting cutStroke and tetra vertices onto screen coord
		vector<KVector2d> cutStroke2D;
		for (int i = 0; i < (int)cutStroke.size(); ++i) {
			const KVector3d& pos = cutStroke[i];
			double winx, winy, winz;
			m_ogl.project(pos.x, pos.y, pos.z, winx, winy, winz);
			cutStroke2D.push_back(KVector2d(winx, winy));
		}
		vector<KVector2d> points;
		vector<double   > values;
		for (int i = 1; i < (int)cutStroke2D.size(); ++i) {
			KVector2d& p0 = cutStroke2D[i - 1];
			KVector2d& p1 = cutStroke2D[i];
			KVector2d d(p1);
			d.sub(p0);
			d.normalize();
			d.scale(10);
			KVector2d cp(p0), cm(p0);
			cp.add(-d.y, d.x);
			cm.add(d.y, -d.x);
			points.push_back(cp);
			points.push_back(cm);
			values.push_back( 1);
			values.push_back(-1);
		}
		rbfCut.setPoints(points);
		rbfCut.setValues(values);
	}
	for (int i = 0; i < (int)m_tetraOrg.m_vertices.size(); ++i) {
		KVector3d& pos = m_tetraOrg.m_vertices[i].m_pos;
		double winx, winy, winz;
		m_ogl.project(pos.x, pos.y, pos.z, winx, winy, winz);
		double val = rbfCut.getValue(winx, winy);
		m_vtxValueCut[i] = max(m_vtxValueCut[i], val);
	}
}
void Core::updateCut() {
	m_polyCut = KMarchingTetra::calcMultiTexMarchingTetra(vector<int>(), m_tetraOrg, m_vtxValueCut, 0, m_polyIDs_oncutplane);
	m_polyCut.calcSmoothNormals(0.75);
}

void Core::constructLaplacian() {
	int N = (int)m_tetraOrg.m_vertices.size();
	vector<set<int> > vtxNeighbor(N);
	//vector<map<int, double> > vtxNeighborDist(N);
	{
		// calculate neighbor around tetra vertex
		for (int i = 0; i < (int)m_tetraOrg.m_tetras.size(); ++i) {
			KMultiTexTetra& tet = m_tetraOrg.m_tetras[i];
			for (int j = 0; j < 4; ++j) {
				int vID = tet.m_vtx[j];
				set<int>& vNeighbor = vtxNeighbor[vID];
				for (int k = 0; k < 3; ++k) {
					int wID = tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][k]];
					if (vNeighbor.find(wID) == vNeighbor.end()) {
						set<int>& wNeighbor = vtxNeighbor[wID];
						vNeighbor.insert(wID);
						wNeighbor.insert(vID);
						//KVector3d& vPos = m_tetraOrg.m_vertices[vID].m_pos;
						//KVector3d& wPos = m_tetraOrg.m_vertices[wID].m_pos;
						//double dist = KUtil::getDistance(vPos, wPos);
						//map<int, double>& vMap = vtxNeighborDist[vID];
						//map<int, double>& wMap = vtxNeighborDist[wID];
						//vMap.insert(pair<int, double>(wID, dist));
						//wMap.insert(pair<int, double>(vID, dist));
					}
				}
			}
		}
	}
	cout << "creating A ...";
	cout << "(size : " << N << ") ...";
	KUmfpackSparseMatrix A(N, N, 30 * N);
	int neighborMax = 0;
	for (int i = 0; i < N; ++i) {
		set<int>& neighbor = vtxNeighbor[i];
		//map<int, double>& distMap = vtxNeighborDist[i];
		int M = (int)neighbor.size();
		//vector<double> weights;
		//weights.reserve(M);
		//double total = 0;
		//set<int>::iterator iter = neighbor.begin();
		//for (int j = 0; j < M; ++j, ++iter) {
		//	double dist = distMap.find(*iter)->second;
		//	double w = exp(-dist * dist);
		//	//double w = 1 / (1 + (dist * dist));
		//	weights.push_back(w);
		//	total += w;
		//}
		//for (int j = 0; j < M; ++j) {
		//	weights[j] /= total;
		//}
		//iter = neighbor.begin();
		//for (int j = 0; j < M; ++j, ++iter) {
		//	A.setValue(i, *iter, weights[j]);
		//}
		double w = 1. / M;
		for (set<int>::iterator iter = neighbor.begin(); iter != neighbor.end(); ++iter)
			A.setValue(i, *iter, w);
		A.setValue(i, i, -1);
	}
	cout << "creating At and AtA ...";
	m_laplacian.setA(A);
	cout << "done." << endl;
}

void Core::constructLaplacianDepth() {
	int N = (int)m_tetraOrg.m_vertices.size();
	vector<set<int> > vtxNeighbor(N);
	vector<map<int, double> > vtxNeighborDist(N);
	{
		// calculate neighbor around tetra vertex
		for (int i = 0; i < (int)m_tetraOrg.m_tetras.size(); ++i) {
			KMultiTexTetra& tet = m_tetraOrg.m_tetras[i];
			for (int j = 0; j < 4; ++j) {
				int vID = tet.m_vtx[j];
				set<int>& vNeighbor = vtxNeighbor[vID];
				for (int k = 0; k < 3; ++k) {
					int wID = tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][k]];
					if (vNeighbor.find(wID) == vNeighbor.end()) {
						set<int>& wNeighbor = vtxNeighbor[wID];
						vNeighbor.insert(wID);
						wNeighbor.insert(vID);
						//KVector3d& vPos = m_tetraOrg.m_vertices[vID].m_pos;
						//KVector3d& wPos = m_tetraOrg.m_vertices[wID].m_pos;
						//double dist = KUtil::getDistance(vPos, wPos);
						double dist = m_vtxDepth[vID] - m_vtxDepth[wID];
						map<int, double>& vMap = vtxNeighborDist[vID];
						map<int, double>& wMap = vtxNeighborDist[wID];
						vMap.insert(pair<int, double>(wID, dist));
						wMap.insert(pair<int, double>(vID, dist));
					}
				}
			}
		}
	}
	cout << "creating A (with depth) ...";
	cout << "(size : " << N << ") ...";
	KUmfpackSparseMatrix A(N, N, 30 * N);
	int neighborMax = 0;
	for (int i = 0; i < N; ++i) {
		set<int>& neighbor = vtxNeighbor[i];
		int M = (int)neighbor.size();
		//// each weight differs accorging to distance
		map<int, double>& distMap = vtxNeighborDist[i];
		vector<double> weights;
		weights.reserve(M);
		double total = 0;
		set<int>::iterator iter = neighbor.begin();
		for (int j = 0; j < M; ++j, ++iter) {
			double dist = distMap.find(*iter)->second;
			double w = exp(-dist * dist);
			//double w = 1 / (1 + (dist * dist));
			weights.push_back(w);
			total += w;
		}
		for (int j = 0; j < M; ++j) {
			weights[j] /= total;
		}
		iter = neighbor.begin();
		for (int j = 0; j < M; ++j, ++iter) {
			A.setValue(i, *iter, weights[j]);
		}
		//// weights are just the same
		//double w = 1. / M;
		//for (set<int>::iterator iter = neighbor.begin(); iter != neighbor.end(); ++iter)
		//	A.setValue(i, *iter, w);
		A.setValue(i, i, -1);
	}
	cout << "creating At and AtA ...";
	m_laplacianDepth.setA(A);
	cout << "done." << endl;
}

void Core::calcTetVectorByLaplacian(vector<KVector3d>& tetVector, const vector<vector<KVector3d> >& strokes) {
	vector<KVector3d> vtxVector(m_tetraOrg.m_vertices.size());
	{
		vector<KVector3d> constraintPos;
		vector<double>    constraintX;
		vector<double>    constraintY;
		vector<double>    constraintZ;
		for (int i = 0; i < (int)strokes.size(); ++i) {
			const vector<KVector3d>& stroke = strokes[i];
			for (int j = 1; j < (int)stroke.size(); ++j) {
				const KVector3d& pos0 = stroke[j - 1];
				const KVector3d& pos1 = stroke[j];
				constraintPos.push_back(pos0);
				constraintX.push_back(pos1.x - pos0.x);
				constraintY.push_back(pos1.y - pos0.y);
				constraintZ.push_back(pos1.z - pos0.z);
			}
		}
		int numVtx = (int)m_tetraOrg.m_vertices.size();
		vector<KSparseVector> C(constraintPos.size(), KSparseVector(numVtx, 4));
		for (int i = 0; i < (int)constraintPos.size(); ++i) {
			KVector3d& pos   = constraintPos[i];
			int    vID[4];
			double w[4];
			{
				int tetID;
				double dist;
				KUtil::getNearestTetraID(tetID, dist, m_tetraOrg, pos);
				KMultiTexTetra& tet = m_tetraOrg.m_tetras[tetID];
				KVector3d v[4];
				for (int j = 0; j < 4; ++j) {
					vID[j] = tet.m_vtx[j];
					v[j] = m_tetraOrg.m_vertices[vID[j]].m_pos;
				}
				KUtil::getBarycentricCoord(w[0], w[1], w[2], w[3], v[0], v[1], v[2], v[3], pos, 1);
			}
			KSparseVector& c = C[i];
			for (int j = 0; j < 4; ++j) {
				c.setValue(vID[j], w[j]);
			}
		}
		m_laplacian.setC(C);
		vector<double> vtxVectorX;
		vector<double> vtxVectorY;
		vector<double> vtxVectorZ;
		m_laplacian.solve(vtxVectorX, constraintX);
		m_laplacian.solve(vtxVectorY, constraintY);
		m_laplacian.solve(vtxVectorZ, constraintZ);
		for (int i = 0; i < numVtx; ++i)
			vtxVector[i] = KVector3d(vtxVectorX[i], vtxVectorY[i], vtxVectorZ[i]);
	}
	tetVector.resize(m_tetraOrg.m_tetras.size());
	for (int i = 0; i < (int)m_tetraOrg.m_tetras.size(); ++i) {
		KMultiTexTetra& tet = m_tetraOrg.m_tetras[i];
		KVector3d v;
		for (int j = 0; j < 4; ++j)
			v.add(vtxVector[tet.m_vtx[j]]);
		v.normalize();
		tetVector[i] = v;
	}
}

void Core::calcTetVectorByLaplacianDepth(vector<KVector3d>& tetVector, const vector<vector<KVector3d> >& strokes) {
	vector<KVector3d> vtxVector(m_tetraOrg.m_vertices.size());
	{
		vector<KVector3d> constraintPos;
		vector<double>    constraintX;
		vector<double>    constraintY;
		vector<double>    constraintZ;
		for (int i = 0; i < (int)strokes.size(); ++i) {
			const vector<KVector3d>& stroke = strokes[i];
			for (int j = 1; j < (int)stroke.size(); ++j) {
				const KVector3d& pos0 = stroke[j - 1];
				const KVector3d& pos1 = stroke[j];
				constraintPos.push_back(pos0);
				constraintX.push_back(pos1.x - pos0.x);
				constraintY.push_back(pos1.y - pos0.y);
				constraintZ.push_back(pos1.z - pos0.z);
			}
		}
		int numVtx = (int)m_tetraOrg.m_vertices.size();
		vector<KSparseVector> C(constraintPos.size(), KSparseVector(numVtx, 4));
		for (int i = 0; i < (int)constraintPos.size(); ++i) {
			int    vID[4];
			double w[4];
			{
				KVector3d& pos   = constraintPos[i];
				double depth = m_rbfDepth.getValue(pos);
				int tetID;
				double dist;
				KUtil::getNearestTetraID(tetID, dist, m_tetraOrg, pos);
				KMultiTexTetra& tet = m_tetraOrg.m_tetras[tetID];
				double total = 0;
				for (int j = 0; j < 4; ++j) {
					vID[j] = tet.m_vtx[j];
					double vDepth = m_vtxDepth[vID[j]];
					double d = depth - vDepth;
					w[j] = exp(-d * d);
					total += w[j];
				}
				for (int j = 0; j < 4; ++j)
					w[j] /= total;
			}
			KSparseVector& c = C[i];
			for (int j = 0; j < 4; ++j) {
				c.setValue(vID[j], w[j]);
			}
		}
		m_laplacianDepth.setC(C);
		vector<double> vtxVectorX;
		vector<double> vtxVectorY;
		vector<double> vtxVectorZ;
		m_laplacianDepth.solve(vtxVectorX, constraintX);
		m_laplacianDepth.solve(vtxVectorY, constraintY);
		m_laplacianDepth.solve(vtxVectorZ, constraintZ);
		for (int i = 0; i < numVtx; ++i)
			vtxVector[i] = KVector3d(vtxVectorX[i], vtxVectorY[i], vtxVectorZ[i]);
	}
	tetVector.clear();
	tetVector.reserve(m_tetraOrg.m_tetras.size());
	for (int i = 0; i < (int)m_tetraOrg.m_tetras.size(); ++i) {
		KMultiTexTetra& tet = m_tetraOrg.m_tetras[i];
		double depth = m_tetDepth[i];
		KVector3d v;
		for (int j = 0; j < 4; ++j) {
			int vID = tet.m_vtx[j];
			double vDepth = m_tetDepth[vID];
			double d = depth - vDepth;
			double w = exp(-d * d);
			v.addWeighted(vtxVector[vID], w);
		}
		v.normalize();
		tetVector.push_back(v);
	}
}

void Core::updateDepth() {
	int tetSize = (int)m_tetraOrg.m_tetras.size();
	m_tetDepth.clear();
	m_tetDepth.reserve(tetSize);
	for (int i = 0; i < tetSize; ++i) {
		KMultiTexTetra& tet = m_tetraOrg.m_tetras[i];
		KVector3d pos;
		KUtil::getBarycenter(pos, m_tetraOrg, tet);
		m_tetDepth.push_back(m_rbfDepth.getValue(pos));
	}
	int vtxSize = (int)m_tetraOrg.m_vertices.size();
	m_vtxDepth.clear();
	m_vtxDepth.reserve(vtxSize);
	for (int i = 0; i < vtxSize; ++i) {
		KVector3d& pos = m_tetraOrg.m_vertices[i].m_pos;
		m_vtxDepth.push_back(m_rbfDepth.getValue(pos));
	}
}

void Core::calcVolMiddle() {
	m_volMiddle.clear();
	m_volMiddle.resize(VOLSIZE * VOLSIZE * VOLSIZE * 4);
	for (int iz = 0; iz < VOLSIZE; ++iz) {
		int offz = VOLSIZE * VOLSIZE * iz;
		for (int iy = 0; iy < VOLSIZE; ++iy) {
			int offy = VOLSIZE * iy;
			for (int ix = 0; ix < VOLSIZE; ++ix) {
				int index = ix + offy + offz;
				int indexInput = index * m_numChannels;
				GLubyte r = m_volInput[indexInput];
				GLubyte g = m_volInput[indexInput + 1];
				GLubyte b = m_volInput[indexInput + 2];
				GLubyte a = m_numChannels == 4 ? m_volInput[indexInput + 3] : 255;
				a = min(a, m_volMask[index]);
				int indexOutput = index * 4;
				m_volMiddle[indexOutput]     = r;
				m_volMiddle[indexOutput + 1] = g;
				m_volMiddle[indexOutput + 2] = b;
				m_volMiddle[indexOutput + 3] = a;
			}
		}
	}
}

void Core::calcVolMiddleDisp() {
	m_volMiddleDisp.clear();
	m_volMiddleDisp.resize(VOLSIZE * VOLSIZE * VOLSIZE);
	for (int iz = 0; iz < VOLSIZE; ++iz) {
		int offz = VOLSIZE * VOLSIZE * iz;
		for (int iy = 0; iy < VOLSIZE; ++iy) {
			int offy = VOLSIZE * iy;
			for (int ix = 0; ix < VOLSIZE; ++ix) {
				int index = ix + offy + offz;
				GLubyte d = min(m_volInputDisp[index], m_volMask[index]);
				m_volMiddleDisp[index] = d;
			}
		}
	}
}

void Core::calcVolInOut() {
	m_volInner.clear();
	m_volOuter.clear();
	m_volInner.resize(VOLSIZE * VOLSIZE * VOLSIZE * 4);
	m_volOuter.resize(VOLSIZE * VOLSIZE * VOLSIZE * 4);
	for (int iz = 0; iz < VOLSIZE; ++iz) {
		int offz = VOLSIZE * VOLSIZE * iz;
		for (int iy = 0; iy < VOLSIZE; ++iy) {
			int iyInner = max(iy - VOLSIZE / 2, 0          );
			int iyOuter = min(iy + VOLSIZE / 2, VOLSIZE - 1);
			int offy      = VOLSIZE * iy;
			int offyInner = VOLSIZE * iyInner;
			int offyOuter = VOLSIZE * iyOuter;
			for (int ix = 0; ix < VOLSIZE; ++ix) {
				int index      = ix + offy      + offz;
				int indexInner = ix + offyInner + offz;
				int indexOuter = ix + offyOuter + offz;
				int indexInput = index * m_numChannels;
				GLubyte r = m_volInput[indexInput];
				GLubyte g = m_volInput[indexInput + 1];
				GLubyte b = m_volInput[indexInput + 2];
				GLubyte a = m_numChannels == 4 ? m_volInput[indexInput + 3] : 255;
				GLubyte aInner = min(a, m_volMask[indexInner]);
				GLubyte aOuter = min(a, m_volMask[indexOuter]);
				int indexOutput = index * 4;
				m_volInner[indexOutput]     = m_volOuter[indexOutput]     =  r;
				m_volInner[indexOutput + 1] = m_volOuter[indexOutput + 1] =  g;
				m_volInner[indexOutput + 2] = m_volOuter[indexOutput + 2] =  b;
				m_volInner[indexOutput + 3] = aInner;
				m_volOuter[indexOutput + 3] = aOuter;
			}
		}
	}
}

void Core::calcVolInOutDisp() {
	m_volInnerDisp.clear();
	m_volOuterDisp.clear();
	m_volInnerDisp.resize(VOLSIZE * VOLSIZE * VOLSIZE);
	m_volOuterDisp.resize(VOLSIZE * VOLSIZE * VOLSIZE);
	for (int iz = 0; iz < VOLSIZE; ++iz) {
		int offz = VOLSIZE * VOLSIZE * iz;
		for (int iy = 0; iy < VOLSIZE; ++iy) {
			int iyInner = max(iy - VOLSIZE / 2, 0          );
			int iyOuter = min(iy + VOLSIZE / 2, VOLSIZE - 1);
			int offy      = VOLSIZE * iy;
			int offyInner = VOLSIZE * iyInner;
			int offyOuter = VOLSIZE * iyOuter;
			for (int ix = 0; ix < VOLSIZE; ++ix) {
				int index      = ix + offy      + offz;
				int indexInner = ix + offyInner + offz;
				int indexOuter = ix + offyOuter + offz;
				GLubyte dInner = min(m_volInputDisp[index], m_volMask[indexInner]);
				GLubyte dOuter = min(m_volInputDisp[index], m_volMask[indexOuter]);
				m_volInnerDisp[index] = dInner;
				m_volOuterDisp[index] = dOuter;
			}
		}
	}
}




void Core::calcPolyPatch() {
	/*
		first, store vertices and establish a mapping of vertices between patch and original
	*/
	vector<KVertex> vertices;
	vector<int>   mapVtxPatch2Org;
	map<int, int> mapVtxOrg2Patch;
	for (int i = 0; i < (int)m_patch.size(); ++i) {
		int tetID = m_patch[i];
		KMultiTexTetra& tet = m_tetraOrg.m_tetras[tetID];
		for (int j = 0; j < 4; ++j) {
			int vtxID = tet.m_vtx[j];
			if (find(mapVtxPatch2Org.begin(), mapVtxPatch2Org.end(), vtxID) == mapVtxPatch2Org.end()) {
				mapVtxPatch2Org.push_back(vtxID);
				mapVtxOrg2Patch.insert(pair<int, int>(vtxID, (int)vertices.size()));
				vertices.push_back(m_tetraOrg.m_vertices[vtxID]);
			}
		}
	}
	/*
		next, store tetra model
	*/
	vector<KMultiTexTetra> tetras;
	for (int i = 0; i < (int)m_patch.size(); ++i) {
		int tetID = m_patch[i];
		KMultiTexTetra& tet = m_tetraOrg.m_tetras[tetID];
		int patchVtxID[4];
		for (int j = 0; j < 4; ++j) {
			patchVtxID[j] = mapVtxOrg2Patch.find(tet.m_vtx[j])->second;
		}
		KMultiTexTetra tetPatch(patchVtxID[0], patchVtxID[1], patchVtxID[2], patchVtxID[3]);
		KTetraTexCoord texCoord;
		for (int j = 0; j < 4; ++j) {
			texCoord.m_coord[j] = m_optimized.find(tet.m_vtx[j])->second;
		}
		for (int j = 0; j < 4; ++j) {
			tetPatch.m_neighbor[j] = tet.m_neighbor[j] == -1 ? -1 : -2;
		}
		tetPatch.m_texCoords.push_back(texCoord);
		tetras.push_back(tetPatch);
	}
	KMultiTexTetraModel tetraPatch;
	tetraPatch.m_vertices = vertices;
	tetraPatch.m_tetras   = tetras;
	vector<double> patchVtxValueCut(tetraPatch.m_vertices.size());
	for (int i = 0; i < (int)tetraPatch.m_vertices.size(); ++i) {
		patchVtxValueCut[i] = m_vtxValueCut[mapVtxPatch2Org[i]];
	}
	m_polyPatch = KMarchingTetra::calcMultiTexMarchingTetra(vector<int>(), tetraPatch, patchVtxValueCut, 0);
	m_polyPatch.calcSmoothNormals(0.75);
}


void Core::updatePolySlice(const KMultiTexTetraModel& tetra, int numSlice) {
	vector<double> vtxDistance(tetra.m_vertices.size());
	double zMax = -DBL_MAX;
	double zMin =  DBL_MAX;
	for (int i = 0; i < (int)vtxDistance.size(); ++i) {
		const KVector3d& pos = tetra.m_vertices[i].m_pos;
		double winx, winy, winz;
		m_ogl.project(pos.x, pos.y, pos.z, winx, winy, winz);
		vtxDistance[i] = winz;
		zMax = max(zMax, winz);
		zMin = min(zMin, winz);
	}
	KVolumeRenderer::go(m_polySlice, tetra, vtxDistance, zMax, zMin, numSlice);
}

void Core::calcStrokeRadius() {
	double xMin, yMin, zMin, xMax, yMax, zMax;
	KUtil::getBoundingBox(m_tetraOrg, xMin, yMin, zMin, xMax, yMax, zMax);
	m_strokeRadius = max(max(xMax - xMin, yMax - yMin), zMax - zMin) * 0.01;
}

void Core::calcPolyLayers() {
	int margin = 1;
	vector<double> vtxDepth2(m_tetraOrg.m_vertices.size());
	for (int i = 0; i < (int)vtxDepth2.size(); ++i) {
		vtxDepth2[i] = -m_vtxDepth[i];
	}
	m_polyLayers.clear();
	m_polyLayers.reserve(LAYER_MAX + 1);
	for (int i = 0; i <= LAYER_MAX; ++i) {
		double depth = -(i + margin) / (double)(LAYER_MAX + margin * 2);
		KMultiTexPolygonModel& poly = KMarchingTetra::calcMultiTexMarchingTetra(vector<int>(), m_tetraOrg, vtxDepth2, depth);
		poly.calcSmoothNormals();
		m_polyLayers.push_back(poly);
	}
}

