#pragma once


// DlgInformation �_�C�A���O

class DlgInformation : public CDialog
{
	DECLARE_DYNAMIC(DlgInformation)

public:
	DlgInformation(CWnd* pParent = NULL);   // �W���R���X�g���N�^
	virtual ~DlgInformation();

// �_�C�A���O �f�[�^
	enum { IDD = IDD_DLG_INFORMATION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV �T�|�[�g

	DECLARE_MESSAGE_MAP()
public:
	CString m_numTetra;
public:
	CString m_numVtx;
public:
	CString m_maxLap;
public:
	CString m_minLap;
public:
	CString m_avgLap;
public:
	CString m_numTexture;
public:
	CString m_hasDisp;
public:
	CString m_numFace;
};
