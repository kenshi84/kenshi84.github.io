#include "StdAfx.h"
#include "StateProcess.h"

#include "MainFrm.h"
#include "Core.h"
#include "StateResult.h"
#include "StateBrowse.h"

#include <KLIB/KUtil.h>
#include <KLIB/KDrawer.h>

#include <ctime>

#include <algorithm>

using namespace std;

void StateProcess::init() {
	Core& core = *Core::getInstance();
	for (int i = 0; i < (int)core.m_tetraOrg.m_tetras.size(); ++i) {
		KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[i];
		tet.m_texCoords.clear();
		tet.m_texIDs.clear();
	}
	core.initCut();
	initUncovered();
	//core.m_lst.setField(core.m_tetVectorS, core.m_tetVectorT, core.m_vtxDepth, core.m_tetScale);
	core.m_lst.setField(core.m_tetVectorS, core.m_tetVectorT, core.m_rbfDepth, core.m_tetScale);
	m_isProcessing = false;
	m_selectedTetID = -1;
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_process, true, true);
	core.m_patch.clear();
	m_tetID_showTensor = -1;
}

State* StateProcess::next() {
	Core& core = *Core::getInstance();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_process, false, true);
	return StateResult::getInstance();
}

bool StateProcess::isReady() {
	return true;	//m_uncovered.empty();
}

void StateProcess::initUncovered() {
	Core& core = *Core::getInstance();
	vector<int> shuffle(core.m_tetraOrg.m_tetras.size());
	for (int i = 0; i < (int)shuffle.size(); ++i)
		shuffle[i] = i;
	random_shuffle(shuffle.begin(), shuffle.end());
	m_uncovered.clear();
	for (int i = 0; i < (int)shuffle.size(); ++i)
		m_uncovered.push_back(shuffle[i]);
	m_seedIndex = 0;
}

void StateProcess::pasteOne() {
	Core& core = *Core::getInstance();
	int cntBef = (int)m_uncovered.size();
	if (m_seedIndex >= (int)m_uncovered.size()) m_seedIndex = 0;
	list<int>::iterator iter = m_uncovered.begin();
	advance(iter, m_seedIndex);
	int seed = *iter;
	core.m_seed = seed;
	//m_uncovered.erase(iter);
	++m_seedIndex;
	//m_uncovered.pop_front();
	int depthID;
	//vector<int> patch;
	//map<int, KVector3d> optimized;
	vector<int>& patch = core.m_patch;
	map<int, KVector3d>& optimized = core.m_optimized;
	vector<int> covered;
	//double c0 = rand() / (double)RAND_MAX;
	//double c1 = (1 - c0) * rand() / (double)RAND_MAX;
	//double c2 = (1 - c0 - c1) * rand() / (double)RAND_MAX;
	//double c3 = 1 - c0 - c1 - c2;
	//KMultiTexTetra& tetSeed = core.m_tetraOrg.m_tetras[seed];
	//KVector3d& p0 = core.m_tetraOrg.m_vertices[tetSeed.m_vtx[0]].m_pos;
	//KVector3d& p1 = core.m_tetraOrg.m_vertices[tetSeed.m_vtx[1]].m_pos;
	//KVector3d& p2 = core.m_tetraOrg.m_vertices[tetSeed.m_vtx[2]].m_pos;
	//KVector3d& p3 = core.m_tetraOrg.m_vertices[tetSeed.m_vtx[3]].m_pos;
	//KVector3d c;
	//c.addWeighted(p0, c0);
	//c.addWeighted(p1, c1);
	//c.addWeighted(p2, c2);
	//c.addWeighted(p3, c3);
	core.m_lst.pastePatch(seed, NULL, depthID, patch, optimized, covered, true);
	for (int i = 0; i < (int)covered.size(); ++i) {
		int tetID = covered[i];
		list<int>::iterator findPos = find(m_uncovered.begin(), m_uncovered.end(), tetID);
		if (findPos != m_uncovered.end())
			m_uncovered.erase(findPos);
		//if (core.m_numChannels == 3) {
		//	KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[tetID];
		//	tet.m_texCoords.clear();
		//	tet.m_texIDs   .clear();
		//}
	}
	for (int i = 0; i < (int)patch.size(); ++i) {
		int tetID = patch[i];
		KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[tetID];
		KTetraTexCoord texCoord;
		for (int j = 0; j < 4; ++j) {
			int vtxID = tet.m_vtx[j];
			texCoord.m_coord[j] = optimized.find(vtxID)->second;
		}
		tet.m_texCoords.push_back(texCoord);
		tet.m_texIDs   .push_back(depthID);
	}
	int cntAft = (int)m_uncovered.size();
	cout << m_uncovered.size() << " (" << (cntBef - cntAft) << ")" << endl;
	core.updateCut();
	core.m_ogl.RedrawWindow();
}

void StateProcess::pasteAll() {
	Core& core = *Core::getInstance();
	int cnt = 0;
	m_isProcessing = true;
	clock_t start,end;
	start = clock();
	while (!m_uncovered.empty()) {
		pasteOne();
		{
			MSG msg;
			while(::PeekMessage( &msg, NULL, NULL, NULL, PM_NOREMOVE ))
				AfxGetThread()->PumpMessage() ;
		}
		if (m_isCancelPressed) break;
		++cnt;
		if (cnt % 20 == 0) {
			core.updateCut();
		}
		core.m_ogl.RedrawWindow();
	}
	end = clock();
	printf("total time: %.2f sec.\n", (double)(end - start) / CLOCKS_PER_SEC);
	printf("total count: %d\n", cnt);
	//core.p_mainFrm->UpdateDialogControls(&core.p_mainFrm->m_wndToolBar_process, true);
	m_isCancelPressed = false;
	m_isProcessing = false;
	core.m_ogl.RedrawWindow();
}

void StateProcess::clear() {
	Core& core = *Core::getInstance();
	initUncovered();
	for (int i = 0; i < (int)core.m_tetraOrg.m_tetras.size(); ++i) {
		KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[i];
		tet.m_texCoords.clear();
		tet.m_texIDs.clear();
	}
	core.updateCut();
	core.m_patch.clear();
	core.m_lst.clearCoverAcc();
	m_seedTemp.clear();
}

void StateProcess::draw() {
	Core& core = *Core::getInstance();
	KMultiTexPolygonModel& poly = core.m_polyCut;
	glEnable(GL_LIGHTING);
	glColor3dv(Drawer::COLOR_FACE);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& n = p.m_normal[j];
			KVector3d& v = poly.m_vertices[p.m_vtx[j]].m_pos;
			glNormal3dv(n.getPtr());
			glVertex3dv(v.getPtr());
		}
	}
	glEnd();
	glEnable(GL_TEXTURE_3D);
	glEnable(GL_BLEND);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < (int)p.m_texCoords.size(); ++j) {
			int texID = p.m_texIDs[j];
			int texName =
				texID == 0 ? core.m_drawer.m_texNameMiddle
				: texID == 1 ? core.m_drawer.m_texNameOuter
				: core.m_drawer.m_texNameInner;
			glBindTexture(GL_TEXTURE_3D, texName);
			glBegin(GL_TRIANGLES);
			for (int k = 0; k < 3; ++k) {
				KVector3d& n = p.m_normal[k];
				KVector3d& t = p.m_texCoords[j].m_coord[k];
				KVector3d& v = poly.m_vertices[p.m_vtx[k]].m_pos;
				glNormal3dv(n.getPtr());
				glTexCoord3dv(t.getPtr());
				glVertex3dv(v.getPtr());
			}
			glEnd();
		}
	}
	glDisable(GL_TEXTURE_3D);
	glDisable(GL_BLEND);
	
	if (m_tetID_showTensor != -1) {
		KVector3d c;
		KUtil::getBarycenter(c, core.m_tetraOrg, core.m_tetraOrg.m_tetras[m_tetID_showTensor]);
		double scale = core.m_strokeRadius * 20;
		KVector3d r = core.m_lst.m_tetVectorR[m_tetID_showTensor];
		KVector3d s = core.m_lst.m_tetVectorS[m_tetID_showTensor];
		KVector3d t = core.m_lst.m_tetVectorT[m_tetID_showTensor];
		r.scale(scale);
		s.scale(scale);
		t.scale(scale);
		glDisable(GL_DEPTH_TEST);
		glColor3d(1, 0, 0);
		KDrawer::drawArrow(c, r);
		glColor3d(0, 1, 0);
		KDrawer::drawArrow(c, s);
		glColor3d(0, 0, 1);
		KDrawer::drawArrow(c, t);
		glEnable(GL_DEPTH_TEST);
	}
	
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);
	glColor3dv(Drawer::COLOR_CUTSTROKE);
	glLineWidth(5);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < (int)core.m_cutStroke.size(); ++i)
		glVertex3dv(core.m_cutStroke[i].getPtr());
	glEnd();
	glDepthMask(GL_TRUE);
	glEnable(GL_DEPTH_TEST);
}

void StateProcess::postDraw(CWnd* hWnd, CDC* pDC) {
	Core& core = *Core::getInstance();
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	CString str;
	if (m_uncovered.empty()) {
		str = "Done!";
	} else if (m_isProcessing) {
		int N = (int)core.m_tetraOrg.m_tetras.size();
		int n = (int)m_uncovered.size();
		str.Format("Processing...(%d%%)", (N - n) * 100 / N);
	} else {
		str = "Paste texture one by one!";
	}
	pDC->DrawText(str, -1, &rc, DT_LEFT | DT_TOP | DT_SINGLELINE);
	pDC->SelectObject(pOldFont);
}

void StateProcess::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	m_tetID_showTensor = -1;
	if (KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) {
		double dist;
		int seedID;
		KUtil::getNearestTetraID(seedID, dist, core.m_tetraOrg, pos);
		if (nFlags & MK_CONTROL) {
			m_tetID_showTensor = seedID;
			//m_selectedTetID = seedID;
		} else {
			int depthID;
			//vector<int> patch;
			//map<int, KVector3d> optimized;
			m_seedTemp.push_back(seedID);
			vector<int>& patch = core.m_patch;
			map<int, KVector3d>& optimized = core.m_optimized;
			vector<int> covered;
			core.m_lst.pastePatch(seedID, &pos, depthID, patch, optimized, covered, true);
			//m_centerPos_prev = pos;
			//m_seedID_prev = seedID;
			int cntBef = (int)m_uncovered.size();
			for (int i = 0; i < (int)covered.size(); ++i) {
				int tetID = covered[i];
				list<int>::iterator findPos = find(m_uncovered.begin(), m_uncovered.end(), tetID);
				if (findPos != m_uncovered.end())
					m_uncovered.erase(findPos);
			}
			for (int i = 0; i < (int)patch.size(); ++i) {
				int tetID = patch[i];
				KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[tetID];
				KTetraTexCoord texCoord;
				for (int j = 0; j < 4; ++j) {
					int vtxID = tet.m_vtx[j];
					texCoord.m_coord[j] = optimized.find(vtxID)->second;
				}
				tet.m_texCoords.push_back(texCoord);
				tet.m_texIDs   .push_back(depthID);
			}
			int cntAft = (int)m_uncovered.size();
			cout << m_uncovered.size() << " (" << (cntBef - cntAft) << ")" << endl;
			core.updateCut();
			core.m_ogl.RedrawWindow();
		}
		core.m_ogl.RedrawWindow();
	} else {
		start.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(start);
		m_isCutting = true;
		m_pointOld = point;
	}
}

void StateProcess::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	if (!m_isCutting) return;
	Core& core = *Core::getInstance();
	m_isCutting = false;
	if (core.m_cutStroke.size() == 1) {
		core.initCut();
	} else {
		core.calcVtxValueCut(core.m_cutStroke);
		core.updateCut();
	}
	core.m_cutStroke.clear();
	core.m_ogl.RedrawWindow();
}

void StateProcess::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			core.m_ogl.ButtonDownForTranslate(point);
		} else {
			core.m_ogl.ButtonDownForRotate(point);
		}
	}else {
		core.m_ogl.ButtonDownForZoom(point);
	}
	m_isRButtonDown = true;
}

void StateProcess::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	core.m_ogl.ButtonUp();
	m_isRButtonDown = false;
}

void StateProcess::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isRButtonDown) {
		core.m_ogl.MouseMove(point);
		return;
	}
	if (!m_isCutting) return;
	double dx = point.x - m_pointOld.x;
	double dy = point.y - m_pointOld.y;
	double dist = sqrt(dx * dx + dy * dy);
	if (dist < 10) return;
	m_pointOld = point;
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	start.addWeighted(ori, 0.5);
	core.m_cutStroke.push_back(start);
	core.m_ogl.RedrawWindow();
}

void StateProcess::OnDropFiles  (CView* view, HDROP hDropInfo) {
	char fname[256];
	if (DragQueryFile(hDropInfo, -1, fname, sizeof(fname)) != 1) return;
	DragQueryFile(hDropInfo, 0, fname, sizeof(fname));
	
	string str(fname);
	string ext = str.substr(str.length() - 4, 4);
	if (ext.compare(".lst")) {
		AfxMessageBox("Please drop *.lst file!");
		return;
	}
	Core& core = *Core::getInstance();
	core.m_state = StateBrowse::getInstance();
	core.m_state->init();
	StateBrowse::getInstance()->OnDropFiles(view, hDropInfo);
}
