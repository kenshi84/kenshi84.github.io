#include "StdAfx.h"
#include "StatePeelStroke.h"
#include "StateScale.h"
#include "StateProcess.h"
#include "MainFrm.h"

#include <KLIB/KDrawer.h>
#include <KLIB/KUtil.h>

using namespace std;

const char* str_vert_shader = "\
varying vec3 vNormal;\
varying vec3 vPosition;\
\
void main(void)\
{\
   gl_Position = ftransform();\
   vNormal = gl_NormalMatrix * gl_Normal;\
   vPosition = vec3(gl_ModelViewMatrix * gl_Vertex);\
}\
";

const char* str_frag_shader = "\
varying vec3 vNormal;\
varying vec3 vPosition;\
\
void main(void)\
{\
   vec3 n = normalize(vNormal);\
   vec3 e = -normalize(vPosition);\
   float edot = abs(dot(n, e));\
   float i = min(floor(edot * 5.0), 1.0);\
   gl_FragColor.rgb = vec3(0.0, 0.0, 0.0);\
   gl_FragColor.a = 1.0 - i;\
}\
";

StatePeelStroke::StatePeelStroke() {
	Core& core = *Core::getInstance();
	core.m_ogl.makeOpenGLCurrent();
	if (Drawer::FUTL_MakeShader(str_vert_shader, str_frag_shader, &m_shaderProg) < 0) {
		m_shaderProg = 0;
		printf("failed to load shader.\n");
	}
	
}

State* StatePeelStroke::next() {
	Core& core = *Core::getInstance();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_peelStroke, false, true);
	//core.updateDepth();
	core.constructLaplacianDepth();
	//core.calcTetVectorByLaplacian(core.m_tetVectorT, core.m_strokes);
	core.calcTetVectorByLaplacianDepth(core.m_tetVectorT, core.m_strokes);
	if (core.m_mode == Core::MODE_DblDirHomo) {
		// set tetVectorS as depth gradient
		core.m_tetVectorS.clear();
		core.m_tetVectorS.reserve(core.m_tetraOrg.m_tetras.size());
		for (int i = 0; i < (int)core.m_tetraOrg.m_tetras.size(); ++i) {
			KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[i];
			KVector3d pos;
			KUtil::getBarycenter(pos, core.m_tetraOrg, tet);
			double f0 = core.m_rbfDepth.getValue(pos);
			double fx = core.m_rbfDepth.getValue(pos.x + Core::GRADIENT_DELTA, pos.y, pos.z);
			double fy = core.m_rbfDepth.getValue(pos.x, pos.y + Core::GRADIENT_DELTA, pos.z);
			double fz = core.m_rbfDepth.getValue(pos.x, pos.y, pos.z + Core::GRADIENT_DELTA);
			KVector3d vectorS(fx - f0, fy - f0, fz - f0);
			vectorS.scale(1 / Core::GRADIENT_DELTA);
			core.m_tetVectorS.push_back(vectorS);
		}
		return StateScale::getInstance();
	} else {
		return StateProcess::getInstance();
	}
}

bool StatePeelStroke::isReady() {
	return !Core::getInstance()->m_strokes.empty();
}

void StatePeelStroke::init() {
	Core& core = *Core::getInstance();
	core.calcPolyLayers();
	core.m_strokes.clear();
	core.m_polyCut = core.m_tetraOrg.toMultiTexPolygonModel();
	core.m_polyCut.calcSmoothNormals();
	m_currentLayer = 0;
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_peelStroke, true, true);
}

void StatePeelStroke::draw() {
	Core& core = *Core::getInstance();
	KMultiTexPolygonModel& poly = core.m_polyLayers[m_currentLayer];
	glColor3dv(Drawer::COLOR_FACE);
	glEnable(GL_LIGHTING);
	glEnable(GL_TEXTURE_1D);
	glBindTexture(GL_TEXTURE_1D, core.m_drawer.m_texNameDepth);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& n = p.m_normal[j];
			KVector3d& v = poly.m_vertices[p.m_vtx[j]].m_pos;
			glNormal3dv(n.getPtr());
			glTexCoord1d(m_currentLayer / (double)Core::LAYER_MAX);
			glVertex3dv(v.getPtr());
		}
	}
	glEnd();
	glDisable(GL_TEXTURE_1D);
	// draw strokes!
	glColor3dv(Drawer::COLOR_STROKE);
	for (int i = 0; i < (int)core.m_strokes.size(); ++i) {
		vector<KVector3d>& stroke = core.m_strokes[i];
		for (int j = 1; j < (int)stroke.size(); ++j) {
			KVector3d& p0 = stroke[j - 1];
			KVector3d& p1 = stroke[j];
			KVector3d d;
			d.sub(p1, p0);
			d.scale(1.2);
			KDrawer::drawCylinder(p0, d, core.m_strokeRadius);
			if (j == (int)stroke.size() - 1)
				KDrawer::drawCone(p1, d, 2 * core.m_strokeRadius, 4 * core.m_strokeRadius);
		}
	}
	glDisable(GL_LIGHTING);
	// draw contour
	if (m_shaderProg != 0) {
		glEnable(GL_BLEND);
		//glDepthMask(GL_FALSE);
		glUseProgram(m_shaderProg);
		glBegin(GL_TRIANGLES);
		//glColor4d(0.75, 0.75, 0.75, 0.6);
		for (int i = 0; i < (int)core.m_polyCut.m_polygons.size(); ++i) {
			KMultiTexPolygon& p = core.m_polyCut.m_polygons[i];
			for (int j = 0; j < 3; ++j) {
				KVector3d& n = p.m_normal[j];
				KVector3d& v = core.m_polyCut.m_vertices[p.m_vtx[j]].m_pos;
				glNormal3dv(n.getPtr());
				glVertex3dv(v.getPtr());
			}
		}
		glEnd();
		//glDepthMask(GL_TRUE);
		glDisable(GL_BLEND);
		glUseProgram(0);
	}
	
}

void StatePeelStroke::postDraw(CWnd* hWnd, CDC* pDC) {
	Core& core = *Core::getInstance();
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	pDC->DrawText ( "Draw strokes on layers!", -1, &rc, DT_LEFT | DT_TOP | DT_SINGLELINE);
	pDC->SelectObject ( pOldFont );
}

void StatePeelStroke::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (KUtil::getIntersection(pos, polyID, core.m_polyLayers[m_currentLayer], start, ori)) {
		core.m_strokes.push_back(vector<KVector3d>());
		core.m_strokes.back().push_back(pos);
		m_isDrawing = true;
		m_pointOld = point;
	}
}

void StatePeelStroke::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (nFlags & MK_CONTROL) {
		printf("------------------------------------------------\n");
		for (int i = 0; i < (int)core.m_strokes.back().size(); ++i) {
			KVector3d& pos = core.m_strokes.back()[i];
			printf("%f, %f, %f\n", pos.x, pos.y, pos.z);
		}
	}
	if (m_isDrawing) {
		m_isDrawing = false;
	}
}

void StatePeelStroke::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			Core::getInstance()->m_ogl.ButtonDownForTranslate(point);
		} else {
			Core::getInstance()->m_ogl.ButtonDownForRotate(point);
		}
	}else {
		Core::getInstance()->m_ogl.ButtonDownForZoom(point);
	}
	m_isRButtonDown = true;
}

void StatePeelStroke::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core::getInstance()->m_ogl.ButtonUp();
	m_isRButtonDown = false;
}

void StatePeelStroke::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isRButtonDown) {
		core.m_ogl.MouseMove(point);
		return;
	}
	if (!m_isDrawing) return;
	double dx = point.x - m_pointOld.x;
	double dy = point.y - m_pointOld.y;
	double dist = sqrt(dx * dx + dy * dy);
	if (dist < 10) return;
	m_pointOld = point;
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (KUtil::getIntersection(pos, polyID, core.m_polyLayers[m_currentLayer], start, ori)) {
		core.m_strokes.back().push_back(pos);
		core.m_ogl.RedrawWindow();
	}
}

void StatePeelStroke::OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt) {
	if (zDelta > 0 && m_currentLayer < Core::LAYER_MAX)
		goInner();
	else if (zDelta < 0 && m_currentLayer > 0)
		goOuter();
}

void StatePeelStroke::goInner() {
	++m_currentLayer;
	Core::getInstance()->m_ogl.RedrawWindow();
}

void StatePeelStroke::goOuter() {
	--m_currentLayer;
	Core::getInstance()->m_ogl.RedrawWindow();
}

void StatePeelStroke::OnKeyDown(CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {
	Core& core = *Core::getInstance();
	switch (nChar) {
		case VK_UP:
			if (m_currentLayer < Core::LAYER_MAX) goInner();
			break;
		case VK_DOWN:
			if (m_currentLayer > 0) goOuter();
			break;
	}
}

