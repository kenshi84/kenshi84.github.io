// DlgDisplacement.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "LSTDemo.h"
#include "DlgDisplacement.h"


// DlgDisplacement �_�C�A���O

IMPLEMENT_DYNAMIC(DlgDisplacement, CDialog)

DlgDisplacement::DlgDisplacement(CWnd* pParent /*=NULL*/)
	: CDialog(DlgDisplacement::IDD, pParent)
	, m_numSubdiv(0)
	, m_degDisp(0)
{

}

DlgDisplacement::~DlgDisplacement()
{
}

void DlgDisplacement::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_SUBDIV, m_numSubdiv);
	DDV_MinMaxInt(pDX, m_numSubdiv, 0, 100);
	DDX_Text(pDX, IDC_EDIT_DISP, m_degDisp);
	DDV_MinMaxDouble(pDX, m_degDisp, 0, 10000);
}


BEGIN_MESSAGE_MAP(DlgDisplacement, CDialog)
END_MESSAGE_MAP()


// DlgDisplacement ���b�Z�[�W �n���h��
