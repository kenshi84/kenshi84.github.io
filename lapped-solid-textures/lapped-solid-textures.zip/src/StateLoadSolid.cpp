#include "StdAfx.h"
#include "StateLoadSolid.h"

#include <KLIB/KDrawer.h>

#include "StateScale.h"
#include "StateSDHStroke.h"
#include "StateDepthPaint.h"
#include "DlgTexTypeSelect.h"
#include "MainFrm.h"
#include <KLIB/KIcosahedron.h>
#include <KLIB/KMarchingTetraSubdiv.h>
#include <KLIB/KMarchingTetra.h>
#include <KLIB/KUtil.h>

using namespace std;

StateLoadSolid::StateLoadSolid() {
	KIcosahedron icosa = KIcosahedron(0.05);
	icosa.subdivide();
	m_polyIcosa = icosa;
	m_polyIcosa.calcSmoothNormals();
	m_polyIcosaX = m_polyIcosa;
	m_polyIcosaY = m_polyIcosa;
	m_polyIcosaZ = m_polyIcosa;
}

State* StateLoadSolid::next() {
	Core& core = *Core::getInstance();
	
	DlgTexTypeSelect dlg;
	if (dlg.DoModal() != IDOK) return 0;
	
	core.m_ogl.makeOpenGLCurrent();
	glDisable(GL_TEXTURE_3D);
	glDisable(GL_BLEND);
	
	CRect rect;
	core.p_view->GetWindowRect(&rect);
	int w = rect.right - rect.left;
	int h = rect.bottom - rect.top;
	glViewport(0, 0, w, h);
	glMatrixMode( GL_PROJECTION );
	glLoadIdentity();
	gluPerspective(30,w / (double)h , 0.01,10000);
	glMatrixMode( GL_MODELVIEW ) ;
	
	core.calcVolMiddle();
	if (!core.m_volInputDisp.empty())
		core.calcVolMiddleDisp();
	core.m_drawer.genTexMiddle();
	core.setFocusCenter();
	
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_loadTexture, false, true);
	
	if (dlg.m_texType == 0) {
		core.m_tetVectorS.clear();
		core.m_tetVectorT.clear();
		core.m_mode = Core::MODE_ISOTROPIC;
		return StateScale::getInstance();
	} else if (dlg.m_texType == 1) {
		core.m_mode = Core::MODE_SglDirHomo;
		return StateSDHStroke::getInstance();
	} else if (dlg.m_texType == 2) {
		core.m_mode = Core::MODE_SglDirLayer;
		return StateDepthPaint::getInstance();
	} else if (dlg.m_texType == 3) {
		core.m_mode = Core::MODE_DblDirHomo;
		return StateDepthPaint::getInstance();
	} else if (dlg.m_texType == 4) {
		core.m_mode = Core::MODE_DblDirLayer;
		return StateDepthPaint::getInstance();
	} else {
		return 0;
	}
}

void StateLoadSolid::init() {
	Core& core = *Core::getInstance();
	core.m_ogl.setEyePosition(0.5, 0.5, 5, 0.5, 0.5, 0.5, 0, 1, 0);
	core.m_ogl.updateEyePosition();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_loadTexture, true, true);
	m_mode = MODE_COLOR;
	m_currentSlice = Core::VOLSIZE - 1;
	m_currentPlane = PLANE_X;
	updateHandlePos();
	updateTetraCut();
	updatePolyCut();
	core.updatePolySlice(core.m_tetraCut);
	m_isVolumeRendering = false;
	m_isDrawHandle = true;
	m_isDrawAxis = true;
	m_isDrawBox = true;
	m_isDrawMasked = false;
}

void StateLoadSolid::draw() {
	Core& core = *Core::getInstance();
	if ((m_mode == MODE_COLOR && core.m_volInput.empty()) ||
		(m_mode == MODE_DISPLACEMENT && core.m_volInputDisp.empty())) return;
	
	CRect rect;
	core.p_view->GetWindowRect(&rect);
	int w = rect.right - rect.left;
	int h = rect.bottom - rect.top;
	
	// draw 3D texture
	//glViewport(0, 0, w, h);
	//glMatrixMode( GL_PROJECTION );
	//glLoadIdentity();
	////gluPerspective(30,w * 0.5 / (double)h , 0.01,10000);
	//gluPerspective(30,w / (double)h , 0.01,10000);
	//glMatrixMode( GL_MODELVIEW ) ;
	//core.m_ogl.updateEyePosition();
	glDisable(GL_LIGHTING);
	if (m_isDrawBox) {
		glLineWidth(2);
		glColor3d(0.5, 0.5, 0.5);
		KDrawer::drawWireBox(0, 0, 0, 1, 1, 1);
	}
	if (m_isDrawAxis) {
		glLineWidth(5);
		KDrawer::drawAxis();
	}
	
	glEnable(GL_TEXTURE_3D);
	glEnable(GL_BLEND);
	if (m_mode == MODE_COLOR) {
		glBindTexture(GL_TEXTURE_3D, core.m_drawer.m_texNameInput);
	}
	else
		glBindTexture(GL_TEXTURE_3D, core.m_drawer.m_texNameDisp);
	glColor3d(1, 1, 1);
	glBegin(GL_TRIANGLES);
	if (m_isVolumeRendering) {
		for (int i = 0; i < (int)core.m_polySlice.m_polygons.size(); ++i) {
			KMultiTexPolygon& p = core.m_polySlice.m_polygons[i];
			//KVector3d& n = p.m_normal[0];
			//glNormal3d(n.x, n.y, n.z);
			for (int j = 0; j < 3; ++j) {
				glTexCoord3dv(p.m_texCoords[0].m_coord[j].getPtr());
				glVertex3dv(core.m_polySlice.m_vertices[p.m_vtx[j]].m_pos.getPtr());
			}
		}
	} else {
		for (int i = 0; i < (int)core.m_polyCut.m_polygons.size(); ++i) {
			KMultiTexPolygon& p = core.m_polyCut.m_polygons[i];
			for (int j = 0; j < 3; ++j) {
				glTexCoord3dv(p.m_texCoords[0].m_coord[j].getPtr());
				glVertex3dv(core.m_polyCut.m_vertices[p.m_vtx[j]].m_pos.getPtr());
			}
		}
	}
	glEnd();
	glDisable(GL_TEXTURE_3D);
	glDisable(GL_BLEND);
	if (m_isDrawHandle) {
		glEnable(GL_LIGHTING);
		if (m_currentPlane == PLANE_X)
			glColor3d(1, 1, 0);
		else
			glColor3d(0.5, 0.5, 0.5);
		glBegin(GL_TRIANGLES);
		for (int i = 0; i < (int)m_polyIcosa.m_polygons.size(); ++i) {
			KPolygon& p = m_polyIcosa.m_polygons[i];
			for (int j = 0; j < 3; ++j) {
				glNormal3dv(p.m_normal[j].getPtr());
				glVertex3dv(m_polyIcosaX.m_vertices[p.m_vtx[j]].m_pos.getPtr());
			}
		}
		glEnd();
		if (m_currentPlane == PLANE_Y)
			glColor3d(1, 1, 0);
		else
			glColor3d(0.5, 0.5, 0.5);
		glBegin(GL_TRIANGLES);
		for (int i = 0; i < (int)m_polyIcosa.m_polygons.size(); ++i) {
			KPolygon& p = m_polyIcosa.m_polygons[i];
			for (int j = 0; j < 3; ++j) {
				glNormal3dv(p.m_normal[j].getPtr());
				glVertex3dv(m_polyIcosaY.m_vertices[p.m_vtx[j]].m_pos.getPtr());
			}
		}
		glEnd();
		if (m_currentPlane == PLANE_Z)
			glColor3d(1, 1, 0);
		else
			glColor3d(0.5, 0.5, 0.5);
		glBegin(GL_TRIANGLES);
		for (int i = 0; i < (int)m_polyIcosa.m_polygons.size(); ++i) {
			KPolygon& p = m_polyIcosa.m_polygons[i];
			for (int j = 0; j < 3; ++j) {
				glNormal3dv(p.m_normal[j].getPtr());
				glVertex3dv(m_polyIcosaZ.m_vertices[p.m_vtx[j]].m_pos.getPtr());
			}
		}
		glEnd();
	}
}

void StateLoadSolid::updatePolyCut() {
	Core& core = *Core::getInstance();
	vector<double> vtxValue(core.m_tetraCube.m_vertices.size());
	for (int i = 0; i < (int)vtxValue.size(); ++i) {
		KVector3d& pos = core.m_tetraCube.m_vertices[i].m_pos;
		vtxValue[i] = 
			m_currentPlane == PLANE_X ? pos.x
			: m_currentPlane == PLANE_Y ? pos.y : pos.z;
	}
	double threshold = (m_currentSlice + 0.5) / Core::VOLSIZE;
	core.m_polyCut = KMarchingTetra::calcMultiTexMarchingTetra(vector<int>(), core.m_tetraCube, vtxValue, threshold);
}

void StateLoadSolid::updateTetraCut() {
	Core& core = *Core::getInstance();
	vector<double> vtxValue(core.m_tetraCube.m_vertices.size());
	for (int i = 0; i < (int)vtxValue.size(); ++i) {
		KVector3d& pos = core.m_tetraCube.m_vertices[i].m_pos;
		vtxValue[i] = 
			m_currentPlane == PLANE_X ? pos.x
			: m_currentPlane == PLANE_Y ? pos.y : pos.z;
	}
	double threshold = (m_currentSlice + 0.5) / Core::VOLSIZE;
	core.m_tetraCut = KMarchingTetraSubdiv::calcMarchingTetraSubdiv(core.m_tetraCube, vtxValue, threshold);
}

void StateLoadSolid::updateHandlePos() {
	double off = (m_currentSlice + 0.5) / Core::VOLSIZE;
	for (int i = 0; i < (int)m_polyIcosa.m_vertices.size(); ++i) {
		m_polyIcosaX.m_vertices[i].m_pos.x = m_polyIcosa.m_vertices[i].m_pos.x + off;
		m_polyIcosaY.m_vertices[i].m_pos.y = m_polyIcosa.m_vertices[i].m_pos.y + off;
		m_polyIcosaZ.m_vertices[i].m_pos.z = m_polyIcosa.m_vertices[i].m_pos.z + off;
	}
}

void StateLoadSolid::postDraw(CWnd* hWnd, CDC* pDC) {
	Core& core = *Core::getInstance();
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	if (m_mode == MODE_COLOR && core.m_volInput.empty())
		pDC->DrawText ( "Drop solid texture (*.vol) here!", -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	else if (m_mode == MODE_DISPLACEMENT && core.m_volInputDisp.empty())
		pDC->DrawText ( "Drop displacement map (*.vol) here!", -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	pDC->SelectObject ( pOldFont );
}

void StateLoadSolid::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (KUtil::getIntersection(pos, polyID, m_polyIcosaX, start, ori)) {
		m_currentPlane = PLANE_X;
		m_isDragging = true;
	} else if (KUtil::getIntersection(pos, polyID, m_polyIcosaY, start, ori)) {
		m_currentPlane = PLANE_Y;
		m_isDragging = true;
	} else if (KUtil::getIntersection(pos, polyID, m_polyIcosaZ, start, ori)) {
		m_currentPlane = PLANE_Z;
		m_isDragging = true;
	}
	if (m_isDragging) core.m_ogl.RedrawWindow();
}

void StateLoadSolid::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	m_isDragging = false;
}

void StateLoadSolid::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			Core::getInstance()->m_ogl.ButtonDownForTranslate(point);
		} else {
			Core::getInstance()->m_ogl.ButtonDownForRotate(point);
		}
	}else {
		Core::getInstance()->m_ogl.ButtonDownForZoom(point);
	}
	m_isRButtonDown = true;
}
void StateLoadSolid::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	core.m_ogl.ButtonUp();
	m_isRButtonDown = false;
}
void StateLoadSolid::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isRButtonDown) {
		core.m_ogl.MouseMove(point);
		if (m_isVolumeRendering) core.updatePolySlice(core.m_tetraCut);
		core.m_ogl.RedrawWindow();
		return;
	}
	if (!m_isDragging) return;
	
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	
	KVector3d x(start);
	x.add(ori);
	KVector3d e(core.m_ogl.m_eyePoint);
	KVector3d d;
	if (m_currentPlane == PLANE_X)
		d.set(1, 0, 0);
	else if (m_currentPlane == PLANE_Y)
		d.set(0, 1, 0);
	else
		d.set(0, 0, 1);
	KVector3d n1;
	n1.cross(e, d);
	KVector3d n2;
	KVector3d ex(x);
	ex.sub(e);
	n2.cross(ex, n1);
	double k = n2.dot(e) / n2.dot(d);
	int numSlice = (int)(k * Core::VOLSIZE - 0.5);
	if (numSlice < 0 || numSlice >= Core::VOLSIZE) return;
	m_currentSlice = numSlice;
	if (m_isVolumeRendering) {
		updateTetraCut();
		core.updatePolySlice(core.m_tetraCut);
	} else {
		updatePolyCut();
	}
	updateHandlePos();
	core.m_ogl.RedrawWindow();
}
//bool isRotating = false;
void StateLoadSolid::OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {
	Core& core = *Core::getInstance();
	switch (nChar) {
		case 'X':
			if (m_currentPlane == PLANE_X) return;
			m_currentPlane = PLANE_X;
			if (m_isVolumeRendering) {
				updateTetraCut();
				core.updatePolySlice(core.m_tetraCut);
			} else {
				updatePolyCut();
			}
			core.m_ogl.RedrawWindow();
			break;
		case 'Y':
			if (m_currentPlane == PLANE_Y) return;
			m_currentPlane = PLANE_Y;
			if (m_isVolumeRendering) {
				updateTetraCut();
				core.updatePolySlice(core.m_tetraCut);
			} else {
				updatePolyCut();
			}
			core.m_ogl.RedrawWindow();
			break;
		case 'Z':
			if (m_currentPlane == PLANE_Z) return;
			m_currentPlane = PLANE_Z;
			if (m_isVolumeRendering) {
				updateTetraCut();
				core.updatePolySlice(core.m_tetraCut);
			} else {
				updatePolyCut();
			}
			core.m_ogl.RedrawWindow();
			break;
		case VK_UP:
			if (m_currentSlice == Core::VOLSIZE - 1) return;
			++m_currentSlice;
			updateHandlePos();
			if (m_isVolumeRendering) {
				updateTetraCut();
				core.updatePolySlice(core.m_tetraCut);
			} else {
				updatePolyCut();
			}
			core.m_ogl.RedrawWindow();
			break;
		case VK_DOWN:
			if (m_currentSlice == 0) return;
			--m_currentSlice;
			updateHandlePos();
			if (m_isVolumeRendering) {
				updateTetraCut();
				core.updatePolySlice(core.m_tetraCut);
			} else {
				updatePolyCut();
			}
			core.m_ogl.RedrawWindow();
			break;
		case 'H':
			m_isDrawHandle = !m_isDrawHandle;
			core.m_ogl.RedrawWindow();
			break;
		case 'A':
			m_isDrawAxis = !m_isDrawAxis;
			core.m_ogl.RedrawWindow();
			break;
		case 'B':
			m_isDrawBox = !m_isDrawBox;
			core.m_ogl.RedrawWindow();
			break;
	//	case VK_RETURN:
	//		if (isRotating) {
	//			isRotating = false;
	//		} else {
	//			isRotating = true;
	//			CPoint pos;
	//			core.m_ogl.ButtonDownForRotate(pos);
	//			while(1) {
	//				pos.x += 3;
	//				core.m_ogl.MouseMove(pos);
	//				Sleep(1);
	//				if (m_isVolumeRendering) core.updatePolySlice(core.m_tetraCut);
	//				core.m_ogl.RedrawWindow();
	//				MSG msg;
	//				while(::PeekMessage( &msg, NULL, NULL, NULL, PM_NOREMOVE ))
	//					AfxGetThread()->PumpMessage();
	//				if (!isRotating) break;
	//			}
	//			core.m_ogl.ButtonUp();
	//		}
	//		break;
	}
}

void StateLoadSolid::OnDropFiles  (CView* view, HDROP hDropInfo) {
	char fname[256];
	if (DragQueryFile(hDropInfo, -1, fname, sizeof(fname)) != 1) return;
	DragQueryFile(hDropInfo, 0, fname, sizeof(fname));
	string str(fname);
	string ext = str.substr(str.length() - 4, 4);
	if (ext.compare(".vol")) {
		AfxMessageBox("Please drop *.vol file!");
		return;
	}
	Core& core = *Core::getInstance();
	if (m_mode == MODE_COLOR) {
		if (!core.loadVolInput(str)) return;
		core.m_drawer.genTexInput();
		core.calcVolMiddle();
		core.m_drawer.genTexMiddle();
	} else {
		if (!core.loadVolInputDisp(str)) return;
		core.m_drawer.genTexDisp(core.m_volInputDisp);
	}
	//core.updatePolySlice(core.m_tetraCut);
	core.m_ogl.RedrawWindow();
}

