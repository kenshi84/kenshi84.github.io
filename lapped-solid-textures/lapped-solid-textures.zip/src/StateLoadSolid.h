#pragma once
#include "state.h"
#include "Core.h"

class StateLoadSolid : public State {
	StateLoadSolid(void);
	~StateLoadSolid(void) {}
public:
	static StateLoadSolid* getInstance() {
		static StateLoadSolid p;
		return &p;
	}
	State* next();
	bool isReady() {
		return !Core::getInstance()->m_volInput.empty();
	}
	void init();
	void draw();
	void postDraw(CWnd* hWnd, CDC* pDC);
	void OnLButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnLButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnRButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnRButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnMouseMove  (CView* view, UINT nFlags, CPoint& point);
	void OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags);
	void OnDropFiles  (CView* view, HDROP hDropInfo);
	void OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt) {}
	void OnLButtonDblClk(CView* view, UINT nFlags, CPoint point) {}
	enum {
		MODE_COLOR,
		MODE_DISPLACEMENT
	} m_mode;
	bool m_isVolumeRendering;
	void updateTetraCut();
	void updatePolyCut();
protected:
	bool m_isRButtonDown;
	bool m_isDragging;
	bool m_isDrawHandle;
	bool m_isDrawMasked;
	bool m_isDrawAxis;
	bool m_isDrawBox;
	//void updatePolySlice();
	KPolygonModel m_polyIcosa;
	KPolygonModel m_polyIcosaX;
	KPolygonModel m_polyIcosaY;
	KPolygonModel m_polyIcosaZ;
	int m_currentSlice;
	enum {
		PLANE_X,
		PLANE_Y,
		PLANE_Z,
	} m_currentPlane;
	void updateHandlePos();
};
