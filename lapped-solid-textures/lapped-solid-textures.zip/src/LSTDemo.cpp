// LSTDemo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "LSTDemo.h"
#include "MainFrm.h"

#include "LSTDemoDoc.h"
#include "LSTDemoView.h"

#include "Core.h"
#include "StateLoadTetra.h"
#include "StateLoadSolid.h"
#include "StateScale.h"
#include "StateProcess.h"
#include "StateResult.h"
#include "StateManualPaste.h"
#include "StateBrowse.h"
#include "StateDepthPaint.h"
#include "StatePeelStroke.h"
#include "StateLoadSolidMP.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CLSTDemoApp

BEGIN_MESSAGE_MAP(CLSTDemoApp, CWinApp)
	ON_COMMAND(ID_APP_ABOUT, &CLSTDemoApp::OnAppAbout)
	// Standard file based document commands
	//ON_COMMAND(ID_FILE_NEW, &CWinApp::OnFileNew)
	//ON_COMMAND(ID_FILE_OPEN, &CWinApp::OnFileOpen)
	ON_COMMAND(ID_NAVIGATION_NEXT, &CLSTDemoApp::OnNavigationNext)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_NEXT, &CLSTDemoApp::OnUpdateNavigationNext)
	ON_COMMAND(ID_SCALE_SET, &CLSTDemoApp::OnScaleSet)
	ON_UPDATE_COMMAND_UI(ID_SCALE_SET, &CLSTDemoApp::OnUpdateScaleSet)
	ON_COMMAND(ID_SCALE_DECREASE, &CLSTDemoApp::OnScaleDecrease)
	ON_UPDATE_COMMAND_UI(ID_SCALE_DECREASE, &CLSTDemoApp::OnUpdateScaleDecrease)
	ON_COMMAND(ID_SCALE_INCREASE, &CLSTDemoApp::OnScaleIncrease)
	ON_UPDATE_COMMAND_UI(ID_SCALE_INCREASE, &CLSTDemoApp::OnUpdateScaleIncrease)
	ON_COMMAND(ID_PROCESS_ALL, &CLSTDemoApp::OnProcessAll)
	ON_UPDATE_COMMAND_UI(ID_PROCESS_ALL, &CLSTDemoApp::OnUpdateProcessAll)
	ON_COMMAND(ID_PROCESS_ONE, &CLSTDemoApp::OnProcessOne)
	ON_UPDATE_COMMAND_UI(ID_PROCESS_ONE, &CLSTDemoApp::OnUpdateProcessOne)
	ON_COMMAND(ID_RESULT_BROWSE, &CLSTDemoApp::OnResultBrowse)
	ON_UPDATE_COMMAND_UI(ID_RESULT_BROWSE, &CLSTDemoApp::OnUpdateResultBrowse)
	ON_COMMAND(ID_RESULT_SAVE, &CLSTDemoApp::OnResultSave)
	ON_UPDATE_COMMAND_UI(ID_RESULT_SAVE, &CLSTDemoApp::OnUpdateResultSave)
	ON_UPDATE_COMMAND_UI(ID_MANUAL_DECREASE, &CLSTDemoApp::OnUpdateManualDecrease)
	ON_UPDATE_COMMAND_UI(ID_MANUAL_INCREASE, &CLSTDemoApp::OnUpdateManualIncrease)
	ON_UPDATE_COMMAND_UI(ID_MANUAL_MOVE, &CLSTDemoApp::OnUpdateManualMove)
	ON_UPDATE_COMMAND_UI(ID_MANUAL_PASTE, &CLSTDemoApp::OnUpdateManualPaste)
	ON_UPDATE_COMMAND_UI(ID_MANUAL_ROTATE, &CLSTDemoApp::OnUpdateManualRotate)
	ON_COMMAND(ID_MANUAL_DECREASE, &CLSTDemoApp::OnManualDecrease)
	ON_COMMAND(ID_MANUAL_INCREASE, &CLSTDemoApp::OnManualIncrease)
	ON_COMMAND(ID_MANUAL_MOVE, &CLSTDemoApp::OnManualMove)
	ON_COMMAND(ID_MANUAL_PASTE, &CLSTDemoApp::OnManualPaste)
	ON_COMMAND(ID_MANUAL_ROTATE, &CLSTDemoApp::OnManualRotate)
	ON_COMMAND(ID_NAVIGATION_HOME, &CLSTDemoApp::OnNavigationHome)
	ON_UPDATE_COMMAND_UI(ID_NAVIGATION_HOME, &CLSTDemoApp::OnUpdateNavigationHome)
	ON_COMMAND(ID_MODE_BROWSING, &CLSTDemoApp::OnModeBrowsing)
	ON_UPDATE_COMMAND_UI(ID_MODE_BROWSING, &CLSTDemoApp::OnUpdateModeBrowsing)
	ON_COMMAND(ID_MODE_MODELING, &CLSTDemoApp::OnModeModeling)
	ON_UPDATE_COMMAND_UI(ID_MODE_MODELING, &CLSTDemoApp::OnUpdateModeModeling)
	ON_COMMAND(ID_BROWSE_VOLUME, &CLSTDemoApp::OnBrowseVolume)
	ON_UPDATE_COMMAND_UI(ID_BROWSE_VOLUME, &CLSTDemoApp::OnUpdateBrowseVolume)
	ON_COMMAND(ID_VIEW_BROWSE, &CLSTDemoApp::OnViewBrowse)
	ON_UPDATE_COMMAND_UI(ID_VIEW_BROWSE, &CLSTDemoApp::OnUpdateViewBrowse)
	ON_COMMAND(ID_VIEW_NAVIGATION, &CLSTDemoApp::OnViewNavigation)
	ON_UPDATE_COMMAND_UI(ID_VIEW_NAVIGATION, &CLSTDemoApp::OnUpdateViewNavigation)
	ON_COMMAND(ID_DEPTH_ERASE, &CLSTDemoApp::OnDepthErase)
	ON_UPDATE_COMMAND_UI(ID_DEPTH_ERASE, &CLSTDemoApp::OnUpdateDepthErase)
	ON_COMMAND(ID_DEPTH_FACE, &CLSTDemoApp::OnDepthFace)
	ON_UPDATE_COMMAND_UI(ID_DEPTH_FACE, &CLSTDemoApp::OnUpdateDepthFace)
	ON_COMMAND(ID_DEPTH_INNERMOST, &CLSTDemoApp::OnDepthInnermost)
	ON_UPDATE_COMMAND_UI(ID_DEPTH_INNERMOST, &CLSTDemoApp::OnUpdateDepthInnermost)
	ON_COMMAND(ID_DEPTH_MIDDLE, &CLSTDemoApp::OnDepthMiddle)
	ON_UPDATE_COMMAND_UI(ID_DEPTH_MIDDLE, &CLSTDemoApp::OnUpdateDepthMiddle)
	ON_COMMAND(ID_DEPTH_MULTIFACE, &CLSTDemoApp::OnDepthMultiface)
	ON_UPDATE_COMMAND_UI(ID_DEPTH_MULTIFACE, &CLSTDemoApp::OnUpdateDepthMultiface)
	ON_COMMAND(ID_DEPTH_OUTERMOST, &CLSTDemoApp::OnDepthOutermost)
	ON_UPDATE_COMMAND_UI(ID_DEPTH_OUTERMOST, &CLSTDemoApp::OnUpdateDepthOutermost)
	ON_COMMAND(ID_DEPTH_STROKE, &CLSTDemoApp::OnDepthStroke)
	ON_UPDATE_COMMAND_UI(ID_DEPTH_STROKE, &CLSTDemoApp::OnUpdateDepthStroke)
	ON_COMMAND(ID_DEPTH_UPDATE, &CLSTDemoApp::OnDepthUpdate)
	ON_UPDATE_COMMAND_UI(ID_DEPTH_UPDATE, &CLSTDemoApp::OnUpdateDepthUpdate)
	ON_COMMAND(ID_VIEW_DEPTHPAINT, &CLSTDemoApp::OnViewDepthpaint)
	ON_UPDATE_COMMAND_UI(ID_VIEW_DEPTHPAINT, &CLSTDemoApp::OnUpdateViewDepthpaint)
	ON_COMMAND(ID_VIEW_MANUALPASTE, &CLSTDemoApp::OnViewManualpaste)
	ON_UPDATE_COMMAND_UI(ID_VIEW_MANUALPASTE, &CLSTDemoApp::OnUpdateViewManualpaste)
	ON_COMMAND(ID_VIEW_PROCESS, &CLSTDemoApp::OnViewProcess)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PROCESS, &CLSTDemoApp::OnUpdateViewProcess)
	ON_COMMAND(ID_VIEW_RESULT, &CLSTDemoApp::OnViewResult)
	ON_UPDATE_COMMAND_UI(ID_VIEW_RESULT, &CLSTDemoApp::OnUpdateViewResult)
	ON_COMMAND(ID_VIEW_SCALE, &CLSTDemoApp::OnViewScale)
	ON_UPDATE_COMMAND_UI(ID_VIEW_SCALE, &CLSTDemoApp::OnUpdateViewScale)
	ON_COMMAND(ID_PEEL_INNER, &CLSTDemoApp::OnPeelInner)
	ON_COMMAND(ID_PEEL_OUTER, &CLSTDemoApp::OnPeelOuter)
	ON_UPDATE_COMMAND_UI(ID_PEEL_INNER, &CLSTDemoApp::OnUpdatePeelInner)
	ON_UPDATE_COMMAND_UI(ID_PEEL_OUTER, &CLSTDemoApp::OnUpdatePeelOuter)
	ON_COMMAND(ID_VIEW_PEEL, &CLSTDemoApp::OnViewPeel)
	ON_UPDATE_COMMAND_UI(ID_VIEW_PEEL, &CLSTDemoApp::OnUpdateViewPeel)
	ON_COMMAND(ID_PROCESS_CANCEL, &CLSTDemoApp::OnProcessCancel)
	ON_UPDATE_COMMAND_UI(ID_PROCESS_CANCEL, &CLSTDemoApp::OnUpdateProcessCancel)
	ON_COMMAND(ID_LOADTEXTURE_COLOR, &CLSTDemoApp::OnLoadtextureColor)
	ON_UPDATE_COMMAND_UI(ID_LOADTEXTURE_COLOR, &CLSTDemoApp::OnUpdateLoadtextureColor)
	ON_COMMAND(ID_LOADTEXTURE_DISPLACEMENTMAP, &CLSTDemoApp::OnLoadtextureDisplacementmap)
	ON_UPDATE_COMMAND_UI(ID_LOADTEXTURE_DISPLACEMENTMAP, &CLSTDemoApp::OnUpdateLoadtextureDisplacementmap)
	ON_COMMAND(ID_BROWSE_DISPLACEMENTMAP, &CLSTDemoApp::OnBrowseDisplacementmap)
	ON_UPDATE_COMMAND_UI(ID_BROWSE_DISPLACEMENTMAP, &CLSTDemoApp::OnUpdateBrowseDisplacementmap)
	ON_COMMAND(ID_BROWSE_INFORMATION, &CLSTDemoApp::OnBrowseInformation)
	ON_UPDATE_COMMAND_UI(ID_BROWSE_INFORMATION, &CLSTDemoApp::OnUpdateBrowseInformation)
	ON_COMMAND(ID_BROWSE_CLEAR, &CLSTDemoApp::OnBrowseClear)
	ON_UPDATE_COMMAND_UI(ID_BROWSE_CLEAR, &CLSTDemoApp::OnUpdateBrowseClear)
	ON_COMMAND(ID_LOADTEXTURE_VOLUMERENDERING, &CLSTDemoApp::OnLoadtextureVolumerendering)
	ON_UPDATE_COMMAND_UI(ID_LOADTEXTURE_VOLUMERENDERING, &CLSTDemoApp::OnUpdateLoadtextureVolumerendering)
	ON_COMMAND(ID_BROWSE_SAVE, &CLSTDemoApp::OnBrowseSave)
	ON_UPDATE_COMMAND_UI(ID_BROWSE_SAVE, &CLSTDemoApp::OnUpdateBrowseSave)
	ON_COMMAND(ID_PROCESS_CLEAR, &CLSTDemoApp::OnProcessClear)
	ON_UPDATE_COMMAND_UI(ID_PROCESS_CLEAR, &CLSTDemoApp::OnUpdateProcessClear)
END_MESSAGE_MAP()


// CLSTDemoApp construction

CLSTDemoApp::CLSTDemoApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}


// The one and only CLSTDemoApp object

CLSTDemoApp theApp;


// CLSTDemoApp initialization

BOOL CLSTDemoApp::InitInstance()
{
	CWinApp::InitInstance();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	// of your final executable, you should remove from the following
	// the specific initialization routines you do not need
	// Change the registry key under which our settings are stored
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));
	LoadStdProfileSettings(0);  // Load standard INI file options (including MRU)
	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views
	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CLSTDemoDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CLSTDemoView));
	if (!pDocTemplate)
		return FALSE;
	AddDocTemplate(pDocTemplate);



	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);


	// Dispatch commands specified on the command line.  Will return FALSE if
	// app was launched with /RegServer, /Register, /Unregserver or /Unregister.
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();
	// call DragAcceptFiles only if there's a suffix
	//  In an SDI app, this should occur after ProcessShellCommand
	return TRUE;
}



// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	enum { IDD = IDD_ABOUTBOX };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

// Implementation
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

// App command to run the dialog
void CLSTDemoApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}


// CLSTDemoApp message handlers


void CLSTDemoApp::OnNavigationNext()
{
	Core& core = *Core::getInstance();
	State* p = core.m_state->next();
	if (p) {
		State* pOld = core.m_state;
		core.m_state = p;
		core.m_state->init();
		core.m_state->p_prev = pOld;
	}
	core.m_ogl.RedrawWindow();
}

void CLSTDemoApp::OnUpdateNavigationNext(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(Core::getInstance()->m_state->isReady());
}

void CLSTDemoApp::OnScaleSet()
{
	StateScale* p = (StateScale *)Core::getInstance()->m_state;
	p->set();
}

void CLSTDemoApp::OnUpdateScaleSet(CCmdUI *pCmdUI)
{
	Core& core = *Core::getInstance();
	pCmdUI->Enable(core.m_state == StateScale::getInstance() && !core.m_patch.empty());
}

void CLSTDemoApp::OnScaleDecrease()
{
	StateScale* p = (StateScale *)Core::getInstance()->m_state;
	p->decrease();
}

void CLSTDemoApp::OnUpdateScaleDecrease(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(Core::getInstance()->m_state == StateScale::getInstance());
}

void CLSTDemoApp::OnScaleIncrease()
{
	StateScale* p = (StateScale *)Core::getInstance()->m_state;
	p->increase();
}

void CLSTDemoApp::OnUpdateScaleIncrease(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(Core::getInstance()->m_state == StateScale::getInstance());
}

void CLSTDemoApp::OnProcessAll()
{
	StateProcess* p = StateProcess::getInstance();
	if (p->m_isProcessing) return;
	p->pasteAll();
}

void CLSTDemoApp::OnUpdateProcessAll(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(Core::getInstance()->m_state == StateProcess::getInstance() &&
		!StateProcess::getInstance()->m_uncovered.empty());
}

void CLSTDemoApp::OnProcessCancel() {
	if (!StateProcess::getInstance()->m_isProcessing) return;
	StateProcess::getInstance()->m_isCancelPressed = true;
}

void CLSTDemoApp::OnUpdateProcessCancel(CCmdUI *pCmdUI) {
	pCmdUI->Enable(Core::getInstance()->m_state == StateProcess::getInstance() &&
		!StateProcess::getInstance()->m_uncovered.empty());
}

void CLSTDemoApp::OnProcessOne()
{
	StateProcess* p = StateProcess::getInstance();
	if (p->m_isProcessing) return;
	p->pasteOne();
}

void CLSTDemoApp::OnUpdateProcessOne(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(Core::getInstance()->m_state == StateProcess::getInstance() &&
		!StateProcess::getInstance()->m_uncovered.empty());
}

void CLSTDemoApp::OnResultBrowse()
{
	StateResult* p = (StateResult *)Core::getInstance()->m_state;
	p->gotoBrowsing();
}

void CLSTDemoApp::OnUpdateResultBrowse(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(Core::getInstance()->m_state == StateResult::getInstance());
}

void CLSTDemoApp::OnResultSave()
{
	StateResult* p = (StateResult *)Core::getInstance()->m_state;
	p->save();
}

void CLSTDemoApp::OnUpdateResultSave(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(Core::getInstance()->m_state == StateResult::getInstance());
}

void CLSTDemoApp::OnUpdateManualDecrease(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(Core::getInstance()->m_state == StateManualPaste::getInstance());
}

void CLSTDemoApp::OnUpdateManualIncrease(CCmdUI *pCmdUI)
{
	pCmdUI->Enable(Core::getInstance()->m_state == StateManualPaste::getInstance());
}

void CLSTDemoApp::OnUpdateManualMove(CCmdUI *pCmdUI)
{
	bool b = Core::getInstance()->m_state == StateManualPaste::getInstance();
	pCmdUI->Enable(b);
	if (b) {
		StateManualPaste* p = (StateManualPaste *)Core::getInstance()->m_state;
		pCmdUI->SetCheck(!p->m_isRotateMode);
	}
}

void CLSTDemoApp::OnUpdateManualPaste(CCmdUI *pCmdUI)
{
	Core& core = *Core::getInstance();
	pCmdUI->Enable(core.m_state == StateManualPaste::getInstance() && !core.m_patch.empty());
}

void CLSTDemoApp::OnUpdateManualRotate(CCmdUI *pCmdUI)
{
	bool b = Core::getInstance()->m_state == StateManualPaste::getInstance();
	pCmdUI->Enable(b);
	if (b) {
		StateManualPaste* p = (StateManualPaste *)Core::getInstance()->m_state;
		pCmdUI->SetCheck(p->m_isRotateMode);
	}
}

void CLSTDemoApp::OnManualDecrease()
{
	StateManualPaste* p = (StateManualPaste *)Core::getInstance()->m_state;
	p->decrease();
}

void CLSTDemoApp::OnManualIncrease()
{
	StateManualPaste* p = (StateManualPaste *)Core::getInstance()->m_state;
	p->increase();
}

void CLSTDemoApp::OnManualMove()
{
	StateManualPaste* p = (StateManualPaste *)Core::getInstance()->m_state;
	p->m_isRotateMode = false;
}

void CLSTDemoApp::OnManualPaste()
{
	StateManualPaste* p = (StateManualPaste *)Core::getInstance()->m_state;
	p->paste();
}

void CLSTDemoApp::OnManualRotate()
{
	StateManualPaste* p = (StateManualPaste *)Core::getInstance()->m_state;
	p->m_isRotateMode = true;
}

void CLSTDemoApp::OnNavigationHome()
{
	Core& core = *Core::getInstance();
	core.m_state = StateLoadTetra::getInstance();
	core.m_state->init();
	core.m_ogl.RedrawWindow();
}

void CLSTDemoApp::OnUpdateNavigationHome(CCmdUI *pCmdUI)
{
	Core& core = *Core::getInstance();
	pCmdUI->Enable(core.m_state != StateLoadTetra::getInstance() &&
		core.m_state != StateBrowse::getInstance());
}

void CLSTDemoApp::OnModeBrowsing()
{
	Core& core = *Core::getInstance();
	if (core.m_state == StateBrowse::getInstance()) return;
	core.m_state = StateBrowse::getInstance();
	core.m_state->init();
	core.m_ogl.RedrawWindow();
}

void CLSTDemoApp::OnUpdateModeBrowsing(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(Core::getInstance()->m_state == StateBrowse::getInstance());
}

void CLSTDemoApp::OnModeModeling()
{
	Core& core = *Core::getInstance();
	if (core.m_state != StateBrowse::getInstance()) return;
	core.m_state = core.m_state->next();
	core.m_state->init();
	core.m_ogl.RedrawWindow();
}

void CLSTDemoApp::OnUpdateModeModeling(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(Core::getInstance()->m_state != StateBrowse::getInstance());
}

void CLSTDemoApp::OnBrowseVolume()
{
	StateBrowse* p = (StateBrowse *)StateBrowse::getInstance();
	p->doVolumeRendering();
	Core::getInstance()->m_ogl.RedrawWindow();
}

void CLSTDemoApp::OnUpdateBrowseVolume(CCmdUI *pCmdUI)
{
	Core& core = *Core::getInstance();
	pCmdUI->Enable(core.m_state == StateBrowse::getInstance() &&
		!core.m_tetraOrg.m_tetras.empty() &&
		core.m_polySlice.m_polygons.empty());
}


// Event handler for Depth Paint

void CLSTDemoApp::OnDepthMiddle() {
	StateDepthPaint* p = (StateDepthPaint *)Core::getInstance()->m_state;
	p->m_currentColor = StateDepthPaint::COLOR_MID;
}

void CLSTDemoApp::OnDepthOutermost() {
	StateDepthPaint* p = (StateDepthPaint *)Core::getInstance()->m_state;
	p->m_currentColor = StateDepthPaint::COLOR_OUT;
}

void CLSTDemoApp::OnDepthInnermost() {
	StateDepthPaint* p = (StateDepthPaint *)Core::getInstance()->m_state;
	p->m_currentColor = StateDepthPaint::COLOR_IN;
}

void CLSTDemoApp::OnUpdateDepthMiddle(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	if (core.m_state == StateDepthPaint::getInstance()) {
		pCmdUI->Enable(true);
		StateDepthPaint* p = (StateDepthPaint *)core.m_state;
		pCmdUI->SetCheck(p->m_currentColor == StateDepthPaint::COLOR_MID);
	} else
		pCmdUI->Enable(false);
}

void CLSTDemoApp::OnUpdateDepthOutermost(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	if (core.m_state == StateDepthPaint::getInstance()) {
		pCmdUI->Enable(true);
		StateDepthPaint* p = (StateDepthPaint *)core.m_state;
		pCmdUI->SetCheck(p->m_currentColor == StateDepthPaint::COLOR_OUT);
	} else
		pCmdUI->Enable(false);
}

void CLSTDemoApp::OnUpdateDepthInnermost(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	if (core.m_state == StateDepthPaint::getInstance()) {
		pCmdUI->Enable(true);
		StateDepthPaint* p = (StateDepthPaint *)core.m_state;
		pCmdUI->SetCheck(p->m_currentColor == StateDepthPaint::COLOR_IN);
	} else
		pCmdUI->Enable(false);
}

void CLSTDemoApp::OnDepthErase() {
	StateDepthPaint* p = (StateDepthPaint *)Core::getInstance()->m_state;
	p->m_currentColor = StateDepthPaint::COLOR_ERASE;
}

void CLSTDemoApp::OnUpdateDepthErase(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	if (core.m_state == StateDepthPaint::getInstance()) {
		StateDepthPaint* p = (StateDepthPaint *)core.m_state;
		if (p->m_currentTool == StateDepthPaint::TOOL_STROKE)
			pCmdUI->Enable(false);
		else {
			pCmdUI->Enable(true);
			pCmdUI->SetCheck(p->m_currentColor == StateDepthPaint::COLOR_ERASE);
		}
	} else
		pCmdUI->Enable(false);
}

void CLSTDemoApp::OnDepthFace() {
	StateDepthPaint* p = (StateDepthPaint *)Core::getInstance()->m_state;
	p->m_currentTool = StateDepthPaint::TOOL_FACE;
}

void CLSTDemoApp::OnDepthMultiface() {
	StateDepthPaint* p = (StateDepthPaint *)Core::getInstance()->m_state;
	p->m_currentTool = StateDepthPaint::TOOL_MULTIFACE;
}

void CLSTDemoApp::OnUpdateDepthFace(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	if (core.m_state == StateDepthPaint::getInstance()) {
		pCmdUI->Enable(true);
		StateDepthPaint* p = (StateDepthPaint *)core.m_state;
		pCmdUI->SetCheck(p->m_currentTool == StateDepthPaint::TOOL_FACE);
	} else
		pCmdUI->Enable(false);
}

void CLSTDemoApp::OnUpdateDepthMultiface(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	if (core.m_state == StateDepthPaint::getInstance()) {
		pCmdUI->Enable(true);
		StateDepthPaint* p = (StateDepthPaint *)core.m_state;
		pCmdUI->SetCheck(p->m_currentTool == StateDepthPaint::TOOL_MULTIFACE);
	} else
		pCmdUI->Enable(false);
}

void CLSTDemoApp::OnDepthStroke() {
	StateDepthPaint* p = (StateDepthPaint *)Core::getInstance()->m_state;
	p->m_currentTool = StateDepthPaint::TOOL_STROKE;
}

void CLSTDemoApp::OnUpdateDepthStroke(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	if (core.m_state == StateDepthPaint::getInstance()) {
		StateDepthPaint* p = (StateDepthPaint *)core.m_state;
		if (p->m_currentColor == StateDepthPaint::COLOR_ERASE)
			pCmdUI->Enable(false);
		else {
			pCmdUI->Enable(true);
			pCmdUI->SetCheck(p->m_currentTool == StateDepthPaint::TOOL_STROKE);
		}
	} else
		pCmdUI->Enable(false);
}

void CLSTDemoApp::OnDepthUpdate() {
	Core& core = *Core::getInstance();
	StateDepthPaint* p = (StateDepthPaint *)core.m_state;
	p->update();
	core.m_ogl.RedrawWindow();
}

void CLSTDemoApp::OnUpdateDepthUpdate(CCmdUI *pCmdUI) {
	pCmdUI->Enable(Core::getInstance()->m_state == StateDepthPaint::getInstance());
}


// Event handler for toolbar show/hide

void CLSTDemoApp::OnViewBrowse()
{
	CMainFrame& f = *Core::getInstance()->p_mainFrm;
	bool b = f.m_wndToolBar_browse.IsWindowVisible() == TRUE;
	f.ShowControlBar(&f.m_wndToolBar_browse, !b, true);
}

void CLSTDemoApp::OnUpdateViewBrowse(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(Core::getInstance()->p_mainFrm->m_wndToolBar_browse.IsWindowVisible());
}

void CLSTDemoApp::OnViewNavigation()
{
	CMainFrame& f = *Core::getInstance()->p_mainFrm;
	bool b = f.m_wndToolBar_navigate.IsWindowVisible() == TRUE;
	f.ShowControlBar(&f.m_wndToolBar_navigate, !b, true);
}

void CLSTDemoApp::OnUpdateViewNavigation(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(Core::getInstance()->p_mainFrm->m_wndToolBar_navigate.IsWindowVisible());
}

void CLSTDemoApp::OnViewDepthpaint()
{
	CMainFrame& f = *Core::getInstance()->p_mainFrm;
	bool b = f.m_wndToolBar_depthPaint.IsWindowVisible() == TRUE;
	f.ShowControlBar(&f.m_wndToolBar_depthPaint, !b, true);
}

void CLSTDemoApp::OnUpdateViewDepthpaint(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(Core::getInstance()->p_mainFrm->m_wndToolBar_depthPaint.IsWindowVisible());
}

void CLSTDemoApp::OnViewManualpaste()
{
	CMainFrame& f = *Core::getInstance()->p_mainFrm;
	bool b = f.m_wndToolBar_manualPaste.IsWindowVisible() == TRUE;
	f.ShowControlBar(&f.m_wndToolBar_manualPaste, !b, true);
}

void CLSTDemoApp::OnUpdateViewManualpaste(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(Core::getInstance()->p_mainFrm->m_wndToolBar_manualPaste.IsWindowVisible());
}

void CLSTDemoApp::OnViewProcess()
{
	CMainFrame& f = *Core::getInstance()->p_mainFrm;
	bool b = f.m_wndToolBar_process.IsWindowVisible() == TRUE;
	f.ShowControlBar(&f.m_wndToolBar_process, !b, true);
}

void CLSTDemoApp::OnUpdateViewProcess(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(Core::getInstance()->p_mainFrm->m_wndToolBar_process.IsWindowVisible());
}

void CLSTDemoApp::OnViewResult()
{
	CMainFrame& f = *Core::getInstance()->p_mainFrm;
	bool b = f.m_wndToolBar_result.IsWindowVisible() == TRUE;
	f.ShowControlBar(&f.m_wndToolBar_result, !b, true);
}

void CLSTDemoApp::OnUpdateViewResult(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(Core::getInstance()->p_mainFrm->m_wndToolBar_result.IsWindowVisible());
}

void CLSTDemoApp::OnViewScale()
{
	CMainFrame& f = *Core::getInstance()->p_mainFrm;
	bool b = f.m_wndToolBar_scale.IsWindowVisible() == TRUE;
	f.ShowControlBar(&f.m_wndToolBar_scale, !b, true);
}

void CLSTDemoApp::OnUpdateViewScale(CCmdUI *pCmdUI)
{
	pCmdUI->SetCheck(Core::getInstance()->p_mainFrm->m_wndToolBar_scale.IsWindowVisible());
}

void CLSTDemoApp::OnViewPeel() {
	CMainFrame& f = *Core::getInstance()->p_mainFrm;
	bool b = f.m_wndToolBar_peelStroke.IsWindowVisible() == TRUE;
	f.ShowControlBar(&f.m_wndToolBar_peelStroke, !b, true);
}

void CLSTDemoApp::OnUpdateViewPeel(CCmdUI *pCmdUI) {
	pCmdUI->SetCheck(Core::getInstance()->p_mainFrm->m_wndToolBar_peelStroke.IsWindowVisible());
}



// Handler for peeling ui
void CLSTDemoApp::OnPeelInner() {
	StatePeelStroke::getInstance()->goInner();
}

void CLSTDemoApp::OnPeelOuter() {
	StatePeelStroke::getInstance()->goOuter();
}

void CLSTDemoApp::OnUpdatePeelInner(CCmdUI *pCmdUI) {
	pCmdUI->Enable(Core::getInstance()->m_state == StatePeelStroke::getInstance() &&
		StatePeelStroke::getInstance()->m_currentLayer < Core::LAYER_MAX);
}

void CLSTDemoApp::OnUpdatePeelOuter(CCmdUI *pCmdUI) {
	pCmdUI->Enable(Core::getInstance()->m_state == StatePeelStroke::getInstance() &&
		StatePeelStroke::getInstance()->m_currentLayer > 0);
}


void CLSTDemoApp::OnLoadtextureColor() {
	if (Core::getInstance()->m_state == StateLoadSolid::getInstance()) {
		StateLoadSolid::getInstance()->m_mode = StateLoadSolid::MODE_COLOR;
		Core::getInstance()->m_ogl.RedrawWindow();
	} else {
		StateLoadSolidMP::getInstance()->m_mode = StateLoadSolidMP::MODE_COLOR;
		Core::getInstance()->m_ogl.RedrawWindow();
	}
}

void CLSTDemoApp::OnUpdateLoadtextureColor(CCmdUI *pCmdUI) {
	if (Core::getInstance()->m_state == StateLoadSolid::getInstance()) {
		StateLoadSolid* state = StateLoadSolid::getInstance();
		pCmdUI->Enable(true);
		pCmdUI->SetCheck(state->m_mode == StateLoadSolid::MODE_COLOR);
	} else if (Core::getInstance()->m_state == StateLoadSolidMP::getInstance()) {
		StateLoadSolidMP* state = StateLoadSolidMP::getInstance();
		pCmdUI->Enable(true);
		pCmdUI->SetCheck(state->m_mode == StateLoadSolidMP::MODE_COLOR);
	} else {
		pCmdUI->Enable(false);
	}
}

void CLSTDemoApp::OnLoadtextureDisplacementmap() {
	if (Core::getInstance()->m_state == StateLoadSolid::getInstance()) {
		StateLoadSolid::getInstance()->m_mode = StateLoadSolid::MODE_DISPLACEMENT;
		Core::getInstance()->m_ogl.RedrawWindow();
	} else {
		StateLoadSolidMP::getInstance()->m_mode = StateLoadSolidMP::MODE_DISPLACEMENT;
		Core::getInstance()->m_ogl.RedrawWindow();
	}
}

void CLSTDemoApp::OnUpdateLoadtextureDisplacementmap(CCmdUI *pCmdUI) {
	if (Core::getInstance()->m_state == StateLoadSolid::getInstance()) {
		StateLoadSolid* state = StateLoadSolid::getInstance();
		pCmdUI->Enable(true);
		pCmdUI->SetCheck(state->m_mode == StateLoadSolid::MODE_DISPLACEMENT);
	} else if (Core::getInstance()->m_state == StateLoadSolidMP::getInstance()) {
		StateLoadSolidMP* state = StateLoadSolidMP::getInstance();
		pCmdUI->Enable(!Core::getInstance()->m_volInputDisp.empty());
		pCmdUI->SetCheck(state->m_mode == StateLoadSolidMP::MODE_DISPLACEMENT);
	} else {
		pCmdUI->Enable(false);
	}
}

void CLSTDemoApp::OnBrowseDisplacementmap() {
	StateBrowse::getInstance()->doDisplacementMap();
	Core::getInstance()->m_ogl.RedrawWindow();
}

void CLSTDemoApp::OnUpdateBrowseDisplacementmap(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	pCmdUI->Enable(core.m_state == StateBrowse::getInstance() &&
		!core.m_volBrowseDisp.empty());
}

void CLSTDemoApp::OnBrowseInformation() {
	StateBrowse::getInstance()->showInformation();
}

void CLSTDemoApp::OnUpdateBrowseInformation(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	pCmdUI->Enable(core.m_state == StateBrowse::getInstance() &&
		!core.m_tetraOrg.m_tetras.empty());
}

void CLSTDemoApp::OnBrowseClear() {
	StateBrowse::getInstance()->clear();
	Core::getInstance()->m_ogl.RedrawWindow();
}

void CLSTDemoApp::OnUpdateBrowseClear(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	pCmdUI->Enable(core.m_state == StateBrowse::getInstance() &&
		!core.m_tetraOrg.m_tetras.empty());
}

void CLSTDemoApp::OnLoadtextureVolumerendering() {
	Core& core = *Core::getInstance();
	if (core.m_state == StateLoadSolid::getInstance()) {
		StateLoadSolid& p = *StateLoadSolid::getInstance();
		bool& b = p.m_isVolumeRendering;
		b = !b;
		if (b) {
			p.updateTetraCut();
			core.updatePolySlice(core.m_tetraCut);
		} else {
			p.updatePolyCut();
		}
		core.m_ogl.RedrawWindow();
	} else if (core.m_state == StateLoadSolidMP::getInstance()) {
		StateLoadSolidMP& p = *StateLoadSolidMP::getInstance();
		bool& b = p.m_isVolumeRendering;
		b = !b;
		if (b) {
			p.updateTetraCut();
			core.updatePolySlice(core.m_tetraCut);
		} else {
			p.updatePolyCut();
		}
		core.m_ogl.RedrawWindow();
	}

}

void CLSTDemoApp::OnUpdateLoadtextureVolumerendering(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	if (core.m_state == StateLoadSolid::getInstance()) {
		pCmdUI->Enable(true);
		pCmdUI->SetCheck(StateLoadSolid::getInstance()->m_isVolumeRendering);
	} else if(core.m_state == StateLoadSolidMP::getInstance()) {
		pCmdUI->Enable(true);
		pCmdUI->SetCheck(StateLoadSolidMP::getInstance()->m_isVolumeRendering);
	} else {
		pCmdUI->Enable(false);
	}
}

void CLSTDemoApp::OnBrowseSave() {
	StateBrowse::getInstance()->save();
}

void CLSTDemoApp::OnUpdateBrowseSave(CCmdUI *pCmdUI) {
	Core& core = *Core::getInstance();
	pCmdUI->Enable(core.m_state == StateBrowse::getInstance() &&
		!core.m_tetraOrg.m_tetras.empty());
}

void CLSTDemoApp::OnProcessClear() {
	StateProcess::getInstance()->clear();
	Core::getInstance()->m_ogl.RedrawWindow();
}

void CLSTDemoApp::OnUpdateProcessClear(CCmdUI *pCmdUI) {
	pCmdUI->Enable(Core::getInstance()->m_state == StateProcess::getInstance());
}
