// DlgVR.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "LSTDemo.h"
#include "DlgVR.h"


// DlgVR �_�C�A���O

IMPLEMENT_DYNAMIC(DlgVR, CDialog)

DlgVR::DlgVR(CWnd* pParent /*=NULL*/)
	: CDialog(DlgVR::IDD, pParent)
	, m_numSlice(0)
{

}

DlgVR::~DlgVR()
{
}

void DlgVR::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_NUMSLICE, m_numSlice);
	DDV_MinMaxInt(pDX, m_numSlice, 1, 1000000);
}


BEGIN_MESSAGE_MAP(DlgVR, CDialog)
END_MESSAGE_MAP()


// DlgVR ���b�Z�[�W �n���h��
