#pragma once

#include <vector>
#include <gl/glew.h>
#include <gl/wglew.h>

class Drawer {
public:
	static const double COLOR_EDGE      [3];
	static const double COLOR_FACE      [3];
	static const double COLOR_CUTSTROKE [3];
	static const double COLOR_STROKE    [3];
	
	bool m_isDrawEdge;
	bool m_isDrawFace;
	bool m_isDrawAxis;
	bool m_isDrawPatch;

	GLuint m_texNameInput;
	GLuint m_texNameMiddle;
	GLuint m_texNameInner;
	GLuint m_texNameOuter;
	std::vector<GLuint> m_texNameManual;
	std::vector<GLuint> m_texNameBrowse;
	
	GLuint m_texNameDisp;
	
	GLuint m_texNameDepth;
	
	Drawer(void);
	~Drawer(void) {}
	void draw();
	void init();
	void genTexInput();
	void delTexInput();
	void genTexMiddle();
	void genTexInner();
	void genTexOuter();
	void genTexManual();
	void genTexBrowse();
	void delTexBrowse();
	void genTexDepth();
	void genTexDisp(const std::vector<GLubyte>& volDisp);
	void postDraw(CWnd* hWnd, CDC* pDC);
	static int FUTL_LoadShader(char *vtxShdName, char *frgShdName, GLuint *lpProg);
	static int FUTL_MakeShader(const char *vtxShdCode, const char *frgShdCode, GLuint *lpProg);
protected:
	void genTexture(GLuint* texName, GLubyte* data, bool hasAlpha = true);
	static int loadShader(GLuint shader, char *name);
	static int makeShader(GLuint shader, const char *code);
	static void printShaderInfoLog(GLuint shader);
	static void printProgramInfoLog(GLuint program);
};
