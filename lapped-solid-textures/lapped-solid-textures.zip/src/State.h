#pragma once

class State
{
protected:
	State(void) {}
	~State(void) {}
public:
	virtual State* next() = 0;
	virtual bool isReady() = 0;
	virtual void init() = 0;
	virtual void draw() = 0;
	virtual void postDraw(CWnd* hWnd, CDC* pDC) = 0;
	virtual void OnLButtonDown(CView* view, UINT nFlags, CPoint& point) = 0;
	virtual void OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) = 0;
	virtual void OnRButtonDown(CView* view, UINT nFlags, CPoint& point) = 0;
	virtual void OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) = 0;
	virtual void OnMouseMove  (CView* view, UINT nFlags, CPoint& point) = 0;
	virtual void OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) = 0;
	virtual void OnDropFiles  (CView* view, HDROP hDropInfo) = 0;
	virtual void OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt) = 0;
	virtual void OnLButtonDblClk(CView* view, UINT nFlags, CPoint point) = 0;
	State* p_prev;
};
