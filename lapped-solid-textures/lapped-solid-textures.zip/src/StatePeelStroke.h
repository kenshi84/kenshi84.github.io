#pragma once
#include "state.h"
#include "Core.h"

#include <vector>

class StatePeelStroke : public State {
	StatePeelStroke(void);
	~StatePeelStroke(void) {}
public:
	static StatePeelStroke* getInstance() {
		static StatePeelStroke p;
		return &p;
	}
	State* next();
	bool isReady();
	void init();
	void draw();
	void postDraw(CWnd* hWnd, CDC* pDC);
	void OnLButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnLButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnRButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnRButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnMouseMove  (CView* view, UINT nFlags, CPoint& point);
	void OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags);
	void OnDropFiles  (CView* view, HDROP hDropInfo) {}
	void OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt);
	void OnLButtonDblClk(CView* view, UINT nFlags, CPoint point) {}
	
	void goInner();
	void goOuter();
	
	GLuint m_shaderProg;
	int m_currentLayer;
protected:
	bool m_isRButtonDown;
	bool m_isDrawing;
	CPoint m_pointOld;
};
