// DlgInformation.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "LSTDemo.h"
#include "DlgInformation.h"


// DlgInformation �_�C�A���O

IMPLEMENT_DYNAMIC(DlgInformation, CDialog)

DlgInformation::DlgInformation(CWnd* pParent /*=NULL*/)
	: CDialog(DlgInformation::IDD, pParent)
	, m_numTetra(_T(""))
	, m_numVtx(_T(""))
	, m_maxLap(_T(""))
	, m_minLap(_T(""))
	, m_avgLap(_T(""))
	, m_numTexture(_T(""))
	, m_hasDisp(_T(""))
	, m_numFace(_T(""))
{

}

DlgInformation::~DlgInformation()
{
}

void DlgInformation::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_STATIC_NUMTETRA, m_numTetra);
	DDX_Text(pDX, IDC_STATIC_NUMVTX, m_numVtx);
	DDX_Text(pDX, IDC_STATIC_MAXLAP, m_maxLap);
	DDX_Text(pDX, IDC_STATIC_MINLAP, m_minLap);
	DDX_Text(pDX, IDC_STATIC_AVGLAP, m_avgLap);
	DDX_Text(pDX, IDC_STATIC_NUMTEXTURE, m_numTexture);
	DDX_Text(pDX, IDC_STATIC_HASDISP, m_hasDisp);
	DDX_Text(pDX, IDC_STATIC_NUMFACE, m_numFace);
}


BEGIN_MESSAGE_MAP(DlgInformation, CDialog)
END_MESSAGE_MAP()


// DlgInformation ���b�Z�[�W �n���h��
