#pragma once
#include "state.h"
#include <KLIB/KMath.h>
#include "Core.h"
#include <vector>
#include <list>
#include <map>

class StateProcess : public State {
	StateProcess(void) {}
	~StateProcess(void) {}
public:
	static StateProcess* getInstance() {
		static StateProcess p;
		return &p;
	}
	State* next();
	bool isReady();
	void init();
	void draw();
	void postDraw(CWnd* hWnd, CDC* pDC);
	void OnLButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnLButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnRButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnRButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnMouseMove  (CView* view, UINT nFlags, CPoint& point);
	void OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {}
	void OnDropFiles  (CView* view, HDROP hDropInfo);
	void OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt) {}
	void OnLButtonDblClk(CView* view, UINT nFlags, CPoint point) {}
	
	void pasteOne();
	void pasteAll();
	void clear();
	
	bool m_isCancelPressed;
	bool m_isProcessing;
	std::list<int> m_uncovered;
protected:
	bool m_isRButtonDown;
	bool m_isCutting;
	CPoint m_pointOld;
	int m_seedIndex;
	void initUncovered();
	int m_selectedTetID;
	std::vector<int> m_seedTemp;
	int m_tetID_showTensor;
	KVector3d m_eyePoint;
	KVector3d m_focusPoint;
	KVector3d m_upDirection;
};
