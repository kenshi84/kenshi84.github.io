#include "StdAfx.h"
#include "Drawer.h"

#include "Core.h"
#include <KLIB/KDrawer.h>
#include <KLIB/KUtil.h>

#include <vector>

#define MAX_SHADER_LOG_SIZE		(1024)
char s_logBuffer[MAX_SHADER_LOG_SIZE]; 

using namespace std;

const double Drawer::COLOR_EDGE      [3] = {0.5, 0.5, 0.5};
const double Drawer::COLOR_FACE      [3] = {1, 1, 1};
const double Drawer::COLOR_CUTSTROKE [3] = {1, 0, 0};
const double Drawer::COLOR_STROKE    [3] = {1, 0.75, 0};

Drawer::Drawer(void) :
m_isDrawEdge(false),
m_isDrawFace(true),
m_isDrawAxis(false) {
}

void Drawer::init() {
	Core& core = *Core::getInstance();
	core.m_ogl.m_clearColor[0] = core.m_ogl.m_clearColor[1] = core.m_ogl.m_clearColor[2] = core.m_ogl.m_clearColor[3] = 1.0f;
	core.m_ogl.makeOpenGLCurrent();
	
	GLenum err = glewInit();
	if (err != GLEW_OK) {
		fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
	}
	
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glEnable(GL_COLOR_MATERIAL);
	glColorMaterial(GL_FRONT, GL_DIFFUSE);
	glColorMaterial(GL_FRONT, GL_AMBIENT);
	glEnable(GL_LIGHTING);
	GLfloat amb = 0.2f;
	GLfloat dif = 0.2f;
	GLfloat ambv[] = { amb, amb, amb, 1};
	GLfloat difv[] = { dif, dif, dif, 1};
	GLfloat posv[] = { 1, 1, 1};
	glLightfv(GL_LIGHT0, GL_AMBIENT, ambv);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, difv);
	glLightfv(GL_LIGHT0, GL_POSITION, posv);
	glEnable(GL_LIGHT0);
	glDepthFunc(GL_LEQUAL);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
}

void Drawer::genTexDisp(const vector<GLubyte>& volDisp) {
	vector<GLubyte> data((int)volDisp.size() * 3);
	for (int i = 0; i < (int)volDisp.size(); ++i) {
		data[3 * i] = data[3 * i + 1] = data[3 * i + 2] = volDisp[i];
	}
	genTexture(&m_texNameDisp, &data[0], false);
}

void Drawer::genTexInput() {
	Core& core = *Core::getInstance();
	genTexture(&m_texNameInput, &core.m_volInput[0], core.m_numChannels == 4);
}

void Drawer::delTexInput() {
	glDeleteTextures(1, &m_texNameInput);
}

void Drawer::genTexMiddle() {
	genTexture(&m_texNameMiddle, &Core::getInstance()->m_volMiddle[0]);
}

void Drawer::genTexInner() {
	genTexture(&m_texNameInner, &Core::getInstance()->m_volInner[0]);
}

void Drawer::genTexOuter() {
	genTexture(&m_texNameOuter, &Core::getInstance()->m_volOuter[0]);
}

void Drawer::genTexManual() {
	genTexture(&m_texNameManual.back(), &Core::getInstance()->m_volManual.back()[0]);
}

void Drawer::genTexBrowse() {
	Core& core = *Core::getInstance();
	m_texNameBrowse.resize(core.m_volBrowse.size());
	for (int i = 0; i < (int)m_texNameBrowse.size(); ++i)
		genTexture(&m_texNameBrowse[i], &core.m_volBrowse[i][0]);
}

void Drawer::delTexBrowse() {
	for (int i = 0; i < (int)m_texNameBrowse.size(); ++i)
		glDeleteTextures(1, &m_texNameBrowse[i]);
}

void Drawer::genTexDepth() {
	int texSize = 128;
	int texSize_2 = texSize / 2;
	vector<GLubyte> data(texSize * 3);
	for (int i = 0; i < texSize; ++i) {
		int r = 512 - 1024 * i / texSize;
		int g = 512 - 512 * abs(i - texSize_2) / texSize_2;
		int b = -512 + 1024 * i / texSize;
		//int r = 255 * i / texSize;
		//int g = 255 * i / texSize;
		//int b = 255 * i / texSize;
		GLubyte r_ = (GLubyte)max(min(r, 255), 0);
		GLubyte g_ = (GLubyte)max(min(g, 255), 0);
		GLubyte b_ = (GLubyte)max(min(b, 255), 0);
		data[3 * i]     = r_;
		data[3 * i + 1] = g_;
		data[3 * i + 2] = b_;
	}
	Core& core = *Core::getInstance();
	core.m_ogl.makeOpenGLCurrent();
	glGenTextures(1, &m_texNameDepth);
	glBindTexture(GL_TEXTURE_1D, m_texNameDepth);
	glTexImage1D(GL_TEXTURE_1D, 0, GL_RGB, texSize, 0, GL_RGB, GL_UNSIGNED_BYTE, &data[0]);
	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
	glTexParameteri(GL_TEXTURE_1D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
}

void Drawer::genTexture(GLuint* texName, GLubyte* data, bool hasAlpha) {
	Core& core = *Core::getInstance();
	core.m_ogl.makeOpenGLCurrent();
	glGenTextures(1, texName);
	glBindTexture(GL_TEXTURE_3D, *texName);
	GLint components = hasAlpha ? GL_RGBA : GL_RGB;
	glTexImage3D(GL_TEXTURE_3D, 0, components, Core::VOLSIZE, Core::VOLSIZE, Core::VOLSIZE, 0, components, GL_UNSIGNED_BYTE, data);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameteri(GL_TEXTURE_3D, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
	glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
}

void Drawer::draw() {
	Core::getInstance()->m_state->draw();
}

void Drawer::postDraw(CWnd* hWnd, CDC* pDC) {
	Core::getInstance()->m_state->postDraw(hWnd, pDC);
}

int Drawer::FUTL_LoadShader(
	char *vtxShdName,
	char *frgShdName,
	GLuint *lpProg
)
{
	GLuint vtxShader;
	GLuint frgShader;
	GLuint prog;
	GLint linked;

	vtxShader = glCreateShader(GL_VERTEX_SHADER);
	frgShader = glCreateShader(GL_FRAGMENT_SHADER);

	if (loadShader(vtxShader, vtxShdName) < 0)
	{
		return -1;
	}

	if (loadShader(frgShader, frgShdName) < 0)
	{
		return -1;
	}

	prog = glCreateProgram();

	glAttachShader(prog, vtxShader);
	glAttachShader(prog, frgShader);

	glDeleteShader(vtxShader);
	glDeleteShader(frgShader);

	glLinkProgram(prog);
	glGetProgramiv(prog, GL_LINK_STATUS, &linked);
	printProgramInfoLog(prog);
	if (linked == GL_FALSE)
	{
		fprintf(stderr, "Link error of %s & %s!!\n", vtxShdName, frgShdName);
		return -1;
	}

	*lpProg = prog;

	return 0;
}

int Drawer::FUTL_MakeShader(
	const char *vtxShdCode,
	const char *frgShdCode,
	GLuint *lpProg
)
{
	GLuint vtxShader;
	GLuint frgShader;
	GLuint prog;
	GLint linked;

	vtxShader = glCreateShader(GL_VERTEX_SHADER);
	frgShader = glCreateShader(GL_FRAGMENT_SHADER);

	if (makeShader(vtxShader, vtxShdCode) < 0)
	{
		return -1;
	}

	if (makeShader(frgShader, frgShdCode) < 0)
	{
		return -1;
	}

	prog = glCreateProgram();

	glAttachShader(prog, vtxShader);
	glAttachShader(prog, frgShader);

	glDeleteShader(vtxShader);
	glDeleteShader(frgShader);

	glLinkProgram(prog);
	glGetProgramiv(prog, GL_LINK_STATUS, &linked);
	printProgramInfoLog(prog);
	if (linked == GL_FALSE)
	{
		fprintf(stderr, "Link error of %s & %s!!\n", vtxShdCode, frgShdCode);
		return -1;
	}

	*lpProg = prog;

	return 0;
}

int Drawer::loadShader(
	GLuint shader, 
	char *name
)
{
	errno_t err;
	FILE *fp;
	void *buf;
	int size;
	GLint compiled;

	if ((err = fopen_s(&fp, name, "rb")) != 0)
	{
		fprintf(stderr, "%s is not found!!\n", name);
		return -1;
	}
  
	fseek(fp, 0, SEEK_END);
	size = ftell(fp);

	if ((buf = (void *)malloc(size)) == NULL)
	{
		fprintf(stderr, "Memory is not enough for %s\n", name);
		fclose(fp);
		return -1;
	}
  
	fseek(fp, 0, SEEK_SET);
	fread(buf, 1, size, fp);

	glShaderSource(shader, 1, (const GLchar **)&buf, &size);
  
	free(buf);
	fclose(fp);

	glCompileShader(shader);
	glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
	printShaderInfoLog(shader);
	if (compiled == GL_FALSE)
	{
		fprintf(stderr, "Compile error in %s!!\n", name);
		return -1;
	}

	return 0;
}

int Drawer::makeShader(
	GLuint shader, 
	const char *code
)
{
	int size = (int)strlen(code);
	glShaderSource(shader, 1, (const GLchar **)&code, &size);

	GLint compiled;
	glCompileShader(shader);
	glGetShaderiv(shader, GL_COMPILE_STATUS, &compiled);
	printShaderInfoLog(shader);
	if (compiled == GL_FALSE)
	{
		fprintf(stderr, "Compile error in %s!!\n", code);
		return -1;
	}

	return 0;
}

void Drawer::printShaderInfoLog(
	GLuint shader
)
{
	int logSize;
	int length;

	glGetShaderiv(shader, GL_INFO_LOG_LENGTH , &logSize);

	if (logSize > 1)
	{
		glGetShaderInfoLog(shader, MAX_SHADER_LOG_SIZE, &length, s_logBuffer);
		fprintf(stderr, "Shader Info Log\n%s\n", s_logBuffer);
	}
}


void Drawer::printProgramInfoLog(
	GLuint program
)
{
	int logSize;
	int length;

	glGetProgramiv(program, GL_INFO_LOG_LENGTH , &logSize);

	if (logSize > 1)
	{
		glGetProgramInfoLog(program, MAX_SHADER_LOG_SIZE, &length, s_logBuffer);
		fprintf(stderr, "Program Info Log\n%s\n", s_logBuffer);
	}
}
