#pragma once

#include "KMultiTexGeometry.h"

#include <vector>

class KFaceSubdivision
{
	KFaceSubdivision(void);
	~KFaceSubdivision(void);
public:
	static KMultiTexPolygonModel go(const KMultiTexPolygonModel& poly);
protected:
	static KMultiTexPolygon makePolygon(
		int vtx0, int vtx1, int vtx2,
		const std::vector<KVector3d>& texCoordsForVtx0,
		const std::vector<KVector3d>& texCoordsForVtx1,
		const std::vector<KVector3d>& texCoordsForVtx2,
		const std::vector<int>& texIDs);
};
