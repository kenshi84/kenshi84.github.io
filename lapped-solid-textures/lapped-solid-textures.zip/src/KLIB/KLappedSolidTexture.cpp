#include "StdAfx.h"
#include "KLappedSolidTexture.h"

#include "KUtil.h"
#include "KUmfpack.h"
#include "KUmfpackSparseMatrix.h"

#include <iostream>
#include <algorithm>

using namespace std;

KMatrix4d g_affine;

KLappedSolidTexture::KLappedSolidTexture()
: m_gradDelta(0.005)
, m_samplingDiv(16)
{
	initTable();
}

void KLappedSolidTexture::initTable() {
	const int& M = m_samplingDiv;
	m_tableDivNum2AccID.clear();
	m_tableDivNum2AccID.resize((M + 1) * (M + 1) * (M + 1), -1);
	int sum = 0;
	for (int i0 = 0; i0 <= M; ++i0) {
		for (int i1 = 0; i1 <= M - i0; ++i1) {
			for (int i2 = 0; i2 <= M - i0 - i1; ++i2) {
				int index = (M + 1) * (M + 1) * i0 + (M + 1) * i1 + i2;
				m_tableDivNum2AccID[index] = sum;
				++sum;
			}
		}
	}
}

int KLappedSolidTexture::getAccID(int i0, int i1, int i2) const {
	const int& M = m_samplingDiv;
	return m_tableDivNum2AccID[(M + 1) * (M + 1) * i0 + (M + 1) * i1 + i2];
}

void KLappedSolidTexture::clearCoverAcc() {
	int accSize = (m_samplingDiv + 1) * (m_samplingDiv + 2) * (m_samplingDiv + 3) / 6;
	m_tetCoverAcc.clear();
	m_tetCoverAcc.resize(m_tetra.m_tetras.size(), vector<int>(accSize, 0));
}

void KLappedSolidTexture::setField(
	const std::vector<KVector3d>& tetVectorS,	// primary axis
	const std::vector<KVector3d>& tetVectorT,	// secondary axis
	//const std::vector<double>& vtxDepth,		// 0:outermost, 1:innermost
	const KThinPlate3D& rbfDepth,				// 0:outermost, 1:innermost
	const std::vector<double>& tetScale
) {
	m_tetVectorS = tetVectorS;
	m_tetVectorT = tetVectorT;
	//m_vtxDepth = vtxDepth;
	m_rbfDepth = rbfDepth;
	m_tetScale = tetScale;
	
	// determine mode
	//if (m_vtxDepth.empty()) {				// homogeneous
	if (!m_rbfDepth.isReady()) {
		if (m_tetVectorS.empty()) {
			m_mode = MODE_Isotropic;
		} else if (m_tetVectorT.empty()) {
			m_mode = MODE_SglDirHomo;
		} else {
			m_mode = MODE_DblDirHomo;
		}
	} else if (m_tetVectorT.empty()) {		// layered
		m_mode = MODE_SglDirLayer;
	} else {
		m_mode = MODE_DblDirLayer;
	}
	
	m_tetVectorR.clear();
	
	if (m_mode == MODE_SglDirHomo || m_mode == MODE_DblDirHomo) {
	// noramlize tetVectorS
		for (int i = 0; i < (int)m_tetra.m_tetras.size(); ++i) {
			m_tetVectorS[i].normalize();
		}
	}
	
	if (m_mode == MODE_SglDirLayer || m_mode == MODE_DblDirLayer) {
	// calculate {tetVectorS, tetScale, tetDepth, vtxDepth} from rbfDepth
		int tetSize = (int)m_tetra.m_tetras.size();
		m_tetVectorS.clear();
		m_tetScale  .clear();
		m_tetDepth  .clear();
		m_tetVectorS.reserve(tetSize);
		m_tetScale  .reserve(tetSize);
		m_tetDepth  .reserve(tetSize);
		for (int i = 0; i < tetSize; ++i) {
			const KMultiTexTetra& tet = m_tetra.m_tetras[i];
			KVector3d pos;
			KUtil::getBarycenter(pos, m_tetra, tet);
			double f0 = m_rbfDepth.getValue(pos);
			double fx = m_rbfDepth.getValue(pos.x + m_gradDelta, pos.y, pos.z);
			double fy = m_rbfDepth.getValue(pos.x, pos.y + m_gradDelta, pos.z);
			double fz = m_rbfDepth.getValue(pos.x, pos.y, pos.z + m_gradDelta);
			KVector3d grad(fx - f0, fy - f0, fz - f0);
			grad.scale(1 / m_gradDelta);
			double s = 1 / grad.length();
			grad.scale(s);
			m_tetVectorS.push_back(grad);
			m_tetScale.push_back(s);
			m_tetDepth.push_back(f0);
		}
		int vtxSize = (int)m_tetra.m_vertices.size();
		m_vtxDepth.clear();
		m_vtxDepth.reserve(vtxSize);
		for (int i = 0; i < vtxSize; ++i) {
			KVector3d& pos = m_tetra.m_vertices[i].m_pos;
			m_vtxDepth.push_back(m_rbfDepth.getValue(pos));
		}
	}
	
	if (m_mode == MODE_DblDirHomo || m_mode == MODE_DblDirLayer) {
	// orthogonalize tetVectorT to tetVectorS and calculate tetVectorR
		m_tetVectorR.reserve(m_tetra.m_tetras.size());
		for (int i = 0; i < (int)m_tetra.m_tetras.size(); ++i) {
			KVector3d& s = m_tetVectorS[i];
			KVector3d& t = m_tetVectorT[i];
			KVector3d r;
			r.cross(s, t);
			r.normalize();
			t.cross(r, s);
			m_tetVectorR.push_back(r);
		};
	}
	clearCoverAcc();
}

void KLappedSolidTexture::pastePatch(const int seed, const KVector3d* centerPos,
	int&                      resDepthID,		// 0:middle, 1:outside, 2:inside
	std::vector<int>&         resPatch,
	std::map<int, KVector3d>& resOptimized,
	std::vector<int>&         resCovered,
	bool isUpdateRandomVector
) {
	resDepthID = 0;
	KVector3d centerPos0;
	if (!centerPos) {
		vector<int>& coverAcc = m_tetCoverAcc[seed];
		KMultiTexTetra& tetSeed = m_tetra.m_tetras[seed];
		KVector3d& p0 = m_tetra.m_vertices[tetSeed.m_vtx[0]].m_pos;
		KVector3d& p1 = m_tetra.m_vertices[tetSeed.m_vtx[1]].m_pos;
		KVector3d& p2 = m_tetra.m_vertices[tetSeed.m_vtx[2]].m_pos;
		KVector3d& p3 = m_tetra.m_vertices[tetSeed.m_vtx[3]].m_pos;
		for (int i = 0; i <= m_samplingDiv; ++i) {
			double ui = i / (double)m_samplingDiv;
			for (int j = 0; j <= m_samplingDiv - i; ++j) {
			double uj = j / (double)m_samplingDiv;
				for (int k = 0; k <= m_samplingDiv - i - j; ++k) {
					int l = m_samplingDiv - i - j - k;
					double uk = k / (double)m_samplingDiv;
					double ul = l / (double)m_samplingDiv;
					if (coverAcc[getAccID(i, j, k)] < 255) {
						//printf("%d(%d, %d, %d, %d)\n", coverAcc[getAccID(i, j, k)], i, j, k, l);
						centerPos0.addWeighted(p0, ui);
						centerPos0.addWeighted(p1, uj);
						centerPos0.addWeighted(p2, uk);
						centerPos0.addWeighted(p3, ul);
						centerPos = &centerPos0;
						break;
					}
				}
				if (centerPos) break;
			}
			if (centerPos) break;
		}
	}
	if (m_mode == MODE_SglDirLayer || m_mode == MODE_DblDirLayer) {
	// decide depthID (if vtxDepth is defined)
		double depth;
		if (centerPos) {
			depth = m_rbfDepth.getValue(*centerPos);
		} else {
			depth = m_tetDepth[seed];
		}
		resDepthID = 
			depth < 0.25 ? 1 :	// mid
			depth < 0.75 ? 0 :	// out
			2;					// in
	}
	
	if (m_mode == MODE_Isotropic && (isUpdateRandomVector || m_tetVectorR.empty())) {
	// reset all vector fields with random 3 constant vectors
		KVector3d r(rand(), rand(), rand());
		KVector3d s(rand(), rand(), rand());
		KVector3d t;
		s.normalize();
		t.cross(r, s);
		t.normalize();
		r.cross(s, t);
		m_tetVectorR.clear();
		m_tetVectorS.clear();
		m_tetVectorT.clear();
		m_tetVectorR.resize(m_tetra.m_tetras.size(), r);
		m_tetVectorS.resize(m_tetra.m_tetras.size(), s);
		m_tetVectorT.resize(m_tetra.m_tetras.size(), t);
	} else if ((m_mode == MODE_SglDirHomo || m_mode == MODE_SglDirLayer) && (isUpdateRandomVector || m_tetVectorR.empty())) {
	// reset tetVectorR and tetVectorT by randomly choosing a vector
		KVector3d t0(rand(), rand(), rand());
		KVector3d seedS = m_tetVectorS[seed];
		seedS.scale(seedS.dot(t0));
		t0.sub(seedS);
		m_tetVectorR.clear();
		m_tetVectorT.clear();
		for (int i = 0; i < (int)m_tetra.m_tetras.size(); ++i) {
			KVector3d& s = m_tetVectorS[i];
			KVector3d r, t;
			r.cross(s, t0);
			r.normalize();
			t.cross(r, s);
			m_tetVectorR.push_back(r);
			m_tetVectorT.push_back(t);
		}
	}
	
	/*
		Here, we have
			m_tetVectorR, m_tetVectorS, m_tetVectorT		[3 orthogonal unit vector field]
			m_tetScale					[scalar values assigned to each tetra]
			m_tetDepth					[depth values assigned to each tetra  (if provided)]
			m_vtxDepth					[depth values assigned to each vertex (if provided)]
	*/
	
	// grow a tetra patch (w.r.t. centerPos or depth if provided)
	resPatch = growPatch(resDepthID, seed, centerPos);
	
	// repeat optimization and coverage test
	while (true) {
		resOptimized = optimizePatch(resPatch, centerPos);
		vector<int>& additional = checkPatch(resDepthID, resPatch, resOptimized);
		if (additional.empty()) break;
		for (int i = 0; i < (int)additional.size(); ++i)
			resPatch.push_back(additional[i]);
	}
	
	// count totally covered tetras
	resCovered.clear();
	
	//// old version (until 080106) ----------------------------------------------
	//for (int i = 0; i < (int)resPatch.size(); ++i) {
	//	int tetID = resPatch[i];
	//	const KMultiTexTetra& tet = m_tetra.m_tetras[tetID];
	//	KTetraTexCoord texCoord;
	//	for (int j = 0; j < 4; ++j) {
	//		int vtxID = tet.m_vtx[j];
	//		const KVector3d& transformed = resOptimized.find(vtxID)->second;
	//		texCoord.m_coord[j] = transformed;
	//	}
	//	bool isInside = true;
	//	for (int j = 0; j < 4; ++j) {
	//		KVector3d& p0 = texCoord.m_coord[KTetraModel::FACE_VTX_ORDER[j][0]];
	//		KVector3d& p1 = texCoord.m_coord[KTetraModel::FACE_VTX_ORDER[j][1]];
	//		KVector3d& p2 = texCoord.m_coord[KTetraModel::FACE_VTX_ORDER[j][2]];
	//		if (!isTriangleInsideMask(resDepthID, p0, p1, p2)) {
	//		//if (isTriangleOutsideMask(resDepthID, p0, p1, p2)) {
	//			isInside = false;
	//			break;
	//		}
	//	}
	//	if (isInside) {
	//		resCovered.push_back(tetID);
	//	}
	//}
	
	// new version (after 080107) -----------------------------------------------
	updateCoverAcc(resDepthID, resPatch, resOptimized);
	for (int i = 0; i < (int)resPatch.size(); ++i) {
		int tetID = resPatch[i];
		vector<int>& coverAcc = m_tetCoverAcc[tetID];
		bool isCovered = true;
		for (int j = 0; j < (int)coverAcc.size(); ++j) {	// check if covered at every sampling point
			if (coverAcc[j] < 247) {
				isCovered = false;
				break;
			}
		}
		if (isCovered)
			resCovered.push_back(tetID);
	}
}

void KLappedSolidTexture::updateCoverAcc(int depthID, const std::vector<int>& patch, const std::map<int, KVector3d>& optimized) {
	const int&   M   = m_samplingDiv;
	const double _M  = 1. / M;
	const int&   N   = m_maskSize;
	const int    NN  = N * N;
	const int    N_2 = N / 2;
	for (int i = 0; i < (int)patch.size(); ++i) {
		int tetID = patch[i];
		KMultiTexTetra& tet = m_tetra.m_tetras[tetID];
		vector<int>& coverAcc = m_tetCoverAcc[tetID];
		const KVector3d& pos0 = optimized.find(tet.m_vtx[0])->second;
		const KVector3d& pos1 = optimized.find(tet.m_vtx[1])->second;
		const KVector3d& pos2 = optimized.find(tet.m_vtx[2])->second;
		const KVector3d& pos3 = optimized.find(tet.m_vtx[3])->second;
		KVector3d pos;
		for (int i0 = 0; i0 <= M; ++i0) {
			for (int i1 = 0; i1 <= M - i0; ++i1) {
				for (int i2 = 0; i2 <= M - i0 - i1; ++i2) {
					int i3 = M - i0 - i1 - i2;
					pos.set(0, 0, 0);
					pos.addWeighted(pos0, i0 * _M);
					pos.addWeighted(pos1, i1 * _M);
					pos.addWeighted(pos2, i2 * _M);
					pos.addWeighted(pos3, i3 * _M);
					int ix = (int)(pos.x * (N - 1));
					int iy = (int)(pos.y * (N - 1));
					int iz = (int)(pos.z * (N - 1));
					// shift by N/2 along y-axis according to depthID
					if (depthID == 1) {
						iy += N_2;
					} else if (depthID == 2) {
						iy -= N_2;
					}
					if (ix < 0 || N <= ix || iy < 0 || N <= iy || iz < 0 || N <= iz) continue;
					int index = ix + N * iy + NN * iz;
					GLubyte a = m_mask[index];
					int accID = getAccID(i0, i1, i2);
					coverAcc[accID] += a;
				}
			}
		}
	}
}


void KLappedSolidTexture::getTransformedTetraVertices(KVector3d result[4], int tetID, const KVector3d* centerPos) const {
	const KMultiTexTetra& tet = m_tetra.m_tetras[tetID];
	const KVector3d& v0 = m_tetra.m_vertices[tet.m_vtx[0]].m_pos;
	const KVector3d& v1 = m_tetra.m_vertices[tet.m_vtx[1]].m_pos;
	const KVector3d& v2 = m_tetra.m_vertices[tet.m_vtx[2]].m_pos;
	const KVector3d& v3 = m_tetra.m_vertices[tet.m_vtx[3]].m_pos;
	double dr0, dr1, dr2, dr3;
	double ds0, ds1, ds2, ds3;
	double dt0, dt1, dt2, dt3;
	KVector3d r = m_tetVectorR[tetID];
	KVector3d s = m_tetVectorS[tetID];
	KVector3d t = m_tetVectorT[tetID];
	double tetScale = m_tetScale[tetID];
	r.scale(tetScale);
	s.scale(tetScale);
	t.scale(tetScale);
	KUtil::getBarycentricCoord(dr0, dr1, dr2, dr3, v0, v1, v2, v3, r, 0);
	KUtil::getBarycentricCoord(ds0, ds1, ds2, ds3, v0, v1, v2, v3, s, 0);
	KUtil::getBarycentricCoord(dt0, dt1, dt2, dt3, v0, v1, v2, v3, t, 0);
	double c0, c1, c2, c3;
	if (centerPos) {
		KUtil::getBarycentricCoord(c0, c1, c2, c3, v0, v1, v2, v3, *centerPos, 1);
	} else {
		c0 = c1 = c2 = c3 = 0.25;
	}
	/* place the seed tetra onto the texture space */
	/*
		[input]
		v{i} (i = 0...3) : pos of the tetra's vertex
		r, s, t : vector field of the tetra (properly scaled)
		
		[medium]
		dr{i} (i = 0...3) : barycentric coord of r for v{i}
		ds{i} (i = 0...3) : barycentric coord of s for v{i}
		dt{i} (i = 0...3) : barycentric coord of t for v{i}
		
		[output]
		w[i] (i = 0...3) : texture coord of the vertex
		
		| dr0 dr1 dr2 dr3 |   | w0 |   | er |		<- constraints for R
		| ds0 ds1 ds2 ds3 | * | w1 | = | es |
		| dt0 dt1 dt2 dt3 |   | w2 |   | et |
		| c0  c1  c2  c3  |   | w3 |   | c  |		<- center is located to the center (0.5, 0.5, 0.5)
	*/
	
	KMatrix4d A(
		dr0, dr1, dr2, dr3,
		ds0, ds1, ds2, ds3,
		dt0, dt1, dt2, dt3,
		c0 , c1 , c2 , c3);
	A.invert();
	double br[4] = {1, 0, 0, 0.5};
	double bt[4] = {0, 0, 1, 0.5};
	double wr[4], ws[4], wt[4];
	A.mul(wr, br);
	if (m_mode == MODE_SglDirLayer || m_mode == MODE_DblDirLayer) {
		for (int i = 0; i < 4; ++i) {
			ws[i] = m_vtxDepth[tet.m_vtx[i]];
		}
	} else {
		double bs[4] = {0, 1, 0, 0.5};
		A.mul(ws, bs);
	}
	A.mul(wt, bt);
	
	for (int i = 0; i < 4; ++i)
		result[i].set(wr[i], ws[i], wt[i]);
}

std::vector<int> KLappedSolidTexture::growPatch(int depthID, int seed, const KVector3d* centerPos) const {
	vector<int> result;
	
	/* get transformed position of vertices */
	KVector3d w[4];
	getTransformedTetraVertices(w, seed, centerPos);
	
	/* obtain a 4x4 matrix T which transforms v into w */
	const KMultiTexTetra& tetSeed = m_tetra.m_tetras[seed];
	KVector3d v[4];
	for (int i = 0; i < 4; ++i)
		v[i].set(m_tetra.m_vertices[tetSeed.m_vtx[i]].m_pos);
	KMatrix4d& affine = KUtil::getAffineTransform(v, w);
	g_affine = affine;
	
	const KVector3d& seedVectorR = m_tetVectorR[seed];
	const KVector3d& seedVectorS = m_tetVectorS[seed];
	const KVector3d& seedVectorT = m_tetVectorT[seed];
	
	//int depthID = 0;
	//if (m_mode == MODE_SglDirLayer || m_mode == MODE_DblDirLayer) {
	//	double seedDepth = m_tetDepth[seed];
	//	depthID =
	//		seedDepth < 0.25 ? 1 :	// out
	//		seedDepth < 0.75 ? 0 :	// mid
	//		2;						// in
	//}
	
	vector<int> candidates;
	candidates.push_back(seed);
	//map<int, KVector3d> initialVtxPos;
	int N = m_maskSize;
	int NN = N * N;
	while(!candidates.empty()) {
		int tetID = candidates.front();//back();
		candidates.erase(candidates.begin());//pop_back();
		result.push_back(tetID);
		const KMultiTexTetra& tet = m_tetra.m_tetras[tetID];
		//const KVector3d& tetVectorR = m_tetVectorR[tetID];
		//const KVector3d& tetVectorS = m_tetVectorS[tetID];
		//const KVector3d& tetVectorT = m_tetVectorT[tetID];
		for (int i = 0; i < 4; ++i) {
			int neighborID = tet.m_neighbor[i];
			if (neighborID == -1) continue;			// tetra on boundary
			if (result.end()     != find(result.begin()    , result.end()    , neighborID)) continue;	// already contained in result
			if (candidates.end() != find(candidates.begin(), candidates.end(), neighborID)) continue;	// already contained in candidates
			const KVector3d& neighborVectorR = m_tetVectorR[neighborID];
			const KVector3d& neighborVectorS = m_tetVectorS[neighborID];
			const KVector3d& neighborVectorT = m_tetVectorT[neighborID];
			if ((seedVectorR.dot(neighborVectorR) < 0) ||
				(seedVectorS.dot(neighborVectorS) < 0) ||
				(seedVectorT.dot(neighborVectorT) < 0)) continue;			// vector field is not continuous
			//if ((tetVectorR.dot(neighborVectorR) < 0) |
			//	(tetVectorS.dot(neighborVectorS) < 0) ||
			//	(tetVectorT.dot(neighborVectorT) < 0)) continue;
			// check the mask coverage
			//KVector3d* pos[3];
			KVector3d pos[3];
			for (int j = 0; j < 3; ++j) {
				int vtxID = tet.m_vtx[KTetraModel::FACE_VTX_ORDER[i][j]];
				//map<int, KVector3d>::iterator findPos = initialVtxPos.find(vtxID);
				//bool isContained = findPos != initialVtxPos.end();
				//KVector3d& transformed = isContained
				//	? findPos->second
				//	: affine.transform(m_tetra.m_vertices[vtxID].m_pos);
				//if (!isContained) {
				//	initialVtxPos.insert(pair<int, KVector3d>(vtxID, transformed));
				//}
				//pos[j] = &transformed;
				pos[j] = affine.transform(m_tetra.m_vertices[vtxID].m_pos);
				if (m_mode == MODE_SglDirLayer || m_mode == MODE_DblDirLayer) {
					pos[j].y = m_vtxDepth[vtxID];
				}
			}
			//if (isTriangleOutsideMask(depthID, *pos[0], *pos[1], *pos[2])) continue;
			if (isTriangleOutsideMask(depthID, pos[0], pos[1], pos[2])) continue;
			candidates.push_back(tet.m_neighbor[i]);
		}
	}
	return result;
}


std::map<int, KVector3d> KLappedSolidTexture::optimizePatch(const std::vector<int>& patch, const KVector3d* centerPos) const {
	vector<int> mapI2V;
	map<int, int> mapV2I;
	for (int i = 0; i < (int)patch.size(); ++i) {
		int tetID = patch[i];
		const KMultiTexTetra& tet = m_tetra.m_tetras[tetID];
		for (int j = 0; j < 4; ++j) {
			int vtxID = tet.m_vtx[j];
			if (find(mapI2V.begin(), mapI2V.end(), vtxID) != mapI2V.end()) continue;
			mapI2V.push_back(vtxID);
			mapV2I.insert(pair<int, int>(vtxID, (int)mapI2V.size() - 1));
		}
	}
	int numRow = 3 * (int)patch.size() + 1;
	int numCol = (int)mapI2V.size();
	KUmfpackSparseMatrix A(numRow, numCol, 4 * numRow);
	vector<double> Br(numRow, 0);
	vector<double> Bs(numRow, 0);
	vector<double> Bt(numRow, 0);
	for (int i = 0; i < (int)patch.size(); ++i) {
		int tetID = patch[i];
		const KMultiTexTetra& tet = m_tetra.m_tetras[tetID];
		const KVector3d& v0 = m_tetra.m_vertices[tet.m_vtx[0]].m_pos;
		const KVector3d& v1 = m_tetra.m_vertices[tet.m_vtx[1]].m_pos;
		const KVector3d& v2 = m_tetra.m_vertices[tet.m_vtx[2]].m_pos;
		const KVector3d& v3 = m_tetra.m_vertices[tet.m_vtx[3]].m_pos;
		double dr[4], ds[4], dt[4];
		KVector3d vectorR = m_tetVectorR[tetID];
		KVector3d vectorS = m_tetVectorS[tetID];
		KVector3d vectorT = m_tetVectorT[tetID];
		vectorR.scale(m_tetScale[tetID]);
		vectorS.scale(m_tetScale[tetID]);
		vectorT.scale(m_tetScale[tetID]);
		KUtil::getBarycentricCoord(dr[0], dr[1], dr[2], dr[3], v0, v1, v2, v3, vectorR, 0);
		KUtil::getBarycentricCoord(ds[0], ds[1], ds[2], ds[3], v0, v1, v2, v3, vectorS, 0);
		KUtil::getBarycentricCoord(dt[0], dt[1], dt[2], dt[3], v0, v1, v2, v3, vectorT, 0);
		for (int j = 0; j < 4; ++j) {
			int vtxID = tet.m_vtx[j];
			int vtxID_i = mapV2I.find(vtxID)->second;
			A.setValue(3 * i    , vtxID_i, dr[j]);
			A.setValue(3 * i + 1, vtxID_i, ds[j]);
			A.setValue(3 * i + 2, vtxID_i, dt[j]);
			Br[3 * i    ] = Bs[3 * i + 1] = Bt[3 * i + 2] = 1;
		}
		if (i == 0) {
			double c[4];
			if (centerPos) {
				KUtil::getBarycentricCoord(c[0], c[1], c[2], c[3], v0, v1, v2, v3, *centerPos, 1);
			} else {
				c[0] = c[1] = c[2] = c[3] = 0.25;
			}
			for (int j = 0; j < 4; ++j)
				A.setValue(numRow - 1, j, c[j]);
		}
	}
	Br[numRow - 1] = 0.5;
	Bs[numRow - 1] = 0.5;		// used only for Homo cases, not for Layer cases
	Bt[numRow - 1] = 0.5;
	KUmfpackSparseMatrix& At = A.transpose();
	KUmfpackSparseMatrix& AtA = A.transposedMultipliedBySelf();
	vector<int>   & Ap = AtA.getAp();
	vector<int>   & Ai = AtA.getAi();
	vector<double>& Ax = AtA.getAx();
	KUmfpack umfpack(numCol, Ap, Ai, Ax);
	
	vector<double>& AtBr = At.mul(Br);
	vector<double>& AtBt = At.mul(Bt);
	vector<double> Xr(numCol);
	vector<double> Xt(numCol);
	umfpack.solve(Xr, AtBr);
	umfpack.solve(Xt, AtBt);
	
	vector<double> Xs(numCol);
	if (m_mode == MODE_SglDirLayer || m_mode == MODE_DblDirLayer) {
		// skip solving when depth is available
		for (int i = 0; i < numCol; ++i)
			Xs[i] = m_vtxDepth[mapI2V[i]];
	} else {
		vector<double>& AtBs = At.mul(Bs);
		umfpack.solve(Xs, AtBs);
	}
	map<int, KVector3d> result;
	for (int i = 0; i < numCol; ++i) {
		KVector3d pos(Xr[i], Xs[i], Xt[i]);
		result.insert(pair<int, KVector3d>(mapI2V[i], pos));
	}
	return result;
}

std::vector<int> KLappedSolidTexture::checkPatch(int depthID, const std::vector<int>& patch, const std::map<int, KVector3d>& optimized) const {
	vector<int> result;
	
	int seedID = patch.front();
	const KVector3d& seedVectorR = m_tetVectorR[seedID];
	const KVector3d& seedVectorS = m_tetVectorS[seedID];
	const KVector3d& seedVectorT = m_tetVectorT[seedID];
	
	for (int i = 0; i < (int)patch.size(); ++i) {
		int tetID = patch[i];
		const KMultiTexTetra& tet = m_tetra.m_tetras[tetID];
		for (int j = 0; j < 4; ++j) {
			int neighborID = tet.m_neighbor[j];
			if (neighborID == -1) continue;			// tetra on boundary
			if (find(patch .begin(), patch .end(), neighborID) != patch .end()) continue;
			if (find(result.begin(), result.end(), neighborID) != result.end()) continue;
			const KVector3d& vectorR = m_tetVectorR[neighborID];
			const KVector3d& vectorS = m_tetVectorS[neighborID];
			const KVector3d& vectorT = m_tetVectorT[neighborID];
			if ((seedVectorR.dot(vectorR) < 0) ||
				(seedVectorS.dot(vectorS) < 0) ||
				(seedVectorT.dot(vectorT) < 0)) continue;			// vector field is not continuous
			const KVector3d& pos0 = optimized.find(tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][0]])->second;
			const KVector3d& pos1 = optimized.find(tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][1]])->second;
			const KVector3d& pos2 = optimized.find(tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][2]])->second;
			if (isTriangleOutsideMask(depthID, pos0, pos1, pos2)) continue;
			result.push_back(neighborID);
		}
	}
	return result;
}

bool KLappedSolidTexture::isTriangleInsideMask (int depthID, const KVector3d& pos0, const KVector3d& pos1, const KVector3d& pos2, const int numDiv) const {
	const int& N = m_maskSize;
	int NN = N * N;
	int N_2 = N / 2;
	KVector3d pos;
	for (int i0 = 0; i0 <= numDiv; ++i0)
		for (int i1 = 0; i1 <= numDiv - i0; ++i1) {
			int i2 = numDiv - i0 - i1;
			double _l = 1. / numDiv;
			double w0 = i0 * _l;
			double w1 = i1 * _l;
			double w2 = i2 * _l;
			pos.set(0, 0, 0);
			pos.addWeighted(pos0, w0);
			pos.addWeighted(pos1, w1);
			pos.addWeighted(pos2, w2);
			int ix = (int)(pos.x * (N - 1));
			int iy = (int)(pos.y * (N - 1));
			int iz = (int)(pos.z * (N - 1));
			// shift by N/2 along y-axis according to depthID
			if (depthID == 1) {
				iy += N_2;
			} else if (depthID == 2) {
				iy -= N_2;
			}
			if (ix < 0 || N <= ix || iy < 0 || N <= iy || iz < 0 || N <= iz) return false;
			int index = ix + N * iy + NN * iz;
			GLubyte a = m_mask[index];
			if (a != 255)
				return false;
		}
	return true;
}

bool KLappedSolidTexture::isTriangleOutsideMask(int depthID, const KVector3d& pos0, const KVector3d& pos1, const KVector3d& pos2, const int numDiv) const {
	const int& N = m_maskSize;
	int NN = N * N;
	int N_2 = N / 2;
	KVector3d pos;
	for (int i0 = 0; i0 <= numDiv; ++i0)
		for (int i1 = 0; i1 <= numDiv - i0; ++i1) {
			int i2 = numDiv - i0 - i1;
			double _l = 1. / numDiv;
			double w0 = i0 * _l;
			double w1 = i1 * _l;
			double w2 = i2 * _l;
			pos.set(0, 0, 0);
			pos.addWeighted(pos0, w0);
			pos.addWeighted(pos1, w1);
			pos.addWeighted(pos2, w2);
			int ix = (int)(pos.x * (N - 1));
			int iy = (int)(pos.y * (N - 1));
			int iz = (int)(pos.z * (N - 1));
			// shift by N/2 along y-axis according to depthID
			if (depthID == 1) {
				iy += N_2;
			} else if (depthID == 2) {
				iy -= N_2;
			}
			if (ix < 0 || N <= ix || iy < 0 || N <= iy || iz < 0 || N <= iz) continue;
			int index = ix + N * iy + NN * iz;
			GLubyte a = m_mask[index];
			if (a != 0) return false;
		}
	return true;
}




// version without optimization (only for making presen figure)
void KLappedSolidTexture::pastePatch_without_optimization(const int seed, const KVector3d* centerPos,
	int&                      resDepthID,		// 0:middle, 1:outside, 2:inside
	std::vector<int>&         resPatch,
	std::map<int, KVector3d>& resOptimized,
	std::vector<int>&         resCovered,
	bool isUpdateRandomVector
) {
	resDepthID = 0;
	KVector3d centerPos0;
	if (!centerPos) {
		vector<int>& coverAcc = m_tetCoverAcc[seed];
		KMultiTexTetra& tetSeed = m_tetra.m_tetras[seed];
		KVector3d& p0 = m_tetra.m_vertices[tetSeed.m_vtx[0]].m_pos;
		KVector3d& p1 = m_tetra.m_vertices[tetSeed.m_vtx[1]].m_pos;
		KVector3d& p2 = m_tetra.m_vertices[tetSeed.m_vtx[2]].m_pos;
		KVector3d& p3 = m_tetra.m_vertices[tetSeed.m_vtx[3]].m_pos;
		for (int i = 0; i <= m_samplingDiv; ++i) {
			double ui = i / (double)m_samplingDiv;
			for (int j = 0; j <= m_samplingDiv - i; ++j) {
			double uj = j / (double)m_samplingDiv;
				for (int k = 0; k <= m_samplingDiv - i - j; ++k) {
					int l = m_samplingDiv - i - j - k;
					double uk = k / (double)m_samplingDiv;
					double ul = l / (double)m_samplingDiv;
					if (coverAcc[getAccID(i, j, k)] < 255) {
						//printf("%d(%d, %d, %d, %d)\n", coverAcc[getAccID(i, j, k)], i, j, k, l);
						centerPos0.addWeighted(p0, ui);
						centerPos0.addWeighted(p1, uj);
						centerPos0.addWeighted(p2, uk);
						centerPos0.addWeighted(p3, ul);
						centerPos = &centerPos0;
						break;
					}
				}
				if (centerPos) break;
			}
			if (centerPos) break;
		}
	}
	if (m_mode == MODE_SglDirLayer || m_mode == MODE_DblDirLayer) {
	// decide depthID (if vtxDepth is defined)
		double depth;
		if (centerPos) {
			depth = m_rbfDepth.getValue(*centerPos);
		} else {
			depth = m_tetDepth[seed];
		}
		resDepthID = 
			depth < 0.25 ? 1 :	// mid
			depth < 0.75 ? 0 :	// out
			2;					// in
	}
	
	if (m_mode == MODE_Isotropic && (isUpdateRandomVector || m_tetVectorR.empty())) {
	// reset all vector fields with random 3 constant vectors
		KVector3d r(rand(), rand(), rand());
		KVector3d s(rand(), rand(), rand());
		KVector3d t;
		s.normalize();
		t.cross(r, s);
		t.normalize();
		r.cross(s, t);
		m_tetVectorR.clear();
		m_tetVectorS.clear();
		m_tetVectorT.clear();
		m_tetVectorR.resize(m_tetra.m_tetras.size(), r);
		m_tetVectorS.resize(m_tetra.m_tetras.size(), s);
		m_tetVectorT.resize(m_tetra.m_tetras.size(), t);
	} else if ((m_mode == MODE_SglDirHomo || m_mode == MODE_SglDirLayer) && (isUpdateRandomVector || m_tetVectorR.empty())) {
	// reset tetVectorR and tetVectorT by randomly choosing a vector
		KVector3d t0(rand(), rand(), rand());
		KVector3d seedS = m_tetVectorS[seed];
		seedS.scale(seedS.dot(t0));
		t0.sub(seedS);
		m_tetVectorR.clear();
		m_tetVectorT.clear();
		for (int i = 0; i < (int)m_tetra.m_tetras.size(); ++i) {
			KVector3d& s = m_tetVectorS[i];
			KVector3d r, t;
			r.cross(s, t0);
			r.normalize();
			t.cross(r, s);
			m_tetVectorR.push_back(r);
			m_tetVectorT.push_back(t);
		}
	}
	
	/*
		Here, we have
			m_tetVectorR, m_tetVectorS, m_tetVectorT		[3 orthogonal unit vector field]
			m_tetScale					[scalar values assigned to each tetra]
			m_tetDepth					[depth values assigned to each tetra  (if provided)]
			m_vtxDepth					[depth values assigned to each vertex (if provided)]
	*/
	
	// grow a tetra patch (w.r.t. centerPos or depth if provided)
	resPatch = growPatch(resDepthID, seed, centerPos);
	resOptimized.clear();
	vector<int> vIDs;
	for (int i = 0; i < (int)resPatch.size(); ++i) {
		KMultiTexTetra& tet = m_tetra.m_tetras[resPatch[i]];
		for (int j = 0; j < 4; ++j) {
			int vID = tet.m_vtx[j];
			if (find(vIDs.begin(), vIDs.end(), vID) == vIDs.end()) vIDs.push_back(vID);
		}
	}
	for (int i = 0; i < (int)vIDs.size(); ++i) {
		int vID = vIDs[i];
		KVector3d newPos = g_affine.transform(m_tetra.m_vertices[vID].m_pos);
		resOptimized.insert(pair<int, KVector3d>(vID, newPos));
	}
	//// repeat optimization and coverage test
	//while (true) {
	//	resOptimized = optimizePatch(resPatch, centerPos);
	//	vector<int>& additional = checkPatch(resDepthID, resPatch, resOptimized);
	//	if (additional.empty()) break;
	//	for (int i = 0; i < (int)additional.size(); ++i)
	//		resPatch.push_back(additional[i]);
	//}
	
	// count totally covered tetras
	resCovered.clear();
	
	//// old version (until 080106) ----------------------------------------------
	//for (int i = 0; i < (int)resPatch.size(); ++i) {
	//	int tetID = resPatch[i];
	//	const KMultiTexTetra& tet = m_tetra.m_tetras[tetID];
	//	KTetraTexCoord texCoord;
	//	for (int j = 0; j < 4; ++j) {
	//		int vtxID = tet.m_vtx[j];
	//		const KVector3d& transformed = resOptimized.find(vtxID)->second;
	//		texCoord.m_coord[j] = transformed;
	//	}
	//	bool isInside = true;
	//	for (int j = 0; j < 4; ++j) {
	//		KVector3d& p0 = texCoord.m_coord[KTetraModel::FACE_VTX_ORDER[j][0]];
	//		KVector3d& p1 = texCoord.m_coord[KTetraModel::FACE_VTX_ORDER[j][1]];
	//		KVector3d& p2 = texCoord.m_coord[KTetraModel::FACE_VTX_ORDER[j][2]];
	//		if (!isTriangleInsideMask(resDepthID, p0, p1, p2)) {
	//		//if (isTriangleOutsideMask(resDepthID, p0, p1, p2)) {
	//			isInside = false;
	//			break;
	//		}
	//	}
	//	if (isInside) {
	//		resCovered.push_back(tetID);
	//	}
	//}
	
	// new version (after 080107) -----------------------------------------------
	updateCoverAcc(resDepthID, resPatch, resOptimized);
	for (int i = 0; i < (int)resPatch.size(); ++i) {
		int tetID = resPatch[i];
		vector<int>& coverAcc = m_tetCoverAcc[tetID];
		bool isCovered = true;
		for (int j = 0; j < (int)coverAcc.size(); ++j) {	// check if covered at every sampling point
			if (coverAcc[j] < 247) {
				isCovered = false;
				break;
			}
		}
		if (isCovered)
			resCovered.push_back(tetID);
	}
}

