#pragma once

#include "KMultiTexGeometry.h"
#include "KRBF.h"
#include <gl/gl.h>

#include <vector>
#include <map>

class KLappedSolidTexture
{
public:
	KLappedSolidTexture();
	~KLappedSolidTexture(void) {}
	
	void setTetra(const KMultiTexTetraModel& tetra) {
		m_tetra = tetra;
	}
	void setMask(int maskSize, const std::vector<GLubyte>& mask) {
		if (maskSize * maskSize * maskSize != (int)mask.size()) {
			throw "maskSize^3 != mask.size()";
		}
		m_maskSize = maskSize;
		m_mask = mask;
	}
	
	void setField(
		const std::vector<KVector3d>& tetVectorS,	// primary axis
		const std::vector<KVector3d>& tetVectorT,	// secondary axis
		//const std::vector<double>& vtxDepth,		// 0:outermost, 1:innermost
		const KThinPlate3D& vtxDepth,		// 0:outermost, 1:innermost
		const std::vector<double>& tetScale
	);
	void setScale(const std::vector<double>& tetScale) {
		m_tetScale = tetScale;
	}
	/*
	
	!rbfDepth.isReady() &&
	tetVectorS.empty()			// requires tetScale
		--> Isotropic
	
	!rbfDepth.isReady() &&
	!tetVectorS.empty() &&
	tetVectorT.empty()			// requires tetScale
		--> Single Directional Homogeneous
	
	!rbfDepth.isReady() &&
	!tetVectorS.empty() &&
	!tetVectorT.empty()			// requires tetScale
		--> Double Directional Homogeneous
	
	rbfDepth.isReady() &&
	tetVectorT.empty()
		--> Single Directional Layered
	
	rbfDepth.isReady() &&
	!tetVectorT.empty()
		--> Double Directional Layered
	
	tetScale must always be specified except in the Layered case
	*/
	void pastePatch(
		const int seed,								// [input] seed tetra ID
		const KVector3d* centerPos,					// [input] positional constraint on seed (NULL --> non-constrained)
		int&                      resDepthID,		// [output] mask ID (0:middle, 1:outside, 2:inside)
		std::vector<int>&         resPatch,			// [output] resulting patch (list of tetra ID) 
		std::map<int, KVector3d>& resOptimized,		// [output] optimization result (mapping between vtxID and texCoord)
		std::vector<int>&         resCovered,		// [output] ID list of totally-covered tetras
		bool isUpdateRandomVector = true			// true: reset unspecified vectors randomly, false: keep previous vectors
	);

//protected:
	const double m_gradDelta;
	const int    m_samplingDiv;
	
	// input data ----------------------------
	// input tetra
	KMultiTexTetraModel m_tetra;
	// input mask
	int m_maskSize;
	// input field
	std::vector<GLubyte> m_mask;
	std::vector<KVector3d> m_tetVectorS;
	std::vector<KVector3d> m_tetVectorT;
	//std::vector<double> m_vtxDepth;
	KThinPlate3D m_rbfDepth;
	std::vector<double> m_tetScale;
	
	// operation modes -------------------
	enum {
		MODE_Isotropic,
		MODE_SglDirHomo,
		MODE_DblDirHomo,
		MODE_SglDirLayer,
		MODE_DblDirLayer
	} m_mode;
	
	// intermediate data ------------------------------
	std::vector<KVector3d> m_tetVectorR;
	std::vector<double> m_vtxDepth;
	std::vector<double> m_tetDepth;
	
	// core functions ------------------------------------------------------------------------------------
	void getTransformedTetraVertices(KVector3d result[4], int tetID, const KVector3d* centerPos) const;
	std::vector<int> growPatch(int depthID, int seed, const KVector3d* centerPos) const;
	std::map<int, KVector3d> optimizePatch(const std::vector<int>& patch, const KVector3d* centerPos) const;
	std::vector<int> checkPatch(int depthID, const std::vector<int>& patch, const std::map<int, KVector3d>& optimized) const;
	bool isTriangleInsideMask (int depthID, const KVector3d& pos0, const KVector3d& pos1, const KVector3d& pos2, const int numDiv = 4) const;
	bool isTriangleOutsideMask(int depthID, const KVector3d& pos0, const KVector3d& pos1, const KVector3d& pos2, const int numDiv = 4) const;
	void updateCoverAcc(int depthID, const std::vector<int>& patch, const std::map<int, KVector3d>& optimized);
	
	// coverage accumulation (08.01.07) -------------------------------------------
	std::vector<std::vector<int> > m_tetCoverAcc;	// accumulated sum of alpha
	std::vector<int> m_tableDivNum2AccID;
	void initTable();
	void clearCoverAcc();
	int getAccID(int i0, int i1, int i2) const;
	
	
	void pastePatch_without_optimization(
		const int seed,								// [input] seed tetra ID
		const KVector3d* centerPos,					// [input] positional constraint on seed (NULL --> non-constrained)
		int&                      resDepthID,		// [output] mask ID (0:middle, 1:outside, 2:inside)
		std::vector<int>&         resPatch,			// [output] resulting patch (list of tetra ID) 
		std::map<int, KVector3d>& resOptimized,		// [output] optimization result (mapping between vtxID and texCoord)
		std::vector<int>&         resCovered,		// [output] ID list of totally-covered tetras
		bool isUpdateRandomVector = true			// true: reset unspecified vectors randomly, false: keep previous vectors
	);
};
