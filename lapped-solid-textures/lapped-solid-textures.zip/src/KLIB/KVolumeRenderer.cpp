#include "StdAfx.h"
#include "KVolumeRenderer.h"

#include "KUtil.h"

using namespace std;

void KVolumeRenderer::go(
	KMultiTexPolygonModel& result,
	const KMultiTexTetraModel& tetra,
	const vector<double> vtxDistance, double valFar, double valNear, int numSlice
) {
	static const int mapping_pattern[][4] = {
		{-1, -1, -1, -1},	//0
		{0, 1, 2, 3},	//1
		{1, 2, 0, 3},	//2
		{0, 1, 2, 3},	//3
		{2, 0, 1, 3},	//4
		{0, 2, 3, 1},	//5
		{1, 2, 0, 3},	//6
		{3, 2, 1, 0},	//7
		{3, 2, 1, 0},	//8
		{0, 3, 1, 2},	//9
		{1, 3, 2, 0},	//10
		{2, 0, 1, 3},	//11
		{2, 3, 0, 1},	//12
		{1, 2, 0, 3},	//13
		{0, 1, 2, 3},	//14
		{0, 1, 2, 3}	//15
	};
	
	double step = (valFar - valNear) / (numSlice - 1);
	if (step <= 0) return;
	vector<KVertex> vertices;
	vector<KMultiTexPolygon> polygons;
	for (double dist = valFar; dist >= valNear; dist -= step) {
		for (int i = 0; i < (int)tetra.m_tetras.size(); ++i) {
			const KMultiTexTetra& tet = tetra.m_tetras[i];
			const vector<KTetraTexCoord>& texCoords = tet.m_texCoords;
			const vector<int>&            texIDs    = tet.m_texIDs;
			int code = 0;
			double val[4];
			for (int j = 0; j < 4; ++j) {
				val[j] = vtxDistance[tet.m_vtx[j]];
				if (val[j] > dist)
					code += (1 << j);
			}
			if (code == 0 || code == 15) continue;
			const int* mapping = mapping_pattern[code];
			KVector3d vPos[4];
			vector<KVector3d> vCoord[4];
			for (int j = 0; j < 4; ++j) {
				int index = tet.m_vtx[mapping[j]];
				const KVector3d& pos = tetra.m_vertices[index].m_pos;
				vPos[j] = pos;
				for (int k = 0; k < (int)texCoords.size(); ++k)
					vCoord[j].push_back(texCoords[k].m_coord[mapping[j]]);
			}
			switch (code) {
				case 1:
				case 2:
				case 4:
				case 8:
					{
						KVector3d wPos[3];
						vector<KVector3d> wCoord[3];
						for (int j = 0; j < 3; ++j) {
							double u = (dist - val[mapping[0]]) / (val[mapping[j + 1]] - val[mapping[0]]);
							wPos[j] = vPos[0];
							wPos[j].scale(1 - u);
							wPos[j].addWeighted(vPos[j + 1], u);
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex = vCoord[0][k];
								tex.scale(1 - u);
								tex.addWeighted(vCoord[j + 1][k], u);
								wCoord[j].push_back(tex);
							}
						}
						int vIndex = (int)vertices.size();
						vertices.push_back(KVertex(wPos[0]));
						vertices.push_back(KVertex(wPos[1]));
						vertices.push_back(KVertex(wPos[2]));
						KMultiTexPolygon p(vIndex, vIndex + 1, vIndex + 2);
						//KVector3d n;
						//KUtil::calcNormal(n, wPos[0], wPos[1], wPos[2]);
						//p.m_normal[0] = n;
						//p.m_normal[1] = n;
						//p.m_normal[2] = n;
						p.m_texCoords.reserve(texCoords.size());
						for (int j = 0; j < (int)texCoords.size(); ++j)
							p.m_texCoords.push_back(KPolygonTexCoord(wCoord[0][j], wCoord[1][j], wCoord[2][j]));
						p.m_texIDs = texIDs;
						polygons.push_back(p);
					}
					break;
				case 3:
				case 5:
				case 6:
				case 9:
				case 10:
				case 12:
					{
						static int pairs[][2] = {{0, 3}, {0, 2}, {1, 2}, {1, 3}};
						KVector3d wPos[4];
						vector<KVector3d> wCoord[4];
						for (int j = 0; j < 4; ++j) {
							const int& i0 = pairs[j][0];
							const int& i1 = pairs[j][1];
							double u = (dist - val[mapping[i0]]) / (val[mapping[i1]] - val[mapping[i0]]);
							wPos[j] = vPos[i0];
							wPos[j].scale(1 - u);
							wPos[j].addWeighted(vPos[i1], u);
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex(vCoord[i0][k]);
								tex.scale(1 - u);
								tex.addWeighted(vCoord[i1][k], u);
								wCoord[j].push_back(tex);
							}
						}
						int vIndex = (int)vertices.size();
						vertices.push_back(KVertex(wPos[0]));
						vertices.push_back(KVertex(wPos[1]));
						vertices.push_back(KVertex(wPos[2]));
						vertices.push_back(KVertex(wPos[3]));
						KMultiTexPolygon p1(vIndex, vIndex + 2, vIndex + 1);
						KMultiTexPolygon p2(vIndex, vIndex + 3, vIndex + 2);
						//KVector3d n;
						//KUtil::calcNormal(n, wPos[0], wPos[2], wPos[1]);
						//p1.m_normal[0] = n;
						//p1.m_normal[1] = n;
						//p1.m_normal[2] = n;
						//p2.m_normal[0] = n;
						//p2.m_normal[1] = n;
						//p2.m_normal[2] = n;
						p1.m_texCoords.reserve(texCoords.size());
						p2.m_texCoords.reserve(texCoords.size());
						for (int j = 0; j < (int)texCoords.size(); ++j) {
							p1.m_texCoords.push_back(KPolygonTexCoord(wCoord[0][j], wCoord[2][j], wCoord[1][j]));
							p2.m_texCoords.push_back(KPolygonTexCoord(wCoord[0][j], wCoord[3][j], wCoord[2][j]));
						}
						p1.m_texIDs = texIDs;
						p2.m_texIDs = texIDs;
						polygons.push_back(p1);
						polygons.push_back(p2);
					}
					break;
				case 7:
				case 11:
				case 13:
				case 14:
					{
						KVector3d wPos[3];
						vector<KVector3d> wCoord[3];
						for (int j = 0; j < 3; ++j) {
							double u = (dist - val[mapping[0]]) / (val[mapping[j + 1]] - val[mapping[0]]);
							wPos[j] = vPos[0];
							wPos[j].scale(1 - u);
							wPos[j].addWeighted(vPos[j + 1], u);
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex(vCoord[0][k]);
								tex.scale(1 - u);
								tex.addWeighted(vCoord[j + 1][k], u);
								wCoord[j].push_back(tex);
							}
						}
						int vIndex = (int)vertices.size();
						vertices.push_back(KVertex(wPos[2]));
						vertices.push_back(KVertex(wPos[1]));
						vertices.push_back(KVertex(wPos[0]));
						KMultiTexPolygon p(vIndex, vIndex + 1, vIndex + 2);
						//KVector3d n;
						//KUtil::calcNormal(n, wPos[2], wPos[1], wPos[0]);
						//p.m_normal[0] = n;
						//p.m_normal[1] = n;
						//p.m_normal[2] = n;
						p.m_texCoords.reserve(texCoords.size());
						for (int j = 0; j < (int)texCoords.size(); ++j)
							p.m_texCoords.push_back(KPolygonTexCoord(wCoord[2][j], wCoord[1][j], wCoord[0][j]));
						p.m_texIDs = texIDs;
						polygons.push_back(p);
					}
					break;
			}
		}
	}
	result.m_vertices = vertices;
	result.m_polygons = polygons;
}

