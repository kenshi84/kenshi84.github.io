#pragma once

#include "KMultiTexGeometry.h"

#include <vector>

class KVolumeRenderer
{
	KVolumeRenderer(void);
	~KVolumeRenderer(void);
public:
	static void go(
		KMultiTexPolygonModel& result,
		const KMultiTexTetraModel& input,
		const std::vector<double> vtxDistance, double valFar, double valNear, int numSlice
	);
};
