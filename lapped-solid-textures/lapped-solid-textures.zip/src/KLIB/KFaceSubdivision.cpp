#include "StdAfx.h"
#include "KFaceSubdivision.h"

#include <map>

using namespace std;

KMultiTexPolygonModel KFaceSubdivision::go(const KMultiTexPolygonModel& poly) {
	vector<KVertex> vertices;
	vector<KMultiTexPolygon> polygons;

	// ----------------------------------------------------
	// For each face, divide it into 4 faces:
	// (v0-w2-w1), (v1-w0-w2), (v2-w1-w0), (w0-w1-w2)
	//
	//       v0
	//      /  \
	//     /    \
	//    w2-----w1
	//   / \    / \
	//  /   \  /   \
	// v1____w0____v2
	//
	// ---------------------------------------------------
	
	map<int, int> mapVtxCode2Index;
	int numVtx = (int)poly.m_vertices.size();
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		const KMultiTexPolygon& p = poly.m_polygons[i];
		const vector<KPolygonTexCoord>& texCoords = p.m_texCoords;
		const vector<int>& texIDs = p.m_texIDs;
		int vIndex[3], wIndex[3];
		vector<KVector3d> vTexCoords[3];
		vector<KVector3d> wTexCoords[3];
		// first, establish vertices and their associated texCoords
		for (int j = 0; j < 3; ++j) {
			int vID = p.m_vtx[j];
			int vCode = vID * (numVtx + 1);
			map<int, int>::iterator vFindPos = mapVtxCode2Index.find(vCode);
			if (vFindPos == mapVtxCode2Index.end()) {
				vIndex[j] = (int)vertices.size();
				mapVtxCode2Index.insert(pair<int, int>(vCode, vIndex[j]));
				vertices.push_back(poly.m_vertices[vID]);
			} else {
				vIndex[j] = vFindPos->second;
			}
			int wID0 = p.m_vtx[(j + 1) % 3];
			int wID1 = p.m_vtx[(j + 2) % 3];
			if (wID0 > wID1) {
				int tmp = wID0;
				wID0 = wID1;
				wID1 = tmp;
			}
			int wCode = wID0 * numVtx + wID1;
			map<int, int>::iterator wFindPos = mapVtxCode2Index.find(wCode);
			if (wFindPos == mapVtxCode2Index.end()) {
				wIndex[j] = (int)vertices.size();
				mapVtxCode2Index.insert(pair<int, int>(wCode, wIndex[j]));
				KVector3d pos;
				pos.addWeighted(poly.m_vertices[wID0].m_pos, 0.5);
				pos.addWeighted(poly.m_vertices[wID1].m_pos, 0.5);
				vertices.push_back(KVertex(pos));
			} else {
				wIndex[j] = wFindPos->second;
			}
			vTexCoords[j].reserve(texCoords.size());
			wTexCoords[j].reserve(texCoords.size());
			for (int k = 0; k < (int)texCoords.size(); ++k) {
				const KPolygonTexCoord& texCoord = texCoords[k];
				vTexCoords[j].push_back(texCoord.m_coord[j]);
				KVector3d pos;
				pos.addWeighted(texCoord.m_coord[(j + 1) % 3], 0.5);
				pos.addWeighted(texCoord.m_coord[(j + 2) % 3], 0.5);
				wTexCoords[j].push_back(pos);
			}
		}
		// and then, make and register polygon
		polygons.push_back(makePolygon(
			vIndex[0], wIndex[2], wIndex[1],
			vTexCoords[0], wTexCoords[2], wTexCoords[1], texIDs));
		polygons.push_back(makePolygon(
			vIndex[1], wIndex[0], wIndex[2],
			vTexCoords[1], wTexCoords[0], wTexCoords[2], texIDs));
		polygons.push_back(makePolygon(
			vIndex[2], wIndex[1], wIndex[0],
			vTexCoords[2], wTexCoords[1], wTexCoords[0], texIDs));
		polygons.push_back(makePolygon(
			wIndex[0], wIndex[1], wIndex[2],
			wTexCoords[0], wTexCoords[1], wTexCoords[2], texIDs));
	}
	
	KMultiTexPolygonModel result;
	result.m_vertices = vertices;
	result.m_polygons = polygons;
	return result;
}

KMultiTexPolygon KFaceSubdivision::makePolygon(
	int vtx0, int vtx1, int vtx2,
	const vector<KVector3d>& texCoordsForVtx0,
	const vector<KVector3d>& texCoordsForVtx1,
	const vector<KVector3d>& texCoordsForVtx2,
	const vector<int>& texIDs)
{
	KMultiTexPolygon p(vtx0, vtx1, vtx2);
	vector<KPolygonTexCoord> texCoords;
	texCoords.reserve(texCoordsForVtx0.size());
	for (int i = 0; i < (int)texCoordsForVtx0.size(); ++i) {
		texCoords.push_back(KPolygonTexCoord(
			texCoordsForVtx0[i],
			texCoordsForVtx1[i],
			texCoordsForVtx2[i]));
	}
	p.m_texCoords = texCoords;
	p.m_texIDs = texIDs;
	return p;
}
