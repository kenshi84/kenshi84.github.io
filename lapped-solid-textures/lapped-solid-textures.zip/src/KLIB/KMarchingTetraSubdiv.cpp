#include "StdAfx.h"
#include "KMarchingTetraSubdiv.h"

#include <algorithm>

using namespace std;

KTetraModel KMarchingTetraSubdiv::calcMarchingTetraSubdiv(const KTetraModel& tetra, const vector<double>& vtxValue, const double threshold) {
	static const int mapping_pattern[][4] = {
		{-1, -1, -1, -1},	//0
		{0, 1, 2, 3},	//1
		{1, 2, 0, 3},	//2
		{0, 1, 2, 3},	//3
		{2, 0, 1, 3},	//4
		{0, 2, 3, 1},	//5
		{1, 2, 0, 3},	//6
		{3, 2, 1, 0},	//7
		{3, 2, 1, 0},	//8
		{0, 3, 1, 2},	//9
		{1, 3, 2, 0},	//10
		{2, 0, 1, 3},	//11
		{2, 3, 0, 1},	//12
		{1, 2, 0, 3},	//13
		{0, 1, 2, 3},	//14
		{0, 1, 2, 3}	//15
	};
	
	int vtxSize = (int)tetra.m_vertices.size();
	int tetSize = (int)tetra.m_tetras.size();
	vector<KVertex> vertices;
	vector<KTetra> tetras;
	map<int, int> vtxMap;
	for (int i = 0; i < tetSize; ++i) {
		const KTetra& tet = tetra.m_tetras[i];
		int code = 0;
		double val[4];
		for (int j = 0; j < 4; ++j) {
			val[j] = vtxValue[tet.m_vtx[j]];
			if (val[j] < threshold)
				code += (1 << j);
		}
		if (code == 0) continue;
		const int* mapping = mapping_pattern[code];
		KVector3d vPos[4];
		int       vKey[4];
		int       vID[4];
		for (int j = 0; j < 4; ++j) {
			int index = tet.m_vtx[mapping[j]];
			vKey[j] = (vtxSize * (vtxSize + 1) + 1) * index;
			map<int, int>::iterator findPos = vtxMap.find(vKey[j]);
			if (findPos != vtxMap.end()) {
				vID[j] = findPos->second;
			} else {
				vID[j] = -1;
			}
			vPos[j] = tetra.m_vertices[index].m_pos;
		}
		if (code == 15) {
			addTetra(
				vertices, tetras, vtxMap,
				vPos[0], vPos[1], vPos[2], vPos[3],
				vKey[0], vKey[1], vKey[2], vKey[3],
				vID [0], vID [1], vID [2], vID [3]); 
		} else {
//     v0--v2
//    / \ .|
//   /  .\ |
//  / .   \|
//v1.______v3
			switch(code) {
				// o : in
				// x : out
				case 1:
				case 2:
				case 4:
				case 8:
// case 1
//     o---x
//    / \ .|
//   /  .\ |
//  / .   \|
// x.______x
					{
						KVector3d wPos[3];
						int       wKey[3];
						int       wID [3];
						for (int j = 0; j < 3; ++j) {
							int index0 = min(tet.m_vtx[mapping[0]], tet.m_vtx[mapping[j + 1]]);
							int index1 = max(tet.m_vtx[mapping[0]], tet.m_vtx[mapping[j + 1]]);
							wKey[j] = vtxSize * (vtxSize + 1) * index0 + index1;
							map<int, int>::iterator findPos = vtxMap.find(wKey[j]);
							if (findPos != vtxMap.end()) {
								wID[j] = findPos->second;
								wPos[j] = vertices[wID[j]].m_pos;
							} else {
								wID[j] = -1;
								double u = (threshold - val[mapping[0]]) / (val[mapping[j + 1]] - val[mapping[0]]);
								wPos[j] = vPos[0];
								wPos[j].scale(1 - u);
								wPos[j].addWeighted(vPos[j + 1], u);
							}
						}
					addTetra(
						vertices, tetras, vtxMap,
						vPos[0], wPos[0], wPos[1], wPos[2],
						vKey[0], wKey[0], wKey[1], wKey[2],
						vID [0], wID [0], wID [1], wID [2]); 
					}
					break;
				case 3:
				case 5:
				case 6:
				case 9:
				case 10:
				case 12:
// case 3
//     o---x
//    / \ .|
//   /  .\ |
//  / .   \|
// o.______x
					{
						static int pairs[][2] = {{0, 3}, {0, 2}, {1, 2}, {1, 3}};
						KVector3d wPos[4];
						int       wKey[4];
						int       wID [4];
						for (int j = 0; j < 4; ++j) {
							const int& i0 = pairs[j][0];
							const int& i1 = pairs[j][1];
							int index0 = min(tet.m_vtx[mapping[i0]], tet.m_vtx[mapping[i1]]);
							int index1 = max(tet.m_vtx[mapping[i0]], tet.m_vtx[mapping[i1]]);
							wKey[j] = vtxSize * (vtxSize + 1) * index0 + index1;
							map<int, int>::iterator findPos = vtxMap.find(wKey[j]);
							if (findPos != vtxMap.end()) {
								wID[j] = findPos->second;
								wPos[j] = vertices[wID[j]].m_pos;
							} else {
								wID[j] = -1;
								double u = (threshold - val[mapping[i0]]) / (val[mapping[i1]] - val[mapping[i0]]);
								wPos[j] = vPos[i0];
								wPos[j].scale(1 - u);
								wPos[j].addWeighted(vPos[i1], u);
							}
						}
						KVector3d uPos0;
						int       uKey0;
						int       uID0;
						{
							vector<int> indices(3);
							for (int k = 0; k < 3; ++k)
								indices[k] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[3][k]]];
							sort(indices.begin(), indices.end());
							uKey0 = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
							map<int, int>::iterator findPos = vtxMap.find(uKey0);
							if (findPos != vtxMap.end()) {
								uID0 = findPos->second;
								uPos0 = vertices[uID0].m_pos;
							} else {
								uID0 = -1;
								uPos0.addWeighted(vPos[0], 0.25);
								uPos0.addWeighted(vPos[1], 0.25);
								uPos0.addWeighted(wPos[1], 0.25);
								uPos0.addWeighted(wPos[2], 0.25);
							}
						}
						KVector3d uPos1;
						int       uKey1;
						int       uID1;
						{
							vector<int> indices(3);
							for (int k = 0; k < 3; ++k)
								indices[k] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[2][k]]];
							sort(indices.begin(), indices.end());
							uKey1 = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
							map<int, int>::iterator findPos = vtxMap.find(uKey1);
							if (findPos != vtxMap.end()) {
								uID1 = findPos->second;
								uPos1 = vertices[uID1].m_pos;
							} else {
								uID1 = -1;
								uPos1.addWeighted(vPos[0], 0.25);
								uPos1.addWeighted(vPos[1], 0.25);
								uPos1.addWeighted(wPos[0], 0.25);
								uPos1.addWeighted(wPos[3], 0.25);
							}
						}
						KVector3d uPos2;
						int       uKey2;
						int       uID2 = -1;
						{
							for (int k = 0; k < 4; ++k) {
								uPos2.addWeighted(wPos[k], 0.25);
							}
							vector<int> indices(3);
							for (int k = 0; k < 3; ++k)
								indices[k] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[1][k]]];
							sort(indices.begin(), indices.end());
							uKey2 = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
						}
						KVector3d cPos;
						int       cKey;
						int       cID = -1;
						{
							for (int k = 0; k < 4; ++k) {
								cPos.add(wPos[k]);
							}
							cPos.add(vPos[0]);
							cPos.add(vPos[1]);
							cPos.scale(1. / 6);
							vector<int> indices(3);
							for (int k = 0; k < 3; ++k)
								indices[k] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[0][k]]];
							sort(indices.begin(), indices.end());
							cKey = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
						}
						addTetra(vertices, tetras, vtxMap,
							cPos, vPos[0], wPos[0], wPos[1],
							cKey, vKey[0], wKey[0], wKey[1],
							cID , vID [0], wID [0], wID [1]);
						addTetra(vertices, tetras, vtxMap,
							cPos, vPos[1], wPos[2], wPos[3],
							cKey, vKey[1], wKey[2], wKey[3],
							cID , vID [1], wID [2], wID [3]);
						// square pyramid c-v0-w1-w2-v1 divided into 4 tetrahedra using u0
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos0, vPos[0], wPos[1],
							cKey, uKey0, vKey[0], wKey[1],
							cID , uID0 , vID [0], wID [1]);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos0, wPos[1], wPos[2],
							cKey, uKey0, wKey[1], wKey[2],
							cID , uID0 , wID [1], wID [2]);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos0, wPos[2], vPos[1],
							cKey, uKey0, wKey[2], vKey[1],
							cID , uID0 , wID [2], vID [1]);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos0, vPos[1], vPos[0],
							cKey, uKey0, vKey[1], vKey[0],
							cID , uID0 , vID [1], vID [0]);

						// square pyramid c-v0-v1-w3-w0 divided into 4 tetrahedra using u1
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos1, vPos[0], vPos[1],
							cKey, uKey1, vKey[0], vKey[1],
							cID , uID1 , vID [0], vID [1]);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos1, vPos[1], wPos[3],
							cKey, uKey1, vKey[1], wKey[3],
							cID , uID1 , vID [1], wID [3]);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos1, wPos[3], wPos[0],
							cKey, uKey1, wKey[3], wKey[0],
							cID , uID1 , wID [3], wID [0]);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos1, wPos[0], vPos[0],
							cKey, uKey1, wKey[0], vKey[0],
							cID , uID1 , wID [0], vID [0]);
						// square pyramid c-w3-w2-w1-w0 divided into 4 tetrahedra using u2
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos2, wPos[3], wPos[2],
							cKey, uKey2, wKey[3], wKey[2],
							cID , uID2 , wID [3], wID [2]);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos2, wPos[2], wPos[1],
							cKey, uKey2, wKey[2], wKey[1],
							cID , uID2 , wID [2], wID [1]);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos2, wPos[1], wPos[0],
							cKey, uKey2, wKey[1], wKey[0],
							cID , uID2 , wID [1], wID [0]);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos2, wPos[0], wPos[3],
							cKey, uKey2, wKey[0], wKey[3],
							cID , uID2 , wID [0], wID [3]);
					}
					break;
				case 7:
				case 11:
				case 13:
				case 14:
// case 14
//     x---o
//    / \ .|
//   /  .\ |
//  / .   \|
// o.______o
					{
						KVector3d wPos[3];
						int       wKey[3];
						int       wID [3];
						for (int j = 0; j < 3; ++j) {
							int index0 = min(tet.m_vtx[mapping[0]], tet.m_vtx[mapping[j + 1]]);
							int index1 = max(tet.m_vtx[mapping[0]], tet.m_vtx[mapping[j + 1]]);
							wKey[j] = vtxSize * (vtxSize + 1) * index0 + index1;
							map<int, int>::iterator findPos = vtxMap.find(wKey[j]);
							if (findPos != vtxMap.end()) {
								wID[j] = findPos->second;
								wPos[j] = vertices[wID[j]].m_pos;
							} else {
								wID[j] = -1;
								double u = (threshold - val[mapping[0]]) / (val[mapping[j + 1]] - val[mapping[0]]);
								wPos[j] = vPos[0];
								wPos[j].scale(1 - u);
								wPos[j].addWeighted(vPos[j + 1], u);
							}
						}
						KVector3d uPos[3];
						int       uKey[3];
						int       uID [3];
						for (int j = 0; j < 3; ++j) {
							vector<int> indices(3);
							for (int k = 0; k < 3; ++k)
								indices[k] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[j + 1][k]]];
							sort(indices.begin(), indices.end());
							uKey[j] = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
							map<int, int>::iterator findPos = vtxMap.find(uKey[j]);
							if (findPos != vtxMap.end()) {
								uID[j] = findPos->second;
								uPos[j] = vertices[uID[j]].m_pos;
							} else {
								uID[j] = -1;
								uPos[j].addWeighted(wPos[(j + 1) % 3], 0.25);
								uPos[j].addWeighted(wPos[(j + 2) % 3], 0.25);
								uPos[j].addWeighted(vPos[(j + 1) % 3 + 1], 0.25);
								uPos[j].addWeighted(vPos[(j + 2) % 3 + 1], 0.25);
							}
						}
						KVector3d cPos;
						int       cKey;
						int       cID = -1;
						{
							for (int j = 0; j < 3; ++j) {
								cPos.add(vPos[j + 1]);
								cPos.add(wPos[j]);
							}
							cPos.scale(1. / 6);
							vector<int> indices(3);
							for (int j = 0; j < 3; ++j)
								indices[j] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[0][j]]];
							sort(indices.begin(), indices.end());
							cKey = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
						}
						addTetra(vertices, tetras, vtxMap,
							cPos, wPos[0], wPos[2], wPos[1],
							cKey, wKey[0], wKey[2], wKey[1],
							cID,  wID [0], wID [2], wID [1]);
						addTetra(vertices, tetras, vtxMap,
							cPos, vPos[1], vPos[2], vPos[3],
							cKey, vKey[1], vKey[2], vKey[3],
							cID,  vID [1], vID [2], vID [3]);
						for (int j = 0; j < 3; ++j) {
							addTetra(vertices, tetras, vtxMap,
								cPos, uPos[j], wPos[(j + 1) % 3], wPos[(j + 2) % 3], 
								cKey, uKey[j], wKey[(j + 1) % 3], wKey[(j + 2) % 3],
								cID,  uID [j], wID [(j + 1) % 3], wID [(j + 2) % 3]);
							addTetra(vertices, tetras, vtxMap,
								cPos, uPos[j], vPos[(j + 2) % 3 + 1], vPos[(j + 1) % 3 + 1], 
								cKey, uKey[j], vKey[(j + 2) % 3 + 1], vKey[(j + 1) % 3 + 1],
								cID,  uID [j], vID [(j + 2) % 3 + 1], vID [(j + 1) % 3 + 1]);
							addTetra(vertices, tetras, vtxMap,
								cPos, uPos[j], vPos[(j + 1) % 3 + 1], wPos[(j + 1) % 3], 
								cKey, uKey[j], vKey[(j + 1) % 3 + 1], wKey[(j + 1) % 3],
								cID,  uID [j], vID [(j + 1) % 3 + 1], wID [(j + 1) % 3]);
							addTetra(vertices, tetras, vtxMap,
								cPos, uPos[j], wPos[(j + 2) % 3], vPos[(j + 2) % 3 + 1], 
								cKey, uKey[j], wKey[(j + 2) % 3], vKey[(j + 2) % 3 + 1],
								cID,  uID [j], wID [(j + 2) % 3], vID [(j + 2) % 3 + 1]);
						}
					}
					break;
			}
		}
	}
	KTetraModel result;
	result.m_vertices = vertices;
	result.m_tetras = tetras;
	return result;
}

void KMarchingTetraSubdiv::addTetra(vector<KVertex>& vertices, vector<KTetra>& tetras, map<int, int>& vtxMap,
	const KVector3d& vPos0, const KVector3d& vPos1, const KVector3d& vPos2, const KVector3d& vPos3,
	const int&       vKey0, const int&       vKey1, const int&       vKey2, const int&       vKey3,
	int&       vID0,  int&       vID1,  int&       vID2,  int&       vID3) {
	const KVector3d* vPos_p[4] = {&vPos0, &vPos1, &vPos2, &vPos3};
	const int      * vKey_p[4] = {&vKey0, &vKey1, &vKey2, &vKey3};
	int      * vID_p [4] = {&vID0,  &vID1,  &vID2,  &vID3};
	for (int i = 0; i < 4; ++i) {
		if (*vID_p[i] == -1) {
			*vID_p[i] = (int)vertices.size();
			vertices.push_back(KVertex(*vPos_p[i]));
			vtxMap.insert(pair<int, int>(*vKey_p[i], *vID_p[i]));
		}
	}
	tetras.push_back(KTetra(vID0, vID1, vID2, vID3));
}

KMultiTexTetraModel KMarchingTetraSubdiv::calcMarchingTetraSubdiv(const KMultiTexTetraModel& tetra, const std::vector<double>& vtxValue, const double threshold) {
	static const int mapping_pattern[][4] = {
		{-1, -1, -1, -1},	//0
		{0, 1, 2, 3},	//1
		{1, 2, 0, 3},	//2
		{0, 1, 2, 3},	//3
		{2, 0, 1, 3},	//4
		{0, 2, 3, 1},	//5
		{1, 2, 0, 3},	//6
		{3, 2, 1, 0},	//7
		{3, 2, 1, 0},	//8
		{0, 3, 1, 2},	//9
		{1, 3, 2, 0},	//10
		{2, 0, 1, 3},	//11
		{2, 3, 0, 1},	//12
		{1, 2, 0, 3},	//13
		{0, 1, 2, 3},	//14
		{0, 1, 2, 3}	//15
	};
	
	int vtxSize = (int)tetra.m_vertices.size();
	int tetSize = (int)tetra.m_tetras.size();
	vector<KVertex> vertices;
	vector<KMultiTexTetra> tetras;
	map<int, int> vtxMap;
	for (int i = 0; i < tetSize; ++i) {
		const KMultiTexTetra& tet = tetra.m_tetras[i];
		const vector<KTetraTexCoord>& texCoords = tet.m_texCoords;
		const vector<int>&            tetIDs    = tet.m_texIDs;
		int code = 0;
		double val[4];
		for (int j = 0; j < 4; ++j) {
			val[j] = vtxValue[tet.m_vtx[j]];
			if (val[j] < threshold)
				code += (1 << j);
		}
		if (code == 0) continue;
		const int* mapping = mapping_pattern[code];
		KVector3d vPos[4];
		int       vKey[4];
		int       vID[4];
		vector<KVector3d> vCoord[4];
		for (int j = 0; j < 4; ++j) {
			int index = tet.m_vtx[mapping[j]];
			vKey[j] = (vtxSize * (vtxSize + 1) + 1) * index;
			map<int, int>::iterator findPos = vtxMap.find(vKey[j]);
			if (findPos != vtxMap.end()) {
				vID[j] = findPos->second;
			} else {
				vID[j] = -1;
			}
			vPos[j] = tetra.m_vertices[index].m_pos;
			vCoord[j].reserve(texCoords.size());
			for (int k = 0; k < (int)texCoords.size(); ++k) {
				vCoord[j].push_back(texCoords[k].m_coord[mapping[j]]);
			}
		}
		if (code == 15) {
			addTetra(
				vertices, tetras, vtxMap,
				vPos[0], vPos[1], vPos[2], vPos[3],
				vKey[0], vKey[1], vKey[2], vKey[3],
				vID [0], vID [1], vID [2], vID [3],
				vCoord[0], vCoord[1], vCoord[2], vCoord[3], tetIDs);
		} else {
//     v0--v2
//    / \ .|
//   /  .\ |
//  / .   \|
//v1.______v3
			switch(code) {
				// o : in
				// x : out
				case 1:
				case 2:
				case 4:
				case 8:
// case 1
//     o---x
//    / \ .|
//   /  .\ |
//  / .   \|
// x.______x
					{
						KVector3d wPos[3];
						int       wKey[3];
						int       wID [3];
						vector<KVector3d> wCoord[3];
						for (int j = 0; j < 3; ++j) {
							double u = (threshold - val[mapping[0]]) / (val[mapping[j + 1]] - val[mapping[0]]);
							wCoord[j].reserve(texCoords.size());
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex = vCoord[0][k];
								tex.scale(1 - u);
								tex.addWeighted(vCoord[j + 1][k], u);
								wCoord[j].push_back(tex);
							}
							int index0 = min(tet.m_vtx[mapping[0]], tet.m_vtx[mapping[j + 1]]);
							int index1 = max(tet.m_vtx[mapping[0]], tet.m_vtx[mapping[j + 1]]);
							wKey[j] = vtxSize * (vtxSize + 1) * index0 + index1;
							map<int, int>::iterator findPos = vtxMap.find(wKey[j]);
							if (findPos != vtxMap.end()) {
								wID[j] = findPos->second;
								wPos[j] = vertices[wID[j]].m_pos;
							} else {
								wID[j] = -1;
								wPos[j] = vPos[0];
								wPos[j].scale(1 - u);
								wPos[j].addWeighted(vPos[j + 1], u);
							}
						}
					addTetra(
						vertices, tetras, vtxMap,
						vPos[0], wPos[0], wPos[1], wPos[2],
						vKey[0], wKey[0], wKey[1], wKey[2],
						vID [0], wID [0], wID [1], wID [2],
						vCoord[0], wCoord[0], wCoord[1], wCoord[2], tetIDs);
					}
					break;
				case 3:
				case 5:
				case 6:
				case 9:
				case 10:
				case 12:
// case 3
//     o---x
//    / \ .|
//   /  .\ |
//  / .   \|
// o.______x
					{
						static int pairs[][2] = {{0, 3}, {0, 2}, {1, 2}, {1, 3}};
						KVector3d wPos[4];
						int       wKey[4];
						int       wID [4];
						vector<KVector3d> wCoord[4];
						for (int j = 0; j < 4; ++j) {
							const int& i0 = pairs[j][0];
							const int& i1 = pairs[j][1];
							double u = (threshold - val[mapping[i0]]) / (val[mapping[i1]] - val[mapping[i0]]);
							wCoord[j].reserve(texCoords.size());
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex = vCoord[i0][k];
								tex.scale(1 - u);
								tex.addWeighted(vCoord[i1][k], u);
								wCoord[j].push_back(tex);
							}
							int index0 = min(tet.m_vtx[mapping[i0]], tet.m_vtx[mapping[i1]]);
							int index1 = max(tet.m_vtx[mapping[i0]], tet.m_vtx[mapping[i1]]);
							wKey[j] = vtxSize * (vtxSize + 1) * index0 + index1;
							map<int, int>::iterator findPos = vtxMap.find(wKey[j]);
							if (findPos != vtxMap.end()) {
								wID[j] = findPos->second;
								wPos[j] = vertices[wID[j]].m_pos;
							} else {
								wID[j] = -1;
								wPos[j] = vPos[i0];
								wPos[j].scale(1 - u);
								wPos[j].addWeighted(vPos[i1], u);
							}
						}
						KVector3d uPos0;
						int       uKey0;
						int       uID0;
						vector<KVector3d> uCoord0;
						{
							uCoord0.reserve(texCoords.size());
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex;
								tex.addWeighted(vCoord[0][k], 0.25);
								tex.addWeighted(vCoord[1][k], 0.25);
								tex.addWeighted(wCoord[1][k], 0.25);
								tex.addWeighted(wCoord[2][k], 0.25);
								uCoord0.push_back(tex);
							}
							vector<int> indices(3);
							for (int j = 0; j < 3; ++j)
								indices[j] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[3][j]]];
							sort(indices.begin(), indices.end());
							uKey0 = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
							map<int, int>::iterator findPos = vtxMap.find(uKey0);
							if (findPos != vtxMap.end()) {
								uID0 = findPos->second;
								uPos0 = vertices[uID0].m_pos;
							} else {
								uID0 = -1;
								uPos0.addWeighted(vPos[0], 0.25);
								uPos0.addWeighted(vPos[1], 0.25);
								uPos0.addWeighted(wPos[1], 0.25);
								uPos0.addWeighted(wPos[2], 0.25);
							}
						}
						KVector3d uPos1;
						int       uKey1;
						int       uID1;
						vector<KVector3d> uCoord1;
						{
							uCoord1.reserve(texCoords.size());
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex;
								tex.addWeighted(vCoord[0][k], 0.25);
								tex.addWeighted(vCoord[1][k], 0.25);
								tex.addWeighted(wCoord[0][k], 0.25);
								tex.addWeighted(wCoord[3][k], 0.25);
								uCoord1.push_back(tex);
							}
							vector<int> indices(3);
							for (int j = 0; j < 3; ++j)
								indices[j] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[2][j]]];
							sort(indices.begin(), indices.end());
							uKey1 = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
							map<int, int>::iterator findPos = vtxMap.find(uKey1);
							if (findPos != vtxMap.end()) {
								uID1 = findPos->second;
								uPos1 = vertices[uID1].m_pos;
							} else {
								uID1 = -1;
								uPos1.addWeighted(vPos[0], 0.25);
								uPos1.addWeighted(vPos[1], 0.25);
								uPos1.addWeighted(wPos[0], 0.25);
								uPos1.addWeighted(wPos[3], 0.25);
							}
						}
						KVector3d uPos2;
						int       uKey2;
						int       uID2 = -1;
						vector<KVector3d> uCoord2;
						{
							uCoord2.reserve(texCoords.size());
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex;
								for (int j = 0; j < 4; ++j)
									tex.addWeighted(wCoord[j][k], 0.25);
								uCoord2.push_back(tex);
							}
							for (int j = 0; j < 4; ++j) {
								uPos2.addWeighted(wPos[j], 0.25);
							}
							vector<int> indices(3);
							for (int j = 0; j < 3; ++j)
								indices[j] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[1][j]]];
							sort(indices.begin(), indices.end());
							uKey2 = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
						}
						KVector3d cPos;
						int       cKey;
						int       cID = -1;
						vector<KVector3d> cCoord;
						{
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex;
								for (int j = 0; j < 4; ++j)
									tex.add(wCoord[j][k]);
								tex.add(vCoord[0][k]);
								tex.add(vCoord[1][k]);
								tex.scale(1. / 6);
								cCoord.push_back(tex);
							}
							for (int j = 0; j < 4; ++j) {
								cPos.add(wPos[j]);
							}
							cPos.add(vPos[0]);
							cPos.add(vPos[1]);
							cPos.scale(1. / 6);
							vector<int> indices(3);
							for (int k = 0; k < 3; ++k)
								indices[k] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[0][k]]];
							sort(indices.begin(), indices.end());
							cKey = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
						}
						addTetra(vertices, tetras, vtxMap,
							cPos, vPos[0], wPos[0], wPos[1],
							cKey, vKey[0], wKey[0], wKey[1],
							cID , vID [0], wID [0], wID [1],
							cCoord, vCoord[0], wCoord[0], wCoord[1], tetIDs);
						addTetra(vertices, tetras, vtxMap,
							cPos, vPos[1], wPos[2], wPos[3],
							cKey, vKey[1], wKey[2], wKey[3],
							cID , vID [1], wID [2], wID [3],
							cCoord, vCoord[1], wCoord[2], wCoord[3], tetIDs);
						// square pyramid c-v0-w1-w2-v1 divided into 4 tetrahedra using u0
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos0, vPos[0], wPos[1],
							cKey, uKey0, vKey[0], wKey[1],
							cID , uID0 , vID [0], wID [1],
							cCoord, uCoord0, vCoord[0], wCoord[1], tetIDs);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos0, wPos[1], wPos[2],
							cKey, uKey0, wKey[1], wKey[2],
							cID , uID0 , wID [1], wID [2],
							cCoord, uCoord0, wCoord[1], wCoord[2], tetIDs);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos0, wPos[2], vPos[1],
							cKey, uKey0, wKey[2], vKey[1],
							cID , uID0 , wID [2], vID [1],
							cCoord, uCoord0, wCoord[2], vCoord[1], tetIDs);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos0, vPos[1], vPos[0],
							cKey, uKey0, vKey[1], vKey[0],
							cID , uID0 , vID [1], vID [0],
							cCoord, uCoord0, vCoord[1], vCoord[0], tetIDs);
						// square pyramid c-v0-v1-w3-w0 divided into 4 tetrahedra using u1
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos1, vPos[0], vPos[1],
							cKey, uKey1, vKey[0], vKey[1],
							cID , uID1 , vID [0], vID [1],
							cCoord, uCoord1, vCoord[0], vCoord[1], tetIDs);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos1, vPos[1], wPos[3],
							cKey, uKey1, vKey[1], wKey[3],
							cID , uID1 , vID [1], wID [3],
							cCoord, uCoord1, vCoord[1], wCoord[3], tetIDs);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos1, wPos[3], wPos[0],
							cKey, uKey1, wKey[3], wKey[0],
							cID , uID1 , wID [3], wID [0],
							cCoord, uCoord1, wCoord[3], wCoord[0], tetIDs);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos1, wPos[0], vPos[0],
							cKey, uKey1, wKey[0], vKey[0],
							cID , uID1 , wID [0], vID [0],
							cCoord, uCoord1, wCoord[0], vCoord[0], tetIDs);
						// square pyramid c-w3-w2-w1-w0 divided into 4 tetrahedra using u2
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos2, wPos[3], wPos[2],
							cKey, uKey2, wKey[3], wKey[2],
							cID , uID2 , wID [3], wID [2],
							cCoord, uCoord2, wCoord[3], wCoord[2], tetIDs);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos2, wPos[2], wPos[1],
							cKey, uKey2, wKey[2], wKey[1],
							cID , uID2 , wID [2], wID [1],
							cCoord, uCoord2, wCoord[2], wCoord[1], tetIDs);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos2, wPos[1], wPos[0],
							cKey, uKey2, wKey[1], wKey[0],
							cID , uID2 , wID [1], wID [0],
							cCoord, uCoord2, wCoord[1], wCoord[0], tetIDs);
						addTetra(vertices, tetras, vtxMap,
							cPos, uPos2, wPos[0], wPos[3],
							cKey, uKey2, wKey[0], wKey[3],
							cID , uID2 , wID [0], wID [3],
							cCoord, uCoord2, wCoord[0], wCoord[3], tetIDs);
					}
					break;
				case 7:
				case 11:
				case 13:
				case 14:
// case 14
//     x---o
//    / \ .|
//   /  .\ |
//  / .   \|
// o.______o
					{
						KVector3d wPos[3];
						int       wKey[3];
						int       wID [3];
						vector<KVector3d> wCoord[3];
						for (int j = 0; j < 3; ++j) {
							double u = (threshold - val[mapping[0]]) / (val[mapping[j + 1]] - val[mapping[0]]);
							wCoord[j].reserve(texCoords.size());
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex = vCoord[0][k];
								tex.scale(1 - u);
								tex.addWeighted(vCoord[j + 1][k], u);
								wCoord[j].push_back(tex);
							}
							int index0 = min(tet.m_vtx[mapping[0]], tet.m_vtx[mapping[j + 1]]);
							int index1 = max(tet.m_vtx[mapping[0]], tet.m_vtx[mapping[j + 1]]);
							wKey[j] = vtxSize * (vtxSize + 1) * index0 + index1;
							map<int, int>::iterator findPos = vtxMap.find(wKey[j]);
							if (findPos != vtxMap.end()) {
								wID[j] = findPos->second;
								wPos[j] = vertices[wID[j]].m_pos;
							} else {
								wID[j] = -1;
								wPos[j] = vPos[0];
								wPos[j].scale(1 - u);
								wPos[j].addWeighted(vPos[j + 1], u);
							}
						}
						KVector3d uPos[3];
						int       uKey[3];
						int       uID [3];
						vector<KVector3d> uCoord[3];
						for (int j = 0; j < 3; ++j) {
							uCoord[j].reserve(texCoords.size());
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex;
								tex.addWeighted(wCoord[(j + 1) % 3][k], 0.25);
								tex.addWeighted(wCoord[(j + 2) % 3][k], 0.25);
								tex.addWeighted(vCoord[(j + 1) % 3 + 1][k], 0.25);
								tex.addWeighted(vCoord[(j + 2) % 3 + 1][k], 0.25);
								uCoord[j].push_back(tex);
							}
							vector<int> indices(3);
							for (int k = 0; k < 3; ++k)
								indices[k] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[j + 1][k]]];
							sort(indices.begin(), indices.end());
							uKey[j] = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
							map<int, int>::iterator findPos = vtxMap.find(uKey[j]);
							if (findPos != vtxMap.end()) {
								uID[j] = findPos->second;
								uPos[j] = vertices[uID[j]].m_pos;
							} else {
								uID[j] = -1;
								uPos[j].addWeighted(wPos[(j + 1) % 3], 0.25);
								uPos[j].addWeighted(wPos[(j + 2) % 3], 0.25);
								uPos[j].addWeighted(vPos[(j + 1) % 3 + 1], 0.25);
								uPos[j].addWeighted(vPos[(j + 2) % 3 + 1], 0.25);
							}
						}
						KVector3d cPos;
						int       cKey;
						int       cID = -1;
						vector<KVector3d> cCoord;
						{
							cCoord.reserve(texCoords.size());
							for (int k = 0; k < (int)texCoords.size(); ++k) {
								KVector3d tex;
								for (int j = 0; j < 3; ++j) {
									tex.add(wCoord[j][k]);
									tex.add(vCoord[j + 1][k]);
								}
								tex.scale(1. / 6);
								cCoord.push_back(tex);
							}
							for (int j = 0; j < 3; ++j) {
								cPos.add(vPos[j + 1]);
								cPos.add(wPos[j]);
							}
							cPos.scale(1. / 6);
							vector<int> indices(3);
							for (int j = 0; j < 3; ++j)
								indices[j] = tet.m_vtx[mapping[KTetraModel::FACE_VTX_ORDER[0][j]]];
							sort(indices.begin(), indices.end());
							cKey = vtxSize * vtxSize * indices[0] + vtxSize * indices[1] + indices[2];
						}
						addTetra(vertices, tetras, vtxMap,
							cPos, wPos[0], wPos[2], wPos[1],
							cKey, wKey[0], wKey[2], wKey[1],
							cID,  wID [0], wID [2], wID [1],
							cCoord, wCoord[0], wCoord[2], wCoord[1], tetIDs);
						addTetra(vertices, tetras, vtxMap,
							cPos, vPos[1], vPos[2], vPos[3],
							cKey, vKey[1], vKey[2], vKey[3],
							cID,  vID [1], vID [2], vID [3],
							cCoord, vCoord[1], vCoord[2], vCoord[3], tetIDs);
						for (int j = 0; j < 3; ++j) {
							addTetra(vertices, tetras, vtxMap,
								cPos, uPos[j], wPos[(j + 1) % 3], wPos[(j + 2) % 3], 
								cKey, uKey[j], wKey[(j + 1) % 3], wKey[(j + 2) % 3],
								cID,  uID [j], wID [(j + 1) % 3], wID [(j + 2) % 3],
								cCoord,  uCoord[j], wCoord[(j + 1) % 3], wCoord[(j + 2) % 3], tetIDs);
							addTetra(vertices, tetras, vtxMap,
								cPos, uPos[j], vPos[(j + 2) % 3 + 1], vPos[(j + 1) % 3 + 1], 
								cKey, uKey[j], vKey[(j + 2) % 3 + 1], vKey[(j + 1) % 3 + 1],
								cID,  uID [j], vID [(j + 2) % 3 + 1], vID [(j + 1) % 3 + 1],
								cCoord,  uCoord[j], vCoord[(j + 2) % 3 + 1], vCoord[(j + 1) % 3 + 1], tetIDs);
							addTetra(vertices, tetras, vtxMap,
								cPos, uPos[j], vPos[(j + 1) % 3 + 1], wPos[(j + 1) % 3], 
								cKey, uKey[j], vKey[(j + 1) % 3 + 1], wKey[(j + 1) % 3],
								cID,  uID [j], vID [(j + 1) % 3 + 1], wID [(j + 1) % 3],
								cCoord,  uCoord[j], vCoord[(j + 1) % 3 + 1], wCoord[(j + 1) % 3], tetIDs);
							addTetra(vertices, tetras, vtxMap,
								cPos, uPos[j], wPos[(j + 2) % 3], vPos[(j + 2) % 3 + 1], 
								cKey, uKey[j], wKey[(j + 2) % 3], vKey[(j + 2) % 3 + 1],
								cID,  uID [j], wID [(j + 2) % 3], vID [(j + 2) % 3 + 1],
								cCoord,  uCoord[j], wCoord[(j + 2) % 3], vCoord[(j + 2) % 3 + 1], tetIDs);
						}
					}
					break;
			}
		}
	}
	KMultiTexTetraModel result;
	result.m_vertices = vertices;
	result.m_tetras = tetras;
	return result;
}

void KMarchingTetraSubdiv::addTetra(vector<KVertex>& vertices, vector<KMultiTexTetra>& tetras, map<int, int>& vtxMap,
	const KVector3d& vPos0, const KVector3d& vPos1, const KVector3d& vPos2, const KVector3d& vPos3,
	const int&       vKey0, const int&       vKey1, const int&       vKey2, const int&       vKey3,
	int&       vID0,  int&       vID1,  int&       vID2,  int&       vID3,
	const vector<KVector3d>& vCoord0, const vector<KVector3d>& vCoord1, const vector<KVector3d>& vCoord2, const vector<KVector3d>& vCoord3,
	const vector<int>& tetIDs) {
	const KVector3d* vPos_p[4] = {&vPos0, &vPos1, &vPos2, &vPos3};
	const int      * vKey_p[4] = {&vKey0, &vKey1, &vKey2, &vKey3};
	int      * vID_p [4] = {&vID0,  &vID1,  &vID2,  &vID3};
	for (int i = 0; i < 4; ++i) {
		if (*vID_p[i] == -1) {
			*vID_p[i] = (int)vertices.size();
			vertices.push_back(KVertex(*vPos_p[i]));
			vtxMap.insert(pair<int, int>(*vKey_p[i], *vID_p[i]));
		}
	}
	KMultiTexTetra tet(vID0, vID1, vID2, vID3);
	tet.m_texCoords.reserve(vCoord0.size());
	for (int i = 0; i < (int)vCoord0.size(); ++i)
		tet.m_texCoords.push_back(KTetraTexCoord(vCoord0[i], vCoord1[i], vCoord2[i], vCoord3[i]));
	tet.m_texIDs = tetIDs;
	tetras.push_back(tet);
}

