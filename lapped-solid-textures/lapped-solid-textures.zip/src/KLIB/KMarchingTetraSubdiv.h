#pragma once

#include "KMultiTexGeometry.h"

#include <vector>
#include <map>

class KMarchingTetraSubdiv
{
	KMarchingTetraSubdiv(void);
	~KMarchingTetraSubdiv(void);
public:
	static KTetraModel calcMarchingTetraSubdiv(const KTetraModel& tetra, const std::vector<double>& vtxValue, const double threshold);
protected:
	static void addTetra(std::vector<KVertex>& vertices, std::vector<KTetra>& tetras, std::map<int, int>& vtxMap,
		const KVector3d& vPos0, const KVector3d& vPos1, const KVector3d& vPos2, const KVector3d& vPos3,
		const int&       vKey0, const int&       vKey1, const int&       vKey2, const int&       vKey3,
		int&       vID0,  int&       vID1, int&       vID2,  int&       vID3);
public:
	static KMultiTexTetraModel calcMarchingTetraSubdiv(const KMultiTexTetraModel& tetra, const std::vector<double>& vtxValue, const double threshold);
protected:
	static void addTetra(std::vector<KVertex>& vertices, std::vector<KMultiTexTetra>& tetras, std::map<int, int>& vtxMap,
		const KVector3d& vPos0, const KVector3d& vPos1, const KVector3d& vPos2, const KVector3d& vPos3,
		const int&       vKey0, const int&       vKey1, const int&       vKey2, const int&       vKey3,
		int&       vID0,  int&       vID1, int&       vID2,  int&       vID3,
		const std::vector<KVector3d>& vCoord0, const std::vector<KVector3d>& vCoord1, const std::vector<KVector3d>& vCoord2, const std::vector<KVector3d>& vCoord3,
		const std::vector<int>& tetIDs);
};
