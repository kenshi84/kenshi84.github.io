#pragma once

#include "Drawer.h"
#include "EventHandler.h"
#include "State.h"
#include "VolumeHeader.h"
#include <KLIB/KLaplacianSmoothing.h>

#include <KLIB/KOGL.h>
#include <KLIB/KMultiTexGeometry.h>
#include <KLIB/KRBF.h>
#include <KLIB/KLappedSolidTexture.h>
#include <KLIB/KUmfpackSparseMatrix.h>

#include <vector>
#include <string>
#include <map>

class CMainFrame;

class Core
{
protected:
	static const char MASKFNAME[];
public:
	static const double GRADIENT_DELTA;
	static const int VOLSIZE;
	static const int LAYER_MAX;
	//static const bool FLAG_DEBUG;

protected:
	Core(void);
	~Core(void);
public:
	static Core* getInstance() {
		static Core p;
		return &p;
	}
	CMainFrame* p_mainFrm;
	CView* p_view;
	
	KOGL m_ogl;
	Drawer m_drawer;
	EventHandler m_handler;
	
	// "Lapped Solid Texture" core algorithm object
	KLappedSolidTexture m_lst;
	
	// tetra model originally loaded
	KMultiTexTetraModel m_tetraOrg;
	void loadTetraOrg(const std::string& fname);
	
	// mask data (1ch) for LST
	std::vector<GLubyte> m_volMask;
	void loadMask(const std::string& fname);
	
	// field data required for LST
	std::vector<KVector3d> m_tetVectorS;
	std::vector<KVector3d> m_tetVectorT;
	std::vector<double> m_vtxDepth;
	std::vector<double> m_tetDepth;
	std::vector<double> m_tetScale;
	KThinPlate3D m_rbfDepth;
	void updateDepth();
	
	// input solid texture
	int m_numChannels;
	std::vector<GLubyte> m_volInput;
	bool loadVolInput(const std::string& fname);
	// masked solid texture (split into 3 parts when layers available)
	std::vector<GLubyte> m_volMiddle;
	std::vector<GLubyte> m_volInner;
	std::vector<GLubyte> m_volOuter;
	void calcVolMiddle();
	void calcVolInOut();
	// manual solid textures
	std::vector<std::vector<GLubyte> > m_volManual;
	bool loadVolManual(const std::string& fname);
	// solid texture list for browsing
	std::vector<std::vector<GLubyte> > m_volBrowse;
	
	// displacement map (08.01.08)
	std::vector<GLubyte> m_volInputDisp;
	bool loadVolInputDisp(const std::string& fname);
	std::vector<GLubyte> m_volMiddleDisp;
	std::vector<GLubyte> m_volInnerDisp;
	std::vector<GLubyte> m_volOuterDisp;
	void calcVolMiddleDisp();
	void calcVolInOutDisp();
	std::vector<std::vector<GLubyte> > m_volManualDisp;
	bool loadVolManualDisp(const std::string& fname);
	
	std::vector<std::vector<GLubyte> > m_volBrowseDisp;

	// state variable
	State* m_state;
	enum {
		MODE_ISOTROPIC,
		MODE_SglDirHomo,		// single direction, homogeneous: requires vector field
		MODE_SglDirLayer,		// single direction, layered    : requires depth field
		MODE_DblDirHomo,		// double direction, homogeneous: requires tensor field
		MODE_DblDirLayer		// double direction, layered    : requires depth field + vector field
	} m_mode;
	
	// Laplacian smoothing object
	KLaplacianSmoothing m_laplacian;
	KLaplacianSmoothing m_laplacianDepth;
	void constructLaplacian();
	void constructLaplacianDepth();
	void calcTetVectorByLaplacian     (std::vector<KVector3d>& tetVector, const std::vector<std::vector<KVector3d> >& strokes);
	void calcTetVectorByLaplacianDepth(std::vector<KVector3d>& tetVector, const std::vector<std::vector<KVector3d> >& strokes);
	
	// tetra model being cut
	KMultiTexTetraModel m_tetraCut;
	KMultiTexPolygonModel m_polyCut;
	std::vector<int> m_polyIDs_oncutplane;
	std::vector<double> m_vtxValueCut;
	void initCut();
	void calcCutSubdiv(const std::vector<KVector3d>& cutStroke);
	void calcVtxValueCut(const std::vector<KVector3d>& cutStroke);
	void updateCut();
	// cut stroke
	std::vector<KVector3d> m_cutStroke;
	
	// sample cube to display solid texture exemplar
	KMultiTexTetraModel m_tetraCube;
	void constructTetraCube();
	
	// patch data (required for interactive dragging)
	int m_seed;
	std::vector<int> m_patch;
	std::map<int, KVector3d> m_optimized;
	KMultiTexPolygonModel m_polyPatch;
	void calcPolyPatch();
	
	// slices for volume rendering
	KMultiTexPolygonModel m_polySlice;
	void updatePolySlice(const KMultiTexTetraModel& tetra, int numSlice = 200);
	
	// strokes to specify vector field
	std::vector<std::vector<KVector3d> > m_strokes;
	double m_strokeRadius;
	void calcStrokeRadius();
	
	// layers
	std::vector<KMultiTexPolygonModel> m_polyLayers;
	void calcPolyLayers();
	
	void setFocusCenter();
};
