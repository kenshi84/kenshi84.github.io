#include "StdAfx.h"
#include "StateDepthPaint.h"
#include "MainFrm.h"
#include "StateLoadSolid.h"
#include "StateProcess.h"
#include "StatePeelStroke.h"
#include "MainFrm.h"

#include <KLIB/KDrawer.h>
#include <KLIB/KUtil.h>
#include <KLIB/KRBF.h>

#include <algorithm>
using namespace std;

State* StateDepthPaint::next() {
	Core& core = *Core::getInstance();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_depthPaint, false, true);
	if (core.m_mode == Core::MODE_SglDirLayer || core.m_mode == Core::MODE_DblDirLayer) {
		core.calcVolInOut();
		core.m_drawer.genTexInner();
		core.m_drawer.genTexOuter();
		//double xmax, ymax, zmax;
		//double xmin, ymin, zmin;
		//KUtil::getBoundingBox(core.m_tetraOrg, xmin, ymin, zmin, xmax, ymax, zmax);
		//double minEdgeLength = max(max(xmax - xmin, ymax - ymin), zmax - zmin) * 0.05;
		//subdivideOnSingularity(0);
		//subdivideOnSingularity(0);
	}
	
	if (core.m_mode == Core::MODE_SglDirLayer)
		return StateProcess::getInstance();
	else
		return StatePeelStroke::getInstance();
}

//bool StateDepthPaint::subdivideOnSingularity(double minEdgeLength) {
//	Core& core = *Core::getInstance();
//	KMultiTexTetraModel& tetra = Core::getInstance()->m_tetraOrg;
//	//bool changed = false;
//	vector<KMultiTexTetra> added;
//	for (vector<KMultiTexTetra>::iterator i = tetra.m_tetras.begin(); i != tetra.m_tetras.end();) {
//		KMultiTexTetra& tet = *i;
//		double maxEdgeLength = 0;
//		for (int j = 0; j < 4; ++j) {
//			KVector3d& pos0 = tetra.m_vertices[tet.m_vtx[j]].m_pos;
//			KVector3d& pos1 = tetra.m_vertices[tet.m_vtx[(j + 1) % 4]].m_pos;
//			KVector3d e(pos0);
//			e.sub(pos1);
//			maxEdgeLength = max(maxEdgeLength, e.length());
//		}
//		if (maxEdgeLength < minEdgeLength) {
//			++i;
//			continue;
//		}
//		KVector3d grad[4];
//		for (int j = 0; j < 4; ++j) {
//			KVector3d& pos = tetra.m_vertices[tet.m_vtx[j]].m_pos;
//			double f = core.m_rbfDepth.getValue(pos);
//			double gx = core.m_rbfDepth.getValue(pos.x + Core::GRADIENT_DELTA, pos.y, pos.z) - f;
//			double gy = core.m_rbfDepth.getValue(pos.x, pos.y + Core::GRADIENT_DELTA, pos.z) - f;
//			double gz = core.m_rbfDepth.getValue(pos.x, pos.y, pos.z + Core::GRADIENT_DELTA) - f;
//			grad[j] = KVector3d(gx, gy, gz);
//		}
//		bool needSubdiv = false;
//		for (int j = 0; j < 4; ++j) {
//			for (int k = j + 1; k < 4; ++k) {
//				if (grad[j].dot(grad[k]) < 0) {
//					needSubdiv = true;
//					break;
//				}
//			}
//			if (needSubdiv) break;
//		}
//		if (!needSubdiv) {
//			++i;
//			continue;
//		}
//		//changed = true;
//		KVector3d c;
//		KUtil::getBarycenter(c, tetra, tet);
//		int vtxID = (int)tetra.m_vertices.size();
//		tetra.m_vertices.push_back(KVertex(c));
//		for (int j = 0; j < 4; ++j) {
//			added.push_back(KMultiTexTetra(
//				vtxID,
//				tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][0]], 
//				tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][1]], 
//				tet.m_vtx[KTetraModel::FACE_VTX_ORDER[j][2]]));
//		}
//		i = tetra.m_tetras.erase(i);
//	}
//	for (int i = 0; i < (int)added.size(); ++i)
//		tetra.m_tetras.push_back(added[i]);
//	return !added.empty();
//	//return changed;
//}

bool StateDepthPaint::isReady() {
	return !m_points.empty();
}

void StateDepthPaint::init() {
	Core& core = *Core::getInstance();
	core.m_ogl.makeOpenGLCurrent();
	glBindTexture(GL_TEXTURE_1D, core.m_drawer.m_texNameDepth);
	core.m_drawer.genTexDepth();
	core.initCut();
	core.m_polyCut.calcNeighbor();
	core.setFocusCenter();
	core.calcStrokeRadius();
	core.m_vtxDepth.clear();
	m_currentColor = COLOR_OUT;
	m_currentTool  = TOOL_MULTIFACE;
	m_points.clear();
	m_values.clear();
	m_faceColor.resize(core.m_polyCut.m_polygons.size(), COLOR_ERASE);
	m_strokes.clear();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_depthPaint, true, true);
}

void StateDepthPaint::draw() {
	Core& core = *Core::getInstance();
	KMultiTexPolygonModel& poly = core.m_polyCut;
	
	glColor3dv(Drawer::COLOR_FACE);
	glEnable(GL_LIGHTING);
	if (!m_points.empty()) {
		glEnable(GL_TEXTURE_1D);
		glBindTexture(GL_TEXTURE_1D, core.m_drawer.m_texNameDepth);
	}
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& n = p.m_normal[j];
			KVector3d& v = poly.m_vertices[p.m_vtx[j]].m_pos;
			if (!m_points.empty()) {
				glTexCoord1d(p.m_texCoords[0].m_coord[j].x);
			}
			glNormal3dv(n.getPtr());
			glVertex3dv(v.getPtr());
		}
	}
	glEnd();
	if (!m_points.empty()) {
		glDisable(GL_TEXTURE_1D);
	}
	
	// draw constraint faces!
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		DepthColor& col = m_faceColor[i];
		if (col == COLOR_ERASE) continue;
		callGlColor3d(col);
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& n = p.m_normal[j];
			KVector3d& v = poly.m_vertices[p.m_vtx[j]].m_pos;
			glNormal3dv(n.getPtr());
			glVertex3dv(v.getPtr());
		}
	}
	glEnd();
	
	// draw constraint strokes!
	for (int i = 0; i < (int)m_strokes.size(); ++i) {
		DepthColor& col = m_strokes[i].first;
		callGlColor3d(col);
		vector<KVector3d>& stroke = m_strokes[i].second;
		for (int j = 1; j < (int)stroke.size(); ++j) {
			KVector3d& p0 = stroke[j - 1];
			KVector3d& p1 = stroke[j];
			KVector3d d;
			d.sub(p1, p0);
			d.scale(1.2);
			KDrawer::drawCylinder(p0, d, core.m_strokeRadius);
		}
	}
	
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);
	glColor3dv(Drawer::COLOR_CUTSTROKE);
	glLineWidth(5);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < (int)core.m_cutStroke.size(); ++i)
		glVertex3dv(core.m_cutStroke[i].getPtr());
	glEnd();
	glDepthMask(GL_TRUE);
	glEnable(GL_DEPTH_TEST);
}

void StateDepthPaint::postDraw(CWnd* hWnd, CDC* pDC) {
	Core& core = *Core::getInstance();
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	pDC->DrawText ( "Paint depth field!", -1, &rc, DT_LEFT | DT_TOP | DT_SINGLELINE);
	pDC->SelectObject ( pOldFont );
}

void StateDepthPaint::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	m_pointOld = point;
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) {
		m_isDrawing = true;
		if (m_currentTool == TOOL_STROKE) {
			m_strokes.push_back(pair<DepthColor, vector<KVector3d> >(m_currentColor, vector<KVector3d>()));
		} else if (m_currentTool == TOOL_FACE) {
			fillFace(polyID, m_currentColor);
		} else {
			fillMultiFace(polyID, m_currentColor);
		}
	} else {
		start.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(start);
		m_isCutting = true;
	}
	core.m_ogl.RedrawWindow();
}

void StateDepthPaint::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isDrawing) {
		m_isDrawing = false;
	} else if (m_isCutting) {
		if (core.m_cutStroke.size() == 1) {
			core.initCut();
		} else {
			core.calcVtxValueCut(core.m_cutStroke);
			core.updateCut();
		}
		core.m_polyCut.calcNeighbor();
		m_strokes.clear();
		m_faceColor.clear();
		m_faceColor.resize(core.m_polyCut.m_polygons.size(), COLOR_ERASE);
		core.m_cutStroke.clear();
		core.m_ogl.RedrawWindow();
		m_isCutting = false;
	}
}

void StateDepthPaint::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			Core::getInstance()->m_ogl.ButtonDownForTranslate(point);
		} else {
			Core::getInstance()->m_ogl.ButtonDownForRotate(point);
		}
	}else {
		Core::getInstance()->m_ogl.ButtonDownForZoom(point);
	}
	m_isRButtonDown = true;
}

void StateDepthPaint::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core::getInstance()->m_ogl.ButtonUp();
	m_isRButtonDown = false;
}

void StateDepthPaint::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isRButtonDown) {
		core.m_ogl.MouseMove(point);
		return;
	}
	if (!m_isCutting && !m_isDrawing) return;
	double dx = point.x - m_pointOld.x;
	double dy = point.y - m_pointOld.y;
	double dist = sqrt(dx * dx + dy * dy);
	if (dist < 10) return;
	m_pointOld = point;
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	if (m_isCutting) {
		start.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(start);
	} else {
		KVector3d pos;
		int polyID;
		if (KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) {
			if (m_currentTool == TOOL_STROKE) {
				m_strokes.back().second.push_back(pos);
			} else if (m_currentTool == TOOL_FACE) {
				fillFace(polyID, m_currentColor);
			}
		}
	}
	core.m_ogl.RedrawWindow();
}

void StateDepthPaint::update() {
	bool noFaceConstrained = true;
	KMultiTexPolygonModel& poly = Core::getInstance()->m_polyCut;
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		DepthColor col = m_faceColor[i];
		if (col == COLOR_ERASE) continue;
		noFaceConstrained = false;
		KMultiTexPolygon& p = poly.m_polygons[i];
		KVector3d pos;
		KUtil::getBarycenter(pos, poly, p);
		m_points.push_back(pos);
		m_values.push_back(col2val(col));
	}
	if (noFaceConstrained && m_strokes.empty()) return;
	for (int i = 0; i < (int)m_strokes.size(); ++i) {
		DepthColor col = m_strokes[i].first;
		double val = col2val(col);
		vector<KVector3d>& stroke = m_strokes[i].second;
		for (int j = 0; j < (int)stroke.size(); ++j) {
			m_points.push_back(stroke[j]);
			m_values.push_back(val);
		}
	}
	
	Core& core = *Core::getInstance();
	KMultiTexTetraModel& tetra = Core::getInstance()->m_tetraOrg;
	core.m_vtxDepth.resize(tetra.m_vertices.size());
	{	// RBF
		core.m_rbfDepth.setPoints(m_points);
		core.m_rbfDepth.setValues(m_values);
		core.updateDepth();
	}
	//{	// Laplacian smoothing
	//	int numVtx = (int)tetra.m_vertices.size();
	//	vector<KSparseVector> C(m_points.size(), KSparseVector(numVtx, 4));
	//	for (int i = 0; i < (int)m_points.size(); ++i) {
	//		KVector3d& point = m_points[i];
	//		int    vID[4];
	//		double w[4];
	//		{
	//			int tetID;
	//			double dist;
	//			KUtil::getNearestTetraID(tetID, dist, tetra, point);
	//			KMultiTexTetra& tet = tetra.m_tetras[tetID];
	//			KVector3d v[4];
	//			for (int j = 0; j < 4; ++j) {
	//				vID[j] = tet.m_vtx[j];
	//				v[j] = tetra.m_vertices[vID[j]].m_pos;
	//			}
	//			KUtil::getLinearCoefficient(w[0], w[1], w[2], w[3], v[0], v[1], v[2], v[3], point);
	//		}
	//		KSparseVector& c = C[i];
	//		for (int j = 0; j < 4; ++j) {
	//			c.setValue(vID[j], w[j]);
	//		}
	//	}
	//	core.m_laplacian.setC(C);
	//	core.m_laplacian.solve(core.m_vtxDepth, m_values);
	//}
	for (int i = 0; i < (int)tetra.m_tetras.size(); ++i) {
		KMultiTexTetra& tet = tetra.m_tetras[i];
		tet.m_texCoords.clear();
		tet.m_texIDs.clear();
		KTetraTexCoord texCoord;
		for (int j = 0; j < 4; ++j)
			texCoord.m_coord[j] = KVector3d(core.m_vtxDepth[tet.m_vtx[j]], 0, 0);
		tet.m_texCoords.push_back(texCoord);
		tet.m_texIDs.push_back(-1);
	}
	core.updateCut();
	core.m_polyCut.calcNeighbor();
	m_strokes.clear();
	m_faceColor.clear();
	m_faceColor.resize(core.m_polyCut.m_polygons.size(), COLOR_ERASE);
}

void StateDepthPaint::fillFace     (const int& polyID, const DepthColor& col) {
	m_faceColor[polyID] = col;
}

void StateDepthPaint::fillMultiFace(const int& seedPolyID, const DepthColor& col) {
	DepthColor colOld = m_faceColor[seedPolyID];
	if (colOld == col) return;
	KMultiTexPolygonModel& poly = Core::getInstance()->m_polyCut;
	vector<int> candidates;
	candidates.push_back(seedPolyID);
	while (!candidates.empty()) {
		int id0 = candidates.back();
		candidates.pop_back();
		if (m_faceColor[id0] != colOld) continue;
		m_faceColor[id0] = col;
		KMultiTexPolygon& p0 = poly.m_polygons[id0];
		KVector3d& n0 = KUtil::calcNormal(p0, poly);
		for (int i = 0; i < 3; ++i) {
			int id1 = p0.m_neighbor[i];
			if (id1 == -1) continue;
			if (find(candidates.begin(), candidates.end(), id1) != candidates.end()) continue;
			KVector3d& n1 = KUtil::calcNormal(poly.m_polygons[id1], poly);
			double dot = n0.dot(n1);
			if (dot < 0.9)
				continue;
			candidates.push_back(id1);
		}
	}
}

