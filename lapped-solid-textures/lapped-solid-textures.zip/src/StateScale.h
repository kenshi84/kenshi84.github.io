#pragma once
#include "state.h"

#include "Core.h"
#include <vector>

class StateScale : public State {
	StateScale(void) {}
	~StateScale(void) {}
public:
	static State* getInstance() {
		static StateScale p;
		return &p;
	}
	State* next();
	bool isReady() {
		return !m_scaleConstraint.empty();
	}
	void init();
	void draw();
	void postDraw(CWnd* hWnd, CDC* pDC);
	void OnLButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnLButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnRButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnRButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnMouseMove  (CView* view, UINT nFlags, CPoint& point);
	void OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {}
	void OnDropFiles  (CView* view, HDROP hDropInfo) {}
	void OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt);
	void OnLButtonDblClk(CView* view, UINT nFlags, CPoint point);
	void set();
	void increase();
	void decrease();
protected:
	bool m_isRButtonDown;
	bool m_isCutting;
	bool m_isDragging;
	CPoint m_pointOld;
	double m_currentScale;
	KVector3d m_seedPos;
	std::vector<std::pair<KVector3d, double> > m_scaleConstraint;
};
