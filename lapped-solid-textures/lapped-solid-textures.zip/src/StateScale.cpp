#include "StdAfx.h"
#include "StateScale.h"
#include "StateProcess.h"
#include "MainFrm.h"

#include <KLIB/KSparseVector.h>

#include <KLIB/KUtil.h>
#include <KLIB/KRBF.h>

using namespace std;

State* StateScale::next() {
	Core& core = *Core::getInstance();
	vector<double> vtxScale(core.m_tetraOrg.m_vertices.size());
	{
		int numVtx = (int)core.m_tetraOrg.m_vertices.size();
		vector<KSparseVector> C(m_scaleConstraint.size(), KSparseVector(numVtx, 4));
		vector<double>        b(m_scaleConstraint.size());
		for (int i = 0; i < (int)m_scaleConstraint.size(); ++i) {
			KVector3d& pos   = m_scaleConstraint[i].first;
			double     scale = m_scaleConstraint[i].second;
			int    vID[4];
			double w[4];
			{
				int tetID;
				double dist;
				KUtil::getNearestTetraID(tetID, dist, core.m_tetraOrg, pos);
				KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[tetID];
				KVector3d v[4];
				for (int j = 0; j < 4; ++j) {
					vID[j] = tet.m_vtx[j];
					v[j] = core.m_tetraOrg.m_vertices[vID[j]].m_pos;
				}
				KUtil::getBarycentricCoord(w[0], w[1], w[2], w[3], v[0], v[1], v[2], v[3], pos, 1);
			}
			KSparseVector& c = C[i];
			for (int j = 0; j < 4; ++j) {
				c.setValue(vID[j], w[j]);
			}
			b[i] = scale;
		}
		core.m_laplacian.setC(C);
		core.m_laplacian.solve(vtxScale, b);
	}
	core.m_tetScale.resize(core.m_tetraOrg.m_tetras.size());
	for (int i = 0; i < (int)core.m_tetraOrg.m_tetras.size(); ++i) {
		KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[i];
		double s = 0;
		for (int j = 0; j < 4; ++j) {
			s += vtxScale[tet.m_vtx[j]];
		}
		s *= 0.25;
		core.m_tetScale[i] = s;
	}
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_scale, false, true);
	core.m_rbfDepth.clear();
	return StateProcess::getInstance();
}

void StateScale::init() {
	Core& core = *Core::getInstance();
	core.initCut();
	double xMin, yMin, zMin, xMax, yMax, zMax;
	KUtil::getBoundingBox(core.m_tetraOrg, xMin, yMin, zMin, xMax, yMax, zMax);
	m_currentScale = max(max(xMax - xMin, yMax - yMin), zMax - zMin) / 4;
	vector<double> tetScale(core.m_tetraOrg.m_tetras.size(), m_currentScale);
	//core.m_lst.setField(core.m_tetVectorS, core.m_tetVectorT, vector<double>(), tetScale);
	core.m_lst.setField(core.m_tetVectorS, core.m_tetVectorT, KThinPlate3D(), tetScale);
	core.m_patch.clear();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_scale, true, true);
	m_scaleConstraint.clear();
}

void StateScale::draw() {
	Core& core = *Core::getInstance();
	KMultiTexPolygonModel& poly = core.m_polyCut;
	glEnable(GL_LIGHTING);
	glColor3dv(Drawer::COLOR_FACE);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& n = p.m_normal[j];
			KVector3d& v = poly.m_vertices[p.m_vtx[j]].m_pos;
			glNormal3dv(n.getPtr());
			glVertex3dv(v.getPtr());
		}
	}
	glEnd();
	glEnable(GL_TEXTURE_3D);
	glEnable(GL_BLEND);
	glBindTexture(GL_TEXTURE_3D, core.m_drawer.m_texNameMiddle);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < (int)p.m_texCoords.size(); ++j) {
			for (int k = 0; k < 3; ++k) {
				KVector3d& n = p.m_normal[k];
				KVector3d& t = p.m_texCoords[j].m_coord[k];
				KVector3d& v = poly.m_vertices[p.m_vtx[k]].m_pos;
				glNormal3dv(n.getPtr());
				glTexCoord3dv(t.getPtr());
				glVertex3dv(v.getPtr());
			}
		}
	}
	KMultiTexPolygonModel& polyPatch = core.m_polyPatch;
	for (int i = 0; i < (int)polyPatch.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = polyPatch.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& n = p.m_normal[j];
			KVector3d& t = p.m_texCoords[0].m_coord[j];
			KVector3d& v = polyPatch.m_vertices[p.m_vtx[j]].m_pos;
			glNormal3dv(n.getPtr());
			glTexCoord3dv(t.getPtr());
			glVertex3dv(v.getPtr());
		}
	}
	glEnd();
	glDisable(GL_TEXTURE_3D);
	glDisable(GL_BLEND);
	
	// draw cutting stroke
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);
	glColor3dv(Drawer::COLOR_CUTSTROKE);
	glLineWidth(5);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < (int)core.m_cutStroke.size(); ++i)
		glVertex3dv(core.m_cutStroke[i].getPtr());
	glEnd();
	glEnable(GL_DEPTH_TEST);
	glDepthMask(GL_TRUE);
}

void StateScale::postDraw(CWnd* hWnd, CDC* pDC) {
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	pDC->DrawText ( "Set scales!", -1, &rc, DT_TOP | DT_LEFT | DT_SINGLELINE);
	pDC->SelectObject ( pOldFont );
}

void StateScale::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) {
		double dist;
		m_seedPos = pos;
		KUtil::getNearestTetraID(core.m_seed, dist, core.m_tetraOrg, m_seedPos);
		vector<double> tetScale(core.m_tetraOrg.m_tetras.size(), m_currentScale);
		core.m_lst.setScale(tetScale);
		int depthID;
		bool isUpdate = core.m_patch.empty();
		core.m_lst.pastePatch(core.m_seed, &pos, depthID, core.m_patch, core.m_optimized, vector<int>(), isUpdate);
		core.calcPolyPatch();
		core.m_ogl.RedrawWindow();
		m_isDragging = true;
		m_pointOld = point;
	} else {
		start.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(start);
		m_isCutting = true;
		m_pointOld = point;
	}
}
void StateScale::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isCutting) {
		m_isCutting = false;
		if (core.m_cutStroke.size() == 1) {
			core.initCut();
			core.calcPolyPatch();
		} else {
			core.calcVtxValueCut(core.m_cutStroke);
			core.updateCut();
			core.calcPolyPatch();
		}
		core.m_cutStroke.clear();
		core.m_ogl.RedrawWindow();
	} else if (m_isDragging) {
		m_isDragging = false;
	}
}
void StateScale::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			Core::getInstance()->m_ogl.ButtonDownForTranslate(point);
		} else {
			Core::getInstance()->m_ogl.ButtonDownForRotate(point);
		}
	}else {
		Core::getInstance()->m_ogl.ButtonDownForZoom(point);
	}
	m_isRButtonDown = true;
}
void StateScale::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core::getInstance()->m_ogl.ButtonUp();
	m_isRButtonDown = false;
}
void StateScale::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isRButtonDown) {
		core.m_ogl.MouseMove(point);
		return;
	}
	if (!m_isCutting && !m_isDragging) return;
	double dx = point.x - m_pointOld.x;
	double dy = point.y - m_pointOld.y;
	double dist = sqrt(dx * dx + dy * dy);
	if (dist < 5) return;
	m_pointOld = point;
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	if (m_isCutting) {
		start.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(start);
		core.m_ogl.RedrawWindow();
	} else {
		KVector3d pos;
		int polyID;
		if (KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) {
			double dist;
			m_seedPos = pos;
			KUtil::getNearestTetraID(core.m_seed, dist, core.m_tetraOrg, m_seedPos);
			vector<double> tetScale(core.m_tetraOrg.m_tetras.size(), m_currentScale);
			core.m_lst.setScale(tetScale);
			int depthID;
			core.m_lst.pastePatch(core.m_seed, &m_seedPos, depthID, core.m_patch, core.m_optimized, vector<int>(), false);
			core.calcPolyPatch();
			core.m_ogl.RedrawWindow();
		}
	}
}
void StateScale::OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt) {
	if (zDelta < 0)
		decrease();
	else
		increase();
}

void StateScale::OnLButtonDblClk(CView* view, UINT nFlags, CPoint point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) {
		set();
	}
}

void StateScale::set() {
	Core& core = *Core::getInstance();
	vector<int>&         patch     = core.m_patch;
	map<int, KVector3d>& optimized = core.m_optimized;
	for (int i = 0; i < (int)patch.size(); ++i) {
		int tetID = patch[i];
		KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[tetID];
		KTetraTexCoord texCoord;
		for (int j = 0; j < 4; ++j) {
			texCoord.m_coord[j] = optimized.find(tet.m_vtx[j])->second;
		}
		tet.m_texCoords.push_back(texCoord);
	}
	core.m_patch.clear();
	core.updateCut();
	core.m_polyPatch = KMultiTexPolygonModel();
	core.m_ogl.RedrawWindow();
	m_scaleConstraint.push_back(pair<KVector3d, double>(m_seedPos, m_currentScale));
}

void StateScale::increase() {
	Core& core = *Core::getInstance();
	m_currentScale *= 1.1;
	if (core.m_patch.empty()) return;
	vector<double> tetScale(core.m_tetraOrg.m_tetras.size(), m_currentScale);
	core.m_lst.setScale(tetScale);
	int depthID;
	core.m_lst.pastePatch(core.m_seed, &m_seedPos, depthID, core.m_patch, core.m_optimized, vector<int>(), false);
	core.calcPolyPatch();
	core.m_ogl.RedrawWindow();
}

void StateScale::decrease() {
	Core& core = *Core::getInstance();
	m_currentScale *= 0.9;
	if (core.m_patch.empty()) return;
	vector<double> tetScale(core.m_tetraOrg.m_tetras.size(), m_currentScale);
	core.m_lst.setScale(tetScale);
	int depthID;
	core.m_lst.pastePatch(core.m_seed, &m_seedPos, depthID, core.m_patch, core.m_optimized, vector<int>(), false);
	core.calcPolyPatch();
	core.m_ogl.RedrawWindow();
}
