#include "StdAfx.h"
#include "StateSDHStroke.h"
#include "StateScale.h"

#include <KLIB/KUtil.h>
#include <KLIB/KDrawer.h>

using namespace std;

State* StateSDHStroke::next() {
	Core& core = *Core::getInstance();
	core.calcTetVectorByLaplacian(core.m_tetVectorS, core.m_strokes);
	return StateScale::getInstance();
}

void StateSDHStroke::init() {
	Core& core = *Core::getInstance();
	core.m_strokes.clear();
	core.initCut();
	core.setFocusCenter();
	core.calcStrokeRadius();
}

void StateSDHStroke::draw() {
	Core& core = *Core::getInstance();
	KMultiTexPolygonModel& poly = core.m_polyCut;
	
	glColor3dv(Drawer::COLOR_FACE);
	glEnable(GL_LIGHTING);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& n = p.m_normal[j];
			KVector3d& v = poly.m_vertices[p.m_vtx[j]].m_pos;
			glNormal3dv(n.getPtr());
			glVertex3dv(v.getPtr());
		}
	}
	glEnd();
	
	// draw strokes!
	glColor3dv(Drawer::COLOR_STROKE);
	for (int i = 0; i < (int)core.m_strokes.size(); ++i) {
		vector<KVector3d>& stroke = core.m_strokes[i];
		for (int j = 1; j < (int)stroke.size(); ++j) {
			KVector3d& p0 = stroke[j - 1];
			KVector3d& p1 = stroke[j];
			KVector3d d;
			d.sub(p1, p0);
			d.scale(1.2);
			KDrawer::drawCylinder(p0, d, core.m_strokeRadius);
			if (j == (int)stroke.size() - 1)
				KDrawer::drawCone(p1, d, 2 * core.m_strokeRadius, 4 * core.m_strokeRadius);
		}
	}
	
	glDisable(GL_LIGHTING);
	glDisable(GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);
	glColor3dv(Drawer::COLOR_CUTSTROKE);
	glLineWidth(5);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < (int)core.m_cutStroke.size(); ++i)
		glVertex3dv(core.m_cutStroke[i].getPtr());
	glEnd();
	glDepthMask(GL_TRUE);
	glEnable(GL_DEPTH_TEST);
}

void StateSDHStroke::postDraw(CWnd* hWnd, CDC* pDC) {
	Core& core = *Core::getInstance();
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	pDC->DrawText ( "Draw strokes!", -1, &rc, DT_LEFT | DT_TOP | DT_SINGLELINE);
	pDC->SelectObject ( pOldFont );
}

void StateSDHStroke::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) {
		core.m_strokes.push_back(vector<KVector3d>());
		core.m_strokes.back().push_back(pos);
		m_isDrawing = true;
		m_pointOld = point;
	} else {
		start.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(start);
		m_isCutting = true;
		m_pointOld = point;
	}
}

void StateSDHStroke::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isDrawing) {
		m_isDrawing = false;
	} else if (m_isCutting) {
		if (core.m_cutStroke.size() == 1) {
			core.initCut();
		} else {
			core.calcVtxValueCut(core.m_cutStroke);
			core.updateCut();
		}
		core.m_cutStroke.clear();
		core.m_ogl.RedrawWindow();
		m_isCutting = false;
	}
}

void StateSDHStroke::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			Core::getInstance()->m_ogl.ButtonDownForTranslate(point);
		} else {
			Core::getInstance()->m_ogl.ButtonDownForRotate(point);
		}
	}else {
		Core::getInstance()->m_ogl.ButtonDownForZoom(point);
	}
	m_isRButtonDown = true;
}

void StateSDHStroke::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core::getInstance()->m_ogl.ButtonUp();
	m_isRButtonDown = false;
}

void StateSDHStroke::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isRButtonDown) {
		core.m_ogl.MouseMove(point);
		return;
	}
	if (!m_isCutting && !m_isDrawing) return;
	double dx = point.x - m_pointOld.x;
	double dy = point.y - m_pointOld.y;
	double dist = sqrt(dx * dx + dy * dy);
	if (dist < 10) return;
	m_pointOld = point;
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	if (m_isCutting) {
		start.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(start);
		core.m_ogl.RedrawWindow();
	} else {
		KVector3d pos;
		int polyID;
		if (KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) {
			core.m_strokes.back().push_back(pos);
			core.m_ogl.RedrawWindow();
		}
	}
}


