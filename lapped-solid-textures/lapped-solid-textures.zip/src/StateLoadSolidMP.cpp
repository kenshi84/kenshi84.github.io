#include "StdAfx.h"
#include "StateLoadSolidMP.h"
#include "StateManualPaste.h"
#include "MainFrm.h"
#include <KLIB/KIcosahedron.h>
#include <KLIB/KMarchingTetraSubdiv.h>
#include <KLIB/KMarchingTetra.h>
#include <KLIB/KUtil.h>

#include "Core.h"

#include <KLIB/KDrawer.h>

using namespace std;

StateLoadSolidMP::StateLoadSolidMP() {
	KIcosahedron icosa = KIcosahedron(0.05);
	icosa.subdivide();
	m_polyIcosa = icosa;
	m_polyIcosa.calcSmoothNormals();
	m_polyIcosaX = m_polyIcosa;
	m_polyIcosaY = m_polyIcosa;
	m_polyIcosaZ = m_polyIcosa;
}

State* StateLoadSolidMP::next() {
	Core& core = *Core::getInstance();
	if (!core.m_volInputDisp.empty() && core.m_volManualDisp.back().empty()) {
		core.m_volManualDisp.back().resize(Core::VOLSIZE * Core::VOLSIZE * Core::VOLSIZE, 0);
	}
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_loadTexture, false, true);
	return StateManualPaste::getInstance();
}

bool StateLoadSolidMP::isReady() {
	Core& core = *Core::getInstance();
	return !core.m_volManual.back().empty();
}

void StateLoadSolidMP::init() {
	Core& core = *Core::getInstance();
	core.m_ogl.setEyePosition(0.5, 0.5, 3, 0.5, 0.5, 0.5, 0, 1, 0);
	core.m_ogl.updateEyePosition();
	core.m_ogl.makeOpenGLCurrent();
	glDisable(GL_LIGHTING);
	core.m_volManual.push_back(vector<GLubyte>());
	core.m_volManualDisp.push_back(vector<GLubyte>());
	core.m_drawer.m_texNameManual.push_back(0);
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_loadTexture, true, true);
	m_mode = MODE_COLOR;
	m_currentSlice = Core::VOLSIZE - 1;
	m_currentPlane = PLANE_X;
	updateHandlePos();
	updateTetraCut();
	updatePolyCut();
	core.updatePolySlice(core.m_tetraCut);
	m_isVolumeRendering = true;
}

void StateLoadSolidMP::draw() {
	Core& core = *Core::getInstance();
	if ((m_mode == MODE_COLOR && core.m_volManual.back().empty()) ||
		(m_mode == MODE_DISPLACEMENT && core.m_volManualDisp.back().empty())) return;
	
	glDisable(GL_LIGHTING);
	glLineWidth(2);
	glColor3d(0.5, 0.5, 0.5);
	glPushMatrix();
	glTranslated(0.5, 0.5, 0.5);
	KDrawer::drawWireBox(0, 0, 0, 1, 1, 1);
	glPopMatrix();
	glLineWidth(5);
	KDrawer::drawAxis();
	
	glEnable(GL_TEXTURE_3D);
	glEnable(GL_BLEND);
	if (m_mode == MODE_COLOR)
		glBindTexture(GL_TEXTURE_3D, core.m_drawer.m_texNameManual.back());
	else
		glBindTexture(GL_TEXTURE_3D, core.m_drawer.m_texNameDisp);
	glColor3d(1, 1, 1);
	glBegin(GL_TRIANGLES);
	KMultiTexPolygonModel& poly = m_isVolumeRendering ? core.m_polySlice : core.m_polyCut;
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			glTexCoord3dv(p.m_texCoords[0].m_coord[j].getPtr());
			glVertex3dv(poly.m_vertices[p.m_vtx[j]].m_pos.getPtr());
		}
	}
	glEnd();
	glDisable(GL_TEXTURE_3D);
	glDisable(GL_BLEND);
	glEnable(GL_LIGHTING);
	if (m_currentPlane == PLANE_X)
		glColor3d(1, 1, 0);
	else
		glColor3d(0.5, 0.5, 0.5);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)m_polyIcosa.m_polygons.size(); ++i) {
		KPolygon& p = m_polyIcosa.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			glNormal3dv(p.m_normal[j].getPtr());
			glVertex3dv(m_polyIcosaX.m_vertices[p.m_vtx[j]].m_pos.getPtr());
		}
	}
	glEnd();
	if (m_currentPlane == PLANE_Y)
		glColor3d(1, 1, 0);
	else
		glColor3d(0.5, 0.5, 0.5);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)m_polyIcosa.m_polygons.size(); ++i) {
		KPolygon& p = m_polyIcosa.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			glNormal3dv(p.m_normal[j].getPtr());
			glVertex3dv(m_polyIcosaY.m_vertices[p.m_vtx[j]].m_pos.getPtr());
		}
	}
	glEnd();
	if (m_currentPlane == PLANE_Z)
		glColor3d(1, 1, 0);
	else
		glColor3d(0.5, 0.5, 0.5);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)m_polyIcosa.m_polygons.size(); ++i) {
		KPolygon& p = m_polyIcosa.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			glNormal3dv(p.m_normal[j].getPtr());
			glVertex3dv(m_polyIcosaZ.m_vertices[p.m_vtx[j]].m_pos.getPtr());
		}
	}
	glEnd();
}

void StateLoadSolidMP::updatePolyCut() {
	Core& core = *Core::getInstance();
	vector<double> vtxValue(core.m_tetraCube.m_vertices.size());
	for (int i = 0; i < (int)vtxValue.size(); ++i) {
		KVector3d& pos = core.m_tetraCube.m_vertices[i].m_pos;
		vtxValue[i] = 
			m_currentPlane == PLANE_X ? pos.x
			: m_currentPlane == PLANE_Y ? pos.y : pos.z;
	}
	double threshold = (m_currentSlice + 0.5) / Core::VOLSIZE;
	core.m_polyCut = KMarchingTetra::calcMultiTexMarchingTetra(vector<int>(), core.m_tetraCube, vtxValue, threshold);
}

void StateLoadSolidMP::updateTetraCut() {
	Core& core = *Core::getInstance();
	vector<double> vtxValue(core.m_tetraCube.m_vertices.size());
	for (int i = 0; i < (int)vtxValue.size(); ++i) {
		KVector3d& pos = core.m_tetraCube.m_vertices[i].m_pos;
		vtxValue[i] = 
			m_currentPlane == PLANE_X ? pos.x
			: m_currentPlane == PLANE_Y ? pos.y : pos.z;
	}
	double threshold = (m_currentSlice + 0.5) / Core::VOLSIZE;
	core.m_tetraCut = KMarchingTetraSubdiv::calcMarchingTetraSubdiv(core.m_tetraCube, vtxValue, threshold);
}

void StateLoadSolidMP::updateHandlePos() {
	double off = (m_currentSlice + 0.5) / Core::VOLSIZE;
	for (int i = 0; i < (int)m_polyIcosa.m_vertices.size(); ++i) {
		m_polyIcosaX.m_vertices[i].m_pos.x = m_polyIcosa.m_vertices[i].m_pos.x + off;
		m_polyIcosaY.m_vertices[i].m_pos.y = m_polyIcosa.m_vertices[i].m_pos.y + off;
		m_polyIcosaZ.m_vertices[i].m_pos.z = m_polyIcosa.m_vertices[i].m_pos.z + off;
	}
}

void StateLoadSolidMP::postDraw(CWnd* hWnd, CDC* pDC) {
	Core& core = *Core::getInstance();
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	pDC->DrawText ( "Manual pasting!", -1, &rc, DT_LEFT | DT_TOP | DT_SINGLELINE);
	if ((m_mode == MODE_COLOR && !core.m_volManual.back().empty()) ||
		(m_mode == MODE_DISPLACEMENT && !core.m_volManualDisp.back().empty())) return;
	if (m_mode == MODE_COLOR)
		pDC->DrawText ( "Drop solid texture (*.vol) here!", -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	else
		pDC->DrawText ( "Drop displacement map (*.vol) here!", -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	pDC->SelectObject ( pOldFont );
}

void StateLoadSolidMP::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (KUtil::getIntersection(pos, polyID, m_polyIcosaX, start, ori)) {
		m_currentPlane = PLANE_X;
		m_isDragging = true;
	} else if (KUtil::getIntersection(pos, polyID, m_polyIcosaY, start, ori)) {
		m_currentPlane = PLANE_Y;
		m_isDragging = true;
	} else if (KUtil::getIntersection(pos, polyID, m_polyIcosaZ, start, ori)) {
		m_currentPlane = PLANE_Z;
		m_isDragging = true;
	}
	if (m_isDragging) core.m_ogl.RedrawWindow();
}

void StateLoadSolidMP::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	m_isDragging = false;
}

void StateLoadSolidMP::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			Core::getInstance()->m_ogl.ButtonDownForTranslate(point);
		} else {
			Core::getInstance()->m_ogl.ButtonDownForRotate(point);
		}
	}else {
		Core::getInstance()->m_ogl.ButtonDownForZoom(point);
	}
	m_isRButtonDown = true;
}

void StateLoadSolidMP::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	core.m_ogl.ButtonUp();
	m_isRButtonDown = false;
}

void StateLoadSolidMP::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isRButtonDown) {
		core.m_ogl.MouseMove(point);
		if (m_isVolumeRendering) core.updatePolySlice(core.m_tetraCut);
		core.m_ogl.RedrawWindow();
		return;
	}
	if (!m_isDragging) return;
	
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	
	KVector3d x(start);
	start.add(ori);
	KVector3d e(core.m_ogl.m_eyePoint);
	KVector3d d;
	if (m_currentPlane == PLANE_X)
		d.set(1, 0, 0);
	else if (m_currentPlane == PLANE_Y)
		d.set(0, 1, 0);
	else
		d.set(0, 0, 1);
	KVector3d n1;
	n1.cross(e, d);
	KVector3d n2;
	KVector3d ex(x);
	ex.sub(e);
	n2.cross(ex, n1);
	double k = n2.dot(e) / n2.dot(d);
	int numSlice = (int)(k * Core::VOLSIZE - 0.5);
	if (numSlice < 0 || numSlice >= Core::VOLSIZE) return;
	m_currentSlice = numSlice;
	if (m_isVolumeRendering) {
		updateTetraCut();
		core.updatePolySlice(core.m_tetraCut);
	} else {
		updatePolyCut();
	}
	updateHandlePos();
	core.m_ogl.RedrawWindow();
}

void StateLoadSolidMP::OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {
	//Core& core = *Core::getInstance();
	//switch (nChar) {
	//	case 'X':
	//		if (m_currentPlane == PLANE_X) return;
	//		m_currentPlane = PLANE_X;
	//		if (m_isVolumeRendering) {
	//			updateTetraCut();
	//			core.updatePolySlice(core.m_tetraCut);
	//		} else {
	//			updatePolyCut();
	//		}
	//		core.m_ogl.RedrawWindow();
	//		break;
	//	case 'Y':
	//		if (m_currentPlane == PLANE_Y) return;
	//		m_currentPlane = PLANE_Y;
	//		if (m_isVolumeRendering) {
	//			updateTetraCut();
	//			core.updatePolySlice(core.m_tetraCut);
	//		} else {
	//			updatePolyCut();
	//		}
	//		core.m_ogl.RedrawWindow();
	//		break;
	//	case 'Z':
	//		if (m_currentPlane == PLANE_Z) return;
	//		m_currentPlane = PLANE_Z;
	//		if (m_isVolumeRendering) {
	//			updateTetraCut();
	//			core.updatePolySlice(core.m_tetraCut);
	//		} else {
	//			updatePolyCut();
	//		}
	//		core.m_ogl.RedrawWindow();
	//		break;
	//	case VK_UP:
	//		if (m_currentSlice == Core::VOLSIZE - 1) return;
	//		++m_currentSlice;
	//		updateHandlePos();
	//		if (m_isVolumeRendering) {
	//			updateTetraCut();
	//			core.updatePolySlice(core.m_tetraCut);
	//		} else {
	//			updatePolyCut();
	//		}
	//		core.m_ogl.RedrawWindow();
	//		break;
	//	case VK_DOWN:
	//		if (m_currentSlice == 0) return;
	//		--m_currentSlice;
	//		updateHandlePos();
	//		if (m_isVolumeRendering) {
	//			updateTetraCut();
	//			core.updatePolySlice(core.m_tetraCut);
	//		} else {
	//			updatePolyCut();
	//		}
	//		core.m_ogl.RedrawWindow();
	//		break;
	//}
}

void StateLoadSolidMP::OnDropFiles  (CView* view, HDROP hDropInfo) {
	char fname[256];
	if (DragQueryFile(hDropInfo, -1, fname, sizeof(fname)) != 1) return;
	DragQueryFile(hDropInfo, 0, fname, sizeof(fname));
	
	string str(fname);
	string ext = str.substr(str.length() - 4, 4);
	if (ext.compare(".vol")) {
		AfxMessageBox("Please drop *.vol file!");
		return;
	}
	Core& core = *Core::getInstance();
	if (m_mode == MODE_COLOR) {
		if (!core.loadVolManual(str)) return;
		core.m_drawer.genTexManual();
	} else {
		if (!core.loadVolManualDisp(str)) return;
		core.m_drawer.genTexDisp(core.m_volManualDisp.back());
	}
	core.updatePolySlice(core.m_tetraCube);
	
	core.m_ogl.RedrawWindow();
}
