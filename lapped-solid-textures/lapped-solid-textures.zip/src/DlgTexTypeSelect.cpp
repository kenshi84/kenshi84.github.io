// DlgTexTypeSelect.cpp : �����t�@�C��
//

#include "stdafx.h"
#include "LSTDemo.h"
#include "DlgTexTypeSelect.h"


// DlgTexTypeSelect �_�C�A���O

IMPLEMENT_DYNAMIC(DlgTexTypeSelect, CDialog)

DlgTexTypeSelect::DlgTexTypeSelect(CWnd* pParent /*=NULL*/)
	: CDialog(DlgTexTypeSelect::IDD, pParent)
	, m_texType(0)
{

}

DlgTexTypeSelect::~DlgTexTypeSelect()
{
}

void DlgTexTypeSelect::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Radio(pDX, IDC_RADIO_ISOTROPIC, m_texType);
}


BEGIN_MESSAGE_MAP(DlgTexTypeSelect, CDialog)
END_MESSAGE_MAP()


// DlgTexTypeSelect ���b�Z�[�W �n���h��
