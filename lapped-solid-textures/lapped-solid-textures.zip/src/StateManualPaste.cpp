#include "StdAfx.h"
#include "StateManualPaste.h"
#include "StateResult.h"
#include "StateBrowse.h"

#include "MainFrm.h"

#include <KLIB/KUtil.h>
#include <KLIB/KRBF.h>

using namespace std;

State* StateManualPaste::next() {
	Core& core = *Core::getInstance();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_manualPaste, false, true);
	return StateResult::getInstance();
}

bool StateManualPaste::isReady() { return m_isPastedOnce; }

void StateManualPaste::init() {
	Core& core = *Core::getInstance();
	core.setFocusCenter();
	core.initCut();
	double xMin, yMin, zMin, xMax, yMax, zMax;
	KUtil::getBoundingBox(core.m_tetraOrg, xMin, yMin, zMin, xMax, yMax, zMax);
	m_currentScale = max(max(xMax - xMin, yMax - yMin), zMax - zMin) / 4;
	m_vectorS = KVector3d(0, 1, 0);
	m_vectorT = KVector3d(0, 0, 1);
	m_vectorR.cross(m_vectorS, m_vectorT);
	int tetSize = (int)core.m_tetraOrg.m_tetras.size();
	core.m_lst.setField(
		vector<KVector3d>(tetSize, m_vectorS),
		vector<KVector3d>(tetSize, m_vectorT), KThinPlate3D(),
		vector<double>(tetSize, m_currentScale));
	core.m_patch.clear();
	core.m_polyPatch = KMultiTexPolygonModel();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_manualPaste, true, true);
	m_isPastedOnce = false;
}

void StateManualPaste::draw() {
	Core& core = *Core::getInstance();
	KMultiTexPolygonModel& poly = core.m_polyCut;
	glEnable(GL_LIGHTING);
	glColor3dv(Drawer::COLOR_FACE);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& n = p.m_normal[j];
			KVector3d& v = poly.m_vertices[p.m_vtx[j]].m_pos;
			glNormal3dv(n.getPtr());
			glVertex3dv(v.getPtr());
		}
	}
	glEnd();
	glEnable(GL_TEXTURE_3D);
	glEnable(GL_BLEND);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < (int)p.m_texCoords.size(); ++j) {
			int texID = p.m_texIDs[j];
			GLuint texName =
				texID == 0 ? core.m_drawer.m_texNameMiddle
				: texID == 1 ? core.m_drawer.m_texNameOuter
				: texID == 2 ? core.m_drawer.m_texNameInner
				: core.m_drawer.m_texNameManual[texID - 3];
			glBindTexture(GL_TEXTURE_3D, texName);
			glBegin(GL_TRIANGLES);
			for (int k = 0; k < 3; ++k) {
				KVector3d& n = p.m_normal[k];
				KVector3d& t = p.m_texCoords[j].m_coord[k];
				KVector3d& v = poly.m_vertices[p.m_vtx[k]].m_pos;
				glNormal3dv(n.getPtr());
				glTexCoord3dv(t.getPtr());
				glVertex3dv(v.getPtr());
			}
			glEnd();
		}
	}
	glBindTexture(GL_TEXTURE_3D, core.m_drawer.m_texNameManual.back());
	glBegin(GL_TRIANGLES);
	KMultiTexPolygonModel& polyPatch = core.m_polyPatch;
	for (int i = 0; i < (int)polyPatch.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = polyPatch.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& n = p.m_normal[j];
			KVector3d& t = p.m_texCoords[0].m_coord[j];
			KVector3d& v = polyPatch.m_vertices[p.m_vtx[j]].m_pos;
			glNormal3dv(n.getPtr());
			glTexCoord3dv(t.getPtr());
			glVertex3dv(v.getPtr());
		}
	}
	glEnd();
	glDisable(GL_TEXTURE_3D);
	glDisable(GL_BLEND);
	
	glDisable(GL_LIGHTING);
	// draw texture axis
	if (!core.m_patch.empty()) {
		glLineWidth(2);
		glBegin(GL_LINES);
		KVector3d pos(m_seedPos);
		glColor3d(1, 0, 0);
		pos.addWeighted(m_vectorR, 0.25 * m_currentScale);
		glVertex3dv(pos.getPtr());
		pos.addWeighted(m_vectorR, -0.5 * m_currentScale);
		glVertex3dv(pos.getPtr());
		pos.set(m_seedPos);
		glColor3d(0, 1, 0);
		pos.addWeighted(m_vectorS, 0.25 * m_currentScale);
		glVertex3dv(pos.getPtr());
		pos.addWeighted(m_vectorS, -0.5 * m_currentScale);
		glVertex3dv(pos.getPtr());
		pos.set(m_seedPos);
		glColor3d(0, 0, 1);
		pos.addWeighted(m_vectorT, 0.25 * m_currentScale);
		glVertex3dv(pos.getPtr());
		pos.addWeighted(m_vectorT, -0.5 * m_currentScale);
		glVertex3dv(pos.getPtr());
		glEnd();
	}
	
	// draw cutting stroke
	glLineWidth(5);
	glDisable(GL_DEPTH_TEST);
	glDepthMask(GL_FALSE);
	glColor3dv(Drawer::COLOR_CUTSTROKE);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < (int)core.m_cutStroke.size(); ++i)
		glVertex3dv(core.m_cutStroke[i].getPtr());
	glEnd();
	glEnable(GL_DEPTH_TEST);
	glDepthMask(GL_TRUE);
}

void StateManualPaste::postDraw(CWnd* hWnd, CDC* pDC) {
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	pDC->DrawText ( "Manual pasting!", -1, &rc, DT_TOP | DT_LEFT | DT_SINGLELINE);
	pDC->SelectObject ( pOldFont );
}

void StateManualPaste::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	m_pointOld = point;
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) {
		m_isDragging = true;
		if (m_isRotateMode) return;
		double dist;
		m_seedPos = pos;
		KUtil::getNearestTetraID(core.m_seed, dist, core.m_tetraOrg, m_seedPos);
		vector<double> tetScale(core.m_tetraOrg.m_tetras.size(), m_currentScale);
		core.m_lst.setScale(tetScale);
		int depthID;
		core.m_lst.pastePatch(core.m_seed, &pos, depthID, core.m_patch, core.m_optimized, vector<int>());
		core.calcPolyPatch();
		core.m_ogl.RedrawWindow();
	} else {
		start.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(start);
		m_isCutting = true;
	}
}

void StateManualPaste::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isCutting) {
		m_isCutting = false;
		if (core.m_cutStroke.size() == 1) {
			core.initCut();
			core.calcPolyPatch();
		} else {
			core.calcVtxValueCut(core.m_cutStroke);
			core.updateCut();
			core.calcPolyPatch();
		}
		core.m_cutStroke.clear();
		core.m_ogl.RedrawWindow();
	} else if (m_isDragging) {
		m_isDragging = false;
	}
}

void StateManualPaste::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			Core::getInstance()->m_ogl.ButtonDownForTranslate(point);
		} else {
			Core::getInstance()->m_ogl.ButtonDownForRotate(point);
		}
	}else {
		Core::getInstance()->m_ogl.ButtonDownForZoom(point);
	}
	m_isRButtonDown = true;
}

void StateManualPaste::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core::getInstance()->m_ogl.ButtonUp();
	m_isRButtonDown = false;
}

void StateManualPaste::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isRButtonDown) {
		core.m_ogl.MouseMove(point);
		return;
	}
	double dx = point.x - m_pointOld.x;
	double dy = point.y - m_pointOld.y;
	double dist = sqrt(dx * dx + dy * dy);
	if (dist < 10) return;
	m_pointOld = point;
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	if (m_isCutting) {
		start.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(start);
		core.m_ogl.RedrawWindow();
	} else if (m_isDragging) {
		if (m_isRotateMode) {
			dx *= 0.01;
			dy *= 0.01;
			KVector3d eye, eyeUp, eyeRight;
			eye  .set(core.m_ogl.m_focusPoint);
			eye  .sub(core.m_ogl.m_eyePoint);
			eyeUp.set(core.m_ogl.m_upDirection);
			eyeRight.cross(eye, eyeUp);
			eyeRight.normalize();
			eyeUp.cross(eyeRight, eye);
			eyeUp.normalize();
			KUtil::getVectorRotatedAroundAxis(m_vectorS, eyeUp,    dx);
			KUtil::getVectorRotatedAroundAxis(m_vectorS, eyeRight, dy);
			KUtil::getVectorRotatedAroundAxis(m_vectorT, eyeUp,    dx);
			KUtil::getVectorRotatedAroundAxis(m_vectorT, eyeRight, dy);
			//double cosx = cos(dx);
			//double sinx = sin(dx);
			//double cosy = cos(dy);
			//double siny = sin(dy);
			//KVector3d S, T, R, T1, S2, T2;
			//S.set(m_vectorS);
			//T.set(m_vectorT);
			//R.cross(S, T);
			//T1.addWeighted(T, cosx);
			//T1.addWeighted(R, sinx);
			//S2.addWeighted(S,  cosy);
			//S2.addWeighted(T1, siny);
			//T2.addWeighted(S, -siny);
			//T2.addWeighted(T1, cosy);
			//m_vectorS.set(S2);
			//m_vectorT.set(T2);
			m_vectorR.cross(m_vectorS, m_vectorT);
			int tetSize = (int)core.m_tetraOrg.m_tetras.size();
			core.m_lst.setField(
				vector<KVector3d>(tetSize, m_vectorS),
				vector<KVector3d>(tetSize, m_vectorT), KThinPlate3D(),
				vector<double>(tetSize, m_currentScale));
			int depthID;
			core.m_lst.pastePatch(core.m_seed, &m_seedPos, depthID, core.m_patch, core.m_optimized, vector<int>(), false);
			core.calcPolyPatch();
			core.m_ogl.RedrawWindow();
		} else {
			KVector3d pos;
			int polyID;
			if (KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) {
				double dist;
				m_seedPos = pos;
				KUtil::getNearestTetraID(core.m_seed, dist, core.m_tetraOrg, m_seedPos);
				vector<double> tetScale(core.m_tetraOrg.m_tetras.size(), m_currentScale);
				core.m_lst.setScale(tetScale);
				int depthID;
				core.m_lst.pastePatch(core.m_seed, &m_seedPos, depthID, core.m_patch, core.m_optimized, vector<int>(), false);
				core.calcPolyPatch();
				core.m_ogl.RedrawWindow();
			}
		}
	}
}

void StateManualPaste::OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt) {
	if (zDelta < 0)
		decrease();
	else
		increase();
}

void StateManualPaste::OnLButtonDblClk(CView* view, UINT nFlags, CPoint point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	KVector3d pos;
	int polyID;
	if (KUtil::getIntersection(pos, polyID, core.m_polyCut, start, ori)) {
		paste();
	}
}

void StateManualPaste::paste() {
	Core& core = *Core::getInstance();
	vector<int>&         patch     = core.m_patch;
	map<int, KVector3d>& optimized = core.m_optimized;
	for (int i = 0; i < (int)patch.size(); ++i) {
		int tetID = patch[i];
		KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[tetID];
		KTetraTexCoord texCoord;
		for (int j = 0; j < 4; ++j) {
			texCoord.m_coord[j] = optimized.find(tet.m_vtx[j])->second;
		}
		tet.m_texCoords.push_back(texCoord);
		tet.m_texIDs   .push_back((int)core.m_volManual.size() + 2);
	}
	core.m_patch.clear();
	core.updateCut();
	core.m_polyPatch = KMultiTexPolygonModel();
	core.m_ogl.RedrawWindow();
	m_isPastedOnce = true;
}

void StateManualPaste::increase() {
	Core& core = *Core::getInstance();
	m_currentScale *= 1.1;
	if (core.m_patch.empty()) return;
	core.m_lst.setScale(vector<double>(core.m_tetraOrg.m_tetras.size(), m_currentScale));
	int depthID;
	core.m_lst.pastePatch(core.m_seed, &m_seedPos, depthID, core.m_patch, core.m_optimized, vector<int>(), false);
	core.calcPolyPatch();
	core.m_ogl.RedrawWindow();
}

void StateManualPaste::decrease() {
	Core& core = *Core::getInstance();
	m_currentScale *= 0.9;
	if (core.m_patch.empty()) return;
	core.m_lst.setScale(vector<double>(core.m_tetraOrg.m_tetras.size(), m_currentScale));
	int depthID;
	core.m_lst.pastePatch(core.m_seed, &m_seedPos, depthID, core.m_patch, core.m_optimized, vector<int>(), false);
	core.calcPolyPatch();
	core.m_ogl.RedrawWindow();
}

void StateManualPaste::OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {
	switch (nChar) {
		case 'R':
			m_isRotateMode = true;
			break;
		case 'M':
			m_isRotateMode = false;
			break;
	}
}

void StateManualPaste::OnDropFiles  (CView* view, HDROP hDropInfo) {
	char fname[256];
	if (DragQueryFile(hDropInfo, -1, fname, sizeof(fname)) != 1) return;
	DragQueryFile(hDropInfo, 0, fname, sizeof(fname));
	
	string str(fname);
	string ext = str.substr(str.length() - 4, 4);
	if (ext.compare(".lst")) {
		AfxMessageBox("Please drop *.lst file!");
		return;
	}
	Core& core = *Core::getInstance();
	core.m_state = StateBrowse::getInstance();
	core.m_state->init();
	StateBrowse::getInstance()->OnDropFiles(view, hDropInfo);
}
