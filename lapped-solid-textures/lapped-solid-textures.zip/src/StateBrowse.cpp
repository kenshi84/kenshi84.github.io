#include "StdAfx.h"
#include "StateBrowse.h"
#include "StateLoadTetra.h"
#include "Core.h"
#include "MainFrm.h"
#include "DlgDisplacement.h"
#include "DlgInformation.h"
#include "DlgVR.h"
#include <KLIB/KFaceSubdivision.h>

#include <KLIB/KUtil.h>
#include <KLIB/KVolumeRenderer.h>
#include <KLIB/KMarchingTetraSubdiv.h>
#include <KLIB/KDrawer.h>

#include <ctime>

using namespace std;

void StateBrowse::init() {
	Core& core = *Core::getInstance();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_navigate,    false, true);
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_loadTexture, false, true);
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_manualPaste, false, true);
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_process,     false, true);
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_result,      false, true);
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_scale,       false, true);
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_browse,      true , true);
	core.m_tetraOrg = KMultiTexTetraModel();
	core.m_tetraCut = KMultiTexTetraModel();
	core.m_polyCut   = KMultiTexPolygonModel();
	core.m_polySlice = KMultiTexPolygonModel();
	core.m_cutStroke.clear();
	for (int i = 0; i < 10; ++i) m_drawFlag[i] = true;
	m_drawFlag[0] = false;
	m_drawFlag[9] = false;
}

State* StateBrowse::next() {
	Core& core = *Core::getInstance();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_browse, false, true);
	return StateLoadTetra::getInstance();
}

void StateBrowse::draw() {
	Core& core = *Core::getInstance();
	if (core.m_polySlice.m_polygons.empty()) {
		KMultiTexPolygonModel& poly = core.m_polyCut;
		if (m_drawFlag[0]) {
			glDisable(GL_LIGHTING);
			glColor3dv(Drawer::COLOR_EDGE);
			glBegin(GL_LINES);
			for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
				KMultiTexPolygon& p = poly.m_polygons[i];
				for (int j = 0; j < 3; ++j) {
					KVector3d& v0 = poly.m_vertices[p.m_vtx[j]].m_pos;
					KVector3d& v1 = poly.m_vertices[p.m_vtx[(j + 1) % 3]].m_pos;
					glVertex3dv(v0.getPtr());
					glVertex3dv(v1.getPtr());
				}
			}
			glEnd();
		}
		glEnable(GL_LIGHTING);
		glColor3dv(Drawer::COLOR_FACE);
		//glBegin(GL_TRIANGLES);
		//for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		//	KMultiTexPolygon& p = poly.m_polygons[i];
		//	for (int j = 0; j < 3; ++j) {
		//		KVector3d& n = p.m_normal[j];
		//		KVector3d& v = poly.m_vertices[p.m_vtx[j]].m_pos;
		//		glNormal3dv(n.getPtr());
		//		glVertex3dv(v.getPtr());
		//	}
		//}
		//glEnd();
		glEnable(GL_BLEND);
		for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
			KMultiTexPolygon& p = poly.m_polygons[i];
			// base color
			glBegin(GL_TRIANGLES);
			for (int k = 0; k < 3; ++k) {
				KVector3d& n = p.m_normal[k];
				KVector3d& v = poly.m_vertices[p.m_vtx[k]].m_pos;
				glNormal3dv(n.getPtr());
				glVertex3dv(v.getPtr());
			}
			glEnd();
			// overlapped textures
			glEnable(GL_TEXTURE_3D);
			for (int j = 0; j < (int)p.m_texCoords.size(); ++j) {
				int texID = p.m_texIDs[j];
				glBindTexture(GL_TEXTURE_3D, core.m_drawer.m_texNameBrowse[texID]);
				glBegin(GL_TRIANGLES);
				for (int k = 0; k < 3; ++k) {
					KVector3d& n = p.m_normal[k];
					KVector3d& t = p.m_texCoords[j].m_coord[k];
					KVector3d& v = poly.m_vertices[p.m_vtx[k]].m_pos;
					glNormal3dv(n.getPtr());
					glTexCoord3dv(t.getPtr());
					glVertex3dv(v.getPtr());
				}
				glEnd();
			}
			glDisable(GL_TEXTURE_3D);
		}
		if (m_drawFlag[9]) {
			// overlay the cross-section
			glDisable(GL_DEPTH_TEST);
			for (int i = 0; i < (int)core.m_polyIDs_oncutplane.size(); ++i) {
				KMultiTexPolygon& p = poly.m_polygons[core.m_polyIDs_oncutplane[i]];
				// base color
				glBegin(GL_TRIANGLES);
				for (int k = 0; k < 3; ++k) {
					KVector3d& n = p.m_normal[k];
					KVector3d& v = poly.m_vertices[p.m_vtx[k]].m_pos;
					glNormal3dv(n.getPtr());
					glVertex3dv(v.getPtr());
				}
				glEnd();
				// overlapped textures
				glEnable(GL_TEXTURE_3D);
				for (int j = 0; j < (int)p.m_texCoords.size(); ++j) {
					int texID = p.m_texIDs[j];
					glBindTexture(GL_TEXTURE_3D, core.m_drawer.m_texNameBrowse[texID]);
					glBegin(GL_TRIANGLES);
					for (int k = 0; k < 3; ++k) {
						KVector3d& n = p.m_normal[k];
						KVector3d& t = p.m_texCoords[j].m_coord[k];
						KVector3d& v = poly.m_vertices[p.m_vtx[k]].m_pos;
						glNormal3dv(n.getPtr());
						glTexCoord3dv(t.getPtr());
						glVertex3dv(v.getPtr());
					}
					glEnd();
				}
				glDisable(GL_TEXTURE_3D);
			}
			glEnable(GL_DEPTH_TEST);
		}
		glDisable(GL_BLEND);
	} else {
		KMultiTexPolygonModel& poly = core.m_polySlice;
		glEnable(GL_TEXTURE_3D);
		glEnable(GL_BLEND);
		glDisable(GL_LIGHTING);
		glColor3dv(Drawer::COLOR_FACE);
		for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
			KMultiTexPolygon& p = poly.m_polygons[i];
			for (int j = 0; j < (int)p.m_texCoords.size(); ++j) {
				int texID = p.m_texIDs[j];
				glBindTexture(GL_TEXTURE_3D, core.m_drawer.m_texNameBrowse[texID]);
				glBegin(GL_TRIANGLES);
				for (int k = 0; k < 3; ++k) {
					KVector3d& t = p.m_texCoords[j].m_coord[k];
					KVector3d& v = poly.m_vertices[p.m_vtx[k]].m_pos;
					glTexCoord3dv(t.getPtr());
					glVertex3dv(v.getPtr());
				}
				glEnd();
			}
		}
	}
	glDisable(GL_LIGHTING);
	glDepthMask(GL_FALSE);
	glDisable(GL_DEPTH_TEST);
	glColor3dv(Drawer::COLOR_CUTSTROKE);
	glLineWidth(5);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < (int)core.m_cutStroke.size(); ++i)
		glVertex3dv(core.m_cutStroke[i].getPtr());
	glEnd();
	glDepthMask(GL_TRUE);
	glEnable(GL_DEPTH_TEST);
}

void StateBrowse::clear() {
	Core& core = *Core::getInstance();
	core.m_tetraOrg = KMultiTexTetraModel();
	core.m_tetraCut = KMultiTexTetraModel();
	core.m_polyCut   = KMultiTexPolygonModel();
	core.m_polySlice = KMultiTexPolygonModel();
	core.m_polyIDs_oncutplane.clear();
	core.m_volBrowse.clear();
	core.m_volBrowseDisp.clear();
}

void StateBrowse::save() {
	Core& core = *Core::getInstance();
	
	CFileDialog dialog(FALSE, ".lst", NULL, OFN_OVERWRITEPROMPT, "Lapped Solid Texture files(*.lst)|*.lst||");
	if (dialog.DoModal() != IDOK) return;
	string fname = dialog.GetPathName();
	FILE * fout = fopen(fname.c_str(), "wb");
	if (!fout) {
		CString str;
		str.Format("Failed to open file %s", fname.c_str());
		AfxMessageBox(str);
		return;
	}
	core.m_tetraOrg = core.m_tetraCut;
	
	// the size of solid textures
	fwrite(&Core::VOLSIZE, sizeof(int), 1, fout);
	
	int totalVols = (int)core.m_volBrowse.size();
	{// total # of solid textures
		fwrite(&totalVols, sizeof(int), 1, fout);
	}
	
	{	// solid texture data
		int volBytes4 = Core::VOLSIZE * Core::VOLSIZE * Core::VOLSIZE * 4;
		for (int i = 0; i < totalVols; ++i)
			fwrite(&core.m_volBrowse[i][0], 1, volBytes4, fout);
	}
	
	{	// displacement map
		int hasDisplacement = (int)!core.m_volBrowseDisp.empty();
		fwrite(&hasDisplacement, sizeof(int), 1, fout);
		if (hasDisplacement) {
			int volBytes = Core::VOLSIZE * Core::VOLSIZE * Core::VOLSIZE;
			for (int i = 0; i < totalVols; ++i)
				fwrite(&core.m_volBrowseDisp[i][0], 1, volBytes, fout);
		}
	}
	
	{	// vertex list
		int numVtx = (int)core.m_tetraOrg.m_vertices.size();
		fwrite(&numVtx, sizeof(int), 1, fout);
		for (int i = 0; i < numVtx; ++i)
			fwrite(&core.m_tetraOrg.m_vertices[i].m_pos, sizeof(double), 3, fout);
	}
	
	{	// multi-textured tetra list
		int numTet = (int)core.m_tetraOrg.m_tetras.size();
		fwrite(&numTet, sizeof(int), 1, fout);
		for (int i = 0; i < numTet; ++i) {
			KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[i];
			fwrite(tet.m_vtx, sizeof(int), 4, fout);
			int numTex = (int)tet.m_texCoords.size();
			fwrite(&numTex, sizeof(int), 1, fout);
			if (numTex == 0) continue;
			fwrite(&tet.m_texCoords[0], sizeof(KTetraTexCoord), numTex, fout);
			fwrite(&tet.m_texIDs   [0], sizeof(int),            numTex, fout);
		}
	}
	fclose(fout);
}

void StateBrowse::showInformation() {
	Core& core = *Core::getInstance();
	DlgInformation dialog;
	dialog.m_numTetra.Format("%d", (int)core.m_tetraOrg.m_tetras.size());
	dialog.m_numVtx  .Format("%d", (int)core.m_tetraOrg.m_vertices.size());
	int maxLap = 0, minLap = INT_MAX;
	int numFace = 0;
	double avgLap = 0;
	for (int i = 0; i < (int)core.m_tetraOrg.m_tetras.size(); ++i) {
		KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[i];
		int lap = (int)tet.m_texCoords.size();
		maxLap = max(lap, maxLap);
		minLap = min(lap, minLap);
		avgLap += lap;
		for (int j = 0; j < 4; ++j)
			if (tet.m_neighbor[j] == -1) ++numFace;
	}
	dialog.m_numFace.Format("%d", numFace);
	avgLap /= (int)core.m_tetraOrg.m_tetras.size();
	dialog.m_maxLap.Format("%d", maxLap);
	dialog.m_minLap.Format("%d", minLap);
	dialog.m_avgLap.Format("%.1f", avgLap);
	dialog.m_numTexture.Format("%d", (int)core.m_volBrowse.size());
	dialog.m_hasDisp.Format("%s", core.m_volBrowseDisp.empty() ? "no" : "yes");
	dialog.DoModal();
}

void StateBrowse::doVolumeRendering() {
	Core& core = *Core::getInstance();
	DlgVR dlg;
	dlg.m_numSlice = 200;
	if (dlg.DoModal() != IDOK) return;
	core.updatePolySlice(core.m_tetraCut, dlg.m_numSlice);
}

void StateBrowse::doDisplacementMap() {
	Core& core = *Core::getInstance();
	DlgDisplacement dialog;
	dialog.m_numSubdiv = 2;
	double xMin, yMin, zMin, xMax, yMax, zMax;
	KUtil::getBoundingBox(core.m_tetraOrg, xMin, yMin, zMin, xMax, yMax, zMax);
	double sizeMax = max(max(xMax - xMin, yMax - yMin), zMax - zMin);
	dialog.m_degDisp = sizeMax / 30;
	if (dialog.DoModal() != IDOK) return;
	KMultiTexPolygonModel& poly = core.m_polyCut;
	poly = core.m_tetraCut.toMultiTexPolygonModel();
	for (int i = 0; i < dialog.m_numSubdiv; ++i)
		poly = KFaceSubdivision::go(poly);
	poly.calcSmoothNormals();
	vector<int>       vtxCount  (poly.m_vertices.size(), 0);
	vector<KVector3d> vtxNormal (poly.m_vertices.size());
	vector<int>       vtxDispAcc(poly.m_vertices.size(), 0);
	int N = Core::VOLSIZE;
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		vector<KPolygonTexCoord>& texCoords = p.m_texCoords;
		vector<int>&              texIDs    = p.m_texIDs;
		for (int j = 0; j < 3; ++j) {
			int dispResult = 0;
			for (int k = 0; k < (int)texCoords.size(); ++k) {
				KVector3d& pos = texCoords[k].m_coord[j];
				int ix = (int)(pos.x * (N - 1));
				int iy = (int)(pos.y * (N - 1));
				int iz = (int)(pos.z * (N - 1));
				if (ix < 0 || ix >= N ||
					iy < 0 || iy >= N ||
					iz < 0 || iz >= N) continue;
				GLubyte disp  = core.m_volBrowseDisp[texIDs[k]][ix + N * iy + N * N * iz];
				GLubyte alpha = core.m_volBrowse[texIDs[k]][4 * (ix + N * iy + N * N * iz) + 3];
				dispResult = (alpha * disp + (255 - alpha) * dispResult) / 255;
			}
			int vtxID = p.m_vtx[j];
			vtxDispAcc[vtxID] += dispResult;
			++vtxCount[vtxID];
			vtxNormal[vtxID].add(p.m_normal[j]);
		}
	}
	for (int i = 0; i < (int)poly.m_vertices.size(); ++i) {
		KVector3d& n = vtxNormal[i];
		n.normalize();
		double dispFinal = vtxDispAcc[i] / (vtxCount[i] * 255.);
		n.scale(dispFinal * dialog.m_degDisp);
		poly.m_vertices[i].m_pos.add(n);
	}
}

void StateBrowse::postDraw(CWnd* hWnd, CDC* pDC) {
	Core& core = *Core::getInstance();
	if (!core.m_tetraOrg.m_tetras.empty()) return;
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	pDC->DrawText ( "Drop LST model (*.lst) here!", -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	pDC->SelectObject ( pOldFont );
}

void StateBrowse::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	start.addWeighted(ori, 0.5);
	core.m_cutStroke.push_back(start);
	m_isCutting = true;
	m_pointOld = point;
	core.m_polySlice = KMultiTexPolygonModel();
}

void StateBrowse::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	m_isCutting = false;
	if (core.m_cutStroke.size() <= 1) {
		core.initCut();
	} else {
		core.calcVtxValueCut(core.m_cutStroke);
		clock_t start,end;
		start = clock();
		core.updateCut();
		//core.calcCutSubdiv(core.m_cutStroke);
		end = clock();
		//{
		//	double thetaTgt = M_PI / 3;
		//	int numStep = 30;
		//	KVector3d v0 = core.m_cutStroke.front();
		//	KVector3d v1 = core.m_cutStroke.back();
		//	core.m_cutStroke.clear();
		//	KVector3d axis(v1.x - v0.x, v1.y - v0.y, v1.z - v0.z);
		//	ILMatrix16 m;
		//	m.RotateAlongArbitraryAxis(axis, -thetaTgt / numStep);
		//	KVector3d focus = core.m_ogl.getFocusPoint();
		//	for (int i = 0; i < numStep; ++i) {
		//		KVector3d eye = core.m_ogl.getEyePoint();
		//		eye -= focus;
		//		eye = m * eye;
		//		KVector3d up = core.m_ogl.getEyeYDirection();
		//		up.Normalize_Self();
		//		KVector3d en = eye;
		//		en.Normalize_Self();
		//		double dot = up * en;
		//		up -= en * dot;
		//		up.Normalize_Self();
		//		eye += focus;
		//		core.m_ogl.setEyePosition(eye, up, focus);
		//		core.m_ogl.RedrawWindow();
		//		Sleep(1);
		//		MSG msg;
		//		while(::PeekMessage( &msg, NULL, NULL, NULL, PM_NOREMOVE ))
		//			AfxGetThread()->PumpMessage();
		//	}
		//}
		//printf("total time: %.2f msec.\n", (double)(end - start) * 1000. / CLOCKS_PER_SEC);
	}
	//core.m_tetraOrg = core.m_tetraCut;
	//core.setFocusCenter();
	core.m_cutStroke.clear();
	core.m_ogl.RedrawWindow();
}

void StateBrowse::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			core.m_ogl.ButtonDownForTranslate(point);
		} else {
			core.m_ogl.ButtonDownForRotate(point);
		}
	}else {
		core.m_ogl.ButtonDownForZoom(point);
	}
	m_isRButtonDown = true;
	core.m_polySlice = KMultiTexPolygonModel();
}

void StateBrowse::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	core.m_ogl.ButtonUp();
	m_isRButtonDown = false;
}

void StateBrowse::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isRButtonDown) {
		core.m_ogl.MouseMove(point);
		return;
	}
	if (!m_isCutting) return;
	double dx = point.x - m_pointOld.x;
	double dy = point.y - m_pointOld.y;
	double dist = sqrt(dx * dx + dy * dy);
	if (dist < 10) return;
	m_pointOld = point;
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	start.addWeighted(ori, 0.5);
	core.m_cutStroke.push_back(start);
	core.m_ogl.RedrawWindow();
}

void StateBrowse::OnDropFiles  (CView* view, HDROP hDropInfo) {
	char fnameChar[256];
	if (DragQueryFile(hDropInfo, -1, fnameChar, sizeof(fnameChar)) != 1) return;
	DragQueryFile(hDropInfo, 0, fnameChar, sizeof(fnameChar));
	
	string fname(fnameChar);
	string ext = fname.substr(fname.length() - 4, 4);
	if (ext.compare(".lst")) {
		AfxMessageBox("Please drop *.lst file!");
		return;
	}
	
	FILE * fin = fopen(fname.c_str(), "rb");
	if (!fin) {
		CString str;
		str.Format("Failed to open file %s", fname.c_str());
		AfxMessageBox(str);
		return;
	}
	
	Core& core = *Core::getInstance();
	
	// the size of solid textures
	int volSize;
	fread(&volSize, sizeof(int), 1, fin);
	if (volSize != Core::VOLSIZE) {
		CString str;
		str.Format("The texture size should be %d.", Core::VOLSIZE);
		AfxMessageBox(str);
		fclose(fin);
		return;
	}
	
	// total # of solid textures
	int numVolsOld = (int)core.m_volBrowse.size();
	int numVols;
	{
		fread(&numVols, sizeof(int), 1, fin);
		//core.m_volBrowse.resize(numVols);
	}
	
	// solid texture data
	vector<vector<GLubyte> > volBrowseTemp(numVols);
	{
		int volBytes4 = Core::VOLSIZE * Core::VOLSIZE * Core::VOLSIZE * 4;
		for (int i = 0; i < numVols; ++i) {
			volBrowseTemp[i].resize(volBytes4);
			fread(&volBrowseTemp[i][0], 1, volBytes4, fin);
		}
	}
	
	
	// displacement map
	int hasDisplacementOld = !core.m_volBrowseDisp.empty();
	int hasDisplacement;
	{
		fread(&hasDisplacement, sizeof(int), 1, fin);
		if (!core.m_tetraOrg.m_tetras.empty()) {
			if (hasDisplacement && !hasDisplacementOld) {
				AfxMessageBox("The model should not have displacement map.");
				return;
			} else if (!hasDisplacement && hasDisplacementOld) {
				AfxMessageBox("The model should have displacement map.");
				return;
			}
		}
		core.m_volBrowse.resize(numVolsOld + numVols);
		for (int i = 0; i < numVols; ++i)
			core.m_volBrowse[numVolsOld + i] = volBrowseTemp[i];
		core.m_drawer.delTexBrowse();
		core.m_drawer.genTexBrowse();
		if (hasDisplacement) {
			core.m_volBrowseDisp.resize(numVolsOld + numVols);
			int volBytes = Core::VOLSIZE * Core::VOLSIZE * Core::VOLSIZE;
			for (int i = 0; i < numVols; ++i) {
				core.m_volBrowseDisp[numVolsOld + i].resize(volBytes);
				fread(&core.m_volBrowseDisp[numVolsOld + i][0], 1, volBytes, fin);
			}
		}
	}
	
	// vertex list
	int numVtxOld = (int)core.m_tetraOrg.m_vertices.size();
	int numVtx;
	fread(&numVtx, sizeof(int), 1, fin);
	core.m_tetraOrg.m_vertices.reserve(numVtxOld + numVtx);
	for (int i = 0; i < numVtx; ++i) {
		KVector3d pos;
		fread(pos.getPtr(), sizeof(double), 3, fin);
		core.m_tetraOrg.m_vertices.push_back(KVertex(pos));
	}
	
	// multi-textured tetra list
	int numTetOld = (int)core.m_tetraOrg.m_tetras.size();
	int numTet;
	fread(&numTet, sizeof(int), 1, fin);
	core.m_tetraOrg.m_tetras.reserve(numTetOld + numTet);
	for (int i = 0; i < numTet; ++i) {
		int vtx[4];
		fread(vtx, sizeof(int), 4, fin);
		for (int j = 0; j < 4; ++j)
			vtx[j] += numVtxOld;
		int numTex;
		fread(&numTex, sizeof(int), 1, fin);
		vector<KTetraTexCoord> texCoords(numTex);
		vector<int>            texIDs   (numTex);
		fread(&texCoords[0], sizeof(KTetraTexCoord), numTex, fin);
		fread(&texIDs   [0], sizeof(int),            numTex, fin);
		for (int j = 0; j < numTex; ++j)
			texIDs[j] += numVolsOld;
		KMultiTexTetra tet(vtx[0], vtx[1], vtx[2], vtx[3]);
		tet.m_texCoords = texCoords;
		tet.m_texIDs    = texIDs;
		core.m_tetraOrg.m_tetras.push_back(tet);
	}
	fclose(fin);
	
	core.m_tetraOrg.calcNeighbor();
	core.setFocusCenter();
	core.initCut();
	core.m_polySlice = KMultiTexPolygonModel();
	core.m_ogl.RedrawWindow();
}


void doVRandSave(char* filename) {
	Core& core = *Core::getInstance();
	core.updatePolySlice(core.m_tetraCut, 200);
	core.m_ogl.RedrawWindow();
	core.m_ogl.outputBitmap(filename);
}

void StateBrowse::OnKeyDown(CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {
	Core& core = *Core::getInstance();
	CPoint pos;
	switch (nChar) {
		case 'R':
			{
				// automatic camera rotation
				int n = 60;
				double delta = 2 * M_PI / n;
				for (int i = 0; i < n; ++i) {
					KVector3d& eye   = core.m_ogl.m_eyePoint;
					KVector3d& focus = core.m_ogl.m_focusPoint;
					KVector3d& up    = core.m_ogl.m_upDirection;
					
					KMatrix4d rot;
					rot.setRotationFromAxisAngle(up, delta);
					KVector3d focus_eye(eye);
					focus_eye.sub(focus);
					focus_eye = rot.transform(focus_eye);
					eye.set(focus);
					eye.add(focus_eye);
					core.m_ogl.updateEyePosition();
					core.m_ogl.RedrawWindow();
					Sleep(1);
					MSG msg;
					while(::PeekMessage( &msg, NULL, NULL, NULL, PM_NOREMOVE ))
						AfxGetThread()->PumpMessage();
				}
			}
			break;
		case '0':
		case '1':
		case '2':
		case '3':
		case '4':
		case '5':
		case '6':
		case '7':
		case '8':
		case '9':
			m_drawFlag[nChar - '0'] = !m_drawFlag[nChar - '0'];
			core.m_ogl.RedrawWindow();
			break;
	}
}
