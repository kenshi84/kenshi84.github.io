// LSTDemo.h : main header file for the LSTDemo application
//
#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"       // main symbols


// CLSTDemoApp:
// See LSTDemo.cpp for the implementation of this class
//

class CLSTDemoApp : public CWinApp
{
public:
	CLSTDemoApp();


// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnNavigationNext();
public:
	afx_msg void OnUpdateNavigationNext(CCmdUI *pCmdUI);
public:
	afx_msg void OnScaleSet();
public:
	afx_msg void OnUpdateScaleSet(CCmdUI *pCmdUI);
public:
	afx_msg void OnScaleDecrease();
public:
	afx_msg void OnUpdateScaleDecrease(CCmdUI *pCmdUI);
public:
	afx_msg void OnScaleIncrease();
public:
	afx_msg void OnUpdateScaleIncrease(CCmdUI *pCmdUI);
public:
	afx_msg void OnProcessAll();
public:
	afx_msg void OnUpdateProcessAll(CCmdUI *pCmdUI);
public:
	afx_msg void OnProcessOne();
public:
	afx_msg void OnUpdateProcessOne(CCmdUI *pCmdUI);
public:
	afx_msg void OnResultBrowse();
public:
	afx_msg void OnUpdateResultBrowse(CCmdUI *pCmdUI);
public:
	afx_msg void OnResultSave();
public:
	afx_msg void OnUpdateResultSave(CCmdUI *pCmdUI);
public:
	afx_msg void OnUpdateManualDecrease(CCmdUI *pCmdUI);
public:
	afx_msg void OnUpdateManualIncrease(CCmdUI *pCmdUI);
public:
	afx_msg void OnUpdateManualMove(CCmdUI *pCmdUI);
public:
	afx_msg void OnUpdateManualPaste(CCmdUI *pCmdUI);
public:
	afx_msg void OnUpdateManualRotate(CCmdUI *pCmdUI);
public:
	afx_msg void OnManualDecrease();
public:
	afx_msg void OnManualIncrease();
public:
	afx_msg void OnManualMove();
public:
	afx_msg void OnManualPaste();
public:
	afx_msg void OnManualRotate();
public:
	afx_msg void OnNavigationHome();
public:
	afx_msg void OnUpdateNavigationHome(CCmdUI *pCmdUI);
public:
	afx_msg void OnModeBrowsing();
public:
	afx_msg void OnUpdateModeBrowsing(CCmdUI *pCmdUI);
public:
	afx_msg void OnModeModeling();
public:
	afx_msg void OnUpdateModeModeling(CCmdUI *pCmdUI);
public:
	afx_msg void OnBrowseVolume();
public:
	afx_msg void OnUpdateBrowseVolume(CCmdUI *pCmdUI);
public:
	afx_msg void OnViewBrowse();
public:
	afx_msg void OnUpdateViewBrowse(CCmdUI *pCmdUI);
public:
	afx_msg void OnViewNavigation();
public:
	afx_msg void OnUpdateViewNavigation(CCmdUI *pCmdUI);
public:
	afx_msg void OnDepthErase();
public:
	afx_msg void OnUpdateDepthErase(CCmdUI *pCmdUI);
public:
	afx_msg void OnDepthFace();
public:
	afx_msg void OnUpdateDepthFace(CCmdUI *pCmdUI);
public:
	afx_msg void OnDepthInnermost();
public:
	afx_msg void OnUpdateDepthInnermost(CCmdUI *pCmdUI);
public:
	afx_msg void OnDepthMiddle();
public:
	afx_msg void OnUpdateDepthMiddle(CCmdUI *pCmdUI);
public:
	afx_msg void OnDepthMultiface();
public:
	afx_msg void OnUpdateDepthMultiface(CCmdUI *pCmdUI);
public:
	afx_msg void OnDepthOutermost();
public:
	afx_msg void OnUpdateDepthOutermost(CCmdUI *pCmdUI);
public:
	afx_msg void OnDepthStroke();
public:
	afx_msg void OnUpdateDepthStroke(CCmdUI *pCmdUI);
public:
	afx_msg void OnDepthUpdate();
public:
	afx_msg void OnUpdateDepthUpdate(CCmdUI *pCmdUI);
public:
	afx_msg void OnViewDepthpaint();
public:
	afx_msg void OnUpdateViewDepthpaint(CCmdUI *pCmdUI);
public:
	afx_msg void OnViewManualpaste();
public:
	afx_msg void OnUpdateViewManualpaste(CCmdUI *pCmdUI);
public:
	afx_msg void OnViewProcess();
public:
	afx_msg void OnUpdateViewProcess(CCmdUI *pCmdUI);
public:
	afx_msg void OnViewResult();
public:
	afx_msg void OnUpdateViewResult(CCmdUI *pCmdUI);
public:
	afx_msg void OnViewScale();
public:
	afx_msg void OnUpdateViewScale(CCmdUI *pCmdUI);
public:
	afx_msg void OnPeelInner();
public:
	afx_msg void OnPeelOuter();
public:
	afx_msg void OnUpdatePeelInner(CCmdUI *pCmdUI);
public:
	afx_msg void OnUpdatePeelOuter(CCmdUI *pCmdUI);
public:
	afx_msg void OnViewPeel();
public:
	afx_msg void OnUpdateViewPeel(CCmdUI *pCmdUI);
public:
	afx_msg void OnProcessCancel();
public:
	afx_msg void OnUpdateProcessCancel(CCmdUI *pCmdUI);
public:
	afx_msg void OnLoadtextureColor();
public:
	afx_msg void OnUpdateLoadtextureColor(CCmdUI *pCmdUI);
public:
	afx_msg void OnLoadtextureDisplacementmap();
public:
	afx_msg void OnUpdateLoadtextureDisplacementmap(CCmdUI *pCmdUI);
public:
	afx_msg void OnBrowseDisplacementmap();
public:
	afx_msg void OnUpdateBrowseDisplacementmap(CCmdUI *pCmdUI);
public:
	afx_msg void OnBrowseInformation();
public:
	afx_msg void OnUpdateBrowseInformation(CCmdUI *pCmdUI);
public:
	afx_msg void OnBrowseClear();
public:
	afx_msg void OnUpdateBrowseClear(CCmdUI *pCmdUI);
public:
	afx_msg void OnLoadtextureVolumerendering();
public:
	afx_msg void OnUpdateLoadtextureVolumerendering(CCmdUI *pCmdUI);
public:
	afx_msg void OnBrowseSave();
public:
	afx_msg void OnUpdateBrowseSave(CCmdUI *pCmdUI);
public:
	afx_msg void OnProcessClear();
public:
	afx_msg void OnUpdateProcessClear(CCmdUI *pCmdUI);
};

extern CLSTDemoApp theApp;