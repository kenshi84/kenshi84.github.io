LSTDemo:

Implementation of
Lapped Solid Textures: Filling a Model with Anisotropic Textures,
by Kenshi Takayama, Makoto Okabe, Takashi Ijiri and Takeo Igarashi,
SIGGRAPH 2008.

Copyright 2008, Kenshi Takayama
kenshi@ui.is.s.u-tokyo.ac.jp
Last update: 2008/12/29

+---------+
| Compile |
+---------+
This project file is built on Microsoft Visual Studio 2005.

