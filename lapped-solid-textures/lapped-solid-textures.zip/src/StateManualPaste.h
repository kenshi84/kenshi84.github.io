#pragma once
#include "state.h"

#include "Core.h"

class StateManualPaste : public State {
	StateManualPaste(void) {}
	~StateManualPaste(void) {}
public:
	static State* getInstance() {
		static StateManualPaste p;
		return &p;
	}
	State* next();
	bool isReady();
	void init();
	void draw();
	void postDraw(CWnd* hWnd, CDC* pDC);
	void OnLButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnLButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnRButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnRButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnMouseMove  (CView* view, UINT nFlags, CPoint& point);
	void OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags);
	void OnDropFiles  (CView* view, HDROP hDropInfo);
	void OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt);
	void OnLButtonDblClk(CView* view, UINT nFlags, CPoint point);
	void paste();
	void increase();
	void decrease();
	
	bool m_isRotateMode;
protected:
	bool m_isRButtonDown;
	bool m_isCutting;
	bool m_isDragging;
	bool m_isPastedOnce;
	CPoint m_pointOld;
	double m_currentScale;
	KVector3d m_seedPos;
	KVector3d m_vectorR;
	KVector3d m_vectorS;
	KVector3d m_vectorT;
};
