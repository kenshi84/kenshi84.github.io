#pragma once
#include "state.h"
#include "Core.h"

#include <vector>

class StateDepthPaint : public State {
	StateDepthPaint(void) {}
	~StateDepthPaint(void) {}
public:
	static State* getInstance() {
		static StateDepthPaint p;
		return &p;
	}
	State* next();
	bool isReady();
	void init();
	void draw();
	void postDraw(CWnd* hWnd, CDC* pDC);
	void OnLButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnLButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnRButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnRButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnMouseMove  (CView* view, UINT nFlags, CPoint& point);
	void OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {}
	void OnDropFiles  (CView* view, HDROP hDropInfo) {}
	void OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt) {}
	void OnLButtonDblClk(CView* view, UINT nFlags, CPoint point) {}
	
	void update();
	enum DepthColor {
		COLOR_OUT,
		COLOR_MID,
		COLOR_IN,
		COLOR_ERASE
	} m_currentColor;
	enum {
		TOOL_FACE,
		TOOL_MULTIFACE,
		TOOL_STROKE
	} m_currentTool;
protected:
	//bool subdivideOnSingularity(double minEdgeLength);
	std::vector<std::pair<DepthColor, std::vector<KVector3d> > > m_strokes;
	std::vector<DepthColor> m_faceColor;
	std::vector<KVector3d> m_points;
	std::vector<double>    m_values;
	bool m_isRButtonDown;
	bool m_isCutting;
	bool m_isDrawing;
	CPoint m_pointOld;
	void callGlColor3d(const DepthColor& col) {
		if (col == COLOR_OUT)
			glColor3d(1, 0, 0);
			//glColor3d(0, 1, 0);
		else if (col == COLOR_MID)
			glColor3d(0, 1, 0);
			//glColor3d(0.5, 1, 0);
		else
			glColor3d(0, 0, 1);
			//glColor3d(1, 1, 0);
	}
	double col2val(const DepthColor& col) {
		if (col == COLOR_ERASE)
			throw "Unexpected color!";
		if (col == COLOR_OUT)
			return 0;
		else if (col == COLOR_MID)
			return 0.5;
		else
			return 1;
	}
	void fillFace     (const int& polyID, const DepthColor& col);
	void fillMultiFace(const int& seedPolyID, const DepthColor& col);
};
