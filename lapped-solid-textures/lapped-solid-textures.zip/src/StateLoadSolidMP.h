#pragma once
#include "state.h"
#include "Core.h"

class StateLoadSolidMP : public State {
	StateLoadSolidMP(void);
	~StateLoadSolidMP(void) {}
public:
	static StateLoadSolidMP* getInstance() {
		static StateLoadSolidMP p;
		return &p;
	}
	State* next();
	bool isReady();
	void init();
	void draw();
	void postDraw(CWnd* hWnd, CDC* pDC);
	void OnLButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnLButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnRButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnRButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnMouseMove  (CView* view, UINT nFlags, CPoint& point);
	void OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags);
	void OnDropFiles  (CView* view, HDROP hDropInfo);
	void OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt) {}
	void OnLButtonDblClk(CView* view, UINT nFlags, CPoint point) {}
	enum {
		MODE_COLOR,
		MODE_DISPLACEMENT
	} m_mode;
	bool m_isVolumeRendering;
	void updateTetraCut();
	void updatePolyCut();
protected:
	bool m_isRButtonDown;
	bool m_isDragging;
	KPolygonModel m_polyIcosa;
	KPolygonModel m_polyIcosaX;
	KPolygonModel m_polyIcosaY;
	KPolygonModel m_polyIcosaZ;
	int m_currentSlice;
	enum {
		PLANE_X,
		PLANE_Y,
		PLANE_Z,
	} m_currentPlane;
	void updateHandlePos();
};
