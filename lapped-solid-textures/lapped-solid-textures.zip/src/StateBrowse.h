#pragma once
#include "state.h"

class StateBrowse : public State {
	StateBrowse(void){}
	~StateBrowse(void) {}
public:
	static StateBrowse* getInstance() {
		static StateBrowse p;
		return &p;
	}
	State* next();
	bool isReady() { return false; }
	void init();
	void draw();
	void postDraw(CWnd* hWnd, CDC* pDC);
	void OnLButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnLButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnRButtonDown(CView* view, UINT nFlags, CPoint& point);
	void OnRButtonUp  (CView* view, UINT nFlags, CPoint& point);
	void OnMouseMove  (CView* view, UINT nFlags, CPoint& point);
	void OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags);
	void OnDropFiles  (CView* view, HDROP hDropInfo);
	void OnMouseWheel (CView* view, UINT nFlags, short zDelta, CPoint pt) {}
	void OnLButtonDblClk(CView* view, UINT nFlags, CPoint point) {}
	void doVolumeRendering();
	void doDisplacementMap();
	void showInformation();
	void clear();
	void save();

protected:
	bool m_isRButtonDown;
	bool m_isCutting;
	bool m_drawFlag[10];
	//bool m_isDrawMesh;
	CPoint m_pointOld;
};
