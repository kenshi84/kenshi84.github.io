#include "StdAfx.h"
#include "StateLoadTetra.h"
#include "StateLoadSolid.h"
#include "Drawer.h"
#include "MainFrm.h"

using namespace std;

State* StateLoadTetra::next() {
	Core& core = *Core::getInstance();
	core.constructLaplacian();
	core.m_lst.setTetra(core.m_tetraOrg);
	return StateLoadSolid::getInstance();
}

void StateLoadTetra::init() {
	Core& core = *Core::getInstance();
	core.m_cutStroke.clear();
	core.m_patch.clear();
	core.m_polyCut   = KMultiTexPolygonModel();
	core.m_polyPatch = KMultiTexPolygonModel();
	core.m_polySlice = KMultiTexPolygonModel();
	core.m_tetraOrg  = KMultiTexTetraModel();
	core.m_tetraCut  =KMultiTexTetraModel();
	core.m_tetScale.clear();
	core.m_tetVectorS.clear();
	core.m_tetVectorT.clear();
	core.m_volInput.clear();
	core.m_volMiddle.clear();
	core.m_volOuter.clear();
	core.m_volInner.clear();
	core.m_volManual.clear();
	core.m_vtxDepth.clear();
	core.m_vtxValueCut.clear();
	core.m_rbfDepth.clear();
	core.m_drawer.m_texNameManual.clear();
	core.m_volInputDisp.clear();
	core.m_volManualDisp.clear();
	if (core.p_mainFrm != NULL) {
		core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_navigate, true, true);
		core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_browse, false, true);
		core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_depthPaint, false, true);
		core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_manualPaste, false, true);
		core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_process, false, true);
		core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_result, false, true);
		core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_scale, false, true);
		core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_peelStroke, false, true);
	}
}

void StateLoadTetra::draw() {
	Core& core = *Core::getInstance();
	KMultiTexPolygonModel& poly = core.m_polyCut;
	glColor3dv(Drawer::COLOR_FACE);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& n = p.m_normal[j];
			KVector3d& v = poly.m_vertices[p.m_vtx[j]].m_pos;
			glNormal3dv(n.getPtr());
			glVertex3dv(v.getPtr());
		}
	}
	glEnd();
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDepthMask(GL_FALSE);
	glColor3dv(Drawer::COLOR_CUTSTROKE);
	glLineWidth(5);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < (int)core.m_cutStroke.size(); ++i)
		glVertex3dv(core.m_cutStroke[i].getPtr());
	glEnd();
	glDepthMask(GL_TRUE);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_LIGHTING);
}
void StateLoadTetra::postDraw(CWnd* hWnd, CDC* pDC) {
	Core& core = *Core::getInstance();
	if (!core.m_tetraOrg.m_tetras.empty()) return;
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	pDC->DrawText ( "Drop tetra model (*.ele) here!", -1, &rc, DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	pDC->SelectObject ( pOldFont );
}
void StateLoadTetra::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	if (!core.m_tetraOrg.m_tetras.empty()) {
		core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
		KVector3d pos(start);
		pos.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(pos);
		m_pointOld = point;
		m_isCutting = true;
	}
}
void StateLoadTetra::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (core.m_cutStroke.empty()) return;
	if (core.m_cutStroke.size() == 1) {
		core.initCut();
	} else {
		core.calcVtxValueCut(core.m_cutStroke);
		core.updateCut();
	}
	core.m_cutStroke.clear();
	core.m_ogl.RedrawWindow();
	m_isCutting = false;
}
void StateLoadTetra::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			Core::getInstance()->m_ogl.ButtonDownForTranslate(point);
		} else {
			Core::getInstance()->m_ogl.ButtonDownForRotate(point);
		}
	}else {
		Core::getInstance()->m_ogl.ButtonDownForZoom(point);
	}
	m_isRButtonDown = true;
}
void StateLoadTetra::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core::getInstance()->m_ogl.ButtonUp();
	m_isRButtonDown = false;
}
void StateLoadTetra::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isRButtonDown) {
		core.m_ogl.MouseMove(point);
		return;
	} else if (m_isCutting) {
		double dx = point.x - m_pointOld.x;
		double dy = point.y - m_pointOld.y;
		double dist = sqrt(dx * dx + dy * dy);
		if (dist < 20) return;
		KVector3d start, ori;
		core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
		KVector3d pos(start);
		pos.addWeighted(ori, 0.5);
		core.m_cutStroke.push_back(pos);
		core.m_ogl.RedrawWindow();
	}
}
void StateLoadTetra::OnKeyDown    (CView* view, UINT nChar, UINT nRepCnt, UINT nFlags) {}
void StateLoadTetra::OnDropFiles  (CView* view, HDROP hDropInfo) {
	char fname[256];
	if (DragQueryFile(hDropInfo, -1, fname, sizeof(fname)) != 1) return;
	DragQueryFile(hDropInfo, 0, fname, sizeof(fname));
	
	string str(fname);
	string ext = str.substr(str.length() - 4, 4);
	if (ext.compare(".ele")) {
		AfxMessageBox("Please drop *.ele file!");
		return;
	}
	str = str.substr(0, str.length() - 4);
	Core& core = *Core::getInstance();
	core.loadTetraOrg(str);
	core.initCut();
	core.m_ogl.RedrawWindow();
}
