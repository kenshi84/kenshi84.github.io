// LSTDemoView.cpp : implementation of the CLSTDemoView class
//

#include "stdafx.h"
#include "LSTDemo.h"

#include "LSTDemoDoc.h"
#include "LSTDemoView.h"

#include "Core.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CLSTDemoView

IMPLEMENT_DYNCREATE(CLSTDemoView, CView)

BEGIN_MESSAGE_MAP(CLSTDemoView, CView)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_WM_DROPFILES()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_RBUTTONDOWN()
	ON_WM_RBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_MOUSEWHEEL()
	ON_WM_LBUTTONDBLCLK()
	ON_WM_KEYDOWN()
END_MESSAGE_MAP()

// CLSTDemoView construction/destruction

CLSTDemoView::CLSTDemoView()
{
	// TODO: add construction code here

}

CLSTDemoView::~CLSTDemoView()
{
}

BOOL CLSTDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

// CLSTDemoView drawing

void CLSTDemoView::OnDraw(CDC* pDC)
{
	CLSTDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	Core::getInstance()->m_ogl.OnDraw_Begin();
	Core::getInstance()->m_drawer.draw();
	Core::getInstance()->m_ogl.OnDraw_End();
	Core::getInstance()->m_drawer.postDraw(this, pDC);
}


// CLSTDemoView diagnostics

#ifdef _DEBUG
void CLSTDemoView::AssertValid() const
{
	CView::AssertValid();
}

void CLSTDemoView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CLSTDemoDoc* CLSTDemoView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CLSTDemoDoc)));
	return (CLSTDemoDoc*)m_pDocument;
}
#endif //_DEBUG


// CLSTDemoView message handlers

int CLSTDemoView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	Core::getInstance()->p_view = this;
	Core::getInstance()->m_ogl.OnCreate(this);
	Core::getInstance()->m_drawer.init();
	DragAcceptFiles();

	return 0;
}

void CLSTDemoView::OnDestroy()
{
	CView::OnDestroy();

	Core::getInstance()->m_ogl.OnDestroy();
}

BOOL CLSTDemoView::OnEraseBkgnd(CDC* pDC)
{
	return TRUE;//CView::OnEraseBkgnd(pDC);
}

void CLSTDemoView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	Core::getInstance()->m_ogl.OnSize(cx, cy);
}

void CLSTDemoView::OnDropFiles(HDROP hDropInfo)
{
	Core::getInstance()->m_handler.OnDropFiles(this, hDropInfo);
	CView::OnDropFiles(hDropInfo);
}

void CLSTDemoView::OnLButtonDown(UINT nFlags, CPoint point)
{
	Core::getInstance()->m_handler.OnLButtonDown(this, nFlags, point);
	CView::OnLButtonDown(nFlags, point);
}

void CLSTDemoView::OnLButtonUp(UINT nFlags, CPoint point)
{
	Core::getInstance()->m_handler.OnLButtonUp(this, nFlags, point);
	CView::OnLButtonUp(nFlags, point);
}

void CLSTDemoView::OnRButtonDown(UINT nFlags, CPoint point)
{
	Core::getInstance()->m_handler.OnRButtonDown(this, nFlags, point);
	CView::OnRButtonDown(nFlags, point);
}

void CLSTDemoView::OnRButtonUp(UINT nFlags, CPoint point)
{
	Core::getInstance()->m_handler.OnRButtonUp(this, nFlags, point);
	CView::OnRButtonUp(nFlags, point);
}

void CLSTDemoView::OnMouseMove(UINT nFlags, CPoint point)
{
	Core::getInstance()->m_handler.OnMouseMove(this, nFlags, point);
	CView::OnMouseMove(nFlags, point);
}

BOOL CLSTDemoView::OnMouseWheel(UINT nFlags, short zDelta, CPoint pt)
{
	Core::getInstance()->m_handler.OnMouseWheel(this, nFlags, zDelta, pt);

	return CView::OnMouseWheel(nFlags, zDelta, pt);
}

void CLSTDemoView::OnLButtonDblClk(UINT nFlags, CPoint point)
{
	Core::getInstance()->m_handler.OnLButtonDblClk(this, nFlags, point);

	CView::OnLButtonDblClk(nFlags, point);
}

void CLSTDemoView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) {
	Core::getInstance()->m_handler.OnKeyDown(this, nChar, nRepCnt, nFlags);

	CView::OnKeyDown(nChar, nRepCnt, nFlags);
}
