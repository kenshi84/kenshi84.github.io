#include "StdAfx.h"
#include "StateResult.h"
#include "Core.h"
#include "MainFrm.h"
#include "StateLoadSolidMP.h"
#include "StateBrowse.h"

using namespace std;

State* StateResult::next() {
	Core& core = *Core::getInstance();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_result, false, true);
	return StateLoadSolidMP::getInstance();
}

void StateResult::init() {
	Core& core = *Core::getInstance();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_result, true, true);
}

void StateResult::draw() {
	Core& core = *Core::getInstance();
	KMultiTexPolygonModel& poly = core.m_polyCut;
	glEnable(GL_LIGHTING);
	glColor3dv(Drawer::COLOR_FACE);
	glBegin(GL_TRIANGLES);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < 3; ++j) {
			KVector3d& n = p.m_normal[j];
			KVector3d& v = poly.m_vertices[p.m_vtx[j]].m_pos;
			glNormal3dv(n.getPtr());
			glVertex3dv(v.getPtr());
		}
	}
	glEnd();
	glEnable(GL_TEXTURE_3D);
	glEnable(GL_BLEND);
	for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
		KMultiTexPolygon& p = poly.m_polygons[i];
		for (int j = 0; j < (int)p.m_texCoords.size(); ++j) {
			int texID = p.m_texIDs[j];
			int texName =
				texID == 0 ? core.m_drawer.m_texNameMiddle
				: texID == 1 ? core.m_drawer.m_texNameOuter
				: texID == 2 ? core.m_drawer.m_texNameInner
				: core.m_drawer.m_texNameManual[texID - 3];
			glBindTexture(GL_TEXTURE_3D, texName);
			glBegin(GL_TRIANGLES);
			for (int k = 0; k < 3; ++k) {
				KVector3d& n = p.m_normal[k];
				KVector3d& t = p.m_texCoords[j].m_coord[k];
				KVector3d& v = poly.m_vertices[p.m_vtx[k]].m_pos;
				glNormal3dv(n.getPtr());
				glTexCoord3dv(t.getPtr());
				glVertex3dv(v.getPtr());
			}
			glEnd();
		}
	}
	glDisable(GL_TEXTURE_3D);
	glDisable(GL_BLEND);
	//glColor3d(0, 1, 1);
	//glLineWidth(3);
	//glBegin(GL_LINES);
	//for (int i = 0; i < (int)poly.m_polygons.size(); ++i) {
	//	KMultiTexPolygon& p = poly.m_polygons[i];
	//	for (int j = 0; j < 3; ++j) {
	//		KVector3d& p0 = poly.m_vertices[p.m_vtx[j]].m_pos;
	//		KVector3d& p1 = poly.m_vertices[p.m_vtx[(j + 1) % 3]].m_pos;
	//		glVertex3dv(p0.getPtr());
	//		glVertex3dv(p1.getPtr());
	//	}
	//}
	//glEnd();
	glDisable(GL_DEPTH_TEST);
	glDisable(GL_LIGHTING);
	glDepthMask(GL_FALSE);
	glColor3dv(Drawer::COLOR_CUTSTROKE);
	glLineWidth(5);
	glBegin(GL_LINE_STRIP);
	for (int i = 0; i < (int)core.m_cutStroke.size(); ++i)
		glVertex3dv(core.m_cutStroke[i].getPtr());
	glEnd();
	glDepthMask(GL_TRUE);
	glEnable(GL_DEPTH_TEST);
}

void StateResult::postDraw(CWnd* hWnd, CDC* pDC) {
	Core& core = *Core::getInstance();
	CFont font;
	CFont *pOldFont;
	font.CreatePointFont ( 300, "Comic Sans MS", pDC );
	pOldFont = pDC->SelectObject ( &font );
	pDC->SetBkMode ( TRANSPARENT );
	pDC->SetTextColor ( RGB ( 255, 0, 0 ) );
	CRect rc;
	hWnd->GetClientRect ( &rc );
	CString str;
	pDC->DrawText("Result.", -1, &rc, DT_LEFT | DT_TOP | DT_SINGLELINE);
	pDC->SelectObject(pOldFont);
}

void StateResult::OnLButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	start.addWeighted(ori, 0.5);
	core.m_cutStroke.push_back(start);
	m_isCutting = true;
	m_pointOld = point;
}

void StateResult::OnLButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	m_isCutting = false;
	if (core.m_cutStroke.size() == 1) {
		core.initCut();
	} else {
		core.calcVtxValueCut(core.m_cutStroke);
		core.updateCut();
	}
	core.m_cutStroke.clear();
	core.m_ogl.RedrawWindow();
}

void StateResult::OnRButtonDown(CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	CRect rect;
	view->GetWindowRect(&rect);
	int width = rect.right - rect.left;
	if (point.x < width * 0.9) {
		if (nFlags & MK_SHIFT) {
			core.m_ogl.ButtonDownForTranslate(point);
		} else {
			core.m_ogl.ButtonDownForRotate(point);
		}
	}else {
		core.m_ogl.ButtonDownForZoom(point);
	}
	m_isRButtonDown = true;
}

void StateResult::OnRButtonUp  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	core.m_ogl.ButtonUp();
	m_isRButtonDown = false;
}

void StateResult::OnMouseMove  (CView* view, UINT nFlags, CPoint& point) {
	Core& core = *Core::getInstance();
	if (m_isRButtonDown) {
		core.m_ogl.MouseMove(point);
		return;
	}
	if (!m_isCutting) return;
	double dx = point.x - m_pointOld.x;
	double dy = point.y - m_pointOld.y;
	double dist = sqrt(dx * dx + dy * dy);
	if (dist < 10) return;
	m_pointOld = point;
	KVector3d start, ori;
	core.m_ogl.getScreenCoordToGlobalLine(point.x, point.y, start, ori);
	start.addWeighted(ori, 0.5);
	core.m_cutStroke.push_back(start);
	core.m_ogl.RedrawWindow();
}

void StateResult::save() {
	Core& core = *Core::getInstance();
	CFileDialog dialog(FALSE, ".lst", NULL, OFN_OVERWRITEPROMPT, "Lapped Solid Texture files(*.lst)|*.lst||");
	if (dialog.DoModal() != IDOK) return;
	string fname = dialog.GetPathName();
	FILE * fout = fopen(fname.c_str(), "wb");
	if (!fout) {
		CString str;
		str.Format("Failed to open file %s", fname.c_str());
		AfxMessageBox(str);
		return;
	}
	
	bool hasLayer = !core.m_volOuter.empty();
	
	// the size of solid textures
	fwrite(&Core::VOLSIZE, sizeof(int), 1, fout);
	
	{// total # of solid textures
		int totalVols = 1;
		if (hasLayer) totalVols += 2;
		totalVols += (int)core.m_volManual.size();
		fwrite(&totalVols, sizeof(int), 1, fout);
	}
	
	{	// solid texture data
		int volBytes4 = Core::VOLSIZE * Core::VOLSIZE * Core::VOLSIZE * 4;
		fwrite(&core.m_volMiddle[0], 1, volBytes4, fout);
		if (hasLayer) {
			fwrite(&core.m_volOuter[0], 1, volBytes4, fout);
			fwrite(&core.m_volInner[0], 1, volBytes4, fout);
		}
		for (int i = 0; i < (int)core.m_volManual.size(); ++i)
			fwrite(&core.m_volManual[i][0], 1, volBytes4, fout);
	}
	
	{	// displacement map
		int hasDisplacement = (int)!core.m_volInputDisp.empty();
		fwrite(&hasDisplacement, sizeof(int), 1, fout);
		if (hasDisplacement) {
			int volBytes = Core::VOLSIZE * Core::VOLSIZE * Core::VOLSIZE;
			fwrite(&core.m_volInputDisp[0], 1, volBytes, fout);
			if (hasLayer) {
				fwrite(&core.m_volInputDisp[0], 1, volBytes, fout);
				fwrite(&core.m_volInputDisp[0], 1, volBytes, fout);
			}
			for (int i = 0; i < (int)core.m_volManualDisp.size(); ++i)
				fwrite(&core.m_volManualDisp[i][0], 1, volBytes, fout);
		}
	}
	
	{	// vertex list
		int numVtx = (int)core.m_tetraOrg.m_vertices.size();
		fwrite(&numVtx, sizeof(int), 1, fout);
		for (int i = 0; i < numVtx; ++i)
			fwrite(&core.m_tetraOrg.m_vertices[i].m_pos, sizeof(double), 3, fout);
	}
	
	{	// multi-textured tetra list
		int numTet = (int)core.m_tetraOrg.m_tetras.size();
		fwrite(&numTet, sizeof(int), 1, fout);
		for (int i = 0; i < numTet; ++i) {
			KMultiTexTetra& tet = core.m_tetraOrg.m_tetras[i];
			fwrite(tet.m_vtx, sizeof(int), 4, fout);
			int numTex = (int)tet.m_texCoords.size();
			fwrite(&numTex, sizeof(int), 1, fout);
			if (numTex == 0) continue;
			fwrite(&tet.m_texCoords[0], sizeof(KTetraTexCoord), numTex, fout);
			fwrite(&tet.m_texIDs   [0], sizeof(int),            numTex, fout);
		}
	}
	fclose(fout);
}

void StateResult::gotoBrowsing() {
	Core& core = *Core::getInstance();
	
	bool hasLayer = !core.m_volOuter.empty();
	
	// total # of solid textures
	int totalVols = 1;
	if (hasLayer) totalVols += 2;
	totalVols += (int)core.m_volManual.size();

	core.m_volBrowse.clear();
	core.m_volBrowse.reserve(totalVols);
	core.m_volBrowse.push_back(core.m_volMiddle);
	if (hasLayer) {
		core.m_volBrowse.push_back(core.m_volOuter);
		core.m_volBrowse.push_back(core.m_volInner);
	}
	for (int i = 0; i < (int)core.m_volManual.size(); ++i)
		core.m_volBrowse.push_back(core.m_volManual[i]);
	core.m_drawer.m_texNameBrowse.clear();
	core.m_drawer.genTexBrowse();
	
	core.m_volBrowseDisp.clear();
	if (!core.m_volInputDisp.empty()) {
		core.m_volBrowseDisp.reserve(totalVols);
		core.m_volBrowseDisp.push_back(core.m_volInputDisp);
		if (hasLayer) {
			core.m_volBrowseDisp.push_back(core.m_volInputDisp);
			core.m_volBrowseDisp.push_back(core.m_volInputDisp);
		}
		for (int i = 0; i < (int)core.m_volManualDisp.size(); ++i)
			core.m_volBrowseDisp.push_back(core.m_volManualDisp[i]);
	}
	
	core.initCut();
	core.m_polySlice = KMultiTexPolygonModel();
	core.m_state = StateBrowse::getInstance();
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_result,   false, true);
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_navigate, false, true);
	core.p_mainFrm->ShowControlBar(&core.p_mainFrm->m_wndToolBar_browse,   true,  true);
	core.m_ogl.RedrawWindow();
}

