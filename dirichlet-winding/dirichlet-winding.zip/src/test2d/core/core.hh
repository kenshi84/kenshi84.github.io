#pragma once
#include <kt84/geometry/PolylineT.hh>
#include "Mesh.hh"

namespace core {

void triangulate(
    const std::vector<kt84::Polyline2d>& paths,
    char* switches,
    double margin_ratio,
    Mesh& mesh);

bool is_intersecting(
    const Eigen::Vector2d& ray_origin,
    const Eigen::Vector2d& ray_direction,
    const Eigen::Vector2d& segment0,
    const Eigen::Vector2d& segment1,
    double& ray_t);

Eigen::VectorXi determine_signs(
    const Mesh& mesh,
    int num_paths,
    std::function<double(OpenMesh::PolyConnectivity::FHandle)> face_scalar_func);

Eigen::VectorXi find_energy_minimizer(
    int num_paths,
    std::function<double(const Eigen::VectorXi&)> energy_func);

namespace method_winding {              // defined for oriented facets
    void compute_field(
        const std::vector<kt84::Polyline2d>& paths,
        const Eigen::VectorXi& signs,
        Mesh& mesh);
    
    Eigen::MatrixXd compute_dirichlet_matrix(const std::vector<kt84::Polyline2d>& paths);
    
    double compute_dirichlet_energy(
        const Eigen::MatrixXd& Q,
        const Eigen::VectorXi& signs);
}

namespace method_diffusion {            // defined for oriented facets
    void compute_field(
        const Eigen::VectorXi& signs,
        Mesh& mesh);
    
    double compute_dirichlet_energy(
        const Mesh& mesh,
        const Eigen::VectorXi& signs);
    
    int is_inside(
        // given halfedge h=(v0, v1), determine whether h is inside the halfspace defined by a path that passes through v0. return value: 1=>inside, 0=>outside, -1=>undefined (i.e., v0 is interior, or is at paths endpoint/crossing)
        const Mesh& mesh, 
        const Eigen::VectorXi& signs, 
        Mesh::HHandle h);
}

namespace method_solidity {             // defined for unoriented facets
    void compute_field(Mesh& mesh);
}

namespace method_parity {       // defined for unoriented facets
    void compute_field(
        const std::vector<kt84::Polyline2d>& paths,
        Mesh& mesh,
        int samples_per_face);
}

namespace method_rayshoot {
    Eigen::VectorXi determine_signs(
        const std::vector<kt84::Polyline2d>& paths,
        int samples_total,
        bool use_parity);
}

}
