#pragma once
#include <OpenMesh/Core/Mesh/TriMesh_ArrayKernelT.hh>
#include <kt84/openmesh/base/Utility.hh>
#include <kt84/openmesh/base/DebugInfo.hh>
#include <kt84/openmesh/base/CotanWeight.hh>

namespace core {

struct MeshTraits : public OpenMesh::DefaultTraits {
    typedef OpenMesh::Vec3d Point;
    typedef OpenMesh::Vec3d Normal;
    FaceTraits
        , public kt84::CotanWeight_FaceTraits
    {
        double solidity;
        double winding;
        double parity;
        int var_index;
        FaceT()
            : solidity(0)
            , winding(0)
            , parity(0)
            , var_index(-1)
        {}
    };
    VertexTraits {
        double diffusion;
        int var_index;
        int num_path_edges;         // number of adjacent path edges (needed for diffusion computation)
        VertexT()
            : diffusion(-1)
            , var_index(-1)
        {}
    };
    HalfedgeTraits
        , public kt84::CotanWeight_HalfedgeTraits
    {};
    EdgeTraits
        , public kt84::CotanWeight_EdgeTraits
    {
        int path_id;
        OpenMesh::Vec3d dir;
        EdgeT()
            : path_id(-1)
            , dir(0, 0, 0)
        {}
    };
};

typedef OpenMesh::TriMesh_ArrayKernelT<MeshTraits> MeshBase;

struct Mesh
    : public MeshBase
    , public kt84::Utility    <MeshBase, Mesh>
    , public kt84::CotanWeight<MeshBase, Mesh>
    , public kt84::DebugInfo  <MeshBase, Mesh>
{};

}
