#include "core.hh"
#include <boost/range/numeric.hpp>
#include <kt84/util.hh>
#include <kt84/eigen_util.hh>
#include <kt84/adjacent_pairs.hh>
#include <kt84/discrete_distribution.hh>
using namespace std;
using namespace Eigen;
using namespace kt84;

VectorXi core::method_rayshoot::determine_signs(
    const vector<Polyline2d>& paths,
    int samples_total,
    bool use_parity)
{
    int num_paths = paths.size();
    
    // Determine per-path #samples
    vector<int> samples_per_path(num_paths, 10);        // #samples should be at least this amount
    double total_length = 0;
    for (auto& path : paths)
        total_length += path.length();
    for (int i = 0; i < num_paths; ++i)
        samples_per_path[i] += static_cast<int>(samples_total * paths[i].length() / total_length);
    // update total #samples
    samples_total = boost::accumulate(samples_per_path, 0);

    // Cumulative distribution of #samples
    vector<int> samples_cdf = samples_per_path;
    for (int i = 1; i < num_paths; ++i)
        samples_cdf[i] = samples_cdf[i - 1] + samples_per_path[i];
    
    // Prepare discrete_distribution per path
    vector<kt84::discrete_distribution<int>> ddist;
    for(auto& path : paths) {
        vector<double> segment_length;
        for (auto segment : adjacent_pairs(path, path.is_loop))
            segment_length.push_back((segment.second - segment.first).norm());
        ddist.push_back(kt84::discrete_distribution<int>(segment_length.begin(), segment_length.end()));
    }
    
    // For Mode::Distance
    vector<int   > infinity_front(num_paths, 0);    // Counting rays reaching infinity
    vector<int   > infinity_back (num_paths, 0);
    vector<double> distance_front(num_paths, 0);    // Summing distances between ray origin and intersecting point
    vector<double> distance_back (num_paths, 0);
    // For Mode::Parity
    vector<double> parity_front(num_paths, 0);
    vector<double> parity_back (num_paths, 0);
    // Shoot rays in parallel
#pragma omp parallel for
    for (int i = 0; i < samples_total; ++i) {
        int path_id = 0;
        while (samples_cdf[path_id] <= i) ++path_id;
        auto& path = paths[path_id];
        
        // Choose segment with probability proportional to its length
        int segment_id = ddist[path_id](util::random_engine());
        Vector2d segment_p0 = path[segment_id];
        Vector2d segment_p1 = path[(segment_id + 1) % path.size()];
        
        // Generate ray
        double s = util::random_double(0, 1);
        double t = util::random_double(0, 2 * util::pi());
        Vector2d ray_origin    = (1 - s) * segment_p0 + s * segment_p1;
        Vector2d ray_direction = Vector2d(cos(t), sin(t));
        if (ray_direction.dot(-eigen_util::rotate90(segment_p1 - segment_p0)) < 0) ray_direction *= -1;
        
        // For visibility method
        double ray_t_min_front = util::dbl_max();
        double ray_t_min_back  = util::dbl_max();
        // For parity method
        int count_front = 0;
        int count_back  = 0;
        for (auto& path2 : paths) {
            for (auto segment : adjacent_pairs(path2, path2.is_loop)) {
                double ray_t;
                // Shoot front side
                if (is_intersecting(ray_origin, ray_direction, segment.first, segment.second, ray_t)) {
                    if (use_parity)
                        ++count_front;
                    else
                        util::update_if_smaller(ray_t_min_front, ray_t);
                }
                // Shoot back side
                if (is_intersecting(ray_origin, -ray_direction, segment.first, segment.second, ray_t)) {
                    if (use_parity)
                        ++count_back;
                    else
                        util::update_if_smaller(ray_t_min_back , ray_t);
                }
            }
        }
        
        if (use_parity) {
            // Accumulate parity vote
            parity_front[path_id] += count_front % 2;
            parity_back [path_id] += count_back  % 2;
        
        } else {
            // Update {infinity|distance}_front
            if (ray_t_min_front == util::dbl_max())
                ++infinity_front[path_id];
            else
                distance_front[path_id] += ray_t_min_front;
            // Update {infinity|distance}_back
            if (ray_t_min_back == util::dbl_max())
                ++infinity_back[path_id];
            else
                distance_back[path_id] += ray_t_min_back;
        }
    }
    
    if (use_parity) {
        // Average parity (not really necessary)
        for (int i = 0; i < num_paths; ++i) {
            parity_front[i] /= samples_per_path[i];
            parity_back [i] /= samples_per_path[i];
        }
    }
    
    // Determine signs
    VectorXi signs = VectorXi::Zero(num_paths);
    for (int i = 0; i < num_paths; ++i) {
        bool is_flipped = use_parity
            ? parity_front[i] > parity_back[i]
            : (infinity_front[i] < infinity_back[i] || infinity_front[i] == infinity_back[i] && distance_front[i] < distance_back[i]);
        signs[i] = is_flipped ? -1 : 1;
    }
    return signs;
}
