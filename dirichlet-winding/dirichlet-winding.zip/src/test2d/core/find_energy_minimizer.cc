#include "core.hh"
#include <kt84/PriorityElement.hh>
#include <boost/range/algorithm.hpp>
using namespace std;
using namespace kt84;
using namespace Eigen;

VectorXi core::find_energy_minimizer(int num_paths, function<double(const VectorXi&)> energy_func) {
    int n = 1 << num_paths;
    
    auto make_signs_from_integer = [&] (int integer) {
        VectorXi signs = VectorXi::Zero(num_paths);
        for (int i = 0; i < num_paths; ++i, integer /= 2)
            signs[i] = integer % 2 ? 1 : -1;
        return signs;
    };
    
    vector<PriorityElement<double, VectorXi>> result;
    result.resize(n);
#pragma omp parallel for
    for (int i = 0; i < n; ++i) {
        auto signs = make_signs_from_integer(i);
        double energy = energy_func(signs);
        result[i] = make_PriorityElement(energy, signs);
    }
    
    boost::sort(result);
    
    return result.front().element;
}
