#include "core.hh"
#include <kt84/eigen_util.hh>
using namespace Eigen;

bool core::is_intersecting(const Vector2d& ray_origin, const Vector2d& ray_direction, const Vector2d& segment0, const Vector2d& segment1, double& ray_t) {
    double segment_t;
    if (!kt84::eigen_util::intersection<Vector2d>(ray_origin, ray_origin + ray_direction, segment0, segment1, ray_t, segment_t))
        return false;
    if (ray_t < 0.000001 || segment_t < 0 || segment_t > 1)
        return false;
    return true;
}

