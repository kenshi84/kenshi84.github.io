#include "core.hh"
using namespace std;
using namespace Eigen;

VectorXi core::determine_signs(const Mesh& mesh, int num_paths, function<double(OpenMesh::PolyConnectivity::FHandle)> face_scalar_func) {
    VectorXd signs_accum = VectorXd::Zero(num_paths);
    for (auto e : mesh.edges()) {
        int path_id = mesh.data(e).path_id;
        if (path_id < 0) continue;

        auto h = mesh.halfedge_handle(e, 0);
        // make sure that h is oriented in the same way as the original path
        if (mesh.util_halfedge_to_vector(h).operator|(mesh.data(e).dir) < 0)
            h = mesh.halfedge_handle(e, 1);
        
        double sign_vote = face_scalar_func(mesh.face_handle(h)) - face_scalar_func(mesh.opposite_face_handle(h));
        signs_accum[path_id] += mesh.data(e).edgeLength * sign_vote;
    }
    
    VectorXi signs = VectorXi::Zero(num_paths);
    for (int i = 0; i < num_paths; ++i)
        signs[i] = signs_accum[i] < 0 ? -1 : 1;
    return signs;
}
