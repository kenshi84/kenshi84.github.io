#include "core.hh"
#include <Eigen/Sparse>
using namespace std;
using namespace Eigen;

void core::method_solidity::compute_field(Mesh& mesh) {
    typedef SparseMatrix<double> Matrix;
    typedef Triplet<double> Triplet;
    
    // assign variable index for non-boundary faces
    int n = 0;
    for (auto f : mesh.faces()) {
        if (!mesh.is_boundary(f))
            mesh.data(f).var_index = n++;
        else
            mesh.data(f).solidity = -1;
    }
    
    // build matrix and right hand side
    vector<Triplet> triplets;
    VectorXd b = VectorXd::Zero(n);
    for (auto f : mesh.faces()) {
        if (mesh.is_boundary(f)) continue;
        
        // sum of edge length
        double edgeLength_sum = 0;
        for (auto fe : mesh.fe_range(f))
            edgeLength_sum += mesh.data(fe).edgeLength;
        
        // diagonal
        int i = mesh.data(f).var_index;
        triplets.push_back(Triplet(i, i, edgeLength_sum));
        
        // off-diagonal and right hand side
        for (auto fe : mesh.fe_range(f)) {
            auto ff = mesh.util_opposite_face(fe, f);
            double length    = mesh.data(fe).edgeLength;
            bool   is_opaque = mesh.data(fe).path_id > -1;
            
            if (mesh.is_boundary(ff)) {
                // adjacent face is at boundary -> set right hand side
                b[i] += (is_opaque ? -1 : 1) * length * (-1);
            } else {
                // adjacent face is non-boundary -> set off-diagonal
                int j = mesh.data(ff).var_index;
                triplets.push_back(Triplet(i, j, (is_opaque ? 1 : -1) * length));
            }
        }
    }
    Matrix M(n, n);
    M.setFromTriplets(triplets.begin(), triplets.end());
    
    // solve
    SimplicialCholesky<Matrix> solver(M);
    VectorXd x = solver.solve(b);
    
    // set solidity
    for (auto f : mesh.faces()) {
        if (!mesh.is_boundary(f))
            mesh.data(f).solidity = x[mesh.data(f).var_index];
        // normalize
        mesh.data(f).solidity += 1;
        mesh.data(f).solidity /= 2;
    }
}
