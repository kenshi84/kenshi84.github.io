#include "core.hh"
#include <kt84/util.hh>
#include <kt84/adjacent_pairs.hh>
#include <kt84/eigen_util.hh>
#include <kt84/openmesh/vector_convert.hh>
using namespace std;
using namespace kt84;
using namespace Eigen;

double compute_winding(const Vector2d& p, const Polyline2d& path) {
    double result = 0;
    for (auto edge : adjacent_pairs(path, path.is_loop)) {
        Vector2d a = edge.first  - p;
        Vector2d b = edge.second - p;
        result += atan2(a.x() * b.y() - a.y() * b.x(), a.dot(b));
    }
    return result / (2 * util::pi());
}

Vector2d compute_gradient(const Vector2d& p, const Polyline2d& path) {
    Vector2d result = Vector2d::Zero();
    for (auto edge : adjacent_pairs(path, path.is_loop)) {
        Vector2d c0 = edge.first;
        Vector2d c1 = edge.second;
        Vector2d d0 = c0 - p;
        Vector2d d1 = c1 - p;
        Vector2d d2(-d0.y(), d0.x());
        double s = d0.dot(d1);
        double t = d2.dot(d1);
        /*
            w(x, y) = f(s, t) = atan2(t, s)
            http://en.wikipedia.org/wiki/Atan2#Derivative
            p = (x, y)
            s(p) = (c0 - p).(c1 - p)
                 = p.p - p.(c0 + c1) + c0.c1
            ds/dx = 2x - (x0 + x1)
            ds/dy = 2y - (y0 + y1)
            t(p) = (- y0 + y, x0 - x).(x1 - x, y1 - y)
                 = (-y0 + y)(x1 - x) + (x0 - x)(y1 - y)
                 = (-y0*x1 + y0*x + y*x1 - x*y) + (x0*y1 - x0*y - x*y1 + x*y)
                 = x*(y0 - y1) + y*(x1 - x0) + x0*y1 - y0*x1
            dt/dx =  y0 - y1
            dt/dy = -x0 + x1
            df/ds = -t / (s^2 + t^2)
            df/dt =  s / (s^2 + t^2)
            dw/dx = df/ds * ds/dx + df/dt * dt/dx
            dw/dy = df/ds * ds/dy + df/dt * dt/dy
        */
        double dsdx = 2 * p.x() - c0.x() - c1.x();
        double dsdy = 2 * p.y() - c0.y() - c1.y();
        double dtdx =   c0.y() - c1.y();
        double dtdy = - c0.x() + c1.x();
        double a = 1 / (s * s + t * t);
        double dfds = -t * a;
        double dfdt =  s * a;
        double dwdx = dfds * dsdx + dfdt * dtdx;
        double dwdy = dfds * dsdy + dfdt * dtdy;
        result += Vector2d(dwdx, dwdy);
    }
    return result / (2 * util::pi());
}

void core::method_winding::compute_field(
    const vector<Polyline2d>& paths,
    const VectorXi& signs,
    Mesh& mesh)
{
#pragma omp parallel for
    for (int i = 0; i < mesh.n_faces(); ++i) {
        auto f = mesh.face_handle(i);
        Vector2d p = o2e(mesh.util_face_center(f)).head(2);
        mesh.data(f).winding = 0;
        for (int j = 0; j < paths.size(); ++j)
            mesh.data(f).winding += signs[j] * compute_winding(p, paths[j]);
    }
}

MatrixXd core::method_winding::compute_dirichlet_matrix(const vector<Polyline2d>& paths) {
    int num_paths = paths.size();
    MatrixXd Q = MatrixXd::Zero(num_paths, num_paths);
    for (int i = 0; i < num_paths; ++i) {
        for (auto edge : adjacent_pairs(paths[i], paths[i].is_loop)) {
            Vector2d edge_vector = edge.second - edge.first;
            double   edge_length = edge_vector.norm();
            Vector2d edge_midpoint = 0.5 * (edge.first + edge.second);
            
            Vector2d n_i = eigen_util::rotate90(edge_vector).normalized();
            
            Vector2d g_i = compute_gradient(edge_midpoint, paths[i]);
            Q(i, i) += -edge_length * g_i.dot(n_i);
            
            for (int j = 0; j < i; ++j) {
                Vector2d g_j = compute_gradient(edge_midpoint, paths[j]);
                Q(i, j) += -edge_length * g_j.dot(n_i);
                Q(j, i) = Q(i, j);
            }
        }
    }
    return Q;
}
    
double core::method_winding::compute_dirichlet_energy(
    const MatrixXd& Q,
    const VectorXi& signs)
{
    VectorXd signs_double = signs.cast<double>();
    return signs_double.transpose() * Q * signs_double;
}
