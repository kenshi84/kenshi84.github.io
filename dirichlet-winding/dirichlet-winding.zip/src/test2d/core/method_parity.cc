#include "core.hh"
#include <kt84/util.hh>
#include <kt84/openmesh/vector_convert.hh>
#include <kt84/adjacent_pairs.hh>
using namespace std;
using namespace Eigen;
using namespace kt84;

void core::method_parity::compute_field(
    const vector<Polyline2d>& paths,
    Mesh& mesh,
    int samples_per_face)
{
#pragma omp parallel for
    for (int i = 0; i < mesh.n_faces(); ++i) {
        auto f = mesh.face_handle(i);
        double parity_sum = 0;
        for (int j = 0; j < samples_per_face; ++j) {
            // random barycentric coordinate (reference: Generating Random Points in Triangles [Turk, Graphics Gems I 1990])
            double s = util::random_double(0, 1);
            double t = util::random_double(0, 1);
            double sqrt_t = sqrt(t);
            double a = 1 - sqrt_t;
            double b = (1 - s) * sqrt_t;
            double c = s * sqrt_t;
            double theta = util::random_double(0, 2 * util::pi());
            //auto face_points = o2e(mesh.util_face_to_points(f));            // C1001 compiler crash in stupid VS 2013...
            auto face_points = mesh.util_face_to_points(f);
            Vector2d ray_origin    = o2e(a * face_points[0] + b * face_points[1] + c * face_points[2]).head(2);
            Vector2d ray_direction = Vector2d(cos(theta), sin(theta));
            double ray_t;
            int parity = 0;
            for (auto& path : paths)
                for (auto segment : adjacent_pairs(path, path.is_loop))
                    if (is_intersecting(ray_origin, ray_direction, segment.first, segment.second, ray_t)) ++parity;
            parity %= 2;
            parity_sum += parity;
        }
        mesh.data(f).parity = parity_sum / samples_per_face;
    }
}
