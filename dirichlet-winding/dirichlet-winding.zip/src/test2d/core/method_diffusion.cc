#include "core.hh"
#include <Eigen/Sparse>
#include <kt84/eigen_util.hh>
#include <kt84/openmesh/vector_convert.hh>
using namespace std;
using namespace Eigen;
using namespace kt84;

void core::method_diffusion::compute_field(
    const VectorXi& signs,
    Mesh& mesh)
{
    typedef SparseMatrix<double> Matrix;
    typedef Triplet<double> Triplet;
    
    // assign variable index for interior vertices
    int n = 0;
    for (auto v : mesh.vertices()) {
        int& num_path_edges = mesh.data(v).num_path_edges;
        num_path_edges = 0;
        for (auto ve : mesh.ve_range(v))
            if (mesh.data(ve).path_id > -1) ++num_path_edges;
        
        if (num_path_edges == 0)
            mesh.data(v).var_index = n++;
        else if (num_path_edges != 2)
            mesh.data(v).diffusion = 0.5;
    }
    
    // build matrix and right hand side
    vector<Triplet> triplets;
    VectorXd b = VectorXd::Zero(n);
    for (auto v : mesh.vertices()) {
        if (mesh.data(v).num_path_edges != 0) continue;
        
        // diagonal
        double cotanWeight_sum = 0;
        for (auto ve : mesh.ve_range(v))
            cotanWeight_sum += mesh.cotanWeight(ve);
        int i = mesh.data(v).var_index;
        triplets.push_back(Triplet(i, i, -cotanWeight_sum));
        
        // off-diagonal and right hand side
        for (auto voh : mesh.voh_range(v)) {
            double weight = mesh.cotanWeight(mesh.edge_handle(voh));
            
            auto vv = mesh.to_vertex_handle(voh);
            if (mesh.data(vv).num_path_edges == 0) {
                // vv is interior -> set off-diagonal
                int j = mesh.data(vv).var_index;
                triplets.push_back(Triplet(i, j, weight));
            
            } else if (mesh.data(vv).num_path_edges == 2) {
                // vv has two adjacent path edges -> set right hand side if v is inside
                if (is_inside(mesh, signs, voh) == 1)
                    b[i] -= weight;
            
            } else {
                // vv is endpoint or crossing of path edges -> set right hand side to the middle value
                b[i] -= 0.5 * weight;
            }
        }
    }
    Matrix M(n, n);
    M.setFromTriplets(triplets.begin(), triplets.end());
    
    // solve
    SimplicialCholesky<Matrix> solver(M);
    VectorXd x = solver.solve(b);
    
    // copy result
    for (auto v : mesh.vertices()) {
        if (mesh.data(v).var_index == -1) continue;
        mesh.data(v).diffusion = x[mesh.data(v).var_index];
    }
}

int core::method_diffusion::is_inside(
    const Mesh& mesh,
    const Eigen::VectorXi& signs,
    Mesh::HHandle h)
{
    auto v = mesh.to_vertex_handle(h);
    if (mesh.data(v).num_path_edges != 2)
        // to_vertex does not have two adjacent path edges --> side is undefined
        return -1;
    
    bool is_first = true;
    for (auto h2 = h; ; h2 = mesh.opposite_halfedge_handle(mesh.next_halfedge_handle(h2))) {
        auto e = mesh.edge_handle(h2);
        int path_id = mesh.data(e).path_id;
        if (path_id < 0) {
            is_first = false;
            continue;
        }
        
        bool result = mesh.util_halfedge_to_vector(h2).operator|(mesh.data(e).dir) < 0;
        
        if (is_first)             result = !result;
        if (signs[path_id] == -1) result = !result;
        
        return result ? 1 : 0;
    }
}
double core::method_diffusion::compute_dirichlet_energy(
    const Mesh& mesh,
    const Eigen::VectorXi& signs)
{
    double result = 0;
#if 1
    // Integral over domain |
    //----------------------+
    for (auto f : mesh.faces()) {
        Vector2d point[3];
        double   value[3];
        int i = 0;
        for (auto fh : mesh.fh_range(f)) {
            auto v = mesh.to_vertex_handle(fh);
            int which_side = is_inside(mesh, signs, fh);
            point[i] = o2e(mesh.point(v)).head(2);
            value[i] = which_side == -1 ? mesh.data(v).diffusion : which_side;
            ++i;
        }
        Vector2d gradient = eigen_util::compute_gradient(point[0], point[1], point[2], value[0], value[1], value[2]);
        result += mesh.data(f).faceArea * gradient.squaredNorm();
    }
#else
    // Integral over domain boundary |
    //-------------------------------+
    for (auto h : mesh.halfedges()) {
        auto e = mesh.edge_handle(h);
        if (mesh.data(e).path_id < 0) continue;
        
        Mesh::HHandle hh[3] = { mesh.prev_halfedge_handle(h), h, mesh.next_halfedge_handle(h) };
        Vector2d point[3];
        double   value[3];
        for (int i = 0; i < 3; ++i) {
            auto v = mesh.to_vertex_handle(hh[i]);
            int which_side = is_inside(mesh, signs, hh[i]);
            point[i] = o2e(mesh.point(v)).head(2);
            value[i] = which_side == -1 ? mesh.data(v).diffusion : which_side;
        }
        Vector2d gradient = eigen_util::compute_gradient(point[0], point[1], point[2], value[0], value[1], value[2]);
        Vector2d n = -eigen_util::rotate90(point[1] - point[0]).normalized();
        result += mesh.data(e).edgeLength * 0.5 * (value[0] + value[1]) * gradient.dot(n);
    }
#endif
    
    return result;
}
