#include "core.hh"
#include <kt84/triangle_util.hh>
#include <kt84/eigen_util.hh>
#include <kt84/openmesh/debug_writeSVG.hh>
#include <kt84/MinSelector.hh>
using namespace std;
using namespace kt84;
using namespace Eigen;

void core::triangulate(const vector<Polyline2d>& paths, char* switches, double margin_ratio, Mesh& mesh) {
    // prepare input for Triangle |
    //----------------------------+
    triangle_util::Format_poly in_poly;
    int vertex_offset = 0;
    for (int i = 0; i < paths.size(); ++i) {
        auto& path = paths[i];
        // vertices
        for (int j = 0; j < path.size(); ++j) {
            auto& p = path[j];
            in_poly.node.pointlist.push_back(p[0]);
            in_poly.node.pointlist.push_back(p[1]);
        }
        // edges
        // >>========== important notes: http://www.cs.cmu.edu/~quake/triangle.markers.html
        //  The boundary marker associated with each segment in an output .poly file and each edge in an output .edge file is chosen as follows:
        //  
        //  - If an output edge is part or all of a PSLG segment with a nonzero boundary marker, then the edge is assigned the same marker as the segment.
        //  - Otherwise, if the edge occurs on a boundary of the triangulation (including boundaries of holes), then the edge is assigned the marker one (1).
        //  - Otherwise, the edge is assigned the marker zero (0).
        // ==========<<
        for (int j0 = 0; j0 < path.size(); ++j0) {
            if (j0 == path.size() - 1 && !path.is_loop)
                continue;
            int j1 = (j0 + 1) % path.size();
            auto p0 = path[j0];
            auto p1 = path[j1];
            // discretize the edge direction
            Vector2d d = p1 - p0;
            MinSelector<int> dir_id(0);
            dir_id.update(-d.dot(Vector2d( 1,  0)), 0);
            dir_id.update(-d.dot(Vector2d( 0,  1)), 1);
            dir_id.update(-d.dot(Vector2d(-1,  0)), 2);
            dir_id.update(-d.dot(Vector2d( 0, -1)), 3);
            in_poly.segmentlist.push_back(vertex_offset + j0);
            in_poly.segmentlist.push_back(vertex_offset + j1);
            in_poly.segmentmarkerlist.push_back(2 + 4 * i + dir_id.value);
        }
        vertex_offset += path.size();
    }
    // add margin
    AlignedBox2d bbox;
    for (auto& path : paths)
        for (auto& p : path)
            bbox.extend(p);
    eigen_util::bbox_add_margin(bbox, margin_ratio, true);
    Vector2d corners[4] = {
        bbox.corner(AlignedBox2d::BottomLeft),
        bbox.corner(AlignedBox2d::BottomRight),
        bbox.corner(AlignedBox2d::TopLeft),
        bbox.corner(AlignedBox2d::TopRight),
    };
    for (auto& p : corners) {
        in_poly.node.pointlist.push_back(p[0]);
        in_poly.node.pointlist.push_back(p[1]);
    }
    
    // call Triangle |
    //---------------+
    triangle_util::Format_poly out_poly;
    triangle_util::Format_ele  out_ele;
    triangle_util::Format_edge out_edge;
    triangle_util::triangulate(in_poly, out_poly, out_ele, out_edge, switches);
    
    // copy Triangle's output to mesh |
    //--------------------------------+
    // vertices
    int out_n_vertices = out_poly.node.pointlist.size() / 2;
    for (int i = 0; i < out_n_vertices; ++i) {
        auto v = mesh.add_vertex(Mesh::Point(out_poly.node.pointlist[2 * i],
                                             out_poly.node.pointlist[2 * i + 1], 0));
    }
    // copy triangles
    assert(out_ele.numberofcorners == 3);
    int out_n_faces = out_ele.trianglelist.size() / 3;
    for (int i = 0; i < out_n_faces; ++i) {
        auto fv0 = mesh.vertex_handle(out_ele.trianglelist[3 * i    ]);
        auto fv1 = mesh.vertex_handle(out_ele.trianglelist[3 * i + 1]);
        auto fv2 = mesh.vertex_handle(out_ele.trianglelist[3 * i + 2]);
        mesh.add_face(fv0, fv1, fv2);
    }
    // set path_id
    assert(!out_edge.edgelist.empty());
    int out_n_edges = out_edge.edgelist.size() / 2;
    for (int i = 0; i < out_n_edges; ++i) {
        int edgemarker = out_edge.edgemarkerlist[i];
        if (edgemarker < 2) continue;
        
        auto e = mesh.util_edge_handle(mesh.vertex_handle(out_edge.edgelist[2 * i    ]),
                                       mesh.vertex_handle(out_edge.edgelist[2 * i + 1]));
        mesh.data(e).path_id = (edgemarker - 2) / 4;
        int          dir_id  = (edgemarker - 2) % 4;
        mesh.data(e).dir = dir_id == 0 ? OpenMesh::Vec3d( 1, 0, 0) :
                           dir_id == 1 ? OpenMesh::Vec3d( 0, 1, 0) :
                           dir_id == 2 ? OpenMesh::Vec3d(-1, 0, 0) : OpenMesh::Vec3d(0, -1, 0);
    }
#if 0
    mesh.debugInfo_get();
    debug_writeSVG(mesh);
#endif
    mesh.cotanWeight_compute();
}
