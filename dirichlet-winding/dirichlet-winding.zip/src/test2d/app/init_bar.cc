#include "app.hh"
#include <kt84/util.hh>
#include <kt84/tw_util.hh>
#include <kt84/zenity_util.hh>
#include <kt84/openmesh/vector_convert.hh>
using namespace std;
using namespace kt84;
using namespace Eigen;

void app::init_bar() {
    g.bar = TwNewBar("test2d");
    
    tw_util::AddButton(g.bar, "print_usage", [](){
        cout << "\
usage:\n\
mouse drag               - draw new path (press [c] key when finishing to make it closed) \n\
mouse drag with ALT      - camera zoom      \n\
mouse drag with ALT+CTRL - camera pan       \n\
mouse click with SHIFT   - flip selected path sign  \n\
mouse click with [d]     - delete selected path     \n\
";
    }, nullptr);
    
    // file
    tw_util::AddButton(g.bar, "save_xml"  , [](){
        string fname;
        if (zenity_util::file_selection_save(fname, "test2d - save xml", g.xml_filename, "xml files|*.xml"))
            if (!save_xml(fname))
                zenity_util::msgbox(zenity_util::MsgBoxType::Error, "test2d - save xml", "Error occurred!");
    }, "group=file label='save xml' key='CTRL+s'");
    tw_util::AddButton(g.bar, "load_xml"  , [](){
        string fname;
        if (zenity_util::file_selection_load(fname, "test2d - load xml", "", "xml files|*.xml"))
            if (!load_xml(fname))
                zenity_util::msgbox(zenity_util::MsgBoxType::Error, "test2d - load xml", "Error occurred!");
    }, "group=file label='load xml' key='CTRL+o'");
    tw_util::AddButton(g.bar, "import_svg", [](){
        string fname;
        if (zenity_util::file_selection_load(fname, "test2d - import svg", "", "svg files|*.svg"))
            if (!import_svg(fname))
                zenity_util::msgbox(zenity_util::MsgBoxType::Error, "test2d - import svg", "Error occurred!");
    }, "group=file label='import svg' key='CTRL+i'");
    tw_util::AddButton(g.bar, "clear", [](){
        g.paths.clear();
        g.mesh.clear();
        g.signs.resize(0);
        g.Q.resize(0, 0);
    }, nullptr);
    
    // triangulate
    tw_util::AddVarCB_default<double>(g.bar, "set_area", g.cfg.triangulate_area, [](){ call_triangulate(); }, "group=triangulate min=0");
    tw_util::AddButton(g.bar, "halve_area", [&](){
        g.cfg.triangulate_area *= 0.5;
        call_triangulate();
    }, "group=triangulate");
    tw_util::AddButton(g.bar, "double_area", [&](){
        g.cfg.triangulate_area *= 2;
        call_triangulate();
    }, "group=triangulate");
    
    // winding
    tw_util::AddVarCB<bool>(g.bar, "winding_draw", [](const bool&){ g.mode = Globals::Mode::Winding; }, [](bool& value) { value = g.mode == Globals::Mode::Winding; }, "group=winding label=draw");
    TwAddVarRW(g.bar, "winding_auto_update", TW_TYPE_BOOLCPP, &g.cfg.winding.auto_update, "group=winding label=auto_update");
    tw_util::AddButton(g.bar, "winding_compute_field"           , [](){ core::method_winding::compute_field(g.paths, g.signs, g.mesh); }, "group=winding label=compute_field");
    tw_util::AddButton(g.bar, "winding_compute_dirichlet_matrix", [](){ g.Q = core::method_winding::compute_dirichlet_matrix(g.paths); }, "group=winding label=compute_matrix");
    tw_util::AddButton(g.bar, "winding_compute_dirichlet_energy", [](){ cout << "energy: " << core::method_winding::compute_dirichlet_energy(g.Q, g.signs) << endl; }, "group=winding label=compute_energy");
    tw_util::AddButton(g.bar, "winding_find_dirichlet_minimizer", [](){
        auto energy_func = [&](const VectorXi& signs){
            return core::method_winding::compute_dirichlet_energy(g.Q, signs);
        };
        g.signs = core::find_energy_minimizer(g.paths.size(), energy_func);
        update(false);
    }, "group=winding label=find_minimizer");
    
    // diffusion
    tw_util::AddVarCB<bool>(g.bar, "diffusion_draw", [](const bool&){ g.mode = Globals::Mode::Diffusion; }, [](bool& value) { value = g.mode == Globals::Mode::Diffusion; }, "group=diffusion label=draw");
    TwAddVarRW(g.bar, "diffusion_auto_update", TW_TYPE_BOOLCPP, &g.cfg.diffusion.auto_update, "group=diffusion label=auto_update");
    tw_util::AddButton(g.bar, "diffusion_compute_field"           , [](){ core::method_diffusion::compute_field(g.signs, g.mesh); }, "group=diffusion label=compute_field");
    tw_util::AddButton(g.bar, "diffusion_compute_dirichlet_energy", [](){ cout << "energy: " << core::method_diffusion::compute_dirichlet_energy(g.mesh, g.signs) << endl; }, "group=diffusion label=compute_energy");
    tw_util::AddButton(g.bar, "diffusion_find_dirichlet_minimizer", [](){
        auto energy_func = [&](const VectorXi& signs){
            auto mesh_temp = g.mesh;
            core::method_diffusion::compute_field(signs, mesh_temp);
            return core::method_diffusion::compute_dirichlet_energy(mesh_temp, signs);
        };
        g.signs = core::find_energy_minimizer(g.paths.size(), energy_func);
        update(false);
    }, "group=diffusion label=find_minimizer");
    
    // solidity
    tw_util::AddVarCB<bool>(g.bar, "solidity_draw", [](const bool&){ g.mode = Globals::Mode::Solidity; }, [](bool& value) { value = g.mode == Globals::Mode::Solidity; }, "group=solidity label=draw");
    TwAddVarRW(g.bar, "solidity_auto_update", TW_TYPE_BOOLCPP, &g.cfg.solidity.auto_update, "group=solidity label=auto_update");
    tw_util::AddButton(g.bar, "solidity_compute_field"  , [](){ core::method_solidity::compute_field(g.mesh); }, "group=solidity label=compute_field");
    tw_util::AddButton(g.bar, "solidity_determine_signs", [](){
        auto face_scalar_func = [&](OpenMesh::PolyConnectivity::FHandle f){
            return g.mesh.data(f).solidity;
        };
        g.signs = core::determine_signs(g.mesh, g.paths.size(), face_scalar_func);
        update(false);
    }, "group=solidity label=determine_signs");
    
    // parity
    tw_util::AddVarCB<bool>(g.bar, "parity_draw", [](const bool&){ g.mode = Globals::Mode::Parity; }, [](bool& value) { value = g.mode == Globals::Mode::Parity; }, "group=parity label=draw");
    TwAddVarRW(g.bar, "parity_auto_update", TW_TYPE_BOOLCPP, &g.cfg.parity.auto_update, "group=parity label=auto_update");
    TwAddVarRW(g.bar, "samples_per_face"  , TW_TYPE_INT32  , &g.cfg.parity.samples_per_face, "group=parity min=1");
    tw_util::AddButton(g.bar, "parity_compute_field"  , [](){ core::method_parity::compute_field(g.paths, g.mesh, g.cfg.parity.samples_per_face); }, "group=parity label=compute_field");
    tw_util::AddButton(g.bar, "parity_determine_signs", [](){
        auto face_scalar_func = [&](OpenMesh::PolyConnectivity::FHandle f){
            return g.mesh.data(f).parity;
        };
        g.signs = core::determine_signs(g.mesh, g.paths.size(), face_scalar_func);
        update(false);
    }, "group=parity label=determine_signs");
    
    // rayshoot
    TwAddVarRW(g.bar, "rayshoot_mode", TW_TYPE_BOOLCPP, &g.cfg.rayshoot.use_parity, "group=rayshoot label=mode true=parity false=visibility");
    tw_util::AddVarCB_default<int>(g.bar, "rayshoot_determine_signs", g.cfg.rayshoot.samples_total, [](){
        g.signs = core::method_rayshoot::determine_signs(g.paths, g.cfg.rayshoot.samples_total, g.cfg.rayshoot.use_parity);
        update(false);
    }, "group=rayshoot label=determine_signs min=100");
    
    // signs
    tw_util::AddButton(g.bar, "randomize", [](){
        for (auto& sign : eigen_util::range_elements(g.signs))
            sign = 2 * util::random_int(0, 1) - 1;
        update(false);
    }, "group=signs key=r");
    tw_util::AddButton(g.bar, "flip", [](){
        g.signs *= -1;
        update(false);
    }, "group=signs key=f");
    
    // config
    TwAddVarRW(g.bar, "path_sampling_interval", TW_TYPE_DOUBLE, &g.cfg.path_sampling_interval, "group=config min=0.1 step=0.1");
    TwAddVarRW(g.bar, "margin_ratio"          , TW_TYPE_DOUBLE, &g.cfg.margin_ratio          , "group=config min=0   step=0.1");
    
    // draw
    TwAddVarRW(g.bar, "edges"        , TW_TYPE_BOOLCPP, &g.cfg.draw.edges         , "group=draw");
    TwAddVarRW(g.bar, "faces"        , TW_TYPE_BOOLCPP, &g.cfg.draw.faces         , "group=draw");
    TwAddVarRW(g.bar, "grid"         , TW_TYPE_BOOLCPP, &g.cfg.draw.grid          , "group=draw key=g");
    TwAddVarRW(g.bar, "colorbar"     , TW_TYPE_BOOLCPP, &g.cfg.draw.colorbar      , "group=draw");
    tw_util::AddVarCB<double>(g.bar, "colorbar_min",
        [&](const double& value) {
            if (value >= g.cfg.draw.colorbar_max) return;
            g.cfg.draw.colorbar_min = value;
        },
        [&](double& value) {
            value = g.cfg.draw.colorbar_min;
        }, "group=draw step=0.1");
    tw_util::AddVarCB<double>(g.bar, "colorbar_max",
        [&](const double& value) {
            if (value <= g.cfg.draw.colorbar_min) return;
            g.cfg.draw.colorbar_max = value;
        },
        [&](double& value) {
            value = g.cfg.draw.colorbar_max;
        }, "group=draw step=0.1");
    TwAddVarRW(g.bar, "num_intervals", TW_TYPE_INT32  , &g.cfg.draw.num_intervals , "group=draw min=2 max=255");
    TwAddVarRW(g.bar, "arrow_scale"  , TW_TYPE_DOUBLE , &g.cfg.draw.arrow_scale   , "group=draw min=0 max=5 step=0.1");
}
