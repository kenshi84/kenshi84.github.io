#pragma once
#include <cstdlib>
#include <GL/glew.h>
#include <utility>
#include <string>
#include "Globals.hh"

namespace app {

// GLUT callback
void glutcb_display_pre();
void glutcb_display_main();
void glutcb_display_post();
void glutcb_reshape(int width, int height);
void glutcb_keyboard_down(unsigned char key, int x, int y);
void glutcb_keyboard_up(unsigned char key, int x, int y);
void glutcb_special(int key, int x, int y);
void glutcb_mouse(int glut_button, int state, int x, int y);
void glutcb_motion(int x, int y);

// file io
bool save_xml(      std::string  fname);
bool load_xml(const std::string& fname);
bool import_svg(const std::string& fname);

// init
void init_globals();
void init_gl();
void init_bar();

// call core::triangulate with appropriate args
void call_triangulate();

void update(bool is_mesh_changed);

}
