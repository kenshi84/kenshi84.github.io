#include "app.hh"
#include <kt84/glut_util.hh>
using namespace std;

namespace app { Globals g; }

int main(int argc, char* argv[]) {
    kt84::glut_util::init(
        argc, argv, 
        GLUT_DOUBLE | GLUT_RGBA | GLUT_DEPTH | GLUT_STENCIL,
        0.8, true, "test2d",
        app::glutcb_display_pre,
        app::glutcb_display_main,
        app::glutcb_display_post,
        app::glutcb_reshape,
        app::glutcb_keyboard_down,
        app::glutcb_keyboard_up,
        app::glutcb_special,
        app::glutcb_mouse,
        app::glutcb_motion,
        app::glutcb_motion);
    
    // GLEW
    glewInit();
    
    // AntTweakBar
    TwInit(TW_OPENGL, NULL);
    TwGLUTModifiersFunc([](){ return glutGetModifiers(); });
    
    // init
    app::init_globals();
    app::init_bar();
    app::init_gl();
    
    // process command line argument
    if (argc == 2) {
        string fname = argv[1];
        auto fname_ext = fname.substr(fname.size() - 4, 4);
        if (fname_ext == ".xml" || fname_ext == ".XML")
            app::load_xml(fname);
        else if (fname_ext == ".svg" || fname_ext == ".SVG")
            app::import_svg(fname);
    }
    
    glutMainLoop();
}
