#include "app.hh"
#include <tinyxml2.h>
#define NANOSVG_IMPLEMENTATION
#include <nanosvg.h>
#include <kt84/eigen_util.hh>
using namespace std;
using namespace Eigen;
using namespace kt84;

bool app::save_xml(string fname) {
    tinyxml2::XMLDocument xml_doc;
    
    auto xml_root = xml_doc.InsertEndChild(xml_doc.NewElement("test2d"))->ToElement();
    if (!xml_root) return false;
    
    for (int i = 0; i < g.paths.size(); ++i) {
        auto& path = g.paths[i];
        auto xml_path = xml_root->InsertEndChild(xml_doc.NewElement("path"))->ToElement();
        xml_path->SetAttribute("num_points", path.size());
        xml_path->SetAttribute("is_loop", path.is_loop ? 1 : 0);
        xml_path->SetAttribute("sign"      , g.signs[i]);
        
        stringstream ss_path;
        for (auto& point : path)
            ss_path << point.x() << " " << point.y() << endl;
        xml_path->InsertEndChild(xml_doc.NewText(ss_path.str().c_str()));
    }
    
    // add file extension if needed
    string fname_ext = fname.substr(fname.size() - 4, 4);
    if (fname_ext != ".xml" && fname_ext != ".XML")
        fname += ".xml";
    if (xml_doc.SaveFile(fname.c_str())) return false;
    
    g.xml_filename = fname;
    
    return true;
}
bool app::load_xml(const string& fname) {
    tinyxml2::XMLDocument xml_doc;
    if (xml_doc.LoadFile(fname.c_str()))
        return false;
    
    auto xml_root = xml_doc.FirstChildElement("test2d");
    if (!xml_root)
        return false;
    
    g.paths.clear();
    g.signs.resize(0);
    for (auto xml_path = xml_root->FirstChildElement("path"); xml_path; xml_path = xml_path->NextSiblingElement("path")) {
        int num_points = xml_path->IntAttribute("num_points");
        int is_loop    = xml_path->IntAttribute("is_loop"   );
        int sign       = xml_path->IntAttribute("sign"      );

        Polyline2d path(num_points, is_loop != 0);
        
        stringstream ss_path;
        ss_path.str(xml_path->GetText());
        for (int i = 0; i < num_points; ++i)
            ss_path >> path.points[i][0] >> path.points[i][1];
        
        g.paths.push_back(path);
        eigen_util::push_back(g.signs, sign);
    }
    
    g.xml_filename = fname;
    
    if (g.cfg.winding.auto_update) g.Q = core::method_winding::compute_dirichlet_matrix(g.paths);
    call_triangulate();
    
    return true;
}
bool app::import_svg(const string& fname) {
    auto svg_image = nsvgParseFromFile(fname.c_str(), "px", 96);
    if (!svg_image)
        return false;
    
    g.paths.clear();
    for (auto svg_shape = svg_image->shapes; svg_shape; svg_shape = svg_shape->next) {
        for (auto svg_path = svg_shape->paths; svg_path; svg_path = svg_path->next) {
            Polyline2d path;
            for (int i = 0; i < svg_path->npts; ++i)
                path.points.push_back(Vector2d(svg_path->pts[2 * i], -svg_path->pts[2 * i + 1]));

            path.is_loop = svg_path->closed != 0;

            g.paths.push_back(path);
        }
    }
    
    nsvgDelete(svg_image);
    
    // adjust the scaling
    AlignedBox2d bbox;
    for (auto& path : g.paths) for (auto& point : path) bbox.extend(point);
    for (auto& path : g.paths) for (auto& point : path) {
        point -= bbox.center();
        point *= 20.0 / bbox.diagonal().norm();
    }
    
    // resampling
    for (auto& path : g.paths)
        path.resample_by_length(g.cfg.path_sampling_interval);
    
    g.xml_filename.clear();
    
    if (g.cfg.winding.auto_update) g.Q = core::method_winding::compute_dirichlet_matrix(g.paths);
    call_triangulate();
    
    return true;
}
