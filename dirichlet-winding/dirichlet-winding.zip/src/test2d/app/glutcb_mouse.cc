#include "app.hh"
#include <kt84/eigen_util.hh>
#include <kt84/glut_util.hh>
#include <kt84/container_util.hh>
#include <kt84/MinSelector.hh>
#include <kt84/graphics/graphics_util.hh>
#include <kt84/adjacent_pairs.hh>
#include <kt84/ScopeExit.hh>
using namespace Eigen;
using namespace kt84;
using namespace app;

Vector2d get_mouse_pos_world() {
    Vector3d world_xyz = graphics_util::unproject(Vector3d(g.mouse_pos_screen.x(), g.mouse_pos_screen.y(), 0));
    return g.camera.center.head(2) + (world_xyz - g.camera.center).head(2) * g.camera.eye.z() / (g.camera.eye.z() - world_xyz.z());
}
Vector2i nearest_integer_grid(const Vector2d& p) {
    double ix = floor(p.x());
    double iy = floor(p.y());
    if (p.x() - ix > 0.5) ++ix;
    if (p.y() - iy > 0.5) ++iy;
    return Vector2i(ix, iy);
}
void add_current_path() {
    g.paths.push_back(g.path_being_drawn);
    g.path_being_drawn.clear();
    eigen_util::push_back(g.signs, 1);
    if (g.cfg.winding.auto_update) g.Q = core::method_winding::compute_dirichlet_matrix(g.paths);
    call_triangulate();
}

void mouse_down(bool shift_pressed, bool ctrl_pressed, bool alt_pressed) {
    g.is_mouse_down = true;
    
    if (alt_pressed) {
        g.camera.mouse_down(g.mouse_pos_screen.x(), g.mouse_pos_screen.y(), ctrl_pressed ? Camera::DragMode::PAN : Camera::DragMode::ZOOM);
        return;
    }
    
    auto p = get_mouse_pos_world();
    
    if (!g.paths.empty() && (shift_pressed || g.is_key_down['d'])) {
        // select the closest path
        MinSelector<int> selected_path_id(-1);
        for (int i = 0; i < g.paths.size(); ++i) {
            auto& path = g.paths[i];
            for (auto edge : adjacent_pairs(path, path.is_loop)) {
                auto p0 = edge.first;
                auto p1 = edge.second;
                auto dist = eigen_util::distance_to_line(p0, p1, p, true);
                if (dist)
                    selected_path_id.update(*dist, i);
            }
        }
        
        if (shift_pressed) {
            // flip sign of selected path
            g.signs[selected_path_id.value] *= -1;
            update(false);
            
        } else {
            // delete selected path
            container_util::erase_at(g.paths, selected_path_id.value);
            eigen_util    ::erase_at(g.signs, selected_path_id.value);
            if (g.cfg.winding.auto_update) g.Q = core::method_winding::compute_dirichlet_matrix(g.paths);
            call_triangulate();
        }
        return;
    }
    if (g.cfg.draw.grid) {
        // snap-to-grid mode
        p = nearest_integer_grid(p).cast<double>();
        if (g.path_being_drawn.empty()) {
            // start new path
            g.path_being_drawn.push_back(p);
            g.path_being_drawn.push_back(p);
        } else if (g.path_being_drawn.front() == p) {
            // clicked point is current path's first point
            if (g.path_being_drawn.size() >= 4) {
                // add current path as closed
                g.path_being_drawn.pop_back();
                g.path_being_drawn.is_loop = true;
                add_current_path();
            }
        } else if (g.path_being_drawn[g.path_being_drawn.size() - 2] == p) {
            // clicked point is current path's last point
            if (g.path_being_drawn.size() >= 3) {
                // add current path as open
                g.path_being_drawn.pop_back();
                add_current_path();
            }
        } else {
            // add point to current path
            g.path_being_drawn.push_back(p);
        }
        return;
    }
    // normal drawing mode
    g.path_being_drawn.push_back(p);
}
void mouse_up  (bool shift_pressed, bool ctrl_pressed, bool alt_pressed) {
    g.is_mouse_down = false;
    
    if (g.camera.drag_mode != Camera::DragMode::NONE) {
        // camera control
        g.camera.mouse_up();
        return;
    }
    
    if (g.cfg.draw.grid) return;
    
    if (!g.path_being_drawn.empty()) {
        // resampling considering loop
        g.path_being_drawn.is_loop = g.is_key_down['c'];
        g.path_being_drawn.resample_by_length(g.cfg.path_sampling_interval);
        
        add_current_path();
    }
}

void app::glutcb_mouse(int glut_button, int state, int x, int y) {
    auto exit_func = make_ScopeExit([](){ glutPostRedisplay(); });
    if (TwEventMouseButtonGLUT(glut_button, state, x, y)) return;
    
    bool shift_pressed = (glutGetModifiers() & GLUT_ACTIVE_SHIFT) != 0;
    bool ctrl_pressed  = (glutGetModifiers() & GLUT_ACTIVE_CTRL ) != 0;
    bool alt_pressed   = (glutGetModifiers() & GLUT_ACTIVE_ALT  ) != 0;
    
    (state == GLUT_DOWN ? mouse_down : mouse_up)(shift_pressed, ctrl_pressed, alt_pressed);
    
    glutPostRedisplay();
}
void app::glutcb_motion(int x, int y) {
    if (TwEventMouseMotionGLUT(x, y)) {
        glutPostRedisplay();
        return;
    }
    
    y = g.camera.height - y;
    g.mouse_pos_screen << x, y;
    
    if (g.camera.drag_mode != Camera::DragMode::NONE) {
        g.camera.mouse_move(x, y);
        glutPostRedisplay();
        return;
    }
    
    auto p = get_mouse_pos_world();
    
    if (!g.path_being_drawn.empty()) {
        // drawing freeform path
        if (g.cfg.draw.grid) {
            p = nearest_integer_grid(p).cast<double>();     // snapped to integer grid point
            g.path_being_drawn.back() = p;
        } else {
            g.path_being_drawn.push_back(p);
        }
        glutPostRedisplay();
    }
}
