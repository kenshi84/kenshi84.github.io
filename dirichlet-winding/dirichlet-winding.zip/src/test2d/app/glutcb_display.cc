#include "app.hh"
#include <iomanip>
#include <kt84/graphics/graphics_util.hh>
#include <kt84/graphics/DisplayList.hh>
#include <kt84/eigen_util.hh>
#include <kt84/glut_util.hh>
#include <kt84/openmesh/vector_convert.hh>
#include <kt84/adjacent_pairs.hh>
using namespace std;
using namespace Eigen;
using namespace kt84;
using namespace kt84::graphics_util;
using namespace app;

void app::glutcb_display_pre() {
    // set window title
    string window_title = "test2d";
    if (!g.xml_filename.empty())
        window_title += string(" (") + g.xml_filename + ")";
    glutSetWindowTitle(window_title.c_str());
    
    glPushAttrib(GL_ALL_ATTRIB_BITS);
    
    glClear (GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);
    
    // set projection matrix
    double zNear = g.camera.eye.z() * 0.1;
    double zFar  = zNear * 100;
    double aspect_ratio = g.camera.width / static_cast<double>(g.camera.height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(40, aspect_ratio, zNear, zFar);
    
    // set modelview matrix
    auto eye    = g.camera.eye;
    auto center = g.camera.center;
    auto up     = g.camera.up;
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    kt84::graphics_util::gluLookAt(eye, center, up);
}
void app::glutcb_display_main() {
    // Alec: Hack to get define to work
    static int once = 0;
    once ? 1 : TwDefine("test2d fontsize=3 size='300 1000' color='153 204 51' alpha=200 text=dark"), ++once;
    
    // mesh faces
    if (g.cfg.draw.faces) {
        glBegin(GL_TRIANGLES);
        for (auto f : g.mesh.faces()) {
            auto set_color = [](double scalar_value) {
                double t = (scalar_value - g.cfg.draw.colorbar_min) / (g.cfg.draw.colorbar_max - g.cfg.draw.colorbar_min);
                t = floor(t * g.cfg.draw.num_intervals) / (g.cfg.draw.num_intervals - 1.0);
                glColor3d(eigen_util::heat_color(t));
            };
            
            if (g.mode == Globals::Mode::Diffusion) {   // per-vertex color
                for (auto fh : g.mesh.fh_range(f)) {
                    int side = core::method_diffusion::is_inside(g.mesh, g.signs, fh);
                    auto v = g.mesh.to_vertex_handle(fh);
                    set_color(side == -1 ? g.mesh.data(v).diffusion : side);
                    glVertex3d(o2e(g.mesh.point(v)));
                }
            
            } else {    // per-face color
                auto& fdata = g.mesh.data(f);
                set_color(g.mode == Globals::Mode::Winding  ? fdata.winding :
                          g.mode == Globals::Mode::Solidity ? fdata.solidity : fdata.parity);
                for (auto fv : g.mesh.fv_range(f))
                    glVertex3d(o2e(g.mesh.point(fv)));
            }
        }
        glEnd();
    }
    
    // mesh edges
    if (g.cfg.draw.edges) {
        glLineWidth(1.5);
        glColor4d(0, 0, 0, 0.5);
        glBegin(GL_LINES);
        for (auto e : g.mesh.edges()) {
            auto p = g.mesh.util_edge_to_point_pair(e);
            glVertex3d(o2e(p.first ));
            glVertex3d(o2e(p.second));
        }
        glEnd();
    }

    // draw grid lines
    if (g.cfg.draw.grid) {
        static DisplayList disp_grid;
        disp_grid.render([](){
            const int num_grid_lines = 1000;
            glLineWidth(1);
            glColor4d(0, 0, 0, 0.2);
            glBegin(GL_LINES);
            for (int i = -num_grid_lines; i <= num_grid_lines; ++i) {
                glVertex2d(i, -num_grid_lines);
                glVertex2d(i,  num_grid_lines);
                glVertex2d(-num_grid_lines, i);
                glVertex2d( num_grid_lines, i);
            }
            glEnd();
        });
    }
    
    // draw paths
    for (auto& path : g.paths) {
        // outline
        glLineWidth(10);
        glColor3d(0, 0, 0);
        glBegin(GL_LINES);
        for (auto p : adjacent_pairs(path, path.is_loop)) {
            glVertex2d(p.first);
            glVertex2d(p.second);
        }
        glEnd();
        
        // inner core
        glLineWidth(5);
        glColor3d(1, 1, 1);
        glBegin(GL_LINES);
        for (auto p : adjacent_pairs(path, path.is_loop)) {
            glVertex2d(p.first);
            glVertex2d(p.second);
        }
        glEnd();
        
        // points
        glPointSize(3);
        glColor3d(0, 0, 0);
        glBegin(GL_POINTS);
        for (auto& p : path)
            glVertex2d(p);
        glEnd();
    }
    
    // draw currently drawn path
    if (!g.path_being_drawn.empty()) {
        // outline
        glLineWidth(10);
        glColor3d(0, 0, 0);
        glBegin(GL_LINES);
        for (auto p : adjacent_pairs(g.path_being_drawn, g.is_key_down['c'])) {
            glVertex2d(p.first);
            glVertex2d(p.second);
        }
        glEnd();
        
        // inner core
        glLineWidth(5);
        glColor3d(0.5, 0.5, 0.5);
        glBegin(GL_LINES);
        for (auto p : adjacent_pairs(g.path_being_drawn, g.is_key_down['c'])) {
            glVertex2d(p.first);
            glVertex2d(p.second);
        }
        glEnd();
    }
    
    // draw small arrow at the middle of each path
    for (int i = 0; i < g.paths.size(); ++i) {
        auto& path = g.paths[i];
        Vector2d p = path.point_at(0.5);
        Vector2d d = (g.signs[i] == 1 ? 1 : -1) * (path.point_at(0.51) - p);
        glPushMatrix();
        glTranslated(p.x(), p.y(), 0);
        glRotated(atan2(d.y(), d.x()) * 360 / (2 * util::pi()), 0, 0, 1);
        glScaled(g.camera.eye.z() * 0.015 * g.cfg.draw.arrow_scale);
        
        // outline
        glColor3d(0, 0, 0);
        glBegin(GL_TRIANGLES);  // tip
        glVertex2d(0,  1);
        glVertex2d(0, -1);
        glVertex2d(2,  0);
        glEnd();
        glBegin(GL_QUADS);      // bar
        glVertex2d(-2, -0.5);
        glVertex2d( 0, -0.5);
        glVertex2d( 0,  0.5);
        glVertex2d(-2,  0.5);
        glEnd();
        
        // inner core
        glColor3d(1, 1, 0);
        glBegin(GL_TRIANGLES);  // tip
        glVertex2d(0.2,  0.7);
        glVertex2d(0.2, -0.7);
        glVertex2d(1.6,    0);
        glEnd();
        glBegin(GL_QUADS);      // bar
        glVertex2d(-1.8, -0.3);
        glVertex2d( 0.2, -0.3);
        glVertex2d( 0.2,  0.3);
        glVertex2d(-1.8,  0.3);
        glEnd();
        
        glPopMatrix();
    }

    // draw colorbar
    if (g.cfg.draw.colorbar) {
        // projection/modelview matrices
        glMatrixMode(GL_PROJECTION);    glPushMatrix();     glLoadIdentity();   gluOrtho2D(0, g.camera.width, 0, g.camera.height);
        glMatrixMode(GL_MODELVIEW );    glPushMatrix();     glLoadIdentity();
        glTranslated(g.camera.width - 100, g.camera.height / 2, 0);
        
        // bar width & margin around
        int rx = 20;
        int ry = g.camera.height / 3;
        
        // black borderline
        glBegin(GL_QUADS);
        glColor3d(0, 0, 0);
        glVertex2d(-rx - 2, -ry - 2);
        glVertex2d( rx + 2, -ry - 2);
        glVertex2d( rx + 2,  ry + 2);
        glVertex2d(-rx - 2,  ry + 2);
        // color bar
        glColor3d(0, 0, 1);     glVertex2d(-rx, -ry    );     glVertex2d( rx, -ry    );     // blue to cyan
        glColor3d(0, 1, 1);     glVertex2d( rx, -ry / 2);     glVertex2d(-rx, -ry / 2);
        glColor3d(0, 1, 1);     glVertex2d(-rx, -ry / 2);     glVertex2d( rx, -ry / 2);     // cyan to green
        glColor3d(0, 1, 0);     glVertex2d( rx,  0     );     glVertex2d(-rx,  0     );
        glColor3d(0, 1, 0);     glVertex2d(-rx,  0     );     glVertex2d( rx,  0     );     // green to yellow
        glColor3d(1, 1, 0);     glVertex2d( rx,  ry / 2);     glVertex2d(-rx,  ry / 2);
        glColor3d(1, 1, 0);     glVertex2d(-rx,  ry / 2);     glVertex2d( rx,  ry / 2);     // yellow to red
        glColor3d(1, 0, 0);     glVertex2d( rx,  ry    );     glVertex2d(-rx,  ry    );
        glEnd();
        
        // bar scale
        glColor3d(0, 0, 0);
        glLineWidth(2);
        double colorbar_mid = 0.5 * (g.cfg.draw.colorbar_min + g.cfg.draw.colorbar_max);
        const int num_div = 10;
        const double step = 1.0 / num_div;
        for (double t = ceil(g.cfg.draw.colorbar_min * num_div) / num_div; t < g.cfg.draw.colorbar_max; t += step) {
            if (abs(t) < 0.000000001) t = 0;
            double d = (t - colorbar_mid) * ry / (g.cfg.draw.colorbar_max - colorbar_mid);
            // little ticks
            glBegin(GL_LINES);
            glVertex2d( rx / 2, d);     glVertex2d( rx, d);
            glVertex2d(-rx / 2, d);     glVertex2d(-rx, d);
            glEnd();
            // little text
            stringstream ss;
            ss << std::right << std::setw(4) << t;
            glRasterPos2i(rx + 5, d);
            for (char c : ss.str())
                glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, c);
        }
        
        glMatrixMode(GL_PROJECTION);    glPopMatrix();
        glMatrixMode(GL_MODELVIEW );    glPopMatrix();
    }
}
void app::glutcb_display_post() {
    glPopAttrib();
    TwDraw();
    glutSwapBuffers();
    glutReportErrors();
}
