#include "app.hh"
#include <kt84/glut_util.hh>

void app::glutcb_keyboard_down(unsigned char key, int x, int y) {
    if (TwEventKeyboardGLUT(key, x, y))
        glutPostRedisplay();
    else
        g.is_key_down[key] = true;
}
void app::glutcb_keyboard_up(unsigned char key, int x, int y) {
    g.is_key_down[key] = false;
}
void app::glutcb_special(int key, int x, int y) {
    if (TwEventSpecialGLUT(key, x, y)) glutPostRedisplay();
}
