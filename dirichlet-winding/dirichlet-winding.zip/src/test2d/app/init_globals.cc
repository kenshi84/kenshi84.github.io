#include "app.hh"

void app::init_globals() {
    g.mode = Globals::Mode::Winding;
    g.camera.eye << 0, 0, 50;
    
    g.is_mouse_down = false;
    for (auto& b : g.is_key_down)
        b = false;
    
    // cfg
    g.cfg.path_sampling_interval = 0.5;
    g.cfg.margin_ratio = 0.5;
    g.cfg.triangulate_area = 0;
    
    // method-specific config
    g.cfg.winding.auto_update = true;
    
    g.cfg.diffusion.auto_update = true;
    
    g.cfg.solidity.auto_update = true;
    
    g.cfg.parity.samples_per_face = 10;
    g.cfg.parity.auto_update = false;
    
    g.cfg.rayshoot.samples_total = 10000;
    g.cfg.rayshoot.use_parity = true;
    
    // cfg.draw
    g.cfg.draw.faces = true;
    g.cfg.draw.edges = true;
    g.cfg.draw.grid = false;
    g.cfg.draw.num_intervals = 64;
    g.cfg.draw.colorbar = true;
    g.cfg.draw.colorbar_min = 0;
    g.cfg.draw.colorbar_max = 1;
    g.cfg.draw.arrow_scale = 1;
}
