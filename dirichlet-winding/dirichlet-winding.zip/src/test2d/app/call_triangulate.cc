#include "app.hh"
#include <kt84/util.hh>
#include <kt84/MinSelector.hh>
using namespace std;
using namespace kt84;

void app::call_triangulate() {
    g.mesh.clear();
    if (g.paths.empty()) return;
    
    string switches = "ezcpq32";
    if (g.cfg.triangulate_area != 0) {
        switches += "a";
        util::append_str(switches, g.cfg.triangulate_area);
    }
    core::triangulate(g.paths, const_cast<char*>(switches.c_str()), g.cfg.margin_ratio, g.mesh);
    
    // get max face area
    MinSelector<int> max_face_area;
    for (auto f : g.mesh.faces())
        max_face_area.update(-g.mesh.data(f).faceArea, 0);
    cout << "Maximum face area: " << (g.cfg.triangulate_area = -max_face_area.score) << endl;
    
    update(true);
}
