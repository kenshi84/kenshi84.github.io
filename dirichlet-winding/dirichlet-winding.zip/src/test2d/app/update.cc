#include "app.hh"
using namespace std;

void app::update(bool is_mesh_changed) {
    if (is_mesh_changed) {
        if (g.cfg.solidity.auto_update) core::method_solidity::compute_field(g.mesh);
        if (g.cfg.parity  .auto_update) core::method_parity  ::compute_field(g.paths, g.mesh, g.cfg.parity.samples_per_face);
    }
    if (g.cfg.winding.auto_update) {
        core::method_winding::compute_field(g.paths, g.signs, g.mesh);
        if (g.mode == Globals::Mode::Winding)
            cout << "energy: " << core::method_winding::compute_dirichlet_energy(g.Q, g.signs) << endl;
    }
    if (g.cfg.diffusion.auto_update) {
        core::method_diffusion::compute_field(g.signs, g.mesh);
        if (g.mode == Globals::Mode::Diffusion)
            cout << "energy: " << core::method_diffusion::compute_dirichlet_energy(g.mesh, g.signs) << endl;
    }
}
