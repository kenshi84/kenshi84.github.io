#pragma once
#include <AntTweakBar.h>
#include <kt84/geometry/CameraFree.hh>
#include "../core/core.hh"

namespace app {

struct Globals {
    std::vector<kt84::Polyline2d> paths;
    Eigen::VectorXi signs;
    core::Mesh mesh;
    Eigen::MatrixXd Q;          // matrix in the quadratic form of Dirichlet energy for winding number
    
    TwBar* bar;
    
    enum struct Mode {
        Winding,
        Diffusion,
        Solidity,
        Parity,
    } mode;
    
    kt84::CameraFree camera;
    std::string xml_filename;
    
    bool is_key_down[256];
    
    bool is_mouse_down;
    kt84::Polyline2d path_being_drawn;
    Eigen::Vector2i mouse_pos_screen;
    
    // config
    struct {
        double path_sampling_interval;                // length of each line segment in the path
        double margin_ratio;
        double triangulate_area;            // maximal area constraint for triangulation
        // method-specific config
        struct {
            bool auto_update;
        } winding;
        struct {
            bool auto_update;
        } diffusion;
        struct {
            bool auto_update;
        } solidity;
        struct {
            bool auto_update;
            int samples_per_face;
        } parity;
        struct {
            bool use_parity;
            int samples_total;
        } rayshoot;
        // draw
        struct {
            bool faces;
            bool edges;
            bool grid;
            int num_intervals;
            bool colorbar;
            double colorbar_max;
            double colorbar_min;
            double arrow_scale;
        } draw;
    } cfg;
};

extern Globals g;

}
