#include "app.hh"

void app::glutcb_reshape(int width, int height) {
    glViewport(0, 0, width, height);
    g.camera.reshape(width, height);
    TwWindowSize(width, height);
}
